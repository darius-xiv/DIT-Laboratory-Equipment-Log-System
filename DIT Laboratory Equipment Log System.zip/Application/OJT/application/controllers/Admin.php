<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    
	public function __construct(){
		parent::__construct();

		$this->load->model('LoginModel');
		$this->load->model('UserModel');
		$this->load->model('AdminModel');

    	if (($this->session->userdata('active_status')) == 1 ) {

			$user_class = new UserModel;
			$user_id = $this->session->userdata('user_id');

			foreach ($user_class->fetchUserProfile($user_id) as $row) {
				$this->session->set_userdata('is_admin', $row->is_admin);
				$this->session->set_userdata('is_active', $row->is_active);
				$this->session->set_userdata('username', $row->username);
				$this->session->set_userdata('student_id', $row->student_id);
				$this->session->set_userdata('password', $row->password);
				$this->session->set_userdata('email_add', $row->email_add);
				$this->session->set_userdata('contact_no', $row->contact_no);
				$this->session->set_userdata('date_created', $row->date_created);
				$this->session->set_userdata('date_updated', $row->date_updated);
			}
		}

		else {
			redirect(base_url('login'), 'refresh');
		}
	}

	public function index()
	{
		if (($this->session->userdata('is_admin')) == 1 ){
			$data['title'] = "Administration";
			$this->load->view('templates/header.php', $data);
			$this->load->view('admin/index.php');
        	$this->load->view('templates/footer.php');
			$this->load->view('templates/modal.php');
		}
		else {
			redirect(base_url(''));
		}
	}

	// LISTS

	public function userList()
	{
		$this->load->view('admin/users_list.php');
	}

	public function itemList()
	{
		$this->load->view('admin/items_list.php');
	}

	public function logList()
	{
		$this->load->view('admin/logs_list.php');
	}

	public function pendingUserList()
	{
		$this->load->view('admin/pending_users_list.php');
	}

	public function borrowList()
	{
		$this->load->view('admin/borrowing_list.php');
	}

	// MODALS

	public function addUser()
	{
		$this->load->view('admin/modals/add_users.php');
	}

	public function addItem()
	{
		$this->load->view('admin/modals/add_items.php');
	}

	public function editUser()
	{
		$data = array();
		$post_user_id = $this->input->post('user_id');

		$admin_class = new AdminModel;

		foreach ($admin_class->getProfileUser($post_user_id) as $row) {
			$data['user_id'] = $row->user_id;
			$data['username'] = $row->username;
			$data['student_id'] = $row->student_id;
			$data['first_name'] = $row->first_name;
			$data['last_name'] = $row->last_name;
			$data['email_add'] = $row->email_add;
			$data['contact_no'] = $row->contact_no;
		}
		$this->load->view('admin/modals/edit_profile.php', $data);
	}

	public function editItem()
	{
		$data = array();
		$post_item_id = $this->input->post('item_id');

		$admin_class = new AdminModel;

		foreach ($admin_class->getProfileItem($post_item_id) as $row) {
			$data['item_id'] = $row->item_id;
			$data['item_name'] = $row->item_name;
			$data['item_desc'] = $row->item_desc;
			$data['item_qty'] = $row->item_qty;
			$data['is_available'] = $row->is_available;
			$data['date_created'] = $row->date_created;
		}
		$this->load->view('admin/modals/edit_item.php', $data);
	}

	public function changeStatus()
	{
		$data = array();
		$post_user_id = $this->input->post('user_id');

		$admin_class = new AdminModel;

		foreach ($admin_class->getIsActiveSpecifiedUser($post_user_id) as $row) {
			$data['user_id'] = $row->user_id;
			$data['is_active'] = $row->is_active;
		}

		$this->load->view('admin/modals/change_status.php', $data);
	}

	public function approvalUser()
	{
		$data = array();
		$post_user_id = $this->input->post('user_id');

		$admin_class = new AdminModel;

		foreach ($admin_class->getIsActiveSpecifiedUser($post_user_id) as $row) {
			$data['user_id'] = $row->user_id;
		}

		$this->load->view('admin/modals/make_active_status.php', $data);
	}

	public function getUserList(){

		$data = array();

		$admin_class = new AdminModel;

			foreach ($admin_class->getAllUsers() as $row) {
			
			$full_name = $row->first_name . " " . $row->last_name;
			if ($row->is_active == 1) {
				$is_active_status = "Yes"; 
			}
			else {
				$is_active_status = "No";
			}
			array_push($data,array
				(
					'user_id' => $row->user_id,
					'is_active' => $row->is_active,
					'is_active_status' => $is_active_status,
					'username' => $row->username,
					'student_id' => $row->student_id,
					'full_name' => $full_name,
					'email_add' => $row->email_add,
					'contact_no' => $row->contact_no,
					'date_created' => $row->date_created,
					'date_updated' => $row->date_updated
				)
			);
		}

		$this->data['finalData'] = $data;
		$this->data['status'] = 'success';
		echo json_encode($this->data);

	}
	
	public function getItemList(){

		$data = array();

		$admin_class = new AdminModel;

			foreach ($admin_class->getAllItems() as $row) {

			array_push($data,array
				(
					'item_id' => $row->item_id,
					'item_name' => $row->item_name,
					'item_desc' => $row->item_desc,
					'item_qty' => $row->item_qty,
					'is_available' => $row->is_available,
					'date_created' => $row->date_created
				)
			);
		}

		$this->data['finalData'] = $data;
		$this->data['status'] = 'success';
		echo json_encode($this->data);

	}

	public function getLogList(){

		$data = array();

		$admin_class = new AdminModel;

			foreach ($admin_class->getAllLogs() as $row) {
		

			array_push($data,array
				(
					'log_id' => $row->log_id,
					'user_id' => $row->user_id,
					'student_id' => $row->student_id,
					'description' => $row->description,
					'log_date' => $row->date_created
				)
			);
		}

		$this->data['finalData'] = $data;
		$this->data['status'] = 'success';
		echo json_encode($this->data);

	}

	public function getPendingUserList(){

		$data = array();

		$admin_class = new AdminModel;

		foreach ($admin_class->getAllPendingUsers() as $row) {
		
			array_push($data,array
				(
					'user_id' => $row->user_id,
					'student_id' => $row->student_id,
					'email_add' => $row->email_add,
					'date_updated' => $row->date_updated
				)
			);
		}

		$this->data['finalData'] = $data;
		$this->data['status'] = 'success';
		echo json_encode($this->data);
	}

	public function changeStatusScript(){

		$post_user_id = $this->input->post('user_id');
		$post_is_active = $this->input->post('is_active');

		if (!empty($post_user_id)){

			if ($post_is_active != 1) {
				$change_value_status = 1;
			}
			else {
				$change_value_status = 0;
				
			}
			$admin_class = new AdminModel;

			$description = "has change a status of a user";

			$admin_class->updateIsStatusUser($post_user_id, $change_value_status);
			$admin_class->insertLogs($description);
			

			$data = array();
			$this->data['is_active'] = $post_is_active;
			$this->data['user_id'] = $post_user_id;

			$this->data['success'] = "success";


			echo json_encode($this->data);
		
		}
        
    }

	public function makeActiveUserScript(){

		$post_user_id = $this->input->post('user_id');

		if (!empty($post_user_id)){

			$status_into = 1;
			$admin_class = new AdminModel;

			$description = "has approved a user";

			$admin_class->updateIsStatusUser($post_user_id, $status_into);
			$admin_class->insertLogs($description);

			$data = array();
			$this->data['user_id'] = $post_user_id;
			$this->data['success'] = "success";
			echo json_encode($this->data);
		}     
    }

	public function editUserScript(){

		$user_id = $this->input->post('user_id');
		$student_id = $this->input->post('student_id');
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email_add = $this->input->post('email_add');
		$contact_no = $this->input->post('contact_no');

		if (!empty($user_id) || !empty($student_id) || !empty($first_name) || !empty($last_name) || !empty($email_add) || !empty($contact_no)){

			$admin_class = new AdminModel;
			$description = "has edit a user profile";

			$admin_class->updateUserProfile($user_id, $student_id, $first_name, $last_name, $email_add, $contact_no);
			$admin_class->insertLogs($description);

			$data = array();
			
			$this->data['success'] = "success";
			echo json_encode($this->data);
		}     
    }

	public function addUserScript(){

		$student_id = $this->input->post('student_id');
		$password = $this->input->post('password');
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email_add = $this->input->post('email_add');
		$contact_no = $this->input->post('contact_no');

		if (!empty($student_id) || !empty($first_name) || !empty($last_name) || !empty($email_add) || !empty($contact_no)){

			$admin_class = new AdminModel;
			$description = "has add a user profile";

			$admin_class->addUserProfile($student_id, $password, $first_name, $last_name, $email_add, $contact_no);
			$admin_class->insertLogs($description);

			$data = array();
			
			$this->data['success'] = "success";
			echo json_encode($this->data);
		}     
    }

	public function editItemScript(){

		$item_id = $this->input->post('item_id');
		$item_name = $this->input->post('item_name');
		$item_desc = $this->input->post('item_desc');
		$item_qty = $this->input->post('item_qty'); 

		if (!empty($item_id) || !empty($item_name) || !empty($item_desc) || !empty($item_qty)){

			$admin_class = new AdminModel;
			$description = "has edit an item";

			$admin_class->updateItemProfile($item_id, $item_name, $item_desc, $item_qty);
			$admin_class->insertLogs($description);

			$data = array();
			
			$this->data['success'] = "success";
			echo json_encode($this->data);
		}     
    }

	public function addItemScript(){

		$item_name = $this->input->post('item_name');
		$item_desc = $this->input->post('item_desc');
		$item_qty = $this->input->post('item_qty');

		if (!empty($item_name) || !empty($item_desc) || !empty($item_qty)){

			$admin_class = new AdminModel;
			$description = "has add an item";

			$admin_class->addItemProfile($item_name, $item_desc, $item_qty);
			$admin_class->insertLogs($description);

			$data = array();
			
			$this->data['success'] = "success";
			echo json_encode($this->data);
		}     
    }

	public function getBorrowList(){

		$data = array();

		$admin_class = new AdminModel;

			foreach ($admin_class->getAllTransaction() as $row) {
			$full_name = $row->first_name . " " . $row->last_name;
			array_push($data,array
				(
					'transaction_id' => $row->transaction_id,
					'student_id' => $row->student_id,
					'full_name' => $full_name,
					'item_name' => $row->item_name,
					'item_desc' => $row->item_desc,
					'is_status' => $row->is_status,
					'date_created' => $row->date_created
				)
			);
		}

		$this->data['finalData'] = $data;
		$this->data['status'] = 'success';
		echo json_encode($this->data);

	}

	public function editBorrowItem()
	{
		$data = array();
		$post_transaction_id = $this->input->post('transaction_id');

		$admin_class = new AdminModel;

		foreach ($admin_class->getBorrowedItem($post_transaction_id) as $row) {
			$data['transaction_id'] = $row->transaction_id;
			$data['user_id'] = $row->user_id;
			$data['item_id'] = $row->item_id;
			$data['is_status'] = $row->is_status;
			$data['date_created'] = $row->date_created;
		}
		$this->load->view('admin/modals/borrow_status.php', $data);
	}

	public function changeBorrowedStatusScript(){

		$post_transaction_id = $this->input->post('transaction_id');
		$post_is_status = $this->input->post('is_status');
		$post_item_id = $this->input->post('item_id');

		if (!empty($post_transaction_id)){

			if ($post_is_status == "Approved")
			{
				$is_available = "No";
			}
			else if ($post_is_status == "Received")
			{
				$is_available = "Yes";
			}
			$admin_class = new AdminModel;

			$description = "has change a borrowed status of a user";

			$admin_class->updateIsStatusUserBorrowed($post_transaction_id, $post_is_status);
			$admin_class->updateItemStatus($post_item_id, $is_available);
			$admin_class->insertLogs($description);
			

			$this->data['success'] = "success";


			echo json_encode($this->data);
		
		}
        
    }
}
