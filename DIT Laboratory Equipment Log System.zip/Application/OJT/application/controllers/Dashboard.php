<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();

		$this->load->model('LoginModel');
		$this->load->model('UserModel');
		$this->load->model('AdminModel');

    	if (($this->session->userdata('active_status')) == 1 ) {

			$user_class = new UserModel;
			$user_id = $this->session->userdata('user_id');

			foreach ($user_class->fetchUserProfile($user_id) as $row) {
				$this->session->set_userdata('is_admin', $row->is_admin);
				$this->session->set_userdata('username', $row->username);
				$this->session->set_userdata('student_id', $row->student_id);
				$this->session->set_userdata('password', $row->password);
				$this->session->set_userdata('first_name', $row->first_name);
				$this->session->set_userdata('last_name', $row->last_name);
				$this->session->set_userdata('email_add', $row->email_add);
				$this->session->set_userdata('contact_no', $row->contact_no);
				$this->session->set_userdata('date_created', $row->date_created);
				$this->session->set_userdata('date_updated', $row->date_updated);
			}

		}

		else {
			redirect(base_url('login'), 'refresh');
		}

		
	}
	
	public function index()
	{
		$data['title'] = "Home";
		$data['fetch_top_items'] = array();
		$data['fetch_top_users'] = array();
		$user_class = new UserModel;

		foreach ($user_class->fetchTopItems() as $row) {
        	array_push($data['fetch_top_items'], array(
				'item_name' => $row->item_name,
				'top_items' => $row->top_items
				)
			);
		}

		foreach ($user_class->fetchTopUsers() as $row) {
        	array_push($data['fetch_top_users'], array(
				'first_name' => $row->first_name,
				'top_users' => $row->top_users
				)
			);
		}

        $this->load->view('templates/header.php', $data);
		$this->load->view('dashboard/index.php', $data);
        $this->load->view('templates/footer.php');
		$this->load->view('templates/modal.php');
	}

	public function getBorrowingList()
	{
		$this->load->view('dashboard/home_borrowing_table.php');
	}

	public function getInventoryBag()
	{
		$this->load->view('dashboard/profile/view_inventory.php');
	}

	public function about()
	{
		$data['title'] = "About";
		$this->load->view('templates/header.php', $data);
		$this->load->view('dashboard/about.php');
        $this->load->view('templates/footer.php');
	}

	public function contact()
	{
		$data['title'] = "Contact";
		$this->load->view('templates/header.php', $data);
		$this->load->view('dashboard/contact.php');
        $this->load->view('templates/footer.php');
	}

	public function profile()
	{
		$data['title'] = "Profile";
		$user_class = new UserModel;
		$user_id = $this->session->userdata('user_id');

		foreach ($user_class->fetchUserProfile($user_id) as $row) {
			$data['first_name'] = $row->first_name;
			$data['last_name'] = $row->last_name;
			$data['email_add'] = $row->email_add;
			$data['contact_no'] = $row->contact_no;
		}

		$this->load->view('templates/header.php', $data);
		$this->load->view('dashboard/profile.php', $data);
        $this->load->view('templates/footer.php');
		$this->load->view('templates/modal.php');
	}

	public function logout()
	{
		$this->load->view('templates/login-header.php');
		$this->load->view('login/index.php');
        $this->load->view('templates/footer.php');
	}

	public function sample()
	{
		$this->load->view('test.php');

	}

	public function fetchLogs()
	{
		$data['fetch_logs'] = array();
		$user_class = new UserModel;

		foreach ($user_class->fetchMinimumLogs() as $row) {
        	array_push($data['fetch_logs'], array(
				'user_id' => $row->user_id, 
				'student_id' => $row->student_id, 
				'first_name' => $row->first_name, 
				'last_name' => $row->last_name, 
				'description' => $row->description,
				'date_created' => $row->date_created
				)
			);
		}

		// var_dump($data['fetch_logs']);

		$this->load->view('dashboard/activity_stream.php',$data);
	}

	
	public function getBorrowingTable()
	{
		$data = array();

		$user_class = new UserModel;

			foreach ($user_class->getAllAvailableItem() as $row) {

			array_push($data,array
				(
					'item_id' => $row->item_id,
					'item_name' => $row->item_name,
					'item_desc' => $row->item_desc,
					'item_qty' => $row->item_qty,
					'date_created' => $row->date_created
				)
			);
		}

		$this->data['finalData'] = $data;
		$this->data['status'] = 'success';
		echo json_encode($this->data);
	}

	public function borrowItem()
	{
		$data = array();
		$post_item_id = $this->input->post('item_id');

		$user_class = new UserModel;

		foreach ($user_class->getSpecificItem($post_item_id) as $row) {
			$data['item_id'] = $row->item_id;
		}

		$this->load->view('dashboard/modals/make_borrow_item.php', $data);
	}

	public function makeBorrowScript()
	{

		$post_item_id = $this->input->post('item_id');
		if (!empty($post_item_id)){

			$user_class = new UserModel;

			$description = "has borrowed an item";

			$user_class->borrowItem($post_item_id);
			// $user_class->updateItemStatusPending($post_item_id);
			$user_class->insertLogs($description);
			
			$data = array();

			$this->data['success'] = "success";

			echo json_encode($this->data);
		
		}
        
    }

	public function updateProfileInfo()
	{
		$user_id = $this->session->userdata('user_id');
		$student_id = $this->session->userdata('student_id');
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email_add = $this->input->post('email_add');
		$contact_no = $this->input->post('contact');

		if (!empty($user_id) || !empty($student_id) || !empty($first_name) || !empty($last_name) || !empty($email_add) || !empty($contact_no)){

			$user_class = new UserModel;
			$description = "has updated profile";

			$user_class->updateUserProfile($user_id, $student_id, $first_name, $last_name, $email_add, $contact_no);
			$user_class->insertLogs($description);

			$data = array();
			
			$this->data['success'] = "success";
			echo json_encode($this->data);
		}    
	}
	
	public function getInventoryTable()
	{
		$data = array();

		$user_class = new UserModel;

			foreach ($user_class->getUserInventoryTransactions() as $row) {

			array_push($data,array
				(
					'transaction_id' => $row->transaction_id,
					'item_id' => $row->item_id,
					'item_name' => $row->item_name,
					'item_desc' => $row->item_desc,
					'item_qty' => $row->item_qty,
					'is_status' => $row->is_status,
					'date_created' => $row->date_created
				)
			);
		}

		$this->data['finalData'] = $data;
		$this->data['status'] = 'success';
		echo json_encode($this->data);
	}

	public function returnItem()
	{
		$data = array();
		$post_transaction_id = $this->input->post('transaction_id');

		$user_class = new UserModel;

		foreach ($user_class->getSpecificTransaction($post_transaction_id) as $row) {
			$data['transaction_id'] = $row->transaction_id;
		}

		$this->load->view('dashboard/modals/make_return_item.php', $data);
	}

	public function makeReturnScript()
	{

		$post_transaction_id = $this->input->post('transaction_id');
		if (!empty($post_transaction_id)){

			$user_class = new UserModel;

			$description = "has returned an item";

			$user_class->returnItem($post_transaction_id);
			// $user_class->updateItemStatusPending($post_item_id);
			$user_class->insertLogs($description);
			
			$data = array();

			$this->data['success'] = "success";

			echo json_encode($this->data);
		
		}
        
    }

}
