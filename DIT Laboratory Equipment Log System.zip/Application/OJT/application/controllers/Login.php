<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
    	$this->load->model('LoginModel');
	}

	public function index()
	{
		if (($this->session->userdata('active_status')) == 1) {
			redirect(base_url(''));
		}
		else {
			
			$this->load->view('templates/login-header.php');
			$this->load->view('login/index.php');
			$this->load->view('templates/footer.php');
		}
	}

	public function loginPageScript()
	{
		$data['title'] = "Attempt login";

		$auth_process = $this->input->post('authenticate_page');

		// LOGIN PROCESS
		$login_student_num = $this->input->post('login_student_num');
		$login_password = md5($this->input->post('login_password'));

		// REGISTRATION PROCESS
		$register_student_num = $this->input->post('register_student_num');
		$register_email = $this->input->post('register_email');
		$register_password = $this->input->post('register_password');
		$register_re_password = $this->input->post('register_re_password');
		
		if ($auth_process != "" && $auth_process == "login_attempt" && $login_student_num != "" && $login_password != "") {
			$login_class = new LoginModel;
			$row_counter = 0;

			foreach ($login_class->validateUser($login_student_num, $login_password) as $row) {

				$data['user_id'] = $this->session->set_userdata('user_id', $row->user_id);
				$this->session->set_userdata('active_status', 1);

				// $log_student_id = $this->session->set_userdata('user_id', $login_student_num);
				$description = "has logged in";
				$login_class->insertLogs($description);
				
				$row_counter++;
			} 
			if ($row_counter == 1 && !empty($data['user_id'])) {
				$this->session->set_flashdata('login_error', '');
				redirect(base_url(''));
			}
			else {
				$this->session->set_flashdata('login_error', 'Incorrect credentials!');
				redirect(base_url('login'));
			}
		}

		else if ($auth_process != "" && $auth_process == "register_attempt" && $register_student_num != "" && $register_email != "" && $register_password != "" && $register_re_password != "") { 
			$login_class = new LoginModel;

			$data['registration_data'] = 0;

			foreach ($login_class->checkStudentNumberExist($register_student_num) as $row) {
				$data['registration_data'] = $row->student_id;
			}

			
			if(strlen($register_password) <= 7) {
				$this->session->set_flashdata('login_error', "Password too short!");
				redirect(base_url('login'));
			}
			else if ($register_password != $register_re_password) {
				$this->session->set_flashdata('login_error', "Password doesn't match!");
				redirect(base_url('login'));
			}
			else if ($data['registration_data'] != 0) {
				$this->session->set_flashdata('login_error', 'Student number already taken!');
				redirect(base_url('login'));
			}
			else {
				$this->session->set_flashdata('login_error', 'success');

				$login_class->registerAccount($register_student_num, $register_email, $register_password);
				redirect(base_url('login'));
			}

		} 
		
		else {
			redirect(base_url('login'));
		}
		
	}

	public function logoutPageScript()
	{
		$login_class = new LoginModel;
		$description = "has logged out";
		$login_class->insertLogs($description);
		$this->session->sess_destroy();
		redirect(base_url('login'));
	}

}
