<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-01-03 02:15:33 --> Config Class Initialized
INFO - 2022-01-03 02:15:33 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:33 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:33 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:33 --> URI Class Initialized
INFO - 2022-01-03 02:15:33 --> Router Class Initialized
INFO - 2022-01-03 02:15:33 --> Output Class Initialized
INFO - 2022-01-03 02:15:33 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:33 --> Input Class Initialized
INFO - 2022-01-03 02:15:33 --> Language Class Initialized
INFO - 2022-01-03 02:15:33 --> Loader Class Initialized
INFO - 2022-01-03 02:15:33 --> Helper loaded: url_helper
INFO - 2022-01-03 02:15:33 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:15:33 --> Controller Class Initialized
INFO - 2022-01-03 02:15:33 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:15:33 --> Model "UserModel" initialized
INFO - 2022-01-03 02:15:33 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:15:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:15:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:15:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:15:33 --> Final output sent to browser
DEBUG - 2022-01-03 02:15:33 --> Total execution time: 0.0610
INFO - 2022-01-03 02:15:39 --> Config Class Initialized
INFO - 2022-01-03 02:15:39 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:39 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:39 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:39 --> URI Class Initialized
INFO - 2022-01-03 02:15:39 --> Router Class Initialized
INFO - 2022-01-03 02:15:39 --> Output Class Initialized
INFO - 2022-01-03 02:15:39 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:39 --> Input Class Initialized
INFO - 2022-01-03 02:15:39 --> Language Class Initialized
INFO - 2022-01-03 02:15:39 --> Loader Class Initialized
INFO - 2022-01-03 02:15:39 --> Helper loaded: url_helper
INFO - 2022-01-03 02:15:39 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:15:40 --> Controller Class Initialized
INFO - 2022-01-03 02:15:40 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:15:40 --> Model "UserModel" initialized
INFO - 2022-01-03 02:15:40 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:15:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:15:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-03 02:15:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:15:40 --> Final output sent to browser
DEBUG - 2022-01-03 02:15:40 --> Total execution time: 0.1034
INFO - 2022-01-03 02:15:41 --> Config Class Initialized
INFO - 2022-01-03 02:15:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:41 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:41 --> URI Class Initialized
INFO - 2022-01-03 02:15:41 --> Router Class Initialized
INFO - 2022-01-03 02:15:41 --> Output Class Initialized
INFO - 2022-01-03 02:15:41 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:41 --> Input Class Initialized
INFO - 2022-01-03 02:15:41 --> Language Class Initialized
INFO - 2022-01-03 02:15:41 --> Loader Class Initialized
INFO - 2022-01-03 02:15:41 --> Helper loaded: url_helper
INFO - 2022-01-03 02:15:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:15:41 --> Controller Class Initialized
INFO - 2022-01-03 02:15:41 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:15:41 --> Config Class Initialized
INFO - 2022-01-03 02:15:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:41 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:41 --> URI Class Initialized
INFO - 2022-01-03 02:15:41 --> Router Class Initialized
INFO - 2022-01-03 02:15:41 --> Output Class Initialized
INFO - 2022-01-03 02:15:41 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:41 --> Input Class Initialized
INFO - 2022-01-03 02:15:41 --> Language Class Initialized
INFO - 2022-01-03 02:15:41 --> Loader Class Initialized
INFO - 2022-01-03 02:15:41 --> Helper loaded: url_helper
INFO - 2022-01-03 02:15:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:15:41 --> Controller Class Initialized
INFO - 2022-01-03 02:15:41 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:15:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 02:15:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 02:15:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:15:41 --> Final output sent to browser
DEBUG - 2022-01-03 02:15:41 --> Total execution time: 0.0580
INFO - 2022-01-03 02:15:43 --> Config Class Initialized
INFO - 2022-01-03 02:15:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:43 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:43 --> URI Class Initialized
INFO - 2022-01-03 02:15:43 --> Router Class Initialized
INFO - 2022-01-03 02:15:43 --> Output Class Initialized
INFO - 2022-01-03 02:15:43 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:43 --> Input Class Initialized
INFO - 2022-01-03 02:15:43 --> Language Class Initialized
ERROR - 2022-01-03 02:15:43 --> 404 Page Not Found: Dasho/index
INFO - 2022-01-03 02:15:46 --> Config Class Initialized
INFO - 2022-01-03 02:15:46 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:46 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:46 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:46 --> URI Class Initialized
INFO - 2022-01-03 02:15:46 --> Router Class Initialized
INFO - 2022-01-03 02:15:46 --> Output Class Initialized
INFO - 2022-01-03 02:15:46 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:46 --> Input Class Initialized
INFO - 2022-01-03 02:15:46 --> Language Class Initialized
INFO - 2022-01-03 02:15:46 --> Loader Class Initialized
INFO - 2022-01-03 02:15:46 --> Helper loaded: url_helper
INFO - 2022-01-03 02:15:46 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:15:46 --> Controller Class Initialized
INFO - 2022-01-03 02:15:46 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:15:46 --> Model "UserModel" initialized
INFO - 2022-01-03 02:15:46 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:15:46 --> Config Class Initialized
INFO - 2022-01-03 02:15:46 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:46 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:46 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:46 --> URI Class Initialized
INFO - 2022-01-03 02:15:46 --> Router Class Initialized
INFO - 2022-01-03 02:15:46 --> Output Class Initialized
INFO - 2022-01-03 02:15:46 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:46 --> Input Class Initialized
INFO - 2022-01-03 02:15:46 --> Language Class Initialized
INFO - 2022-01-03 02:15:46 --> Loader Class Initialized
INFO - 2022-01-03 02:15:46 --> Helper loaded: url_helper
INFO - 2022-01-03 02:15:46 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:15:46 --> Controller Class Initialized
INFO - 2022-01-03 02:15:46 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:15:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 02:15:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 02:15:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:15:46 --> Final output sent to browser
DEBUG - 2022-01-03 02:15:46 --> Total execution time: 0.0585
INFO - 2022-01-03 02:15:52 --> Config Class Initialized
INFO - 2022-01-03 02:15:52 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:52 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:52 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:52 --> URI Class Initialized
INFO - 2022-01-03 02:15:52 --> Router Class Initialized
INFO - 2022-01-03 02:15:53 --> Output Class Initialized
INFO - 2022-01-03 02:15:53 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:53 --> Input Class Initialized
INFO - 2022-01-03 02:15:53 --> Language Class Initialized
INFO - 2022-01-03 02:15:53 --> Loader Class Initialized
INFO - 2022-01-03 02:15:53 --> Helper loaded: url_helper
INFO - 2022-01-03 02:15:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:15:53 --> Controller Class Initialized
INFO - 2022-01-03 02:15:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:15:53 --> Model "UserModel" initialized
INFO - 2022-01-03 02:15:53 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:15:53 --> Config Class Initialized
INFO - 2022-01-03 02:15:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:15:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:15:53 --> Utf8 Class Initialized
INFO - 2022-01-03 02:15:53 --> URI Class Initialized
INFO - 2022-01-03 02:15:53 --> Router Class Initialized
INFO - 2022-01-03 02:15:53 --> Output Class Initialized
INFO - 2022-01-03 02:15:53 --> Security Class Initialized
DEBUG - 2022-01-03 02:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:15:53 --> Input Class Initialized
INFO - 2022-01-03 02:15:53 --> Language Class Initialized
INFO - 2022-01-03 02:15:53 --> Loader Class Initialized
INFO - 2022-01-03 02:15:53 --> Helper loaded: url_helper
INFO - 2022-01-03 02:15:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:15:53 --> Controller Class Initialized
INFO - 2022-01-03 02:15:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:15:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 02:15:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 02:15:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:15:53 --> Final output sent to browser
DEBUG - 2022-01-03 02:15:53 --> Total execution time: 0.0558
INFO - 2022-01-03 02:16:42 --> Config Class Initialized
INFO - 2022-01-03 02:16:42 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:16:42 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:16:42 --> Utf8 Class Initialized
INFO - 2022-01-03 02:16:42 --> URI Class Initialized
INFO - 2022-01-03 02:16:42 --> Router Class Initialized
INFO - 2022-01-03 02:16:42 --> Output Class Initialized
INFO - 2022-01-03 02:16:42 --> Security Class Initialized
DEBUG - 2022-01-03 02:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:16:42 --> Input Class Initialized
INFO - 2022-01-03 02:16:42 --> Language Class Initialized
ERROR - 2022-01-03 02:16:42 --> 404 Page Not Found: Sample/index
INFO - 2022-01-03 02:16:58 --> Config Class Initialized
INFO - 2022-01-03 02:16:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:16:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:16:58 --> Utf8 Class Initialized
INFO - 2022-01-03 02:16:58 --> URI Class Initialized
INFO - 2022-01-03 02:16:58 --> Router Class Initialized
INFO - 2022-01-03 02:16:58 --> Output Class Initialized
INFO - 2022-01-03 02:16:58 --> Security Class Initialized
DEBUG - 2022-01-03 02:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:16:58 --> Input Class Initialized
INFO - 2022-01-03 02:16:58 --> Language Class Initialized
INFO - 2022-01-03 02:16:58 --> Loader Class Initialized
INFO - 2022-01-03 02:16:58 --> Helper loaded: url_helper
INFO - 2022-01-03 02:16:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:16:58 --> Controller Class Initialized
INFO - 2022-01-03 02:16:58 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:16:58 --> Model "UserModel" initialized
INFO - 2022-01-03 02:16:58 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:16:58 --> Config Class Initialized
INFO - 2022-01-03 02:16:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:16:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:16:58 --> Utf8 Class Initialized
INFO - 2022-01-03 02:16:58 --> URI Class Initialized
INFO - 2022-01-03 02:16:58 --> Router Class Initialized
INFO - 2022-01-03 02:16:58 --> Output Class Initialized
INFO - 2022-01-03 02:16:58 --> Security Class Initialized
DEBUG - 2022-01-03 02:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:16:58 --> Input Class Initialized
INFO - 2022-01-03 02:16:58 --> Language Class Initialized
INFO - 2022-01-03 02:16:58 --> Loader Class Initialized
INFO - 2022-01-03 02:16:58 --> Helper loaded: url_helper
INFO - 2022-01-03 02:16:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:16:58 --> Controller Class Initialized
INFO - 2022-01-03 02:16:58 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:16:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 02:16:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 02:16:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:16:58 --> Final output sent to browser
DEBUG - 2022-01-03 02:16:58 --> Total execution time: 0.0618
INFO - 2022-01-03 02:17:03 --> Config Class Initialized
INFO - 2022-01-03 02:17:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:17:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:17:03 --> Utf8 Class Initialized
INFO - 2022-01-03 02:17:03 --> URI Class Initialized
INFO - 2022-01-03 02:17:03 --> Router Class Initialized
INFO - 2022-01-03 02:17:03 --> Output Class Initialized
INFO - 2022-01-03 02:17:03 --> Security Class Initialized
DEBUG - 2022-01-03 02:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:17:03 --> Input Class Initialized
INFO - 2022-01-03 02:17:03 --> Language Class Initialized
INFO - 2022-01-03 02:17:03 --> Loader Class Initialized
INFO - 2022-01-03 02:17:03 --> Helper loaded: url_helper
INFO - 2022-01-03 02:17:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:17:03 --> Controller Class Initialized
INFO - 2022-01-03 02:17:03 --> Model "LoginModel" initialized
ERROR - 2022-01-03 02:17:03 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 43
INFO - 2022-01-03 02:17:03 --> Config Class Initialized
INFO - 2022-01-03 02:17:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:17:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:17:03 --> Utf8 Class Initialized
INFO - 2022-01-03 02:17:03 --> URI Class Initialized
DEBUG - 2022-01-03 02:17:03 --> No URI present. Default controller set.
INFO - 2022-01-03 02:17:03 --> Router Class Initialized
INFO - 2022-01-03 02:17:03 --> Output Class Initialized
INFO - 2022-01-03 02:17:03 --> Security Class Initialized
DEBUG - 2022-01-03 02:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:17:03 --> Input Class Initialized
INFO - 2022-01-03 02:17:03 --> Language Class Initialized
INFO - 2022-01-03 02:17:03 --> Loader Class Initialized
INFO - 2022-01-03 02:17:03 --> Helper loaded: url_helper
INFO - 2022-01-03 02:17:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:17:03 --> Controller Class Initialized
INFO - 2022-01-03 02:17:03 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:17:03 --> Model "UserModel" initialized
INFO - 2022-01-03 02:17:03 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:17:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:17:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:17:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:17:03 --> Final output sent to browser
DEBUG - 2022-01-03 02:17:03 --> Total execution time: 0.0490
INFO - 2022-01-03 02:17:08 --> Config Class Initialized
INFO - 2022-01-03 02:17:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:17:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:17:08 --> Utf8 Class Initialized
INFO - 2022-01-03 02:17:08 --> URI Class Initialized
INFO - 2022-01-03 02:17:08 --> Router Class Initialized
INFO - 2022-01-03 02:17:08 --> Output Class Initialized
INFO - 2022-01-03 02:17:08 --> Security Class Initialized
DEBUG - 2022-01-03 02:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:17:08 --> Input Class Initialized
INFO - 2022-01-03 02:17:08 --> Language Class Initialized
INFO - 2022-01-03 02:17:08 --> Loader Class Initialized
INFO - 2022-01-03 02:17:08 --> Helper loaded: url_helper
INFO - 2022-01-03 02:17:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:17:08 --> Controller Class Initialized
INFO - 2022-01-03 02:17:08 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:17:08 --> Model "UserModel" initialized
INFO - 2022-01-03 02:17:08 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:17:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\test.php
INFO - 2022-01-03 02:17:08 --> Final output sent to browser
DEBUG - 2022-01-03 02:17:08 --> Total execution time: 0.0520
INFO - 2022-01-03 02:22:33 --> Config Class Initialized
INFO - 2022-01-03 02:22:33 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:33 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:33 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:33 --> URI Class Initialized
INFO - 2022-01-03 02:22:33 --> Router Class Initialized
INFO - 2022-01-03 02:22:33 --> Output Class Initialized
INFO - 2022-01-03 02:22:33 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:33 --> Input Class Initialized
INFO - 2022-01-03 02:22:33 --> Language Class Initialized
INFO - 2022-01-03 02:22:33 --> Loader Class Initialized
INFO - 2022-01-03 02:22:33 --> Helper loaded: url_helper
INFO - 2022-01-03 02:22:33 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:22:33 --> Controller Class Initialized
INFO - 2022-01-03 02:22:33 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:22:33 --> Model "UserModel" initialized
INFO - 2022-01-03 02:22:33 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:22:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:22:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:22:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:22:33 --> Final output sent to browser
DEBUG - 2022-01-03 02:22:33 --> Total execution time: 0.0545
INFO - 2022-01-03 02:22:33 --> Config Class Initialized
INFO - 2022-01-03 02:22:33 --> Config Class Initialized
INFO - 2022-01-03 02:22:33 --> Hooks Class Initialized
INFO - 2022-01-03 02:22:33 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 02:22:33 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:33 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:33 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:33 --> URI Class Initialized
INFO - 2022-01-03 02:22:33 --> URI Class Initialized
INFO - 2022-01-03 02:22:33 --> Router Class Initialized
INFO - 2022-01-03 02:22:33 --> Router Class Initialized
INFO - 2022-01-03 02:22:33 --> Output Class Initialized
INFO - 2022-01-03 02:22:33 --> Security Class Initialized
INFO - 2022-01-03 02:22:33 --> Output Class Initialized
DEBUG - 2022-01-03 02:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:33 --> Input Class Initialized
INFO - 2022-01-03 02:22:33 --> Language Class Initialized
INFO - 2022-01-03 02:22:33 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:33 --> Input Class Initialized
INFO - 2022-01-03 02:22:33 --> Language Class Initialized
ERROR - 2022-01-03 02:22:33 --> 404 Page Not Found: Dashboard/assets
ERROR - 2022-01-03 02:22:33 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:34 --> Config Class Initialized
INFO - 2022-01-03 02:22:34 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:34 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:34 --> Config Class Initialized
INFO - 2022-01-03 02:22:34 --> Hooks Class Initialized
INFO - 2022-01-03 02:22:34 --> URI Class Initialized
INFO - 2022-01-03 02:22:34 --> Router Class Initialized
DEBUG - 2022-01-03 02:22:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:34 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:34 --> Output Class Initialized
INFO - 2022-01-03 02:22:34 --> URI Class Initialized
INFO - 2022-01-03 02:22:34 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:34 --> Router Class Initialized
INFO - 2022-01-03 02:22:34 --> Input Class Initialized
INFO - 2022-01-03 02:22:34 --> Language Class Initialized
INFO - 2022-01-03 02:22:34 --> Config Class Initialized
INFO - 2022-01-03 02:22:34 --> Hooks Class Initialized
INFO - 2022-01-03 02:22:34 --> Output Class Initialized
ERROR - 2022-01-03 02:22:34 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:34 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:34 --> Utf8 Class Initialized
DEBUG - 2022-01-03 02:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:34 --> Input Class Initialized
INFO - 2022-01-03 02:22:34 --> URI Class Initialized
INFO - 2022-01-03 02:22:34 --> Language Class Initialized
INFO - 2022-01-03 02:22:34 --> Router Class Initialized
ERROR - 2022-01-03 02:22:34 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:34 --> Output Class Initialized
INFO - 2022-01-03 02:22:34 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:34 --> Input Class Initialized
INFO - 2022-01-03 02:22:34 --> Language Class Initialized
ERROR - 2022-01-03 02:22:34 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:34 --> Config Class Initialized
INFO - 2022-01-03 02:22:34 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:34 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:34 --> URI Class Initialized
INFO - 2022-01-03 02:22:34 --> Router Class Initialized
INFO - 2022-01-03 02:22:34 --> Output Class Initialized
INFO - 2022-01-03 02:22:34 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:34 --> Input Class Initialized
INFO - 2022-01-03 02:22:34 --> Language Class Initialized
ERROR - 2022-01-03 02:22:34 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:34 --> Config Class Initialized
INFO - 2022-01-03 02:22:34 --> Hooks Class Initialized
INFO - 2022-01-03 02:22:34 --> Config Class Initialized
INFO - 2022-01-03 02:22:34 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:34 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:34 --> URI Class Initialized
DEBUG - 2022-01-03 02:22:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:34 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:34 --> Router Class Initialized
INFO - 2022-01-03 02:22:34 --> URI Class Initialized
INFO - 2022-01-03 02:22:34 --> Output Class Initialized
INFO - 2022-01-03 02:22:34 --> Security Class Initialized
INFO - 2022-01-03 02:22:34 --> Router Class Initialized
INFO - 2022-01-03 02:22:34 --> Output Class Initialized
DEBUG - 2022-01-03 02:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:34 --> Input Class Initialized
INFO - 2022-01-03 02:22:34 --> Language Class Initialized
INFO - 2022-01-03 02:22:34 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 02:22:34 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:34 --> Input Class Initialized
INFO - 2022-01-03 02:22:34 --> Language Class Initialized
ERROR - 2022-01-03 02:22:34 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
INFO - 2022-01-03 02:22:37 --> Loader Class Initialized
INFO - 2022-01-03 02:22:37 --> Helper loaded: url_helper
INFO - 2022-01-03 02:22:37 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:22:37 --> Controller Class Initialized
INFO - 2022-01-03 02:22:37 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:22:37 --> Model "UserModel" initialized
INFO - 2022-01-03 02:22:37 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:22:37 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:22:37 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:22:37 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:22:37 --> Final output sent to browser
DEBUG - 2022-01-03 02:22:37 --> Total execution time: 0.0582
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
ERROR - 2022-01-03 02:22:37 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
ERROR - 2022-01-03 02:22:37 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
ERROR - 2022-01-03 02:22:37 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
ERROR - 2022-01-03 02:22:37 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
ERROR - 2022-01-03 02:22:37 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
ERROR - 2022-01-03 02:22:37 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
INFO - 2022-01-03 02:22:37 --> Config Class Initialized
INFO - 2022-01-03 02:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 02:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
INFO - 2022-01-03 02:22:37 --> URI Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Router Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
INFO - 2022-01-03 02:22:37 --> Output Class Initialized
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
INFO - 2022-01-03 02:22:37 --> Security Class Initialized
ERROR - 2022-01-03 02:22:37 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:37 --> Input Class Initialized
INFO - 2022-01-03 02:22:37 --> Language Class Initialized
ERROR - 2022-01-03 02:22:37 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:58 --> Config Class Initialized
INFO - 2022-01-03 02:22:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:58 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:58 --> URI Class Initialized
INFO - 2022-01-03 02:22:58 --> Router Class Initialized
INFO - 2022-01-03 02:22:58 --> Output Class Initialized
INFO - 2022-01-03 02:22:58 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:58 --> Input Class Initialized
INFO - 2022-01-03 02:22:58 --> Language Class Initialized
INFO - 2022-01-03 02:22:58 --> Loader Class Initialized
INFO - 2022-01-03 02:22:58 --> Helper loaded: url_helper
INFO - 2022-01-03 02:22:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:22:58 --> Controller Class Initialized
INFO - 2022-01-03 02:22:58 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:22:58 --> Model "UserModel" initialized
INFO - 2022-01-03 02:22:58 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:22:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:22:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:22:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:22:58 --> Final output sent to browser
DEBUG - 2022-01-03 02:22:58 --> Total execution time: 0.1424
INFO - 2022-01-03 02:22:58 --> Config Class Initialized
INFO - 2022-01-03 02:22:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:58 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:58 --> URI Class Initialized
INFO - 2022-01-03 02:22:58 --> Router Class Initialized
INFO - 2022-01-03 02:22:58 --> Output Class Initialized
INFO - 2022-01-03 02:22:58 --> Config Class Initialized
INFO - 2022-01-03 02:22:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:58 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:58 --> URI Class Initialized
INFO - 2022-01-03 02:22:58 --> Router Class Initialized
INFO - 2022-01-03 02:22:58 --> Output Class Initialized
INFO - 2022-01-03 02:22:58 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:58 --> Input Class Initialized
INFO - 2022-01-03 02:22:58 --> Language Class Initialized
ERROR - 2022-01-03 02:22:58 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:58 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:58 --> Input Class Initialized
INFO - 2022-01-03 02:22:58 --> Language Class Initialized
ERROR - 2022-01-03 02:22:58 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:59 --> Config Class Initialized
INFO - 2022-01-03 02:22:59 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:59 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:59 --> URI Class Initialized
INFO - 2022-01-03 02:22:59 --> Router Class Initialized
INFO - 2022-01-03 02:22:59 --> Output Class Initialized
INFO - 2022-01-03 02:22:59 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:59 --> Input Class Initialized
INFO - 2022-01-03 02:22:59 --> Language Class Initialized
ERROR - 2022-01-03 02:22:59 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:59 --> Config Class Initialized
INFO - 2022-01-03 02:22:59 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:59 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:59 --> URI Class Initialized
INFO - 2022-01-03 02:22:59 --> Config Class Initialized
INFO - 2022-01-03 02:22:59 --> Hooks Class Initialized
INFO - 2022-01-03 02:22:59 --> Router Class Initialized
INFO - 2022-01-03 02:22:59 --> Output Class Initialized
INFO - 2022-01-03 02:22:59 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:59 --> Utf8 Class Initialized
DEBUG - 2022-01-03 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:59 --> Input Class Initialized
INFO - 2022-01-03 02:22:59 --> Language Class Initialized
INFO - 2022-01-03 02:22:59 --> URI Class Initialized
ERROR - 2022-01-03 02:22:59 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:59 --> Router Class Initialized
INFO - 2022-01-03 02:22:59 --> Output Class Initialized
INFO - 2022-01-03 02:22:59 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:59 --> Input Class Initialized
INFO - 2022-01-03 02:22:59 --> Language Class Initialized
ERROR - 2022-01-03 02:22:59 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:59 --> Config Class Initialized
INFO - 2022-01-03 02:22:59 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:59 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:59 --> URI Class Initialized
INFO - 2022-01-03 02:22:59 --> Router Class Initialized
INFO - 2022-01-03 02:22:59 --> Output Class Initialized
INFO - 2022-01-03 02:22:59 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:59 --> Input Class Initialized
INFO - 2022-01-03 02:22:59 --> Language Class Initialized
ERROR - 2022-01-03 02:22:59 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:22:59 --> Config Class Initialized
INFO - 2022-01-03 02:22:59 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:59 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:59 --> URI Class Initialized
INFO - 2022-01-03 02:22:59 --> Router Class Initialized
INFO - 2022-01-03 02:22:59 --> Output Class Initialized
INFO - 2022-01-03 02:22:59 --> Config Class Initialized
INFO - 2022-01-03 02:22:59 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:22:59 --> Utf8 Class Initialized
INFO - 2022-01-03 02:22:59 --> URI Class Initialized
INFO - 2022-01-03 02:22:59 --> Security Class Initialized
INFO - 2022-01-03 02:22:59 --> Router Class Initialized
INFO - 2022-01-03 02:22:59 --> Output Class Initialized
INFO - 2022-01-03 02:22:59 --> Security Class Initialized
DEBUG - 2022-01-03 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:59 --> Input Class Initialized
INFO - 2022-01-03 02:22:59 --> Language Class Initialized
ERROR - 2022-01-03 02:22:59 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:22:59 --> Input Class Initialized
INFO - 2022-01-03 02:22:59 --> Language Class Initialized
ERROR - 2022-01-03 02:22:59 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:00 --> Config Class Initialized
INFO - 2022-01-03 02:23:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:00 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:00 --> URI Class Initialized
INFO - 2022-01-03 02:23:00 --> Router Class Initialized
INFO - 2022-01-03 02:23:00 --> Output Class Initialized
INFO - 2022-01-03 02:23:00 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:00 --> Input Class Initialized
INFO - 2022-01-03 02:23:00 --> Language Class Initialized
INFO - 2022-01-03 02:23:00 --> Loader Class Initialized
INFO - 2022-01-03 02:23:00 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:00 --> Controller Class Initialized
INFO - 2022-01-03 02:23:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:00 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:00 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:00 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:00 --> Total execution time: 0.0503
INFO - 2022-01-03 02:23:01 --> Config Class Initialized
INFO - 2022-01-03 02:23:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:01 --> URI Class Initialized
INFO - 2022-01-03 02:23:01 --> Router Class Initialized
INFO - 2022-01-03 02:23:01 --> Output Class Initialized
INFO - 2022-01-03 02:23:01 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:01 --> Input Class Initialized
INFO - 2022-01-03 02:23:01 --> Config Class Initialized
INFO - 2022-01-03 02:23:01 --> Hooks Class Initialized
INFO - 2022-01-03 02:23:01 --> Language Class Initialized
ERROR - 2022-01-03 02:23:01 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:01 --> URI Class Initialized
INFO - 2022-01-03 02:23:01 --> Router Class Initialized
INFO - 2022-01-03 02:23:01 --> Output Class Initialized
INFO - 2022-01-03 02:23:01 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:01 --> Input Class Initialized
INFO - 2022-01-03 02:23:01 --> Language Class Initialized
ERROR - 2022-01-03 02:23:01 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:01 --> Config Class Initialized
INFO - 2022-01-03 02:23:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:01 --> URI Class Initialized
INFO - 2022-01-03 02:23:01 --> Router Class Initialized
INFO - 2022-01-03 02:23:01 --> Output Class Initialized
INFO - 2022-01-03 02:23:01 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:01 --> Config Class Initialized
INFO - 2022-01-03 02:23:01 --> Input Class Initialized
INFO - 2022-01-03 02:23:01 --> Hooks Class Initialized
INFO - 2022-01-03 02:23:01 --> Language Class Initialized
ERROR - 2022-01-03 02:23:01 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:01 --> URI Class Initialized
INFO - 2022-01-03 02:23:01 --> Router Class Initialized
INFO - 2022-01-03 02:23:01 --> Output Class Initialized
INFO - 2022-01-03 02:23:01 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:01 --> Input Class Initialized
INFO - 2022-01-03 02:23:01 --> Language Class Initialized
INFO - 2022-01-03 02:23:01 --> Config Class Initialized
INFO - 2022-01-03 02:23:01 --> Hooks Class Initialized
ERROR - 2022-01-03 02:23:01 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:01 --> URI Class Initialized
INFO - 2022-01-03 02:23:01 --> Config Class Initialized
INFO - 2022-01-03 02:23:01 --> Router Class Initialized
INFO - 2022-01-03 02:23:01 --> Hooks Class Initialized
INFO - 2022-01-03 02:23:01 --> Output Class Initialized
DEBUG - 2022-01-03 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:01 --> Security Class Initialized
INFO - 2022-01-03 02:23:01 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:01 --> Input Class Initialized
INFO - 2022-01-03 02:23:01 --> Router Class Initialized
INFO - 2022-01-03 02:23:01 --> Language Class Initialized
ERROR - 2022-01-03 02:23:01 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:01 --> Output Class Initialized
INFO - 2022-01-03 02:23:01 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:01 --> Input Class Initialized
INFO - 2022-01-03 02:23:01 --> Language Class Initialized
ERROR - 2022-01-03 02:23:01 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:01 --> Config Class Initialized
INFO - 2022-01-03 02:23:01 --> Hooks Class Initialized
INFO - 2022-01-03 02:23:01 --> Config Class Initialized
INFO - 2022-01-03 02:23:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:01 --> URI Class Initialized
INFO - 2022-01-03 02:23:01 --> URI Class Initialized
INFO - 2022-01-03 02:23:01 --> Router Class Initialized
INFO - 2022-01-03 02:23:01 --> Output Class Initialized
INFO - 2022-01-03 02:23:01 --> Router Class Initialized
INFO - 2022-01-03 02:23:01 --> Output Class Initialized
INFO - 2022-01-03 02:23:01 --> Security Class Initialized
INFO - 2022-01-03 02:23:01 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:01 --> Input Class Initialized
DEBUG - 2022-01-03 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:01 --> Language Class Initialized
INFO - 2022-01-03 02:23:01 --> Input Class Initialized
INFO - 2022-01-03 02:23:01 --> Language Class Initialized
ERROR - 2022-01-03 02:23:01 --> 404 Page Not Found: Dashboard/assets
ERROR - 2022-01-03 02:23:01 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:02 --> Config Class Initialized
INFO - 2022-01-03 02:23:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:02 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:02 --> URI Class Initialized
INFO - 2022-01-03 02:23:02 --> Router Class Initialized
INFO - 2022-01-03 02:23:02 --> Output Class Initialized
INFO - 2022-01-03 02:23:02 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:02 --> Input Class Initialized
INFO - 2022-01-03 02:23:02 --> Language Class Initialized
INFO - 2022-01-03 02:23:02 --> Loader Class Initialized
INFO - 2022-01-03 02:23:02 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:02 --> Controller Class Initialized
INFO - 2022-01-03 02:23:02 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:02 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:02 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:02 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:02 --> Total execution time: 0.0532
INFO - 2022-01-03 02:23:02 --> Config Class Initialized
INFO - 2022-01-03 02:23:02 --> Config Class Initialized
INFO - 2022-01-03 02:23:02 --> Hooks Class Initialized
INFO - 2022-01-03 02:23:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 02:23:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:02 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:02 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:02 --> URI Class Initialized
INFO - 2022-01-03 02:23:02 --> URI Class Initialized
INFO - 2022-01-03 02:23:02 --> Router Class Initialized
INFO - 2022-01-03 02:23:02 --> Output Class Initialized
INFO - 2022-01-03 02:23:02 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:02 --> Input Class Initialized
INFO - 2022-01-03 02:23:02 --> Language Class Initialized
INFO - 2022-01-03 02:23:02 --> Router Class Initialized
ERROR - 2022-01-03 02:23:02 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:02 --> Output Class Initialized
INFO - 2022-01-03 02:23:02 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:02 --> Input Class Initialized
INFO - 2022-01-03 02:23:02 --> Language Class Initialized
ERROR - 2022-01-03 02:23:02 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:03 --> Config Class Initialized
INFO - 2022-01-03 02:23:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:03 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:03 --> URI Class Initialized
INFO - 2022-01-03 02:23:03 --> Router Class Initialized
INFO - 2022-01-03 02:23:03 --> Output Class Initialized
INFO - 2022-01-03 02:23:03 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:03 --> Input Class Initialized
INFO - 2022-01-03 02:23:03 --> Language Class Initialized
ERROR - 2022-01-03 02:23:03 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:03 --> Config Class Initialized
INFO - 2022-01-03 02:23:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:03 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:03 --> URI Class Initialized
INFO - 2022-01-03 02:23:03 --> Router Class Initialized
INFO - 2022-01-03 02:23:03 --> Output Class Initialized
INFO - 2022-01-03 02:23:03 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:03 --> Input Class Initialized
INFO - 2022-01-03 02:23:03 --> Language Class Initialized
ERROR - 2022-01-03 02:23:03 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:03 --> Config Class Initialized
INFO - 2022-01-03 02:23:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:03 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:03 --> URI Class Initialized
INFO - 2022-01-03 02:23:03 --> Router Class Initialized
INFO - 2022-01-03 02:23:03 --> Output Class Initialized
INFO - 2022-01-03 02:23:03 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:03 --> Input Class Initialized
INFO - 2022-01-03 02:23:03 --> Language Class Initialized
ERROR - 2022-01-03 02:23:03 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:03 --> Config Class Initialized
INFO - 2022-01-03 02:23:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:03 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:03 --> URI Class Initialized
INFO - 2022-01-03 02:23:03 --> Router Class Initialized
INFO - 2022-01-03 02:23:03 --> Output Class Initialized
INFO - 2022-01-03 02:23:03 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:03 --> Input Class Initialized
INFO - 2022-01-03 02:23:03 --> Language Class Initialized
ERROR - 2022-01-03 02:23:03 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:03 --> Config Class Initialized
INFO - 2022-01-03 02:23:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:03 --> Config Class Initialized
INFO - 2022-01-03 02:23:03 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:03 --> Hooks Class Initialized
INFO - 2022-01-03 02:23:03 --> URI Class Initialized
INFO - 2022-01-03 02:23:03 --> Router Class Initialized
DEBUG - 2022-01-03 02:23:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:03 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:03 --> Output Class Initialized
INFO - 2022-01-03 02:23:03 --> Security Class Initialized
INFO - 2022-01-03 02:23:03 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:03 --> Router Class Initialized
INFO - 2022-01-03 02:23:03 --> Input Class Initialized
INFO - 2022-01-03 02:23:03 --> Output Class Initialized
INFO - 2022-01-03 02:23:03 --> Language Class Initialized
INFO - 2022-01-03 02:23:03 --> Security Class Initialized
ERROR - 2022-01-03 02:23:03 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:03 --> Input Class Initialized
INFO - 2022-01-03 02:23:03 --> Language Class Initialized
ERROR - 2022-01-03 02:23:03 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:04 --> Config Class Initialized
INFO - 2022-01-03 02:23:04 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:04 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:04 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:04 --> URI Class Initialized
INFO - 2022-01-03 02:23:04 --> Router Class Initialized
INFO - 2022-01-03 02:23:04 --> Output Class Initialized
INFO - 2022-01-03 02:23:04 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:04 --> Input Class Initialized
INFO - 2022-01-03 02:23:04 --> Language Class Initialized
INFO - 2022-01-03 02:23:04 --> Loader Class Initialized
INFO - 2022-01-03 02:23:04 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:04 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:04 --> Controller Class Initialized
INFO - 2022-01-03 02:23:04 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:04 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:04 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:04 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:04 --> Total execution time: 0.0490
INFO - 2022-01-03 02:23:05 --> Config Class Initialized
INFO - 2022-01-03 02:23:05 --> Config Class Initialized
INFO - 2022-01-03 02:23:05 --> Hooks Class Initialized
INFO - 2022-01-03 02:23:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:05 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:05 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:05 --> Router Class Initialized
INFO - 2022-01-03 02:23:05 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:05 --> Output Class Initialized
INFO - 2022-01-03 02:23:05 --> Security Class Initialized
INFO - 2022-01-03 02:23:05 --> URI Class Initialized
INFO - 2022-01-03 02:23:05 --> Router Class Initialized
DEBUG - 2022-01-03 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:05 --> Input Class Initialized
INFO - 2022-01-03 02:23:05 --> Output Class Initialized
INFO - 2022-01-03 02:23:05 --> Language Class Initialized
INFO - 2022-01-03 02:23:05 --> Security Class Initialized
ERROR - 2022-01-03 02:23:05 --> 404 Page Not Found: Dashboard/assets
DEBUG - 2022-01-03 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:05 --> Input Class Initialized
INFO - 2022-01-03 02:23:05 --> Language Class Initialized
ERROR - 2022-01-03 02:23:05 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:05 --> Config Class Initialized
INFO - 2022-01-03 02:23:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:05 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:05 --> URI Class Initialized
INFO - 2022-01-03 02:23:05 --> Router Class Initialized
INFO - 2022-01-03 02:23:05 --> Output Class Initialized
INFO - 2022-01-03 02:23:05 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:05 --> Input Class Initialized
INFO - 2022-01-03 02:23:05 --> Language Class Initialized
ERROR - 2022-01-03 02:23:05 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:05 --> Config Class Initialized
INFO - 2022-01-03 02:23:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:05 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:05 --> URI Class Initialized
INFO - 2022-01-03 02:23:05 --> Router Class Initialized
INFO - 2022-01-03 02:23:05 --> Output Class Initialized
INFO - 2022-01-03 02:23:05 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:05 --> Input Class Initialized
INFO - 2022-01-03 02:23:05 --> Language Class Initialized
ERROR - 2022-01-03 02:23:05 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:05 --> Config Class Initialized
INFO - 2022-01-03 02:23:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:05 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:05 --> URI Class Initialized
INFO - 2022-01-03 02:23:05 --> Router Class Initialized
INFO - 2022-01-03 02:23:05 --> Output Class Initialized
INFO - 2022-01-03 02:23:05 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:05 --> Input Class Initialized
INFO - 2022-01-03 02:23:05 --> Language Class Initialized
ERROR - 2022-01-03 02:23:05 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:05 --> Config Class Initialized
INFO - 2022-01-03 02:23:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:05 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:05 --> URI Class Initialized
INFO - 2022-01-03 02:23:05 --> Router Class Initialized
INFO - 2022-01-03 02:23:05 --> Output Class Initialized
INFO - 2022-01-03 02:23:05 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:05 --> Input Class Initialized
INFO - 2022-01-03 02:23:05 --> Language Class Initialized
ERROR - 2022-01-03 02:23:05 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:05 --> Config Class Initialized
INFO - 2022-01-03 02:23:05 --> Config Class Initialized
INFO - 2022-01-03 02:23:05 --> Hooks Class Initialized
INFO - 2022-01-03 02:23:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 02:23:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:05 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:05 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:05 --> URI Class Initialized
INFO - 2022-01-03 02:23:05 --> URI Class Initialized
INFO - 2022-01-03 02:23:05 --> Router Class Initialized
INFO - 2022-01-03 02:23:05 --> Router Class Initialized
INFO - 2022-01-03 02:23:05 --> Output Class Initialized
INFO - 2022-01-03 02:23:05 --> Output Class Initialized
INFO - 2022-01-03 02:23:05 --> Security Class Initialized
INFO - 2022-01-03 02:23:05 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:05 --> Input Class Initialized
INFO - 2022-01-03 02:23:05 --> Language Class Initialized
DEBUG - 2022-01-03 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:05 --> Input Class Initialized
ERROR - 2022-01-03 02:23:05 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:05 --> Language Class Initialized
ERROR - 2022-01-03 02:23:05 --> 404 Page Not Found: Dashboard/assets
INFO - 2022-01-03 02:23:07 --> Config Class Initialized
INFO - 2022-01-03 02:23:07 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:07 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:07 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:07 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:07 --> No URI present. Default controller set.
INFO - 2022-01-03 02:23:07 --> Router Class Initialized
INFO - 2022-01-03 02:23:07 --> Output Class Initialized
INFO - 2022-01-03 02:23:07 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:07 --> Input Class Initialized
INFO - 2022-01-03 02:23:07 --> Language Class Initialized
INFO - 2022-01-03 02:23:07 --> Loader Class Initialized
INFO - 2022-01-03 02:23:07 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:07 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:07 --> Controller Class Initialized
INFO - 2022-01-03 02:23:07 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:07 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:07 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:07 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:07 --> Total execution time: 0.0554
INFO - 2022-01-03 02:23:13 --> Config Class Initialized
INFO - 2022-01-03 02:23:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:13 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:13 --> URI Class Initialized
INFO - 2022-01-03 02:23:13 --> Router Class Initialized
INFO - 2022-01-03 02:23:13 --> Output Class Initialized
INFO - 2022-01-03 02:23:13 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:13 --> Input Class Initialized
INFO - 2022-01-03 02:23:13 --> Language Class Initialized
INFO - 2022-01-03 02:23:13 --> Loader Class Initialized
INFO - 2022-01-03 02:23:13 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:13 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:13 --> Controller Class Initialized
INFO - 2022-01-03 02:23:13 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:13 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:13 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:13 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:13 --> Total execution time: 0.0553
INFO - 2022-01-03 02:23:32 --> Config Class Initialized
INFO - 2022-01-03 02:23:32 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:32 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:32 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:32 --> URI Class Initialized
INFO - 2022-01-03 02:23:32 --> Router Class Initialized
INFO - 2022-01-03 02:23:32 --> Output Class Initialized
INFO - 2022-01-03 02:23:32 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:32 --> Input Class Initialized
INFO - 2022-01-03 02:23:32 --> Language Class Initialized
INFO - 2022-01-03 02:23:32 --> Loader Class Initialized
INFO - 2022-01-03 02:23:32 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:32 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:32 --> Controller Class Initialized
INFO - 2022-01-03 02:23:32 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:32 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:32 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:32 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:32 --> Total execution time: 0.0507
INFO - 2022-01-03 02:23:36 --> Config Class Initialized
INFO - 2022-01-03 02:23:36 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:36 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:36 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:36 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:36 --> No URI present. Default controller set.
INFO - 2022-01-03 02:23:36 --> Router Class Initialized
INFO - 2022-01-03 02:23:36 --> Output Class Initialized
INFO - 2022-01-03 02:23:36 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:36 --> Input Class Initialized
INFO - 2022-01-03 02:23:36 --> Language Class Initialized
INFO - 2022-01-03 02:23:36 --> Loader Class Initialized
INFO - 2022-01-03 02:23:36 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:36 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:36 --> Controller Class Initialized
INFO - 2022-01-03 02:23:36 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:36 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:36 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:36 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:36 --> Total execution time: 0.0580
INFO - 2022-01-03 02:23:44 --> Config Class Initialized
INFO - 2022-01-03 02:23:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:44 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:44 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:44 --> No URI present. Default controller set.
INFO - 2022-01-03 02:23:44 --> Router Class Initialized
INFO - 2022-01-03 02:23:44 --> Output Class Initialized
INFO - 2022-01-03 02:23:44 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:44 --> Input Class Initialized
INFO - 2022-01-03 02:23:44 --> Language Class Initialized
INFO - 2022-01-03 02:23:44 --> Loader Class Initialized
INFO - 2022-01-03 02:23:44 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:44 --> Controller Class Initialized
INFO - 2022-01-03 02:23:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:44 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:44 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:44 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:44 --> Total execution time: 0.0603
INFO - 2022-01-03 02:23:46 --> Config Class Initialized
INFO - 2022-01-03 02:23:46 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:46 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:46 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:46 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:46 --> No URI present. Default controller set.
INFO - 2022-01-03 02:23:46 --> Router Class Initialized
INFO - 2022-01-03 02:23:46 --> Output Class Initialized
INFO - 2022-01-03 02:23:46 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:46 --> Input Class Initialized
INFO - 2022-01-03 02:23:46 --> Language Class Initialized
INFO - 2022-01-03 02:23:46 --> Loader Class Initialized
INFO - 2022-01-03 02:23:46 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:46 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:46 --> Controller Class Initialized
INFO - 2022-01-03 02:23:46 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:46 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:46 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:46 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:46 --> Total execution time: 0.0876
INFO - 2022-01-03 02:23:47 --> Config Class Initialized
INFO - 2022-01-03 02:23:47 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:47 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:47 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:47 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:47 --> No URI present. Default controller set.
INFO - 2022-01-03 02:23:47 --> Router Class Initialized
INFO - 2022-01-03 02:23:47 --> Output Class Initialized
INFO - 2022-01-03 02:23:47 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:47 --> Input Class Initialized
INFO - 2022-01-03 02:23:47 --> Language Class Initialized
INFO - 2022-01-03 02:23:47 --> Loader Class Initialized
INFO - 2022-01-03 02:23:47 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:47 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:47 --> Controller Class Initialized
INFO - 2022-01-03 02:23:47 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:47 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:47 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:47 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:47 --> Total execution time: 0.0705
INFO - 2022-01-03 02:23:48 --> Config Class Initialized
INFO - 2022-01-03 02:23:48 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:48 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:48 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:48 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:48 --> No URI present. Default controller set.
INFO - 2022-01-03 02:23:48 --> Router Class Initialized
INFO - 2022-01-03 02:23:48 --> Output Class Initialized
INFO - 2022-01-03 02:23:48 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:48 --> Input Class Initialized
INFO - 2022-01-03 02:23:48 --> Language Class Initialized
INFO - 2022-01-03 02:23:48 --> Loader Class Initialized
INFO - 2022-01-03 02:23:48 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:48 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:48 --> Controller Class Initialized
INFO - 2022-01-03 02:23:48 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:48 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:48 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:48 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:48 --> Total execution time: 0.0697
INFO - 2022-01-03 02:23:49 --> Config Class Initialized
INFO - 2022-01-03 02:23:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:49 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:49 --> URI Class Initialized
DEBUG - 2022-01-03 02:23:49 --> No URI present. Default controller set.
INFO - 2022-01-03 02:23:49 --> Router Class Initialized
INFO - 2022-01-03 02:23:49 --> Output Class Initialized
INFO - 2022-01-03 02:23:49 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:49 --> Input Class Initialized
INFO - 2022-01-03 02:23:49 --> Language Class Initialized
INFO - 2022-01-03 02:23:49 --> Loader Class Initialized
INFO - 2022-01-03 02:23:49 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:49 --> Controller Class Initialized
INFO - 2022-01-03 02:23:49 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:49 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:49 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:49 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:49 --> Total execution time: 0.0701
INFO - 2022-01-03 02:23:52 --> Config Class Initialized
INFO - 2022-01-03 02:23:52 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:23:52 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:23:52 --> Utf8 Class Initialized
INFO - 2022-01-03 02:23:52 --> URI Class Initialized
INFO - 2022-01-03 02:23:52 --> Router Class Initialized
INFO - 2022-01-03 02:23:52 --> Output Class Initialized
INFO - 2022-01-03 02:23:52 --> Security Class Initialized
DEBUG - 2022-01-03 02:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:23:52 --> Input Class Initialized
INFO - 2022-01-03 02:23:52 --> Language Class Initialized
INFO - 2022-01-03 02:23:52 --> Loader Class Initialized
INFO - 2022-01-03 02:23:52 --> Helper loaded: url_helper
INFO - 2022-01-03 02:23:52 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:23:52 --> Controller Class Initialized
INFO - 2022-01-03 02:23:52 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:23:52 --> Model "UserModel" initialized
INFO - 2022-01-03 02:23:52 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:23:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:23:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:23:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:23:52 --> Final output sent to browser
DEBUG - 2022-01-03 02:23:52 --> Total execution time: 0.0577
INFO - 2022-01-03 02:24:01 --> Config Class Initialized
INFO - 2022-01-03 02:24:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:01 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:01 --> URI Class Initialized
INFO - 2022-01-03 02:24:01 --> Router Class Initialized
INFO - 2022-01-03 02:24:01 --> Output Class Initialized
INFO - 2022-01-03 02:24:01 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:01 --> Input Class Initialized
INFO - 2022-01-03 02:24:01 --> Language Class Initialized
INFO - 2022-01-03 02:24:01 --> Loader Class Initialized
INFO - 2022-01-03 02:24:01 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:01 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:01 --> Controller Class Initialized
INFO - 2022-01-03 02:24:01 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:01 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:01 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 02:24:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:01 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:01 --> Total execution time: 0.0711
INFO - 2022-01-03 02:24:06 --> Config Class Initialized
INFO - 2022-01-03 02:24:06 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:06 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:06 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:06 --> URI Class Initialized
INFO - 2022-01-03 02:24:06 --> Router Class Initialized
INFO - 2022-01-03 02:24:06 --> Output Class Initialized
INFO - 2022-01-03 02:24:06 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:06 --> Input Class Initialized
INFO - 2022-01-03 02:24:06 --> Language Class Initialized
INFO - 2022-01-03 02:24:06 --> Loader Class Initialized
INFO - 2022-01-03 02:24:06 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:06 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:06 --> Controller Class Initialized
INFO - 2022-01-03 02:24:06 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:06 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:06 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-03 02:24:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:06 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:06 --> Total execution time: 0.0591
INFO - 2022-01-03 02:24:07 --> Config Class Initialized
INFO - 2022-01-03 02:24:07 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:07 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:07 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:07 --> URI Class Initialized
DEBUG - 2022-01-03 02:24:07 --> No URI present. Default controller set.
INFO - 2022-01-03 02:24:07 --> Router Class Initialized
INFO - 2022-01-03 02:24:07 --> Output Class Initialized
INFO - 2022-01-03 02:24:07 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:07 --> Input Class Initialized
INFO - 2022-01-03 02:24:07 --> Language Class Initialized
INFO - 2022-01-03 02:24:07 --> Loader Class Initialized
INFO - 2022-01-03 02:24:07 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:07 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:07 --> Controller Class Initialized
INFO - 2022-01-03 02:24:07 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:07 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:07 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:24:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:07 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:07 --> Total execution time: 0.0697
INFO - 2022-01-03 02:24:09 --> Config Class Initialized
INFO - 2022-01-03 02:24:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:09 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:09 --> URI Class Initialized
INFO - 2022-01-03 02:24:09 --> Router Class Initialized
INFO - 2022-01-03 02:24:09 --> Output Class Initialized
INFO - 2022-01-03 02:24:09 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:09 --> Input Class Initialized
INFO - 2022-01-03 02:24:09 --> Language Class Initialized
INFO - 2022-01-03 02:24:09 --> Loader Class Initialized
INFO - 2022-01-03 02:24:09 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:09 --> Controller Class Initialized
INFO - 2022-01-03 02:24:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:09 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:09 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-03 02:24:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:09 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:09 --> Total execution time: 0.0811
INFO - 2022-01-03 02:24:11 --> Config Class Initialized
INFO - 2022-01-03 02:24:11 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:11 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:11 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:11 --> URI Class Initialized
INFO - 2022-01-03 02:24:11 --> Router Class Initialized
INFO - 2022-01-03 02:24:11 --> Output Class Initialized
INFO - 2022-01-03 02:24:11 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:11 --> Input Class Initialized
INFO - 2022-01-03 02:24:11 --> Language Class Initialized
INFO - 2022-01-03 02:24:11 --> Loader Class Initialized
INFO - 2022-01-03 02:24:11 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:11 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:11 --> Controller Class Initialized
INFO - 2022-01-03 02:24:11 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:11 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:11 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 02:24:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:11 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:11 --> Total execution time: 0.0572
INFO - 2022-01-03 02:24:12 --> Config Class Initialized
INFO - 2022-01-03 02:24:12 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:12 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:12 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:12 --> URI Class Initialized
DEBUG - 2022-01-03 02:24:12 --> No URI present. Default controller set.
INFO - 2022-01-03 02:24:12 --> Router Class Initialized
INFO - 2022-01-03 02:24:12 --> Output Class Initialized
INFO - 2022-01-03 02:24:12 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:12 --> Input Class Initialized
INFO - 2022-01-03 02:24:12 --> Language Class Initialized
INFO - 2022-01-03 02:24:12 --> Loader Class Initialized
INFO - 2022-01-03 02:24:12 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:12 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:12 --> Controller Class Initialized
INFO - 2022-01-03 02:24:12 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:12 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:12 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:24:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:12 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:12 --> Total execution time: 0.0520
INFO - 2022-01-03 02:24:15 --> Config Class Initialized
INFO - 2022-01-03 02:24:15 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:15 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:15 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:15 --> URI Class Initialized
INFO - 2022-01-03 02:24:15 --> Router Class Initialized
INFO - 2022-01-03 02:24:15 --> Output Class Initialized
INFO - 2022-01-03 02:24:15 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:15 --> Input Class Initialized
INFO - 2022-01-03 02:24:15 --> Language Class Initialized
INFO - 2022-01-03 02:24:15 --> Loader Class Initialized
INFO - 2022-01-03 02:24:15 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:15 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:15 --> Controller Class Initialized
INFO - 2022-01-03 02:24:15 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:15 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:15 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:15 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:15 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-03 02:24:15 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:15 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:15 --> Total execution time: 0.0555
INFO - 2022-01-03 02:24:17 --> Config Class Initialized
INFO - 2022-01-03 02:24:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:17 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:17 --> URI Class Initialized
INFO - 2022-01-03 02:24:17 --> Router Class Initialized
INFO - 2022-01-03 02:24:17 --> Output Class Initialized
INFO - 2022-01-03 02:24:17 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:17 --> Input Class Initialized
INFO - 2022-01-03 02:24:17 --> Language Class Initialized
INFO - 2022-01-03 02:24:17 --> Loader Class Initialized
INFO - 2022-01-03 02:24:17 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:17 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:17 --> Controller Class Initialized
INFO - 2022-01-03 02:24:17 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:17 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:17 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 02:24:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:17 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:17 --> Total execution time: 0.0703
INFO - 2022-01-03 02:24:21 --> Config Class Initialized
INFO - 2022-01-03 02:24:21 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:24:21 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:24:21 --> Utf8 Class Initialized
INFO - 2022-01-03 02:24:21 --> URI Class Initialized
DEBUG - 2022-01-03 02:24:21 --> No URI present. Default controller set.
INFO - 2022-01-03 02:24:21 --> Router Class Initialized
INFO - 2022-01-03 02:24:21 --> Output Class Initialized
INFO - 2022-01-03 02:24:21 --> Security Class Initialized
DEBUG - 2022-01-03 02:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:24:21 --> Input Class Initialized
INFO - 2022-01-03 02:24:21 --> Language Class Initialized
INFO - 2022-01-03 02:24:21 --> Loader Class Initialized
INFO - 2022-01-03 02:24:21 --> Helper loaded: url_helper
INFO - 2022-01-03 02:24:21 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:24:21 --> Controller Class Initialized
INFO - 2022-01-03 02:24:21 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:24:21 --> Model "UserModel" initialized
INFO - 2022-01-03 02:24:21 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:24:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:24:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:24:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:24:21 --> Final output sent to browser
DEBUG - 2022-01-03 02:24:21 --> Total execution time: 0.0476
INFO - 2022-01-03 02:28:16 --> Config Class Initialized
INFO - 2022-01-03 02:28:16 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:28:16 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:28:16 --> Utf8 Class Initialized
INFO - 2022-01-03 02:28:16 --> URI Class Initialized
INFO - 2022-01-03 02:28:16 --> Router Class Initialized
INFO - 2022-01-03 02:28:16 --> Output Class Initialized
INFO - 2022-01-03 02:28:16 --> Security Class Initialized
DEBUG - 2022-01-03 02:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:28:16 --> Input Class Initialized
INFO - 2022-01-03 02:28:16 --> Language Class Initialized
INFO - 2022-01-03 02:28:16 --> Loader Class Initialized
INFO - 2022-01-03 02:28:16 --> Helper loaded: url_helper
INFO - 2022-01-03 02:28:16 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:28:16 --> Controller Class Initialized
INFO - 2022-01-03 02:28:16 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:28:16 --> Model "UserModel" initialized
INFO - 2022-01-03 02:28:16 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:28:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:28:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 02:28:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:28:16 --> Final output sent to browser
DEBUG - 2022-01-03 02:28:16 --> Total execution time: 0.0598
INFO - 2022-01-03 02:28:20 --> Config Class Initialized
INFO - 2022-01-03 02:28:20 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:28:20 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:28:20 --> Utf8 Class Initialized
INFO - 2022-01-03 02:28:20 --> URI Class Initialized
INFO - 2022-01-03 02:28:20 --> Router Class Initialized
INFO - 2022-01-03 02:28:20 --> Output Class Initialized
INFO - 2022-01-03 02:28:20 --> Security Class Initialized
DEBUG - 2022-01-03 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:28:20 --> Input Class Initialized
INFO - 2022-01-03 02:28:20 --> Language Class Initialized
INFO - 2022-01-03 02:28:20 --> Loader Class Initialized
INFO - 2022-01-03 02:28:20 --> Helper loaded: url_helper
INFO - 2022-01-03 02:28:20 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:28:20 --> Controller Class Initialized
INFO - 2022-01-03 02:28:20 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:28:20 --> Model "UserModel" initialized
INFO - 2022-01-03 02:28:20 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:28:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:28:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-03 02:28:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:28:20 --> Final output sent to browser
DEBUG - 2022-01-03 02:28:20 --> Total execution time: 0.0553
INFO - 2022-01-03 02:28:22 --> Config Class Initialized
INFO - 2022-01-03 02:28:22 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:28:22 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:28:22 --> Utf8 Class Initialized
INFO - 2022-01-03 02:28:22 --> URI Class Initialized
INFO - 2022-01-03 02:28:22 --> Router Class Initialized
INFO - 2022-01-03 02:28:22 --> Output Class Initialized
INFO - 2022-01-03 02:28:22 --> Security Class Initialized
DEBUG - 2022-01-03 02:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:28:22 --> Input Class Initialized
INFO - 2022-01-03 02:28:22 --> Language Class Initialized
INFO - 2022-01-03 02:28:22 --> Loader Class Initialized
INFO - 2022-01-03 02:28:22 --> Helper loaded: url_helper
INFO - 2022-01-03 02:28:22 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:28:22 --> Controller Class Initialized
INFO - 2022-01-03 02:28:22 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:28:22 --> Model "UserModel" initialized
INFO - 2022-01-03 02:28:22 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:28:22 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:28:22 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 02:28:22 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:28:22 --> Final output sent to browser
DEBUG - 2022-01-03 02:28:22 --> Total execution time: 0.0563
INFO - 2022-01-03 02:28:23 --> Config Class Initialized
INFO - 2022-01-03 02:28:23 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:28:23 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:28:23 --> Utf8 Class Initialized
INFO - 2022-01-03 02:28:23 --> URI Class Initialized
INFO - 2022-01-03 02:28:23 --> Router Class Initialized
INFO - 2022-01-03 02:28:23 --> Output Class Initialized
INFO - 2022-01-03 02:28:23 --> Security Class Initialized
DEBUG - 2022-01-03 02:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:28:23 --> Input Class Initialized
INFO - 2022-01-03 02:28:23 --> Language Class Initialized
INFO - 2022-01-03 02:28:23 --> Loader Class Initialized
INFO - 2022-01-03 02:28:23 --> Helper loaded: url_helper
INFO - 2022-01-03 02:28:23 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:28:23 --> Controller Class Initialized
INFO - 2022-01-03 02:28:23 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:28:23 --> Model "UserModel" initialized
INFO - 2022-01-03 02:28:23 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:28:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:28:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 02:28:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:28:23 --> Final output sent to browser
DEBUG - 2022-01-03 02:28:23 --> Total execution time: 0.0675
INFO - 2022-01-03 02:28:53 --> Config Class Initialized
INFO - 2022-01-03 02:28:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:28:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:28:53 --> Utf8 Class Initialized
INFO - 2022-01-03 02:28:53 --> URI Class Initialized
DEBUG - 2022-01-03 02:28:53 --> No URI present. Default controller set.
INFO - 2022-01-03 02:28:53 --> Router Class Initialized
INFO - 2022-01-03 02:28:53 --> Output Class Initialized
INFO - 2022-01-03 02:28:53 --> Security Class Initialized
DEBUG - 2022-01-03 02:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:28:53 --> Input Class Initialized
INFO - 2022-01-03 02:28:53 --> Language Class Initialized
INFO - 2022-01-03 02:28:53 --> Loader Class Initialized
INFO - 2022-01-03 02:28:53 --> Helper loaded: url_helper
INFO - 2022-01-03 02:28:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:28:53 --> Controller Class Initialized
INFO - 2022-01-03 02:28:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:28:53 --> Model "UserModel" initialized
INFO - 2022-01-03 02:28:53 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:28:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:28:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:28:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:28:53 --> Final output sent to browser
DEBUG - 2022-01-03 02:28:53 --> Total execution time: 0.0459
INFO - 2022-01-03 02:29:08 --> Config Class Initialized
INFO - 2022-01-03 02:29:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:08 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:08 --> URI Class Initialized
DEBUG - 2022-01-03 02:29:08 --> No URI present. Default controller set.
INFO - 2022-01-03 02:29:08 --> Router Class Initialized
INFO - 2022-01-03 02:29:08 --> Output Class Initialized
INFO - 2022-01-03 02:29:08 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:08 --> Input Class Initialized
INFO - 2022-01-03 02:29:08 --> Language Class Initialized
INFO - 2022-01-03 02:29:08 --> Loader Class Initialized
INFO - 2022-01-03 02:29:08 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:08 --> Controller Class Initialized
INFO - 2022-01-03 02:29:08 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:08 --> Model "UserModel" initialized
INFO - 2022-01-03 02:29:08 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:29:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:29:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:29:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:29:08 --> Final output sent to browser
DEBUG - 2022-01-03 02:29:08 --> Total execution time: 0.0761
INFO - 2022-01-03 02:29:10 --> Config Class Initialized
INFO - 2022-01-03 02:29:10 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:10 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:10 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:10 --> URI Class Initialized
INFO - 2022-01-03 02:29:10 --> Router Class Initialized
INFO - 2022-01-03 02:29:10 --> Output Class Initialized
INFO - 2022-01-03 02:29:10 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:10 --> Input Class Initialized
INFO - 2022-01-03 02:29:10 --> Language Class Initialized
INFO - 2022-01-03 02:29:10 --> Loader Class Initialized
INFO - 2022-01-03 02:29:10 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:11 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:11 --> Controller Class Initialized
INFO - 2022-01-03 02:29:11 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:11 --> Config Class Initialized
INFO - 2022-01-03 02:29:11 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:11 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:11 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:11 --> URI Class Initialized
INFO - 2022-01-03 02:29:11 --> Router Class Initialized
INFO - 2022-01-03 02:29:11 --> Output Class Initialized
INFO - 2022-01-03 02:29:11 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:11 --> Input Class Initialized
INFO - 2022-01-03 02:29:11 --> Language Class Initialized
INFO - 2022-01-03 02:29:11 --> Loader Class Initialized
INFO - 2022-01-03 02:29:11 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:11 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:11 --> Controller Class Initialized
INFO - 2022-01-03 02:29:11 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 02:29:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 02:29:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:29:11 --> Final output sent to browser
DEBUG - 2022-01-03 02:29:11 --> Total execution time: 0.0554
INFO - 2022-01-03 02:29:17 --> Config Class Initialized
INFO - 2022-01-03 02:29:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:17 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:17 --> URI Class Initialized
INFO - 2022-01-03 02:29:17 --> Router Class Initialized
INFO - 2022-01-03 02:29:17 --> Output Class Initialized
INFO - 2022-01-03 02:29:17 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:17 --> Input Class Initialized
INFO - 2022-01-03 02:29:17 --> Language Class Initialized
INFO - 2022-01-03 02:29:17 --> Loader Class Initialized
INFO - 2022-01-03 02:29:17 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:17 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:17 --> Controller Class Initialized
INFO - 2022-01-03 02:29:17 --> Model "LoginModel" initialized
ERROR - 2022-01-03 02:29:17 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 43
INFO - 2022-01-03 02:29:17 --> Config Class Initialized
INFO - 2022-01-03 02:29:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:17 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:17 --> URI Class Initialized
DEBUG - 2022-01-03 02:29:17 --> No URI present. Default controller set.
INFO - 2022-01-03 02:29:17 --> Router Class Initialized
INFO - 2022-01-03 02:29:17 --> Output Class Initialized
INFO - 2022-01-03 02:29:17 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:17 --> Input Class Initialized
INFO - 2022-01-03 02:29:17 --> Language Class Initialized
INFO - 2022-01-03 02:29:17 --> Loader Class Initialized
INFO - 2022-01-03 02:29:17 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:17 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:17 --> Controller Class Initialized
INFO - 2022-01-03 02:29:17 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:17 --> Model "UserModel" initialized
INFO - 2022-01-03 02:29:17 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:29:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:29:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:29:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:29:17 --> Final output sent to browser
DEBUG - 2022-01-03 02:29:17 --> Total execution time: 0.0497
INFO - 2022-01-03 02:29:19 --> Config Class Initialized
INFO - 2022-01-03 02:29:19 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:19 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:19 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:19 --> URI Class Initialized
DEBUG - 2022-01-03 02:29:19 --> No URI present. Default controller set.
INFO - 2022-01-03 02:29:19 --> Router Class Initialized
INFO - 2022-01-03 02:29:19 --> Output Class Initialized
INFO - 2022-01-03 02:29:19 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:19 --> Input Class Initialized
INFO - 2022-01-03 02:29:19 --> Language Class Initialized
INFO - 2022-01-03 02:29:19 --> Loader Class Initialized
INFO - 2022-01-03 02:29:19 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:19 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:19 --> Controller Class Initialized
INFO - 2022-01-03 02:29:19 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:19 --> Model "UserModel" initialized
INFO - 2022-01-03 02:29:19 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:29:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:29:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:29:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:29:19 --> Final output sent to browser
DEBUG - 2022-01-03 02:29:19 --> Total execution time: 0.0609
INFO - 2022-01-03 02:29:21 --> Config Class Initialized
INFO - 2022-01-03 02:29:21 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:21 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:21 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:21 --> URI Class Initialized
INFO - 2022-01-03 02:29:21 --> Router Class Initialized
INFO - 2022-01-03 02:29:21 --> Output Class Initialized
INFO - 2022-01-03 02:29:21 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:21 --> Input Class Initialized
INFO - 2022-01-03 02:29:21 --> Language Class Initialized
INFO - 2022-01-03 02:29:21 --> Loader Class Initialized
INFO - 2022-01-03 02:29:21 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:21 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:21 --> Controller Class Initialized
INFO - 2022-01-03 02:29:21 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:21 --> Model "UserModel" initialized
INFO - 2022-01-03 02:29:21 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:29:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:29:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 02:29:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:29:21 --> Final output sent to browser
DEBUG - 2022-01-03 02:29:21 --> Total execution time: 0.0540
INFO - 2022-01-03 02:29:23 --> Config Class Initialized
INFO - 2022-01-03 02:29:23 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:23 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:23 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:23 --> URI Class Initialized
DEBUG - 2022-01-03 02:29:23 --> No URI present. Default controller set.
INFO - 2022-01-03 02:29:23 --> Router Class Initialized
INFO - 2022-01-03 02:29:23 --> Output Class Initialized
INFO - 2022-01-03 02:29:23 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:23 --> Input Class Initialized
INFO - 2022-01-03 02:29:23 --> Language Class Initialized
INFO - 2022-01-03 02:29:23 --> Loader Class Initialized
INFO - 2022-01-03 02:29:23 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:23 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:23 --> Controller Class Initialized
INFO - 2022-01-03 02:29:23 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:23 --> Model "UserModel" initialized
INFO - 2022-01-03 02:29:23 --> Model "AdminModel" initialized
INFO - 2022-01-03 02:29:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 02:29:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 02:29:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:29:23 --> Final output sent to browser
DEBUG - 2022-01-03 02:29:23 --> Total execution time: 0.0494
INFO - 2022-01-03 02:29:26 --> Config Class Initialized
INFO - 2022-01-03 02:29:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:26 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:26 --> URI Class Initialized
INFO - 2022-01-03 02:29:26 --> Router Class Initialized
INFO - 2022-01-03 02:29:26 --> Output Class Initialized
INFO - 2022-01-03 02:29:26 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:26 --> Input Class Initialized
INFO - 2022-01-03 02:29:26 --> Language Class Initialized
INFO - 2022-01-03 02:29:26 --> Loader Class Initialized
INFO - 2022-01-03 02:29:26 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:26 --> Controller Class Initialized
INFO - 2022-01-03 02:29:26 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:26 --> Config Class Initialized
INFO - 2022-01-03 02:29:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 02:29:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 02:29:26 --> Utf8 Class Initialized
INFO - 2022-01-03 02:29:26 --> URI Class Initialized
INFO - 2022-01-03 02:29:26 --> Router Class Initialized
INFO - 2022-01-03 02:29:26 --> Output Class Initialized
INFO - 2022-01-03 02:29:26 --> Security Class Initialized
DEBUG - 2022-01-03 02:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 02:29:26 --> Input Class Initialized
INFO - 2022-01-03 02:29:26 --> Language Class Initialized
INFO - 2022-01-03 02:29:26 --> Loader Class Initialized
INFO - 2022-01-03 02:29:26 --> Helper loaded: url_helper
INFO - 2022-01-03 02:29:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 02:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 02:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 02:29:26 --> Controller Class Initialized
INFO - 2022-01-03 02:29:26 --> Model "LoginModel" initialized
INFO - 2022-01-03 02:29:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 02:29:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 02:29:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 02:29:26 --> Final output sent to browser
DEBUG - 2022-01-03 02:29:26 --> Total execution time: 0.0512
INFO - 2022-01-03 03:52:08 --> Config Class Initialized
INFO - 2022-01-03 03:52:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:52:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:52:08 --> Utf8 Class Initialized
INFO - 2022-01-03 03:52:08 --> URI Class Initialized
INFO - 2022-01-03 03:52:08 --> Router Class Initialized
INFO - 2022-01-03 03:52:08 --> Output Class Initialized
INFO - 2022-01-03 03:52:08 --> Security Class Initialized
DEBUG - 2022-01-03 03:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:52:08 --> Input Class Initialized
INFO - 2022-01-03 03:52:08 --> Language Class Initialized
INFO - 2022-01-03 03:52:08 --> Loader Class Initialized
INFO - 2022-01-03 03:52:08 --> Helper loaded: url_helper
INFO - 2022-01-03 03:52:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:52:08 --> Controller Class Initialized
INFO - 2022-01-03 03:52:08 --> Model "LoginModel" initialized
ERROR - 2022-01-03 03:52:09 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 43
INFO - 2022-01-03 03:52:09 --> Config Class Initialized
INFO - 2022-01-03 03:52:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:52:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:52:09 --> Utf8 Class Initialized
INFO - 2022-01-03 03:52:09 --> URI Class Initialized
DEBUG - 2022-01-03 03:52:09 --> No URI present. Default controller set.
INFO - 2022-01-03 03:52:09 --> Router Class Initialized
INFO - 2022-01-03 03:52:09 --> Output Class Initialized
INFO - 2022-01-03 03:52:09 --> Security Class Initialized
DEBUG - 2022-01-03 03:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:52:09 --> Input Class Initialized
INFO - 2022-01-03 03:52:09 --> Language Class Initialized
INFO - 2022-01-03 03:52:09 --> Loader Class Initialized
INFO - 2022-01-03 03:52:09 --> Helper loaded: url_helper
INFO - 2022-01-03 03:52:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:52:09 --> Controller Class Initialized
INFO - 2022-01-03 03:52:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 03:52:09 --> Model "UserModel" initialized
INFO - 2022-01-03 03:52:09 --> Model "AdminModel" initialized
INFO - 2022-01-03 03:52:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 03:52:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 03:52:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 03:52:09 --> Final output sent to browser
DEBUG - 2022-01-03 03:52:09 --> Total execution time: 0.1268
INFO - 2022-01-03 03:52:12 --> Config Class Initialized
INFO - 2022-01-03 03:52:12 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:52:12 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:52:12 --> Utf8 Class Initialized
INFO - 2022-01-03 03:52:12 --> URI Class Initialized
INFO - 2022-01-03 03:52:12 --> Router Class Initialized
INFO - 2022-01-03 03:52:12 --> Output Class Initialized
INFO - 2022-01-03 03:52:12 --> Security Class Initialized
DEBUG - 2022-01-03 03:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:52:12 --> Input Class Initialized
INFO - 2022-01-03 03:52:12 --> Language Class Initialized
INFO - 2022-01-03 03:52:12 --> Loader Class Initialized
INFO - 2022-01-03 03:52:12 --> Helper loaded: url_helper
INFO - 2022-01-03 03:52:12 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:52:12 --> Controller Class Initialized
INFO - 2022-01-03 03:52:12 --> Model "LoginModel" initialized
INFO - 2022-01-03 03:52:12 --> Model "UserModel" initialized
INFO - 2022-01-03 03:52:12 --> Model "AdminModel" initialized
INFO - 2022-01-03 03:52:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 03:52:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 03:52:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 03:52:12 --> Final output sent to browser
DEBUG - 2022-01-03 03:52:12 --> Total execution time: 0.0783
INFO - 2022-01-03 03:52:13 --> Config Class Initialized
INFO - 2022-01-03 03:52:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:52:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:52:13 --> Utf8 Class Initialized
INFO - 2022-01-03 03:52:13 --> URI Class Initialized
INFO - 2022-01-03 03:52:13 --> Router Class Initialized
INFO - 2022-01-03 03:52:13 --> Output Class Initialized
INFO - 2022-01-03 03:52:13 --> Security Class Initialized
DEBUG - 2022-01-03 03:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:52:13 --> Input Class Initialized
INFO - 2022-01-03 03:52:13 --> Language Class Initialized
INFO - 2022-01-03 03:52:13 --> Loader Class Initialized
INFO - 2022-01-03 03:52:13 --> Helper loaded: url_helper
INFO - 2022-01-03 03:52:13 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:52:13 --> Controller Class Initialized
INFO - 2022-01-03 03:52:13 --> Model "LoginModel" initialized
INFO - 2022-01-03 03:52:13 --> Model "UserModel" initialized
INFO - 2022-01-03 03:52:13 --> Model "AdminModel" initialized
INFO - 2022-01-03 03:52:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 03:52:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-03 03:52:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 03:52:13 --> Final output sent to browser
DEBUG - 2022-01-03 03:52:13 --> Total execution time: 0.0656
INFO - 2022-01-03 03:52:16 --> Config Class Initialized
INFO - 2022-01-03 03:52:16 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:52:16 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:52:16 --> Utf8 Class Initialized
INFO - 2022-01-03 03:52:16 --> URI Class Initialized
INFO - 2022-01-03 03:52:16 --> Router Class Initialized
INFO - 2022-01-03 03:52:16 --> Output Class Initialized
INFO - 2022-01-03 03:52:16 --> Security Class Initialized
DEBUG - 2022-01-03 03:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:52:16 --> Input Class Initialized
INFO - 2022-01-03 03:52:16 --> Language Class Initialized
INFO - 2022-01-03 03:52:16 --> Loader Class Initialized
INFO - 2022-01-03 03:52:16 --> Helper loaded: url_helper
INFO - 2022-01-03 03:52:16 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:52:16 --> Controller Class Initialized
INFO - 2022-01-03 03:52:16 --> Model "LoginModel" initialized
INFO - 2022-01-03 03:52:16 --> Config Class Initialized
INFO - 2022-01-03 03:52:16 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:52:16 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:52:16 --> Utf8 Class Initialized
INFO - 2022-01-03 03:52:16 --> URI Class Initialized
INFO - 2022-01-03 03:52:16 --> Router Class Initialized
INFO - 2022-01-03 03:52:16 --> Output Class Initialized
INFO - 2022-01-03 03:52:16 --> Security Class Initialized
DEBUG - 2022-01-03 03:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:52:16 --> Input Class Initialized
INFO - 2022-01-03 03:52:16 --> Language Class Initialized
INFO - 2022-01-03 03:52:16 --> Loader Class Initialized
INFO - 2022-01-03 03:52:16 --> Helper loaded: url_helper
INFO - 2022-01-03 03:52:16 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:52:16 --> Controller Class Initialized
INFO - 2022-01-03 03:52:16 --> Model "LoginModel" initialized
INFO - 2022-01-03 03:52:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 03:52:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 03:52:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 03:52:16 --> Final output sent to browser
DEBUG - 2022-01-03 03:52:16 --> Total execution time: 0.1014
INFO - 2022-01-03 03:58:42 --> Config Class Initialized
INFO - 2022-01-03 03:58:42 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:58:42 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:58:42 --> Utf8 Class Initialized
INFO - 2022-01-03 03:58:42 --> URI Class Initialized
INFO - 2022-01-03 03:58:42 --> Router Class Initialized
INFO - 2022-01-03 03:58:42 --> Output Class Initialized
INFO - 2022-01-03 03:58:42 --> Security Class Initialized
DEBUG - 2022-01-03 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:58:42 --> Input Class Initialized
INFO - 2022-01-03 03:58:42 --> Language Class Initialized
INFO - 2022-01-03 03:58:42 --> Loader Class Initialized
INFO - 2022-01-03 03:58:42 --> Helper loaded: url_helper
INFO - 2022-01-03 03:58:42 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:58:42 --> Controller Class Initialized
INFO - 2022-01-03 03:58:42 --> Model "LoginModel" initialized
INFO - 2022-01-03 03:58:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 03:58:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 03:58:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 03:58:42 --> Final output sent to browser
DEBUG - 2022-01-03 03:58:42 --> Total execution time: 0.0539
INFO - 2022-01-03 03:58:43 --> Config Class Initialized
INFO - 2022-01-03 03:58:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:58:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:58:43 --> Utf8 Class Initialized
INFO - 2022-01-03 03:58:43 --> URI Class Initialized
INFO - 2022-01-03 03:58:43 --> Router Class Initialized
INFO - 2022-01-03 03:58:43 --> Output Class Initialized
INFO - 2022-01-03 03:58:43 --> Security Class Initialized
DEBUG - 2022-01-03 03:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:58:43 --> Input Class Initialized
INFO - 2022-01-03 03:58:43 --> Language Class Initialized
INFO - 2022-01-03 03:58:43 --> Loader Class Initialized
INFO - 2022-01-03 03:58:43 --> Helper loaded: url_helper
INFO - 2022-01-03 03:58:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:58:43 --> Controller Class Initialized
INFO - 2022-01-03 03:58:43 --> Model "LoginModel" initialized
INFO - 2022-01-03 03:58:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 03:58:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 03:58:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 03:58:43 --> Final output sent to browser
DEBUG - 2022-01-03 03:58:43 --> Total execution time: 0.0499
INFO - 2022-01-03 03:58:44 --> Config Class Initialized
INFO - 2022-01-03 03:58:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 03:58:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 03:58:44 --> Utf8 Class Initialized
INFO - 2022-01-03 03:58:44 --> URI Class Initialized
INFO - 2022-01-03 03:58:44 --> Router Class Initialized
INFO - 2022-01-03 03:58:44 --> Output Class Initialized
INFO - 2022-01-03 03:58:44 --> Security Class Initialized
DEBUG - 2022-01-03 03:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 03:58:44 --> Input Class Initialized
INFO - 2022-01-03 03:58:44 --> Language Class Initialized
INFO - 2022-01-03 03:58:44 --> Loader Class Initialized
INFO - 2022-01-03 03:58:44 --> Helper loaded: url_helper
INFO - 2022-01-03 03:58:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 03:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 03:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 03:58:44 --> Controller Class Initialized
INFO - 2022-01-03 03:58:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 03:58:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 03:58:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 03:58:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 03:58:44 --> Final output sent to browser
DEBUG - 2022-01-03 03:58:44 --> Total execution time: 0.0736
INFO - 2022-01-03 04:00:56 --> Config Class Initialized
INFO - 2022-01-03 04:00:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:00:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:00:56 --> Utf8 Class Initialized
INFO - 2022-01-03 04:00:56 --> URI Class Initialized
INFO - 2022-01-03 04:00:56 --> Router Class Initialized
INFO - 2022-01-03 04:00:56 --> Output Class Initialized
INFO - 2022-01-03 04:00:56 --> Security Class Initialized
DEBUG - 2022-01-03 04:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:00:56 --> Input Class Initialized
INFO - 2022-01-03 04:00:56 --> Language Class Initialized
INFO - 2022-01-03 04:00:56 --> Loader Class Initialized
INFO - 2022-01-03 04:00:56 --> Helper loaded: url_helper
INFO - 2022-01-03 04:00:56 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:00:56 --> Controller Class Initialized
INFO - 2022-01-03 04:00:56 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:00:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:00:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:00:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:00:56 --> Final output sent to browser
DEBUG - 2022-01-03 04:00:56 --> Total execution time: 0.0522
INFO - 2022-01-03 04:02:22 --> Config Class Initialized
INFO - 2022-01-03 04:02:22 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:02:22 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:02:22 --> Utf8 Class Initialized
INFO - 2022-01-03 04:02:22 --> URI Class Initialized
INFO - 2022-01-03 04:02:22 --> Router Class Initialized
INFO - 2022-01-03 04:02:22 --> Output Class Initialized
INFO - 2022-01-03 04:02:22 --> Security Class Initialized
DEBUG - 2022-01-03 04:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:02:22 --> Input Class Initialized
INFO - 2022-01-03 04:02:22 --> Language Class Initialized
INFO - 2022-01-03 04:02:22 --> Loader Class Initialized
INFO - 2022-01-03 04:02:22 --> Helper loaded: url_helper
INFO - 2022-01-03 04:02:22 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:02:22 --> Controller Class Initialized
INFO - 2022-01-03 04:02:22 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:02:22 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:02:22 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:02:22 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:02:22 --> Final output sent to browser
DEBUG - 2022-01-03 04:02:22 --> Total execution time: 0.0456
INFO - 2022-01-03 04:03:41 --> Config Class Initialized
INFO - 2022-01-03 04:03:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:03:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:03:41 --> Utf8 Class Initialized
INFO - 2022-01-03 04:03:41 --> URI Class Initialized
INFO - 2022-01-03 04:03:41 --> Router Class Initialized
INFO - 2022-01-03 04:03:41 --> Output Class Initialized
INFO - 2022-01-03 04:03:41 --> Security Class Initialized
DEBUG - 2022-01-03 04:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:03:41 --> Input Class Initialized
INFO - 2022-01-03 04:03:41 --> Language Class Initialized
INFO - 2022-01-03 04:03:41 --> Loader Class Initialized
INFO - 2022-01-03 04:03:41 --> Helper loaded: url_helper
INFO - 2022-01-03 04:03:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:03:41 --> Controller Class Initialized
INFO - 2022-01-03 04:03:41 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:03:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:03:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:03:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:03:41 --> Final output sent to browser
DEBUG - 2022-01-03 04:03:41 --> Total execution time: 0.0619
INFO - 2022-01-03 04:03:46 --> Config Class Initialized
INFO - 2022-01-03 04:03:46 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:03:46 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:03:46 --> Utf8 Class Initialized
INFO - 2022-01-03 04:03:46 --> URI Class Initialized
INFO - 2022-01-03 04:03:46 --> Router Class Initialized
INFO - 2022-01-03 04:03:46 --> Output Class Initialized
INFO - 2022-01-03 04:03:46 --> Security Class Initialized
DEBUG - 2022-01-03 04:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:03:46 --> Input Class Initialized
INFO - 2022-01-03 04:03:46 --> Language Class Initialized
INFO - 2022-01-03 04:03:46 --> Loader Class Initialized
INFO - 2022-01-03 04:03:46 --> Helper loaded: url_helper
INFO - 2022-01-03 04:03:46 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:03:46 --> Controller Class Initialized
INFO - 2022-01-03 04:03:46 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:03:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:03:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:03:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:03:46 --> Final output sent to browser
DEBUG - 2022-01-03 04:03:46 --> Total execution time: 0.0511
INFO - 2022-01-03 04:03:53 --> Config Class Initialized
INFO - 2022-01-03 04:03:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:03:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:03:53 --> Utf8 Class Initialized
INFO - 2022-01-03 04:03:53 --> URI Class Initialized
INFO - 2022-01-03 04:03:53 --> Router Class Initialized
INFO - 2022-01-03 04:03:53 --> Output Class Initialized
INFO - 2022-01-03 04:03:53 --> Security Class Initialized
DEBUG - 2022-01-03 04:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:03:53 --> Input Class Initialized
INFO - 2022-01-03 04:03:53 --> Language Class Initialized
INFO - 2022-01-03 04:03:53 --> Loader Class Initialized
INFO - 2022-01-03 04:03:53 --> Helper loaded: url_helper
INFO - 2022-01-03 04:03:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:03:53 --> Controller Class Initialized
INFO - 2022-01-03 04:03:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:03:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:03:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:03:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:03:53 --> Final output sent to browser
DEBUG - 2022-01-03 04:03:53 --> Total execution time: 0.0538
INFO - 2022-01-03 04:05:11 --> Config Class Initialized
INFO - 2022-01-03 04:05:11 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:05:11 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:05:11 --> Utf8 Class Initialized
INFO - 2022-01-03 04:05:11 --> URI Class Initialized
INFO - 2022-01-03 04:05:11 --> Router Class Initialized
INFO - 2022-01-03 04:05:11 --> Output Class Initialized
INFO - 2022-01-03 04:05:11 --> Security Class Initialized
DEBUG - 2022-01-03 04:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:05:11 --> Input Class Initialized
INFO - 2022-01-03 04:05:11 --> Language Class Initialized
INFO - 2022-01-03 04:05:11 --> Loader Class Initialized
INFO - 2022-01-03 04:05:11 --> Helper loaded: url_helper
INFO - 2022-01-03 04:05:11 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:05:11 --> Controller Class Initialized
INFO - 2022-01-03 04:05:11 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:05:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:05:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:05:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:05:11 --> Final output sent to browser
DEBUG - 2022-01-03 04:05:11 --> Total execution time: 0.0508
INFO - 2022-01-03 04:05:12 --> Config Class Initialized
INFO - 2022-01-03 04:05:12 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:05:12 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:05:12 --> Utf8 Class Initialized
INFO - 2022-01-03 04:05:12 --> URI Class Initialized
INFO - 2022-01-03 04:05:12 --> Router Class Initialized
INFO - 2022-01-03 04:05:12 --> Output Class Initialized
INFO - 2022-01-03 04:05:12 --> Security Class Initialized
DEBUG - 2022-01-03 04:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:05:12 --> Input Class Initialized
INFO - 2022-01-03 04:05:12 --> Language Class Initialized
INFO - 2022-01-03 04:05:12 --> Loader Class Initialized
INFO - 2022-01-03 04:05:12 --> Helper loaded: url_helper
INFO - 2022-01-03 04:05:12 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:05:12 --> Controller Class Initialized
INFO - 2022-01-03 04:05:12 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:05:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:05:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:05:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:05:12 --> Final output sent to browser
DEBUG - 2022-01-03 04:05:12 --> Total execution time: 0.0530
INFO - 2022-01-03 04:05:23 --> Config Class Initialized
INFO - 2022-01-03 04:05:23 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:05:23 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:05:23 --> Utf8 Class Initialized
INFO - 2022-01-03 04:05:23 --> URI Class Initialized
INFO - 2022-01-03 04:05:23 --> Router Class Initialized
INFO - 2022-01-03 04:05:23 --> Output Class Initialized
INFO - 2022-01-03 04:05:23 --> Security Class Initialized
DEBUG - 2022-01-03 04:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:05:23 --> Input Class Initialized
INFO - 2022-01-03 04:05:23 --> Language Class Initialized
INFO - 2022-01-03 04:05:23 --> Loader Class Initialized
INFO - 2022-01-03 04:05:23 --> Helper loaded: url_helper
INFO - 2022-01-03 04:05:23 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:05:23 --> Controller Class Initialized
INFO - 2022-01-03 04:05:23 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:05:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:05:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:05:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:05:23 --> Final output sent to browser
DEBUG - 2022-01-03 04:05:23 --> Total execution time: 0.0626
INFO - 2022-01-03 04:06:15 --> Config Class Initialized
INFO - 2022-01-03 04:06:15 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:06:15 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:06:15 --> Utf8 Class Initialized
INFO - 2022-01-03 04:06:15 --> URI Class Initialized
INFO - 2022-01-03 04:06:15 --> Router Class Initialized
INFO - 2022-01-03 04:06:15 --> Output Class Initialized
INFO - 2022-01-03 04:06:15 --> Security Class Initialized
DEBUG - 2022-01-03 04:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:06:15 --> Input Class Initialized
INFO - 2022-01-03 04:06:15 --> Language Class Initialized
INFO - 2022-01-03 04:06:15 --> Loader Class Initialized
INFO - 2022-01-03 04:06:15 --> Helper loaded: url_helper
INFO - 2022-01-03 04:06:15 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:06:15 --> Controller Class Initialized
INFO - 2022-01-03 04:06:15 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:06:15 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:06:15 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:06:15 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:06:15 --> Final output sent to browser
DEBUG - 2022-01-03 04:06:15 --> Total execution time: 0.0475
INFO - 2022-01-03 04:06:50 --> Config Class Initialized
INFO - 2022-01-03 04:06:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:06:50 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:06:50 --> Utf8 Class Initialized
INFO - 2022-01-03 04:06:50 --> URI Class Initialized
INFO - 2022-01-03 04:06:50 --> Router Class Initialized
INFO - 2022-01-03 04:06:50 --> Output Class Initialized
INFO - 2022-01-03 04:06:50 --> Security Class Initialized
DEBUG - 2022-01-03 04:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:06:50 --> Input Class Initialized
INFO - 2022-01-03 04:06:50 --> Language Class Initialized
INFO - 2022-01-03 04:06:50 --> Loader Class Initialized
INFO - 2022-01-03 04:06:50 --> Helper loaded: url_helper
INFO - 2022-01-03 04:06:50 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:06:50 --> Controller Class Initialized
INFO - 2022-01-03 04:06:50 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:06:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:06:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:06:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:06:50 --> Final output sent to browser
DEBUG - 2022-01-03 04:06:50 --> Total execution time: 0.0724
INFO - 2022-01-03 04:07:36 --> Config Class Initialized
INFO - 2022-01-03 04:07:36 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:07:36 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:07:36 --> Utf8 Class Initialized
INFO - 2022-01-03 04:07:36 --> URI Class Initialized
INFO - 2022-01-03 04:07:36 --> Router Class Initialized
INFO - 2022-01-03 04:07:36 --> Output Class Initialized
INFO - 2022-01-03 04:07:36 --> Security Class Initialized
DEBUG - 2022-01-03 04:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:07:36 --> Input Class Initialized
INFO - 2022-01-03 04:07:36 --> Language Class Initialized
INFO - 2022-01-03 04:07:36 --> Loader Class Initialized
INFO - 2022-01-03 04:07:36 --> Helper loaded: url_helper
INFO - 2022-01-03 04:07:36 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:07:36 --> Controller Class Initialized
INFO - 2022-01-03 04:07:36 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:07:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:07:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:07:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:07:36 --> Final output sent to browser
DEBUG - 2022-01-03 04:07:36 --> Total execution time: 0.0486
INFO - 2022-01-03 04:09:32 --> Config Class Initialized
INFO - 2022-01-03 04:09:32 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:09:32 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:09:32 --> Utf8 Class Initialized
INFO - 2022-01-03 04:09:32 --> URI Class Initialized
INFO - 2022-01-03 04:09:32 --> Router Class Initialized
INFO - 2022-01-03 04:09:32 --> Output Class Initialized
INFO - 2022-01-03 04:09:32 --> Security Class Initialized
DEBUG - 2022-01-03 04:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:09:32 --> Input Class Initialized
INFO - 2022-01-03 04:09:32 --> Language Class Initialized
INFO - 2022-01-03 04:09:32 --> Loader Class Initialized
INFO - 2022-01-03 04:09:32 --> Helper loaded: url_helper
INFO - 2022-01-03 04:09:32 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:09:32 --> Controller Class Initialized
INFO - 2022-01-03 04:09:32 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:09:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:09:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:09:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:09:32 --> Final output sent to browser
DEBUG - 2022-01-03 04:09:32 --> Total execution time: 0.0604
INFO - 2022-01-03 04:10:08 --> Config Class Initialized
INFO - 2022-01-03 04:10:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:10:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:10:08 --> Utf8 Class Initialized
INFO - 2022-01-03 04:10:08 --> URI Class Initialized
INFO - 2022-01-03 04:10:08 --> Router Class Initialized
INFO - 2022-01-03 04:10:08 --> Output Class Initialized
INFO - 2022-01-03 04:10:08 --> Security Class Initialized
DEBUG - 2022-01-03 04:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:10:08 --> Input Class Initialized
INFO - 2022-01-03 04:10:08 --> Language Class Initialized
INFO - 2022-01-03 04:10:08 --> Loader Class Initialized
INFO - 2022-01-03 04:10:08 --> Helper loaded: url_helper
INFO - 2022-01-03 04:10:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:10:08 --> Controller Class Initialized
INFO - 2022-01-03 04:10:08 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:10:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:10:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:10:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:10:08 --> Final output sent to browser
DEBUG - 2022-01-03 04:10:08 --> Total execution time: 0.0732
INFO - 2022-01-03 04:10:42 --> Config Class Initialized
INFO - 2022-01-03 04:10:42 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:10:42 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:10:42 --> Utf8 Class Initialized
INFO - 2022-01-03 04:10:42 --> URI Class Initialized
INFO - 2022-01-03 04:10:42 --> Router Class Initialized
INFO - 2022-01-03 04:10:42 --> Output Class Initialized
INFO - 2022-01-03 04:10:42 --> Security Class Initialized
DEBUG - 2022-01-03 04:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:10:42 --> Input Class Initialized
INFO - 2022-01-03 04:10:42 --> Language Class Initialized
INFO - 2022-01-03 04:10:42 --> Loader Class Initialized
INFO - 2022-01-03 04:10:42 --> Helper loaded: url_helper
INFO - 2022-01-03 04:10:42 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:10:42 --> Controller Class Initialized
INFO - 2022-01-03 04:10:42 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:10:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:10:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:10:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:10:42 --> Final output sent to browser
DEBUG - 2022-01-03 04:10:42 --> Total execution time: 0.0806
INFO - 2022-01-03 04:11:03 --> Config Class Initialized
INFO - 2022-01-03 04:11:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:11:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:11:03 --> Utf8 Class Initialized
INFO - 2022-01-03 04:11:03 --> URI Class Initialized
INFO - 2022-01-03 04:11:03 --> Router Class Initialized
INFO - 2022-01-03 04:11:03 --> Output Class Initialized
INFO - 2022-01-03 04:11:03 --> Security Class Initialized
DEBUG - 2022-01-03 04:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:11:03 --> Input Class Initialized
INFO - 2022-01-03 04:11:03 --> Language Class Initialized
INFO - 2022-01-03 04:11:03 --> Loader Class Initialized
INFO - 2022-01-03 04:11:03 --> Helper loaded: url_helper
INFO - 2022-01-03 04:11:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:11:03 --> Controller Class Initialized
INFO - 2022-01-03 04:11:03 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:11:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:11:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:11:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:11:03 --> Final output sent to browser
DEBUG - 2022-01-03 04:11:03 --> Total execution time: 0.0526
INFO - 2022-01-03 04:11:26 --> Config Class Initialized
INFO - 2022-01-03 04:11:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:11:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:11:26 --> Utf8 Class Initialized
INFO - 2022-01-03 04:11:26 --> URI Class Initialized
INFO - 2022-01-03 04:11:26 --> Router Class Initialized
INFO - 2022-01-03 04:11:26 --> Output Class Initialized
INFO - 2022-01-03 04:11:26 --> Security Class Initialized
DEBUG - 2022-01-03 04:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:11:26 --> Input Class Initialized
INFO - 2022-01-03 04:11:26 --> Language Class Initialized
INFO - 2022-01-03 04:11:26 --> Loader Class Initialized
INFO - 2022-01-03 04:11:26 --> Helper loaded: url_helper
INFO - 2022-01-03 04:11:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:11:26 --> Controller Class Initialized
INFO - 2022-01-03 04:11:26 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:11:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:11:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:11:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:11:26 --> Final output sent to browser
DEBUG - 2022-01-03 04:11:26 --> Total execution time: 0.0635
INFO - 2022-01-03 04:11:40 --> Config Class Initialized
INFO - 2022-01-03 04:11:40 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:11:40 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:11:40 --> Utf8 Class Initialized
INFO - 2022-01-03 04:11:40 --> URI Class Initialized
INFO - 2022-01-03 04:11:40 --> Router Class Initialized
INFO - 2022-01-03 04:11:40 --> Output Class Initialized
INFO - 2022-01-03 04:11:40 --> Security Class Initialized
DEBUG - 2022-01-03 04:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:11:40 --> Input Class Initialized
INFO - 2022-01-03 04:11:40 --> Language Class Initialized
INFO - 2022-01-03 04:11:40 --> Loader Class Initialized
INFO - 2022-01-03 04:11:40 --> Helper loaded: url_helper
INFO - 2022-01-03 04:11:40 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:11:40 --> Controller Class Initialized
INFO - 2022-01-03 04:11:40 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:11:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:11:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:11:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:11:40 --> Final output sent to browser
DEBUG - 2022-01-03 04:11:40 --> Total execution time: 0.0506
INFO - 2022-01-03 04:12:32 --> Config Class Initialized
INFO - 2022-01-03 04:12:32 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:12:32 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:12:32 --> Utf8 Class Initialized
INFO - 2022-01-03 04:12:32 --> URI Class Initialized
INFO - 2022-01-03 04:12:32 --> Router Class Initialized
INFO - 2022-01-03 04:12:32 --> Output Class Initialized
INFO - 2022-01-03 04:12:32 --> Security Class Initialized
DEBUG - 2022-01-03 04:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:12:32 --> Input Class Initialized
INFO - 2022-01-03 04:12:32 --> Language Class Initialized
INFO - 2022-01-03 04:12:32 --> Loader Class Initialized
INFO - 2022-01-03 04:12:32 --> Helper loaded: url_helper
INFO - 2022-01-03 04:12:32 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:12:32 --> Controller Class Initialized
INFO - 2022-01-03 04:12:32 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:12:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:12:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:12:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:12:32 --> Final output sent to browser
DEBUG - 2022-01-03 04:12:32 --> Total execution time: 0.0618
INFO - 2022-01-03 04:12:50 --> Config Class Initialized
INFO - 2022-01-03 04:12:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:12:50 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:12:50 --> Utf8 Class Initialized
INFO - 2022-01-03 04:12:50 --> URI Class Initialized
INFO - 2022-01-03 04:12:50 --> Router Class Initialized
INFO - 2022-01-03 04:12:50 --> Output Class Initialized
INFO - 2022-01-03 04:12:50 --> Security Class Initialized
DEBUG - 2022-01-03 04:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:12:50 --> Input Class Initialized
INFO - 2022-01-03 04:12:50 --> Language Class Initialized
INFO - 2022-01-03 04:12:50 --> Loader Class Initialized
INFO - 2022-01-03 04:12:50 --> Helper loaded: url_helper
INFO - 2022-01-03 04:12:50 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:12:50 --> Controller Class Initialized
INFO - 2022-01-03 04:12:50 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:12:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:12:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:12:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:12:50 --> Final output sent to browser
DEBUG - 2022-01-03 04:12:50 --> Total execution time: 0.0435
INFO - 2022-01-03 04:13:31 --> Config Class Initialized
INFO - 2022-01-03 04:13:31 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:13:31 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:13:31 --> Utf8 Class Initialized
INFO - 2022-01-03 04:13:31 --> URI Class Initialized
INFO - 2022-01-03 04:13:31 --> Router Class Initialized
INFO - 2022-01-03 04:13:31 --> Output Class Initialized
INFO - 2022-01-03 04:13:31 --> Security Class Initialized
DEBUG - 2022-01-03 04:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:13:31 --> Input Class Initialized
INFO - 2022-01-03 04:13:31 --> Language Class Initialized
INFO - 2022-01-03 04:13:31 --> Loader Class Initialized
INFO - 2022-01-03 04:13:31 --> Helper loaded: url_helper
INFO - 2022-01-03 04:13:31 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:13:31 --> Controller Class Initialized
INFO - 2022-01-03 04:13:31 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:13:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:13:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:13:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:13:31 --> Final output sent to browser
DEBUG - 2022-01-03 04:13:31 --> Total execution time: 0.0559
INFO - 2022-01-03 04:14:30 --> Config Class Initialized
INFO - 2022-01-03 04:14:30 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:14:30 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:14:30 --> Utf8 Class Initialized
INFO - 2022-01-03 04:14:30 --> URI Class Initialized
INFO - 2022-01-03 04:14:30 --> Router Class Initialized
INFO - 2022-01-03 04:14:30 --> Output Class Initialized
INFO - 2022-01-03 04:14:30 --> Security Class Initialized
DEBUG - 2022-01-03 04:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:14:30 --> Input Class Initialized
INFO - 2022-01-03 04:14:30 --> Language Class Initialized
INFO - 2022-01-03 04:14:30 --> Loader Class Initialized
INFO - 2022-01-03 04:14:30 --> Helper loaded: url_helper
INFO - 2022-01-03 04:14:30 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:14:30 --> Controller Class Initialized
INFO - 2022-01-03 04:14:30 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:14:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:14:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:14:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:14:30 --> Final output sent to browser
DEBUG - 2022-01-03 04:14:30 --> Total execution time: 0.0463
INFO - 2022-01-03 04:15:45 --> Config Class Initialized
INFO - 2022-01-03 04:15:45 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:15:45 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:15:45 --> Utf8 Class Initialized
INFO - 2022-01-03 04:15:45 --> URI Class Initialized
INFO - 2022-01-03 04:15:45 --> Router Class Initialized
INFO - 2022-01-03 04:15:45 --> Output Class Initialized
INFO - 2022-01-03 04:15:45 --> Security Class Initialized
DEBUG - 2022-01-03 04:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:15:45 --> Input Class Initialized
INFO - 2022-01-03 04:15:45 --> Language Class Initialized
INFO - 2022-01-03 04:15:45 --> Loader Class Initialized
INFO - 2022-01-03 04:15:45 --> Helper loaded: url_helper
INFO - 2022-01-03 04:15:45 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:15:45 --> Controller Class Initialized
INFO - 2022-01-03 04:15:45 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:15:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:15:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:15:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:15:45 --> Final output sent to browser
DEBUG - 2022-01-03 04:15:45 --> Total execution time: 0.0758
INFO - 2022-01-03 04:15:46 --> Config Class Initialized
INFO - 2022-01-03 04:15:46 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:15:46 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:15:46 --> Utf8 Class Initialized
INFO - 2022-01-03 04:15:46 --> URI Class Initialized
INFO - 2022-01-03 04:15:46 --> Router Class Initialized
INFO - 2022-01-03 04:15:46 --> Output Class Initialized
INFO - 2022-01-03 04:15:46 --> Security Class Initialized
DEBUG - 2022-01-03 04:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:15:46 --> Input Class Initialized
INFO - 2022-01-03 04:15:46 --> Language Class Initialized
INFO - 2022-01-03 04:15:46 --> Loader Class Initialized
INFO - 2022-01-03 04:15:46 --> Helper loaded: url_helper
INFO - 2022-01-03 04:15:46 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:15:46 --> Controller Class Initialized
INFO - 2022-01-03 04:15:46 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:15:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:15:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:15:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:15:46 --> Final output sent to browser
DEBUG - 2022-01-03 04:15:46 --> Total execution time: 0.0556
INFO - 2022-01-03 04:17:52 --> Config Class Initialized
INFO - 2022-01-03 04:17:52 --> Hooks Class Initialized
DEBUG - 2022-01-03 04:17:52 --> UTF-8 Support Enabled
INFO - 2022-01-03 04:17:52 --> Utf8 Class Initialized
INFO - 2022-01-03 04:17:52 --> URI Class Initialized
INFO - 2022-01-03 04:17:52 --> Router Class Initialized
INFO - 2022-01-03 04:17:52 --> Output Class Initialized
INFO - 2022-01-03 04:17:52 --> Security Class Initialized
DEBUG - 2022-01-03 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 04:17:52 --> Input Class Initialized
INFO - 2022-01-03 04:17:52 --> Language Class Initialized
INFO - 2022-01-03 04:17:52 --> Loader Class Initialized
INFO - 2022-01-03 04:17:52 --> Helper loaded: url_helper
INFO - 2022-01-03 04:17:52 --> Database Driver Class Initialized
DEBUG - 2022-01-03 04:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 04:17:52 --> Controller Class Initialized
INFO - 2022-01-03 04:17:52 --> Model "LoginModel" initialized
INFO - 2022-01-03 04:17:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 04:17:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 04:17:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 04:17:52 --> Final output sent to browser
DEBUG - 2022-01-03 04:17:52 --> Total execution time: 0.0500
INFO - 2022-01-03 06:00:25 --> Config Class Initialized
INFO - 2022-01-03 06:00:25 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:00:25 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:00:25 --> Utf8 Class Initialized
INFO - 2022-01-03 06:00:25 --> URI Class Initialized
INFO - 2022-01-03 06:00:25 --> Router Class Initialized
INFO - 2022-01-03 06:00:25 --> Output Class Initialized
INFO - 2022-01-03 06:00:25 --> Security Class Initialized
DEBUG - 2022-01-03 06:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:00:25 --> Input Class Initialized
INFO - 2022-01-03 06:00:25 --> Language Class Initialized
INFO - 2022-01-03 06:00:25 --> Loader Class Initialized
INFO - 2022-01-03 06:00:25 --> Helper loaded: url_helper
INFO - 2022-01-03 06:00:25 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:00:25 --> Controller Class Initialized
INFO - 2022-01-03 06:00:25 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:00:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:00:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:00:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:00:25 --> Final output sent to browser
DEBUG - 2022-01-03 06:00:25 --> Total execution time: 0.0632
INFO - 2022-01-03 06:01:08 --> Config Class Initialized
INFO - 2022-01-03 06:01:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:01:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:01:08 --> Utf8 Class Initialized
INFO - 2022-01-03 06:01:08 --> URI Class Initialized
INFO - 2022-01-03 06:01:08 --> Router Class Initialized
INFO - 2022-01-03 06:01:08 --> Output Class Initialized
INFO - 2022-01-03 06:01:08 --> Security Class Initialized
DEBUG - 2022-01-03 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:01:08 --> Input Class Initialized
INFO - 2022-01-03 06:01:08 --> Language Class Initialized
INFO - 2022-01-03 06:01:08 --> Loader Class Initialized
INFO - 2022-01-03 06:01:08 --> Helper loaded: url_helper
INFO - 2022-01-03 06:01:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:01:08 --> Controller Class Initialized
INFO - 2022-01-03 06:01:08 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:01:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:01:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:01:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:01:08 --> Final output sent to browser
DEBUG - 2022-01-03 06:01:08 --> Total execution time: 0.0507
INFO - 2022-01-03 06:01:29 --> Config Class Initialized
INFO - 2022-01-03 06:01:29 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:01:29 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:01:29 --> Utf8 Class Initialized
INFO - 2022-01-03 06:01:29 --> URI Class Initialized
INFO - 2022-01-03 06:01:29 --> Router Class Initialized
INFO - 2022-01-03 06:01:29 --> Output Class Initialized
INFO - 2022-01-03 06:01:29 --> Security Class Initialized
DEBUG - 2022-01-03 06:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:01:29 --> Input Class Initialized
INFO - 2022-01-03 06:01:29 --> Language Class Initialized
INFO - 2022-01-03 06:01:29 --> Loader Class Initialized
INFO - 2022-01-03 06:01:29 --> Helper loaded: url_helper
INFO - 2022-01-03 06:01:29 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:01:29 --> Controller Class Initialized
INFO - 2022-01-03 06:01:29 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:01:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:01:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:01:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:01:29 --> Final output sent to browser
DEBUG - 2022-01-03 06:01:29 --> Total execution time: 0.0697
INFO - 2022-01-03 06:09:55 --> Config Class Initialized
INFO - 2022-01-03 06:09:55 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:09:55 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:09:55 --> Utf8 Class Initialized
INFO - 2022-01-03 06:09:55 --> URI Class Initialized
INFO - 2022-01-03 06:09:55 --> Router Class Initialized
INFO - 2022-01-03 06:09:55 --> Output Class Initialized
INFO - 2022-01-03 06:09:55 --> Security Class Initialized
DEBUG - 2022-01-03 06:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:09:55 --> Input Class Initialized
INFO - 2022-01-03 06:09:55 --> Language Class Initialized
INFO - 2022-01-03 06:09:55 --> Loader Class Initialized
INFO - 2022-01-03 06:09:55 --> Helper loaded: url_helper
INFO - 2022-01-03 06:09:55 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:09:55 --> Controller Class Initialized
INFO - 2022-01-03 06:09:55 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:09:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:09:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:09:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:09:55 --> Final output sent to browser
DEBUG - 2022-01-03 06:09:55 --> Total execution time: 0.0646
INFO - 2022-01-03 06:09:56 --> Config Class Initialized
INFO - 2022-01-03 06:09:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:09:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:09:56 --> Utf8 Class Initialized
INFO - 2022-01-03 06:09:56 --> URI Class Initialized
INFO - 2022-01-03 06:09:56 --> Router Class Initialized
INFO - 2022-01-03 06:09:56 --> Output Class Initialized
INFO - 2022-01-03 06:09:56 --> Security Class Initialized
DEBUG - 2022-01-03 06:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:09:56 --> Input Class Initialized
INFO - 2022-01-03 06:09:56 --> Language Class Initialized
INFO - 2022-01-03 06:09:56 --> Loader Class Initialized
INFO - 2022-01-03 06:09:56 --> Helper loaded: url_helper
INFO - 2022-01-03 06:09:56 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:09:56 --> Controller Class Initialized
INFO - 2022-01-03 06:09:56 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:09:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:09:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:09:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:09:56 --> Final output sent to browser
DEBUG - 2022-01-03 06:09:56 --> Total execution time: 0.0494
INFO - 2022-01-03 06:10:00 --> Config Class Initialized
INFO - 2022-01-03 06:10:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:10:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:10:00 --> Utf8 Class Initialized
INFO - 2022-01-03 06:10:00 --> URI Class Initialized
INFO - 2022-01-03 06:10:00 --> Router Class Initialized
INFO - 2022-01-03 06:10:00 --> Output Class Initialized
INFO - 2022-01-03 06:10:00 --> Security Class Initialized
DEBUG - 2022-01-03 06:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:10:00 --> Input Class Initialized
INFO - 2022-01-03 06:10:00 --> Language Class Initialized
INFO - 2022-01-03 06:10:00 --> Loader Class Initialized
INFO - 2022-01-03 06:10:00 --> Helper loaded: url_helper
INFO - 2022-01-03 06:10:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:10:00 --> Controller Class Initialized
INFO - 2022-01-03 06:10:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:10:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:10:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:10:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:10:00 --> Final output sent to browser
DEBUG - 2022-01-03 06:10:00 --> Total execution time: 0.0493
INFO - 2022-01-03 06:10:01 --> Config Class Initialized
INFO - 2022-01-03 06:10:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:10:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:10:01 --> Utf8 Class Initialized
INFO - 2022-01-03 06:10:01 --> URI Class Initialized
INFO - 2022-01-03 06:10:01 --> Router Class Initialized
INFO - 2022-01-03 06:10:01 --> Output Class Initialized
INFO - 2022-01-03 06:10:01 --> Security Class Initialized
DEBUG - 2022-01-03 06:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:10:01 --> Input Class Initialized
INFO - 2022-01-03 06:10:01 --> Language Class Initialized
INFO - 2022-01-03 06:10:01 --> Loader Class Initialized
INFO - 2022-01-03 06:10:01 --> Helper loaded: url_helper
INFO - 2022-01-03 06:10:01 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:10:01 --> Controller Class Initialized
INFO - 2022-01-03 06:10:01 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:10:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:10:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:10:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:10:01 --> Final output sent to browser
DEBUG - 2022-01-03 06:10:01 --> Total execution time: 0.0528
INFO - 2022-01-03 06:10:48 --> Config Class Initialized
INFO - 2022-01-03 06:10:48 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:10:48 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:10:48 --> Utf8 Class Initialized
INFO - 2022-01-03 06:10:48 --> URI Class Initialized
INFO - 2022-01-03 06:10:48 --> Router Class Initialized
INFO - 2022-01-03 06:10:48 --> Output Class Initialized
INFO - 2022-01-03 06:10:48 --> Security Class Initialized
DEBUG - 2022-01-03 06:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:10:48 --> Input Class Initialized
INFO - 2022-01-03 06:10:48 --> Language Class Initialized
INFO - 2022-01-03 06:10:48 --> Loader Class Initialized
INFO - 2022-01-03 06:10:48 --> Helper loaded: url_helper
INFO - 2022-01-03 06:10:48 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:10:48 --> Controller Class Initialized
INFO - 2022-01-03 06:10:48 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:10:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:10:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:10:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:10:48 --> Final output sent to browser
DEBUG - 2022-01-03 06:10:48 --> Total execution time: 0.0603
INFO - 2022-01-03 06:14:12 --> Config Class Initialized
INFO - 2022-01-03 06:14:12 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:14:12 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:14:12 --> Utf8 Class Initialized
INFO - 2022-01-03 06:14:12 --> URI Class Initialized
INFO - 2022-01-03 06:14:12 --> Router Class Initialized
INFO - 2022-01-03 06:14:12 --> Output Class Initialized
INFO - 2022-01-03 06:14:12 --> Security Class Initialized
DEBUG - 2022-01-03 06:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:14:12 --> Input Class Initialized
INFO - 2022-01-03 06:14:12 --> Language Class Initialized
INFO - 2022-01-03 06:14:12 --> Loader Class Initialized
INFO - 2022-01-03 06:14:12 --> Helper loaded: url_helper
INFO - 2022-01-03 06:14:12 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:14:12 --> Controller Class Initialized
INFO - 2022-01-03 06:14:12 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:14:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:14:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:14:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:14:12 --> Final output sent to browser
DEBUG - 2022-01-03 06:14:12 --> Total execution time: 0.0693
INFO - 2022-01-03 06:14:19 --> Config Class Initialized
INFO - 2022-01-03 06:14:19 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:14:19 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:14:19 --> Utf8 Class Initialized
INFO - 2022-01-03 06:14:19 --> URI Class Initialized
INFO - 2022-01-03 06:14:19 --> Router Class Initialized
INFO - 2022-01-03 06:14:19 --> Output Class Initialized
INFO - 2022-01-03 06:14:19 --> Security Class Initialized
DEBUG - 2022-01-03 06:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:14:19 --> Input Class Initialized
INFO - 2022-01-03 06:14:19 --> Language Class Initialized
INFO - 2022-01-03 06:14:19 --> Loader Class Initialized
INFO - 2022-01-03 06:14:19 --> Helper loaded: url_helper
INFO - 2022-01-03 06:14:19 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:14:19 --> Controller Class Initialized
INFO - 2022-01-03 06:14:19 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:14:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:14:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:14:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:14:19 --> Final output sent to browser
DEBUG - 2022-01-03 06:14:19 --> Total execution time: 0.0728
INFO - 2022-01-03 06:14:38 --> Config Class Initialized
INFO - 2022-01-03 06:14:38 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:14:38 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:14:38 --> Utf8 Class Initialized
INFO - 2022-01-03 06:14:38 --> URI Class Initialized
INFO - 2022-01-03 06:14:38 --> Router Class Initialized
INFO - 2022-01-03 06:14:38 --> Output Class Initialized
INFO - 2022-01-03 06:14:38 --> Security Class Initialized
DEBUG - 2022-01-03 06:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:14:38 --> Input Class Initialized
INFO - 2022-01-03 06:14:38 --> Language Class Initialized
INFO - 2022-01-03 06:14:38 --> Loader Class Initialized
INFO - 2022-01-03 06:14:38 --> Helper loaded: url_helper
INFO - 2022-01-03 06:14:38 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:14:38 --> Controller Class Initialized
INFO - 2022-01-03 06:14:38 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:14:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:14:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:14:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:14:38 --> Final output sent to browser
DEBUG - 2022-01-03 06:14:38 --> Total execution time: 0.0597
INFO - 2022-01-03 06:15:05 --> Config Class Initialized
INFO - 2022-01-03 06:15:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:15:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:15:05 --> Utf8 Class Initialized
INFO - 2022-01-03 06:15:05 --> URI Class Initialized
INFO - 2022-01-03 06:15:05 --> Router Class Initialized
INFO - 2022-01-03 06:15:05 --> Output Class Initialized
INFO - 2022-01-03 06:15:05 --> Security Class Initialized
DEBUG - 2022-01-03 06:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:15:05 --> Input Class Initialized
INFO - 2022-01-03 06:15:05 --> Language Class Initialized
INFO - 2022-01-03 06:15:05 --> Loader Class Initialized
INFO - 2022-01-03 06:15:05 --> Helper loaded: url_helper
INFO - 2022-01-03 06:15:05 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:15:05 --> Controller Class Initialized
INFO - 2022-01-03 06:15:05 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:15:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:15:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:15:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:15:05 --> Final output sent to browser
DEBUG - 2022-01-03 06:15:05 --> Total execution time: 0.0768
INFO - 2022-01-03 06:16:11 --> Config Class Initialized
INFO - 2022-01-03 06:16:11 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:16:11 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:16:11 --> Utf8 Class Initialized
INFO - 2022-01-03 06:16:11 --> URI Class Initialized
INFO - 2022-01-03 06:16:11 --> Router Class Initialized
INFO - 2022-01-03 06:16:11 --> Output Class Initialized
INFO - 2022-01-03 06:16:11 --> Security Class Initialized
DEBUG - 2022-01-03 06:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:16:11 --> Input Class Initialized
INFO - 2022-01-03 06:16:11 --> Language Class Initialized
INFO - 2022-01-03 06:16:11 --> Loader Class Initialized
INFO - 2022-01-03 06:16:11 --> Helper loaded: url_helper
INFO - 2022-01-03 06:16:11 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:16:11 --> Controller Class Initialized
INFO - 2022-01-03 06:16:11 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:16:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:16:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:16:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:16:11 --> Final output sent to browser
DEBUG - 2022-01-03 06:16:11 --> Total execution time: 0.0544
INFO - 2022-01-03 06:17:03 --> Config Class Initialized
INFO - 2022-01-03 06:17:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:17:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:17:03 --> Utf8 Class Initialized
INFO - 2022-01-03 06:17:03 --> URI Class Initialized
INFO - 2022-01-03 06:17:03 --> Router Class Initialized
INFO - 2022-01-03 06:17:03 --> Output Class Initialized
INFO - 2022-01-03 06:17:03 --> Security Class Initialized
DEBUG - 2022-01-03 06:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:17:03 --> Input Class Initialized
INFO - 2022-01-03 06:17:03 --> Language Class Initialized
INFO - 2022-01-03 06:17:03 --> Loader Class Initialized
INFO - 2022-01-03 06:17:03 --> Helper loaded: url_helper
INFO - 2022-01-03 06:17:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:17:03 --> Controller Class Initialized
INFO - 2022-01-03 06:17:03 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:17:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:17:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:17:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:17:03 --> Final output sent to browser
DEBUG - 2022-01-03 06:17:03 --> Total execution time: 0.0550
INFO - 2022-01-03 06:17:05 --> Config Class Initialized
INFO - 2022-01-03 06:17:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:17:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:17:05 --> Utf8 Class Initialized
INFO - 2022-01-03 06:17:05 --> URI Class Initialized
INFO - 2022-01-03 06:17:05 --> Router Class Initialized
INFO - 2022-01-03 06:17:05 --> Output Class Initialized
INFO - 2022-01-03 06:17:05 --> Security Class Initialized
DEBUG - 2022-01-03 06:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:17:05 --> Input Class Initialized
INFO - 2022-01-03 06:17:05 --> Language Class Initialized
INFO - 2022-01-03 06:17:05 --> Loader Class Initialized
INFO - 2022-01-03 06:17:05 --> Helper loaded: url_helper
INFO - 2022-01-03 06:17:05 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:17:05 --> Controller Class Initialized
INFO - 2022-01-03 06:17:05 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:17:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:17:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:17:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:17:05 --> Final output sent to browser
DEBUG - 2022-01-03 06:17:05 --> Total execution time: 0.0564
INFO - 2022-01-03 06:17:14 --> Config Class Initialized
INFO - 2022-01-03 06:17:14 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:17:14 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:17:14 --> Utf8 Class Initialized
INFO - 2022-01-03 06:17:14 --> URI Class Initialized
INFO - 2022-01-03 06:17:14 --> Router Class Initialized
INFO - 2022-01-03 06:17:14 --> Output Class Initialized
INFO - 2022-01-03 06:17:14 --> Security Class Initialized
DEBUG - 2022-01-03 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:17:14 --> Input Class Initialized
INFO - 2022-01-03 06:17:14 --> Language Class Initialized
INFO - 2022-01-03 06:17:14 --> Loader Class Initialized
INFO - 2022-01-03 06:17:14 --> Helper loaded: url_helper
INFO - 2022-01-03 06:17:14 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:17:14 --> Controller Class Initialized
INFO - 2022-01-03 06:17:14 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:17:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:17:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:17:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:17:14 --> Final output sent to browser
DEBUG - 2022-01-03 06:17:14 --> Total execution time: 0.0629
INFO - 2022-01-03 06:18:10 --> Config Class Initialized
INFO - 2022-01-03 06:18:10 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:18:10 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:18:10 --> Utf8 Class Initialized
INFO - 2022-01-03 06:18:10 --> URI Class Initialized
INFO - 2022-01-03 06:18:10 --> Router Class Initialized
INFO - 2022-01-03 06:18:10 --> Output Class Initialized
INFO - 2022-01-03 06:18:10 --> Security Class Initialized
DEBUG - 2022-01-03 06:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:18:10 --> Input Class Initialized
INFO - 2022-01-03 06:18:10 --> Language Class Initialized
INFO - 2022-01-03 06:18:10 --> Loader Class Initialized
INFO - 2022-01-03 06:18:10 --> Helper loaded: url_helper
INFO - 2022-01-03 06:18:10 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:18:10 --> Controller Class Initialized
INFO - 2022-01-03 06:18:10 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:18:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:18:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:18:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:18:10 --> Final output sent to browser
DEBUG - 2022-01-03 06:18:10 --> Total execution time: 0.0572
INFO - 2022-01-03 06:18:18 --> Config Class Initialized
INFO - 2022-01-03 06:18:18 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:18:18 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:18:18 --> Utf8 Class Initialized
INFO - 2022-01-03 06:18:18 --> URI Class Initialized
INFO - 2022-01-03 06:18:18 --> Router Class Initialized
INFO - 2022-01-03 06:18:18 --> Output Class Initialized
INFO - 2022-01-03 06:18:18 --> Security Class Initialized
DEBUG - 2022-01-03 06:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:18:18 --> Input Class Initialized
INFO - 2022-01-03 06:18:18 --> Language Class Initialized
INFO - 2022-01-03 06:18:18 --> Loader Class Initialized
INFO - 2022-01-03 06:18:18 --> Helper loaded: url_helper
INFO - 2022-01-03 06:18:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:18:18 --> Controller Class Initialized
INFO - 2022-01-03 06:18:18 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:18:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:18:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:18:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:18:18 --> Final output sent to browser
DEBUG - 2022-01-03 06:18:18 --> Total execution time: 0.0495
INFO - 2022-01-03 06:24:30 --> Config Class Initialized
INFO - 2022-01-03 06:24:30 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:24:30 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:24:30 --> Utf8 Class Initialized
INFO - 2022-01-03 06:24:30 --> URI Class Initialized
INFO - 2022-01-03 06:24:30 --> Router Class Initialized
INFO - 2022-01-03 06:24:30 --> Output Class Initialized
INFO - 2022-01-03 06:24:30 --> Security Class Initialized
DEBUG - 2022-01-03 06:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:24:30 --> Input Class Initialized
INFO - 2022-01-03 06:24:30 --> Language Class Initialized
INFO - 2022-01-03 06:24:30 --> Loader Class Initialized
INFO - 2022-01-03 06:24:30 --> Helper loaded: url_helper
INFO - 2022-01-03 06:24:30 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:24:30 --> Controller Class Initialized
INFO - 2022-01-03 06:24:30 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:24:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:24:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:24:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:24:30 --> Final output sent to browser
DEBUG - 2022-01-03 06:24:30 --> Total execution time: 0.0804
INFO - 2022-01-03 06:25:29 --> Config Class Initialized
INFO - 2022-01-03 06:25:29 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:25:29 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:25:29 --> Utf8 Class Initialized
INFO - 2022-01-03 06:25:29 --> URI Class Initialized
INFO - 2022-01-03 06:25:29 --> Router Class Initialized
INFO - 2022-01-03 06:25:29 --> Output Class Initialized
INFO - 2022-01-03 06:25:29 --> Security Class Initialized
DEBUG - 2022-01-03 06:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:25:29 --> Input Class Initialized
INFO - 2022-01-03 06:25:29 --> Language Class Initialized
INFO - 2022-01-03 06:25:29 --> Loader Class Initialized
INFO - 2022-01-03 06:25:29 --> Helper loaded: url_helper
INFO - 2022-01-03 06:25:29 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:25:29 --> Controller Class Initialized
INFO - 2022-01-03 06:25:29 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:25:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:25:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:25:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:25:29 --> Final output sent to browser
DEBUG - 2022-01-03 06:25:29 --> Total execution time: 0.0720
INFO - 2022-01-03 06:25:35 --> Config Class Initialized
INFO - 2022-01-03 06:25:35 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:25:35 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:25:35 --> Utf8 Class Initialized
INFO - 2022-01-03 06:25:35 --> URI Class Initialized
INFO - 2022-01-03 06:25:35 --> Router Class Initialized
INFO - 2022-01-03 06:25:35 --> Output Class Initialized
INFO - 2022-01-03 06:25:35 --> Security Class Initialized
DEBUG - 2022-01-03 06:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:25:35 --> Input Class Initialized
INFO - 2022-01-03 06:25:35 --> Language Class Initialized
INFO - 2022-01-03 06:25:35 --> Loader Class Initialized
INFO - 2022-01-03 06:25:35 --> Helper loaded: url_helper
INFO - 2022-01-03 06:25:35 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:25:35 --> Controller Class Initialized
INFO - 2022-01-03 06:25:35 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:25:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:25:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:25:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:25:35 --> Final output sent to browser
DEBUG - 2022-01-03 06:25:35 --> Total execution time: 0.0471
INFO - 2022-01-03 06:27:43 --> Config Class Initialized
INFO - 2022-01-03 06:27:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:27:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:27:43 --> Utf8 Class Initialized
INFO - 2022-01-03 06:27:43 --> URI Class Initialized
INFO - 2022-01-03 06:27:43 --> Router Class Initialized
INFO - 2022-01-03 06:27:43 --> Output Class Initialized
INFO - 2022-01-03 06:27:43 --> Security Class Initialized
DEBUG - 2022-01-03 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:27:43 --> Input Class Initialized
INFO - 2022-01-03 06:27:43 --> Language Class Initialized
INFO - 2022-01-03 06:27:43 --> Loader Class Initialized
INFO - 2022-01-03 06:27:43 --> Helper loaded: url_helper
INFO - 2022-01-03 06:27:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:27:43 --> Controller Class Initialized
INFO - 2022-01-03 06:27:43 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:27:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:27:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:27:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:27:43 --> Final output sent to browser
DEBUG - 2022-01-03 06:27:43 --> Total execution time: 0.0581
INFO - 2022-01-03 06:27:55 --> Config Class Initialized
INFO - 2022-01-03 06:27:55 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:27:55 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:27:55 --> Utf8 Class Initialized
INFO - 2022-01-03 06:27:55 --> URI Class Initialized
INFO - 2022-01-03 06:27:55 --> Router Class Initialized
INFO - 2022-01-03 06:27:55 --> Output Class Initialized
INFO - 2022-01-03 06:27:55 --> Security Class Initialized
DEBUG - 2022-01-03 06:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:27:55 --> Input Class Initialized
INFO - 2022-01-03 06:27:55 --> Language Class Initialized
INFO - 2022-01-03 06:27:55 --> Loader Class Initialized
INFO - 2022-01-03 06:27:55 --> Helper loaded: url_helper
INFO - 2022-01-03 06:27:55 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:27:55 --> Controller Class Initialized
INFO - 2022-01-03 06:27:55 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:27:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:27:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:27:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:27:55 --> Final output sent to browser
DEBUG - 2022-01-03 06:27:55 --> Total execution time: 0.0507
INFO - 2022-01-03 06:27:57 --> Config Class Initialized
INFO - 2022-01-03 06:27:57 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:27:57 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:27:57 --> Utf8 Class Initialized
INFO - 2022-01-03 06:27:57 --> URI Class Initialized
INFO - 2022-01-03 06:27:57 --> Router Class Initialized
INFO - 2022-01-03 06:27:57 --> Output Class Initialized
INFO - 2022-01-03 06:27:57 --> Security Class Initialized
DEBUG - 2022-01-03 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:27:57 --> Input Class Initialized
INFO - 2022-01-03 06:27:57 --> Language Class Initialized
INFO - 2022-01-03 06:27:57 --> Loader Class Initialized
INFO - 2022-01-03 06:27:57 --> Helper loaded: url_helper
INFO - 2022-01-03 06:27:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:27:57 --> Controller Class Initialized
INFO - 2022-01-03 06:27:57 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:27:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:27:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:27:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:27:57 --> Final output sent to browser
DEBUG - 2022-01-03 06:27:57 --> Total execution time: 0.0753
INFO - 2022-01-03 06:28:27 --> Config Class Initialized
INFO - 2022-01-03 06:28:27 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:28:27 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:28:27 --> Utf8 Class Initialized
INFO - 2022-01-03 06:28:27 --> URI Class Initialized
INFO - 2022-01-03 06:28:27 --> Router Class Initialized
INFO - 2022-01-03 06:28:27 --> Output Class Initialized
INFO - 2022-01-03 06:28:27 --> Security Class Initialized
DEBUG - 2022-01-03 06:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:28:27 --> Input Class Initialized
INFO - 2022-01-03 06:28:27 --> Language Class Initialized
INFO - 2022-01-03 06:28:27 --> Loader Class Initialized
INFO - 2022-01-03 06:28:27 --> Helper loaded: url_helper
INFO - 2022-01-03 06:28:27 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:28:27 --> Controller Class Initialized
INFO - 2022-01-03 06:28:27 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:28:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:28:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:28:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:28:27 --> Final output sent to browser
DEBUG - 2022-01-03 06:28:27 --> Total execution time: 0.0613
INFO - 2022-01-03 06:28:46 --> Config Class Initialized
INFO - 2022-01-03 06:28:46 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:28:46 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:28:46 --> Utf8 Class Initialized
INFO - 2022-01-03 06:28:46 --> URI Class Initialized
INFO - 2022-01-03 06:28:46 --> Router Class Initialized
INFO - 2022-01-03 06:28:46 --> Output Class Initialized
INFO - 2022-01-03 06:28:46 --> Security Class Initialized
DEBUG - 2022-01-03 06:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:28:46 --> Input Class Initialized
INFO - 2022-01-03 06:28:46 --> Language Class Initialized
INFO - 2022-01-03 06:28:46 --> Loader Class Initialized
INFO - 2022-01-03 06:28:46 --> Helper loaded: url_helper
INFO - 2022-01-03 06:28:47 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:28:47 --> Controller Class Initialized
INFO - 2022-01-03 06:28:47 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:28:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:28:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:28:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:28:47 --> Final output sent to browser
DEBUG - 2022-01-03 06:28:47 --> Total execution time: 0.0735
INFO - 2022-01-03 06:31:03 --> Config Class Initialized
INFO - 2022-01-03 06:31:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:31:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:31:03 --> Utf8 Class Initialized
INFO - 2022-01-03 06:31:03 --> URI Class Initialized
INFO - 2022-01-03 06:31:03 --> Router Class Initialized
INFO - 2022-01-03 06:31:03 --> Output Class Initialized
INFO - 2022-01-03 06:31:03 --> Security Class Initialized
DEBUG - 2022-01-03 06:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:31:03 --> Input Class Initialized
INFO - 2022-01-03 06:31:03 --> Language Class Initialized
INFO - 2022-01-03 06:31:03 --> Loader Class Initialized
INFO - 2022-01-03 06:31:03 --> Helper loaded: url_helper
INFO - 2022-01-03 06:31:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:31:03 --> Controller Class Initialized
INFO - 2022-01-03 06:31:03 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:31:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:31:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:31:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:31:03 --> Final output sent to browser
DEBUG - 2022-01-03 06:31:03 --> Total execution time: 0.0861
INFO - 2022-01-03 06:32:18 --> Config Class Initialized
INFO - 2022-01-03 06:32:18 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:32:18 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:32:18 --> Utf8 Class Initialized
INFO - 2022-01-03 06:32:18 --> URI Class Initialized
INFO - 2022-01-03 06:32:18 --> Router Class Initialized
INFO - 2022-01-03 06:32:18 --> Output Class Initialized
INFO - 2022-01-03 06:32:18 --> Security Class Initialized
DEBUG - 2022-01-03 06:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:32:18 --> Input Class Initialized
INFO - 2022-01-03 06:32:18 --> Language Class Initialized
INFO - 2022-01-03 06:32:18 --> Loader Class Initialized
INFO - 2022-01-03 06:32:18 --> Helper loaded: url_helper
INFO - 2022-01-03 06:32:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:32:18 --> Controller Class Initialized
INFO - 2022-01-03 06:32:18 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:32:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:32:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:32:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:32:18 --> Final output sent to browser
DEBUG - 2022-01-03 06:32:18 --> Total execution time: 0.0741
INFO - 2022-01-03 06:33:03 --> Config Class Initialized
INFO - 2022-01-03 06:33:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:33:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:33:03 --> Utf8 Class Initialized
INFO - 2022-01-03 06:33:03 --> URI Class Initialized
INFO - 2022-01-03 06:33:03 --> Router Class Initialized
INFO - 2022-01-03 06:33:03 --> Output Class Initialized
INFO - 2022-01-03 06:33:03 --> Security Class Initialized
DEBUG - 2022-01-03 06:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:33:03 --> Input Class Initialized
INFO - 2022-01-03 06:33:03 --> Language Class Initialized
INFO - 2022-01-03 06:33:03 --> Loader Class Initialized
INFO - 2022-01-03 06:33:03 --> Helper loaded: url_helper
INFO - 2022-01-03 06:33:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:33:03 --> Controller Class Initialized
INFO - 2022-01-03 06:33:03 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:33:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:33:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:33:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:33:03 --> Final output sent to browser
DEBUG - 2022-01-03 06:33:03 --> Total execution time: 0.0928
INFO - 2022-01-03 06:33:33 --> Config Class Initialized
INFO - 2022-01-03 06:33:33 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:33:33 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:33:33 --> Utf8 Class Initialized
INFO - 2022-01-03 06:33:33 --> URI Class Initialized
INFO - 2022-01-03 06:33:33 --> Router Class Initialized
INFO - 2022-01-03 06:33:33 --> Output Class Initialized
INFO - 2022-01-03 06:33:33 --> Security Class Initialized
DEBUG - 2022-01-03 06:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:33:33 --> Input Class Initialized
INFO - 2022-01-03 06:33:33 --> Language Class Initialized
INFO - 2022-01-03 06:33:33 --> Loader Class Initialized
INFO - 2022-01-03 06:33:33 --> Helper loaded: url_helper
INFO - 2022-01-03 06:33:33 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:33:33 --> Controller Class Initialized
INFO - 2022-01-03 06:33:33 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:33:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:33:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:33:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:33:33 --> Final output sent to browser
DEBUG - 2022-01-03 06:33:33 --> Total execution time: 0.0563
INFO - 2022-01-03 06:38:51 --> Config Class Initialized
INFO - 2022-01-03 06:38:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:38:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:38:51 --> Utf8 Class Initialized
INFO - 2022-01-03 06:38:51 --> URI Class Initialized
INFO - 2022-01-03 06:38:51 --> Router Class Initialized
INFO - 2022-01-03 06:38:51 --> Output Class Initialized
INFO - 2022-01-03 06:38:51 --> Security Class Initialized
DEBUG - 2022-01-03 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:38:51 --> Input Class Initialized
INFO - 2022-01-03 06:38:51 --> Language Class Initialized
INFO - 2022-01-03 06:38:51 --> Loader Class Initialized
INFO - 2022-01-03 06:38:51 --> Helper loaded: url_helper
INFO - 2022-01-03 06:38:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:38:51 --> Controller Class Initialized
INFO - 2022-01-03 06:38:51 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:38:51 --> Config Class Initialized
INFO - 2022-01-03 06:38:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:38:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:38:51 --> Utf8 Class Initialized
INFO - 2022-01-03 06:38:51 --> URI Class Initialized
INFO - 2022-01-03 06:38:51 --> Router Class Initialized
INFO - 2022-01-03 06:38:51 --> Output Class Initialized
INFO - 2022-01-03 06:38:51 --> Security Class Initialized
DEBUG - 2022-01-03 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:38:51 --> Input Class Initialized
INFO - 2022-01-03 06:38:51 --> Language Class Initialized
INFO - 2022-01-03 06:38:51 --> Loader Class Initialized
INFO - 2022-01-03 06:38:51 --> Helper loaded: url_helper
INFO - 2022-01-03 06:38:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:38:51 --> Controller Class Initialized
INFO - 2022-01-03 06:38:51 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:38:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:38:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:38:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:38:51 --> Final output sent to browser
DEBUG - 2022-01-03 06:38:51 --> Total execution time: 0.0815
INFO - 2022-01-03 06:40:11 --> Config Class Initialized
INFO - 2022-01-03 06:40:11 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:40:11 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:40:11 --> Utf8 Class Initialized
INFO - 2022-01-03 06:40:11 --> URI Class Initialized
INFO - 2022-01-03 06:40:11 --> Router Class Initialized
INFO - 2022-01-03 06:40:11 --> Output Class Initialized
INFO - 2022-01-03 06:40:11 --> Security Class Initialized
DEBUG - 2022-01-03 06:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:40:11 --> Input Class Initialized
INFO - 2022-01-03 06:40:11 --> Language Class Initialized
INFO - 2022-01-03 06:40:11 --> Loader Class Initialized
INFO - 2022-01-03 06:40:11 --> Helper loaded: url_helper
INFO - 2022-01-03 06:40:11 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:40:11 --> Controller Class Initialized
INFO - 2022-01-03 06:40:11 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:40:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:40:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:40:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:40:11 --> Final output sent to browser
DEBUG - 2022-01-03 06:40:11 --> Total execution time: 0.0475
INFO - 2022-01-03 06:40:20 --> Config Class Initialized
INFO - 2022-01-03 06:40:20 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:40:20 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:40:20 --> Utf8 Class Initialized
INFO - 2022-01-03 06:40:20 --> URI Class Initialized
INFO - 2022-01-03 06:40:20 --> Router Class Initialized
INFO - 2022-01-03 06:40:20 --> Output Class Initialized
INFO - 2022-01-03 06:40:20 --> Security Class Initialized
DEBUG - 2022-01-03 06:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:40:20 --> Input Class Initialized
INFO - 2022-01-03 06:40:20 --> Language Class Initialized
INFO - 2022-01-03 06:40:20 --> Loader Class Initialized
INFO - 2022-01-03 06:40:20 --> Helper loaded: url_helper
INFO - 2022-01-03 06:40:20 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:40:20 --> Controller Class Initialized
INFO - 2022-01-03 06:40:20 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:40:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:40:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:40:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:40:20 --> Final output sent to browser
DEBUG - 2022-01-03 06:40:20 --> Total execution time: 0.0578
INFO - 2022-01-03 06:41:04 --> Config Class Initialized
INFO - 2022-01-03 06:41:04 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:41:04 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:41:04 --> Utf8 Class Initialized
INFO - 2022-01-03 06:41:04 --> URI Class Initialized
INFO - 2022-01-03 06:41:04 --> Router Class Initialized
INFO - 2022-01-03 06:41:04 --> Output Class Initialized
INFO - 2022-01-03 06:41:04 --> Security Class Initialized
DEBUG - 2022-01-03 06:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:41:04 --> Input Class Initialized
INFO - 2022-01-03 06:41:04 --> Language Class Initialized
INFO - 2022-01-03 06:41:04 --> Loader Class Initialized
INFO - 2022-01-03 06:41:04 --> Helper loaded: url_helper
INFO - 2022-01-03 06:41:04 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:41:04 --> Controller Class Initialized
INFO - 2022-01-03 06:41:04 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:41:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:41:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:41:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:41:04 --> Final output sent to browser
DEBUG - 2022-01-03 06:41:04 --> Total execution time: 0.0541
INFO - 2022-01-03 06:41:35 --> Config Class Initialized
INFO - 2022-01-03 06:41:35 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:41:35 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:41:35 --> Utf8 Class Initialized
INFO - 2022-01-03 06:41:35 --> URI Class Initialized
INFO - 2022-01-03 06:41:35 --> Router Class Initialized
INFO - 2022-01-03 06:41:35 --> Output Class Initialized
INFO - 2022-01-03 06:41:35 --> Security Class Initialized
DEBUG - 2022-01-03 06:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:41:35 --> Input Class Initialized
INFO - 2022-01-03 06:41:35 --> Language Class Initialized
INFO - 2022-01-03 06:41:35 --> Loader Class Initialized
INFO - 2022-01-03 06:41:35 --> Helper loaded: url_helper
INFO - 2022-01-03 06:41:35 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:41:35 --> Controller Class Initialized
INFO - 2022-01-03 06:41:35 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:41:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:41:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:41:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:41:35 --> Final output sent to browser
DEBUG - 2022-01-03 06:41:35 --> Total execution time: 0.0661
INFO - 2022-01-03 06:42:05 --> Config Class Initialized
INFO - 2022-01-03 06:42:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:42:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:42:05 --> Utf8 Class Initialized
INFO - 2022-01-03 06:42:05 --> URI Class Initialized
INFO - 2022-01-03 06:42:05 --> Router Class Initialized
INFO - 2022-01-03 06:42:05 --> Output Class Initialized
INFO - 2022-01-03 06:42:05 --> Security Class Initialized
DEBUG - 2022-01-03 06:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:42:05 --> Input Class Initialized
INFO - 2022-01-03 06:42:05 --> Language Class Initialized
INFO - 2022-01-03 06:42:05 --> Loader Class Initialized
INFO - 2022-01-03 06:42:05 --> Helper loaded: url_helper
INFO - 2022-01-03 06:42:05 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:42:05 --> Controller Class Initialized
INFO - 2022-01-03 06:42:05 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:42:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:42:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:42:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:42:05 --> Final output sent to browser
DEBUG - 2022-01-03 06:42:05 --> Total execution time: 0.0456
INFO - 2022-01-03 06:43:18 --> Config Class Initialized
INFO - 2022-01-03 06:43:18 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:43:18 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:43:18 --> Utf8 Class Initialized
INFO - 2022-01-03 06:43:18 --> URI Class Initialized
INFO - 2022-01-03 06:43:18 --> Router Class Initialized
INFO - 2022-01-03 06:43:18 --> Output Class Initialized
INFO - 2022-01-03 06:43:18 --> Security Class Initialized
DEBUG - 2022-01-03 06:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:43:18 --> Input Class Initialized
INFO - 2022-01-03 06:43:18 --> Language Class Initialized
INFO - 2022-01-03 06:43:18 --> Loader Class Initialized
INFO - 2022-01-03 06:43:18 --> Helper loaded: url_helper
INFO - 2022-01-03 06:43:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:43:18 --> Controller Class Initialized
INFO - 2022-01-03 06:43:18 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:43:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:43:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:43:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:43:18 --> Final output sent to browser
DEBUG - 2022-01-03 06:43:18 --> Total execution time: 0.0507
INFO - 2022-01-03 06:43:31 --> Config Class Initialized
INFO - 2022-01-03 06:43:31 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:43:31 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:43:31 --> Utf8 Class Initialized
INFO - 2022-01-03 06:43:31 --> URI Class Initialized
INFO - 2022-01-03 06:43:31 --> Router Class Initialized
INFO - 2022-01-03 06:43:31 --> Output Class Initialized
INFO - 2022-01-03 06:43:31 --> Security Class Initialized
DEBUG - 2022-01-03 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:43:31 --> Input Class Initialized
INFO - 2022-01-03 06:43:31 --> Language Class Initialized
INFO - 2022-01-03 06:43:31 --> Loader Class Initialized
INFO - 2022-01-03 06:43:31 --> Helper loaded: url_helper
INFO - 2022-01-03 06:43:31 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:43:31 --> Controller Class Initialized
INFO - 2022-01-03 06:43:31 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:43:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:43:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:43:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:43:32 --> Final output sent to browser
DEBUG - 2022-01-03 06:43:32 --> Total execution time: 0.0714
INFO - 2022-01-03 06:44:03 --> Config Class Initialized
INFO - 2022-01-03 06:44:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:44:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:44:03 --> Utf8 Class Initialized
INFO - 2022-01-03 06:44:03 --> URI Class Initialized
INFO - 2022-01-03 06:44:03 --> Router Class Initialized
INFO - 2022-01-03 06:44:03 --> Output Class Initialized
INFO - 2022-01-03 06:44:03 --> Security Class Initialized
DEBUG - 2022-01-03 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:44:03 --> Input Class Initialized
INFO - 2022-01-03 06:44:03 --> Language Class Initialized
INFO - 2022-01-03 06:44:03 --> Loader Class Initialized
INFO - 2022-01-03 06:44:03 --> Helper loaded: url_helper
INFO - 2022-01-03 06:44:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:44:03 --> Controller Class Initialized
INFO - 2022-01-03 06:44:03 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:44:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:44:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:44:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:44:03 --> Final output sent to browser
DEBUG - 2022-01-03 06:44:03 --> Total execution time: 0.0752
INFO - 2022-01-03 06:44:28 --> Config Class Initialized
INFO - 2022-01-03 06:44:28 --> Hooks Class Initialized
DEBUG - 2022-01-03 06:44:28 --> UTF-8 Support Enabled
INFO - 2022-01-03 06:44:28 --> Utf8 Class Initialized
INFO - 2022-01-03 06:44:28 --> URI Class Initialized
INFO - 2022-01-03 06:44:28 --> Router Class Initialized
INFO - 2022-01-03 06:44:28 --> Output Class Initialized
INFO - 2022-01-03 06:44:28 --> Security Class Initialized
DEBUG - 2022-01-03 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 06:44:28 --> Input Class Initialized
INFO - 2022-01-03 06:44:28 --> Language Class Initialized
INFO - 2022-01-03 06:44:28 --> Loader Class Initialized
INFO - 2022-01-03 06:44:28 --> Helper loaded: url_helper
INFO - 2022-01-03 06:44:28 --> Database Driver Class Initialized
DEBUG - 2022-01-03 06:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 06:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 06:44:28 --> Controller Class Initialized
INFO - 2022-01-03 06:44:28 --> Model "LoginModel" initialized
INFO - 2022-01-03 06:44:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 06:44:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 06:44:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 06:44:28 --> Final output sent to browser
DEBUG - 2022-01-03 06:44:28 --> Total execution time: 0.0565
INFO - 2022-01-03 07:05:49 --> Config Class Initialized
INFO - 2022-01-03 07:05:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:05:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:05:49 --> Utf8 Class Initialized
INFO - 2022-01-03 07:05:49 --> URI Class Initialized
INFO - 2022-01-03 07:05:49 --> Router Class Initialized
INFO - 2022-01-03 07:05:49 --> Output Class Initialized
INFO - 2022-01-03 07:05:49 --> Security Class Initialized
DEBUG - 2022-01-03 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:05:49 --> Input Class Initialized
INFO - 2022-01-03 07:05:49 --> Language Class Initialized
INFO - 2022-01-03 07:05:49 --> Loader Class Initialized
INFO - 2022-01-03 07:05:49 --> Helper loaded: url_helper
INFO - 2022-01-03 07:05:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:05:49 --> Controller Class Initialized
INFO - 2022-01-03 07:05:49 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:05:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
ERROR - 2022-01-03 07:05:49 --> Severity: error --> Exception: syntax error, unexpected token "if" C:\xampp\htdocs\OJT\application\views\login\index.php 15
INFO - 2022-01-03 07:05:58 --> Config Class Initialized
INFO - 2022-01-03 07:05:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:05:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:05:58 --> Utf8 Class Initialized
INFO - 2022-01-03 07:05:58 --> URI Class Initialized
INFO - 2022-01-03 07:05:58 --> Router Class Initialized
INFO - 2022-01-03 07:05:58 --> Output Class Initialized
INFO - 2022-01-03 07:05:58 --> Security Class Initialized
DEBUG - 2022-01-03 07:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:05:58 --> Input Class Initialized
INFO - 2022-01-03 07:05:58 --> Language Class Initialized
INFO - 2022-01-03 07:05:58 --> Loader Class Initialized
INFO - 2022-01-03 07:05:58 --> Helper loaded: url_helper
INFO - 2022-01-03 07:05:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:05:58 --> Controller Class Initialized
INFO - 2022-01-03 07:05:58 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:05:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:05:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:05:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:05:58 --> Final output sent to browser
DEBUG - 2022-01-03 07:05:58 --> Total execution time: 0.0524
INFO - 2022-01-03 07:06:01 --> Config Class Initialized
INFO - 2022-01-03 07:06:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:06:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:06:01 --> Utf8 Class Initialized
INFO - 2022-01-03 07:06:01 --> URI Class Initialized
INFO - 2022-01-03 07:06:01 --> Router Class Initialized
INFO - 2022-01-03 07:06:01 --> Output Class Initialized
INFO - 2022-01-03 07:06:01 --> Security Class Initialized
DEBUG - 2022-01-03 07:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:06:01 --> Input Class Initialized
INFO - 2022-01-03 07:06:01 --> Language Class Initialized
INFO - 2022-01-03 07:06:01 --> Loader Class Initialized
INFO - 2022-01-03 07:06:01 --> Helper loaded: url_helper
INFO - 2022-01-03 07:06:01 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:06:01 --> Controller Class Initialized
INFO - 2022-01-03 07:06:01 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:06:01 --> Config Class Initialized
INFO - 2022-01-03 07:06:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:06:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:06:01 --> Utf8 Class Initialized
INFO - 2022-01-03 07:06:01 --> URI Class Initialized
INFO - 2022-01-03 07:06:01 --> Router Class Initialized
INFO - 2022-01-03 07:06:01 --> Output Class Initialized
INFO - 2022-01-03 07:06:01 --> Security Class Initialized
DEBUG - 2022-01-03 07:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:06:01 --> Input Class Initialized
INFO - 2022-01-03 07:06:01 --> Language Class Initialized
INFO - 2022-01-03 07:06:01 --> Loader Class Initialized
INFO - 2022-01-03 07:06:01 --> Helper loaded: url_helper
INFO - 2022-01-03 07:06:01 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:06:01 --> Controller Class Initialized
INFO - 2022-01-03 07:06:01 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:06:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:06:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:06:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:06:01 --> Final output sent to browser
DEBUG - 2022-01-03 07:06:01 --> Total execution time: 0.0545
INFO - 2022-01-03 07:06:24 --> Config Class Initialized
INFO - 2022-01-03 07:06:24 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:06:24 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:06:24 --> Utf8 Class Initialized
INFO - 2022-01-03 07:06:24 --> URI Class Initialized
INFO - 2022-01-03 07:06:24 --> Router Class Initialized
INFO - 2022-01-03 07:06:24 --> Output Class Initialized
INFO - 2022-01-03 07:06:24 --> Security Class Initialized
DEBUG - 2022-01-03 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:06:24 --> Input Class Initialized
INFO - 2022-01-03 07:06:24 --> Language Class Initialized
INFO - 2022-01-03 07:06:24 --> Loader Class Initialized
INFO - 2022-01-03 07:06:24 --> Helper loaded: url_helper
INFO - 2022-01-03 07:06:24 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:06:24 --> Controller Class Initialized
INFO - 2022-01-03 07:06:24 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:06:24 --> Config Class Initialized
INFO - 2022-01-03 07:06:24 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:06:24 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:06:24 --> Utf8 Class Initialized
INFO - 2022-01-03 07:06:24 --> URI Class Initialized
INFO - 2022-01-03 07:06:24 --> Router Class Initialized
INFO - 2022-01-03 07:06:24 --> Output Class Initialized
INFO - 2022-01-03 07:06:24 --> Security Class Initialized
DEBUG - 2022-01-03 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:06:24 --> Input Class Initialized
INFO - 2022-01-03 07:06:24 --> Language Class Initialized
INFO - 2022-01-03 07:06:24 --> Loader Class Initialized
INFO - 2022-01-03 07:06:24 --> Helper loaded: url_helper
INFO - 2022-01-03 07:06:24 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:06:24 --> Controller Class Initialized
INFO - 2022-01-03 07:06:24 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:06:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
ERROR - 2022-01-03 07:06:24 --> Severity: Warning --> Undefined array key "login_student_num" C:\xampp\htdocs\OJT\application\views\login\index.php 15
INFO - 2022-01-03 07:06:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:06:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:06:24 --> Final output sent to browser
DEBUG - 2022-01-03 07:06:24 --> Total execution time: 0.0532
INFO - 2022-01-03 07:07:25 --> Config Class Initialized
INFO - 2022-01-03 07:07:25 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:07:25 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:07:25 --> Utf8 Class Initialized
INFO - 2022-01-03 07:07:25 --> URI Class Initialized
INFO - 2022-01-03 07:07:25 --> Router Class Initialized
INFO - 2022-01-03 07:07:25 --> Output Class Initialized
INFO - 2022-01-03 07:07:25 --> Security Class Initialized
DEBUG - 2022-01-03 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:07:25 --> Input Class Initialized
INFO - 2022-01-03 07:07:25 --> Language Class Initialized
INFO - 2022-01-03 07:07:25 --> Loader Class Initialized
INFO - 2022-01-03 07:07:25 --> Helper loaded: url_helper
INFO - 2022-01-03 07:07:25 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:07:25 --> Controller Class Initialized
INFO - 2022-01-03 07:07:25 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:07:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:07:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:07:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:07:25 --> Final output sent to browser
DEBUG - 2022-01-03 07:07:25 --> Total execution time: 0.0684
INFO - 2022-01-03 07:07:28 --> Config Class Initialized
INFO - 2022-01-03 07:07:28 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:07:28 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:07:28 --> Utf8 Class Initialized
INFO - 2022-01-03 07:07:28 --> URI Class Initialized
INFO - 2022-01-03 07:07:28 --> Router Class Initialized
INFO - 2022-01-03 07:07:28 --> Output Class Initialized
INFO - 2022-01-03 07:07:28 --> Security Class Initialized
DEBUG - 2022-01-03 07:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:07:28 --> Input Class Initialized
INFO - 2022-01-03 07:07:28 --> Language Class Initialized
INFO - 2022-01-03 07:07:28 --> Loader Class Initialized
INFO - 2022-01-03 07:07:28 --> Helper loaded: url_helper
INFO - 2022-01-03 07:07:28 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:07:28 --> Controller Class Initialized
INFO - 2022-01-03 07:07:28 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:07:28 --> Config Class Initialized
INFO - 2022-01-03 07:07:28 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:07:28 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:07:28 --> Utf8 Class Initialized
INFO - 2022-01-03 07:07:28 --> URI Class Initialized
INFO - 2022-01-03 07:07:28 --> Router Class Initialized
INFO - 2022-01-03 07:07:28 --> Output Class Initialized
INFO - 2022-01-03 07:07:28 --> Security Class Initialized
DEBUG - 2022-01-03 07:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:07:28 --> Input Class Initialized
INFO - 2022-01-03 07:07:28 --> Language Class Initialized
INFO - 2022-01-03 07:07:28 --> Loader Class Initialized
INFO - 2022-01-03 07:07:28 --> Helper loaded: url_helper
INFO - 2022-01-03 07:07:28 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:07:28 --> Controller Class Initialized
INFO - 2022-01-03 07:07:28 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:07:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:07:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:07:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:07:28 --> Final output sent to browser
DEBUG - 2022-01-03 07:07:28 --> Total execution time: 0.0515
INFO - 2022-01-03 07:07:47 --> Config Class Initialized
INFO - 2022-01-03 07:07:47 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:07:47 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:07:47 --> Utf8 Class Initialized
INFO - 2022-01-03 07:07:47 --> URI Class Initialized
INFO - 2022-01-03 07:07:47 --> Router Class Initialized
INFO - 2022-01-03 07:07:47 --> Output Class Initialized
INFO - 2022-01-03 07:07:47 --> Security Class Initialized
DEBUG - 2022-01-03 07:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:07:47 --> Input Class Initialized
INFO - 2022-01-03 07:07:47 --> Language Class Initialized
INFO - 2022-01-03 07:07:47 --> Loader Class Initialized
INFO - 2022-01-03 07:07:47 --> Helper loaded: url_helper
INFO - 2022-01-03 07:07:47 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:07:47 --> Controller Class Initialized
INFO - 2022-01-03 07:07:47 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:07:47 --> Config Class Initialized
INFO - 2022-01-03 07:07:47 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:07:47 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:07:47 --> Utf8 Class Initialized
INFO - 2022-01-03 07:07:47 --> URI Class Initialized
INFO - 2022-01-03 07:07:47 --> Router Class Initialized
INFO - 2022-01-03 07:07:47 --> Output Class Initialized
INFO - 2022-01-03 07:07:47 --> Security Class Initialized
DEBUG - 2022-01-03 07:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:07:47 --> Input Class Initialized
INFO - 2022-01-03 07:07:47 --> Language Class Initialized
INFO - 2022-01-03 07:07:47 --> Loader Class Initialized
INFO - 2022-01-03 07:07:47 --> Helper loaded: url_helper
INFO - 2022-01-03 07:07:47 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:07:47 --> Controller Class Initialized
INFO - 2022-01-03 07:07:47 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:07:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:07:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:07:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:07:47 --> Final output sent to browser
DEBUG - 2022-01-03 07:07:47 --> Total execution time: 0.0574
INFO - 2022-01-03 07:08:09 --> Config Class Initialized
INFO - 2022-01-03 07:08:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:08:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:08:09 --> Utf8 Class Initialized
INFO - 2022-01-03 07:08:09 --> URI Class Initialized
INFO - 2022-01-03 07:08:09 --> Router Class Initialized
INFO - 2022-01-03 07:08:09 --> Output Class Initialized
INFO - 2022-01-03 07:08:09 --> Security Class Initialized
DEBUG - 2022-01-03 07:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:08:09 --> Input Class Initialized
INFO - 2022-01-03 07:08:09 --> Language Class Initialized
INFO - 2022-01-03 07:08:09 --> Loader Class Initialized
INFO - 2022-01-03 07:08:09 --> Helper loaded: url_helper
INFO - 2022-01-03 07:08:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:08:09 --> Controller Class Initialized
INFO - 2022-01-03 07:08:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:08:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
ERROR - 2022-01-03 07:08:09 --> Severity: Warning --> Undefined array key "login_student_num" C:\xampp\htdocs\OJT\application\views\login\index.php 15
INFO - 2022-01-03 07:08:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:08:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:08:09 --> Final output sent to browser
DEBUG - 2022-01-03 07:08:09 --> Total execution time: 0.0580
INFO - 2022-01-03 07:10:40 --> Config Class Initialized
INFO - 2022-01-03 07:10:40 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:10:40 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:10:40 --> Utf8 Class Initialized
INFO - 2022-01-03 07:10:40 --> URI Class Initialized
INFO - 2022-01-03 07:10:40 --> Router Class Initialized
INFO - 2022-01-03 07:10:40 --> Output Class Initialized
INFO - 2022-01-03 07:10:40 --> Security Class Initialized
DEBUG - 2022-01-03 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:10:40 --> Input Class Initialized
INFO - 2022-01-03 07:10:40 --> Language Class Initialized
INFO - 2022-01-03 07:10:40 --> Loader Class Initialized
INFO - 2022-01-03 07:10:40 --> Helper loaded: url_helper
INFO - 2022-01-03 07:10:40 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:10:40 --> Controller Class Initialized
INFO - 2022-01-03 07:10:40 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:10:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:10:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:10:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:10:40 --> Final output sent to browser
DEBUG - 2022-01-03 07:10:40 --> Total execution time: 0.0889
INFO - 2022-01-03 07:10:42 --> Config Class Initialized
INFO - 2022-01-03 07:10:42 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:10:42 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:10:42 --> Utf8 Class Initialized
INFO - 2022-01-03 07:10:42 --> URI Class Initialized
INFO - 2022-01-03 07:10:42 --> Router Class Initialized
INFO - 2022-01-03 07:10:42 --> Output Class Initialized
INFO - 2022-01-03 07:10:42 --> Security Class Initialized
DEBUG - 2022-01-03 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:10:42 --> Input Class Initialized
INFO - 2022-01-03 07:10:42 --> Language Class Initialized
INFO - 2022-01-03 07:10:42 --> Loader Class Initialized
INFO - 2022-01-03 07:10:42 --> Helper loaded: url_helper
INFO - 2022-01-03 07:10:42 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:10:42 --> Controller Class Initialized
INFO - 2022-01-03 07:10:42 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:10:42 --> Config Class Initialized
INFO - 2022-01-03 07:10:42 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:10:42 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:10:42 --> Utf8 Class Initialized
INFO - 2022-01-03 07:10:42 --> URI Class Initialized
INFO - 2022-01-03 07:10:42 --> Router Class Initialized
INFO - 2022-01-03 07:10:42 --> Output Class Initialized
INFO - 2022-01-03 07:10:42 --> Security Class Initialized
DEBUG - 2022-01-03 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:10:42 --> Input Class Initialized
INFO - 2022-01-03 07:10:42 --> Language Class Initialized
INFO - 2022-01-03 07:10:42 --> Loader Class Initialized
INFO - 2022-01-03 07:10:42 --> Helper loaded: url_helper
INFO - 2022-01-03 07:10:42 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:10:42 --> Controller Class Initialized
INFO - 2022-01-03 07:10:42 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:10:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:10:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:10:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:10:42 --> Final output sent to browser
DEBUG - 2022-01-03 07:10:42 --> Total execution time: 0.0497
INFO - 2022-01-03 07:10:45 --> Config Class Initialized
INFO - 2022-01-03 07:10:45 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:10:45 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:10:45 --> Utf8 Class Initialized
INFO - 2022-01-03 07:10:45 --> URI Class Initialized
INFO - 2022-01-03 07:10:45 --> Router Class Initialized
INFO - 2022-01-03 07:10:45 --> Output Class Initialized
INFO - 2022-01-03 07:10:45 --> Security Class Initialized
DEBUG - 2022-01-03 07:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:10:45 --> Input Class Initialized
INFO - 2022-01-03 07:10:45 --> Language Class Initialized
INFO - 2022-01-03 07:10:45 --> Loader Class Initialized
INFO - 2022-01-03 07:10:45 --> Helper loaded: url_helper
INFO - 2022-01-03 07:10:45 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:10:45 --> Controller Class Initialized
INFO - 2022-01-03 07:10:45 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:10:45 --> Config Class Initialized
INFO - 2022-01-03 07:10:45 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:10:45 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:10:45 --> Utf8 Class Initialized
INFO - 2022-01-03 07:10:45 --> URI Class Initialized
INFO - 2022-01-03 07:10:45 --> Router Class Initialized
INFO - 2022-01-03 07:10:45 --> Output Class Initialized
INFO - 2022-01-03 07:10:45 --> Security Class Initialized
DEBUG - 2022-01-03 07:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:10:45 --> Input Class Initialized
INFO - 2022-01-03 07:10:45 --> Language Class Initialized
INFO - 2022-01-03 07:10:45 --> Loader Class Initialized
INFO - 2022-01-03 07:10:45 --> Helper loaded: url_helper
INFO - 2022-01-03 07:10:45 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:10:45 --> Controller Class Initialized
INFO - 2022-01-03 07:10:45 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:10:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:10:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:10:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:10:45 --> Final output sent to browser
DEBUG - 2022-01-03 07:10:45 --> Total execution time: 0.0473
INFO - 2022-01-03 07:11:29 --> Config Class Initialized
INFO - 2022-01-03 07:11:29 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:11:29 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:11:29 --> Utf8 Class Initialized
INFO - 2022-01-03 07:11:29 --> URI Class Initialized
INFO - 2022-01-03 07:11:29 --> Router Class Initialized
INFO - 2022-01-03 07:11:29 --> Output Class Initialized
INFO - 2022-01-03 07:11:29 --> Security Class Initialized
DEBUG - 2022-01-03 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:11:29 --> Input Class Initialized
INFO - 2022-01-03 07:11:29 --> Language Class Initialized
INFO - 2022-01-03 07:11:29 --> Loader Class Initialized
INFO - 2022-01-03 07:11:29 --> Helper loaded: url_helper
INFO - 2022-01-03 07:11:29 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:11:29 --> Controller Class Initialized
INFO - 2022-01-03 07:11:29 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:11:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:11:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:11:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:11:29 --> Final output sent to browser
DEBUG - 2022-01-03 07:11:29 --> Total execution time: 0.0538
INFO - 2022-01-03 07:11:31 --> Config Class Initialized
INFO - 2022-01-03 07:11:31 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:11:31 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:11:31 --> Utf8 Class Initialized
INFO - 2022-01-03 07:11:31 --> URI Class Initialized
INFO - 2022-01-03 07:11:31 --> Router Class Initialized
INFO - 2022-01-03 07:11:31 --> Output Class Initialized
INFO - 2022-01-03 07:11:31 --> Security Class Initialized
DEBUG - 2022-01-03 07:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:11:31 --> Input Class Initialized
INFO - 2022-01-03 07:11:32 --> Language Class Initialized
INFO - 2022-01-03 07:11:32 --> Loader Class Initialized
INFO - 2022-01-03 07:11:32 --> Helper loaded: url_helper
INFO - 2022-01-03 07:11:32 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:11:32 --> Controller Class Initialized
INFO - 2022-01-03 07:11:32 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:11:32 --> Config Class Initialized
INFO - 2022-01-03 07:11:32 --> Hooks Class Initialized
DEBUG - 2022-01-03 07:11:32 --> UTF-8 Support Enabled
INFO - 2022-01-03 07:11:32 --> Utf8 Class Initialized
INFO - 2022-01-03 07:11:32 --> URI Class Initialized
INFO - 2022-01-03 07:11:32 --> Router Class Initialized
INFO - 2022-01-03 07:11:32 --> Output Class Initialized
INFO - 2022-01-03 07:11:32 --> Security Class Initialized
DEBUG - 2022-01-03 07:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 07:11:32 --> Input Class Initialized
INFO - 2022-01-03 07:11:32 --> Language Class Initialized
INFO - 2022-01-03 07:11:32 --> Loader Class Initialized
INFO - 2022-01-03 07:11:32 --> Helper loaded: url_helper
INFO - 2022-01-03 07:11:32 --> Database Driver Class Initialized
DEBUG - 2022-01-03 07:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 07:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 07:11:32 --> Controller Class Initialized
INFO - 2022-01-03 07:11:32 --> Model "LoginModel" initialized
INFO - 2022-01-03 07:11:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 07:11:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 07:11:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 07:11:32 --> Final output sent to browser
DEBUG - 2022-01-03 07:11:32 --> Total execution time: 0.0584
INFO - 2022-01-03 08:33:40 --> Config Class Initialized
INFO - 2022-01-03 08:33:40 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:33:40 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:33:40 --> Utf8 Class Initialized
INFO - 2022-01-03 08:33:40 --> URI Class Initialized
INFO - 2022-01-03 08:33:40 --> Router Class Initialized
INFO - 2022-01-03 08:33:40 --> Output Class Initialized
INFO - 2022-01-03 08:33:40 --> Security Class Initialized
DEBUG - 2022-01-03 08:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:33:40 --> Input Class Initialized
INFO - 2022-01-03 08:33:40 --> Language Class Initialized
INFO - 2022-01-03 08:33:40 --> Loader Class Initialized
INFO - 2022-01-03 08:33:40 --> Helper loaded: url_helper
INFO - 2022-01-03 08:33:40 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:33:40 --> Controller Class Initialized
INFO - 2022-01-03 08:33:40 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:33:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 08:33:40 --> Final output sent to browser
DEBUG - 2022-01-03 08:33:40 --> Total execution time: 0.0704
INFO - 2022-01-03 08:42:43 --> Config Class Initialized
INFO - 2022-01-03 08:42:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:42:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:42:43 --> Utf8 Class Initialized
INFO - 2022-01-03 08:42:43 --> URI Class Initialized
INFO - 2022-01-03 08:42:43 --> Router Class Initialized
INFO - 2022-01-03 08:42:43 --> Output Class Initialized
INFO - 2022-01-03 08:42:43 --> Security Class Initialized
DEBUG - 2022-01-03 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:42:43 --> Input Class Initialized
INFO - 2022-01-03 08:42:43 --> Language Class Initialized
ERROR - 2022-01-03 08:42:43 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\OJT\application\controllers\Login.php 66
INFO - 2022-01-03 08:42:45 --> Config Class Initialized
INFO - 2022-01-03 08:42:45 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:42:45 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:42:45 --> Utf8 Class Initialized
INFO - 2022-01-03 08:42:45 --> URI Class Initialized
INFO - 2022-01-03 08:42:45 --> Router Class Initialized
INFO - 2022-01-03 08:42:45 --> Output Class Initialized
INFO - 2022-01-03 08:42:45 --> Security Class Initialized
DEBUG - 2022-01-03 08:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:42:45 --> Input Class Initialized
INFO - 2022-01-03 08:42:45 --> Language Class Initialized
ERROR - 2022-01-03 08:42:45 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\OJT\application\controllers\Login.php 66
INFO - 2022-01-03 08:43:04 --> Config Class Initialized
INFO - 2022-01-03 08:43:04 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:04 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:04 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:04 --> URI Class Initialized
INFO - 2022-01-03 08:43:04 --> Router Class Initialized
INFO - 2022-01-03 08:43:04 --> Output Class Initialized
INFO - 2022-01-03 08:43:04 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:04 --> Input Class Initialized
INFO - 2022-01-03 08:43:04 --> Language Class Initialized
ERROR - 2022-01-03 08:43:04 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\OJT\application\controllers\Login.php 66
INFO - 2022-01-03 08:43:05 --> Config Class Initialized
INFO - 2022-01-03 08:43:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:05 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:05 --> URI Class Initialized
INFO - 2022-01-03 08:43:05 --> Router Class Initialized
INFO - 2022-01-03 08:43:05 --> Output Class Initialized
INFO - 2022-01-03 08:43:05 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:05 --> Input Class Initialized
INFO - 2022-01-03 08:43:05 --> Language Class Initialized
ERROR - 2022-01-03 08:43:05 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\OJT\application\controllers\Login.php 66
INFO - 2022-01-03 08:43:20 --> Config Class Initialized
INFO - 2022-01-03 08:43:20 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:20 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:20 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:20 --> URI Class Initialized
INFO - 2022-01-03 08:43:20 --> Router Class Initialized
INFO - 2022-01-03 08:43:20 --> Output Class Initialized
INFO - 2022-01-03 08:43:20 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:20 --> Input Class Initialized
INFO - 2022-01-03 08:43:20 --> Language Class Initialized
INFO - 2022-01-03 08:43:20 --> Loader Class Initialized
INFO - 2022-01-03 08:43:20 --> Helper loaded: url_helper
INFO - 2022-01-03 08:43:20 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:43:20 --> Controller Class Initialized
INFO - 2022-01-03 08:43:20 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:43:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:43:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:43:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:43:21 --> Final output sent to browser
DEBUG - 2022-01-03 08:43:21 --> Total execution time: 0.1042
INFO - 2022-01-03 08:43:49 --> Config Class Initialized
INFO - 2022-01-03 08:43:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:49 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:49 --> URI Class Initialized
INFO - 2022-01-03 08:43:49 --> Router Class Initialized
INFO - 2022-01-03 08:43:49 --> Output Class Initialized
INFO - 2022-01-03 08:43:49 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:49 --> Input Class Initialized
INFO - 2022-01-03 08:43:49 --> Language Class Initialized
INFO - 2022-01-03 08:43:49 --> Loader Class Initialized
INFO - 2022-01-03 08:43:49 --> Helper loaded: url_helper
INFO - 2022-01-03 08:43:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:43:49 --> Controller Class Initialized
INFO - 2022-01-03 08:43:49 --> Model "LoginModel" initialized
ERROR - 2022-01-03 08:43:49 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 08:43:49 --> Config Class Initialized
INFO - 2022-01-03 08:43:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:49 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:49 --> URI Class Initialized
DEBUG - 2022-01-03 08:43:49 --> No URI present. Default controller set.
INFO - 2022-01-03 08:43:49 --> Router Class Initialized
INFO - 2022-01-03 08:43:49 --> Output Class Initialized
INFO - 2022-01-03 08:43:49 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:49 --> Input Class Initialized
INFO - 2022-01-03 08:43:49 --> Language Class Initialized
INFO - 2022-01-03 08:43:49 --> Loader Class Initialized
INFO - 2022-01-03 08:43:49 --> Helper loaded: url_helper
INFO - 2022-01-03 08:43:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:43:49 --> Controller Class Initialized
INFO - 2022-01-03 08:43:49 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:43:49 --> Model "UserModel" initialized
INFO - 2022-01-03 08:43:49 --> Model "AdminModel" initialized
INFO - 2022-01-03 08:43:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 08:43:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 08:43:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:43:49 --> Final output sent to browser
DEBUG - 2022-01-03 08:43:49 --> Total execution time: 0.0666
INFO - 2022-01-03 08:43:49 --> Config Class Initialized
INFO - 2022-01-03 08:43:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:49 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:49 --> URI Class Initialized
INFO - 2022-01-03 08:43:49 --> Router Class Initialized
INFO - 2022-01-03 08:43:49 --> Output Class Initialized
INFO - 2022-01-03 08:43:49 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:49 --> Input Class Initialized
INFO - 2022-01-03 08:43:49 --> Language Class Initialized
ERROR - 2022-01-03 08:43:49 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 08:43:49 --> Config Class Initialized
INFO - 2022-01-03 08:43:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:49 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:49 --> URI Class Initialized
INFO - 2022-01-03 08:43:49 --> Router Class Initialized
INFO - 2022-01-03 08:43:49 --> Output Class Initialized
INFO - 2022-01-03 08:43:49 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:49 --> Input Class Initialized
INFO - 2022-01-03 08:43:49 --> Language Class Initialized
ERROR - 2022-01-03 08:43:49 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 08:43:52 --> Config Class Initialized
INFO - 2022-01-03 08:43:52 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:52 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:52 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:52 --> URI Class Initialized
INFO - 2022-01-03 08:43:52 --> Router Class Initialized
INFO - 2022-01-03 08:43:52 --> Output Class Initialized
INFO - 2022-01-03 08:43:52 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:52 --> Input Class Initialized
INFO - 2022-01-03 08:43:52 --> Language Class Initialized
INFO - 2022-01-03 08:43:52 --> Loader Class Initialized
INFO - 2022-01-03 08:43:52 --> Helper loaded: url_helper
INFO - 2022-01-03 08:43:52 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:43:52 --> Controller Class Initialized
INFO - 2022-01-03 08:43:52 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:43:52 --> Config Class Initialized
INFO - 2022-01-03 08:43:52 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:52 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:52 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:52 --> URI Class Initialized
INFO - 2022-01-03 08:43:52 --> Router Class Initialized
INFO - 2022-01-03 08:43:52 --> Output Class Initialized
INFO - 2022-01-03 08:43:52 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:52 --> Input Class Initialized
INFO - 2022-01-03 08:43:52 --> Language Class Initialized
INFO - 2022-01-03 08:43:52 --> Loader Class Initialized
INFO - 2022-01-03 08:43:52 --> Helper loaded: url_helper
INFO - 2022-01-03 08:43:52 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:43:52 --> Controller Class Initialized
INFO - 2022-01-03 08:43:52 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:43:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:43:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:43:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:43:52 --> Final output sent to browser
DEBUG - 2022-01-03 08:43:52 --> Total execution time: 0.0587
INFO - 2022-01-03 08:43:57 --> Config Class Initialized
INFO - 2022-01-03 08:43:57 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:57 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:57 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:57 --> URI Class Initialized
INFO - 2022-01-03 08:43:57 --> Router Class Initialized
INFO - 2022-01-03 08:43:57 --> Output Class Initialized
INFO - 2022-01-03 08:43:57 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:57 --> Input Class Initialized
INFO - 2022-01-03 08:43:57 --> Language Class Initialized
INFO - 2022-01-03 08:43:57 --> Loader Class Initialized
INFO - 2022-01-03 08:43:57 --> Helper loaded: url_helper
INFO - 2022-01-03 08:43:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:43:57 --> Controller Class Initialized
INFO - 2022-01-03 08:43:57 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:43:57 --> Config Class Initialized
INFO - 2022-01-03 08:43:57 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:43:57 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:43:57 --> Utf8 Class Initialized
INFO - 2022-01-03 08:43:57 --> URI Class Initialized
INFO - 2022-01-03 08:43:57 --> Router Class Initialized
INFO - 2022-01-03 08:43:57 --> Output Class Initialized
INFO - 2022-01-03 08:43:57 --> Security Class Initialized
DEBUG - 2022-01-03 08:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:43:57 --> Input Class Initialized
INFO - 2022-01-03 08:43:57 --> Language Class Initialized
INFO - 2022-01-03 08:43:57 --> Loader Class Initialized
INFO - 2022-01-03 08:43:57 --> Helper loaded: url_helper
INFO - 2022-01-03 08:43:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:43:57 --> Controller Class Initialized
INFO - 2022-01-03 08:43:57 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:43:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:43:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:43:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:43:57 --> Final output sent to browser
DEBUG - 2022-01-03 08:43:57 --> Total execution time: 0.0422
INFO - 2022-01-03 08:44:01 --> Config Class Initialized
INFO - 2022-01-03 08:44:01 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:44:01 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:44:01 --> Utf8 Class Initialized
INFO - 2022-01-03 08:44:01 --> URI Class Initialized
INFO - 2022-01-03 08:44:01 --> Router Class Initialized
INFO - 2022-01-03 08:44:01 --> Output Class Initialized
INFO - 2022-01-03 08:44:01 --> Security Class Initialized
DEBUG - 2022-01-03 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:44:01 --> Input Class Initialized
INFO - 2022-01-03 08:44:01 --> Language Class Initialized
INFO - 2022-01-03 08:44:01 --> Loader Class Initialized
INFO - 2022-01-03 08:44:02 --> Helper loaded: url_helper
INFO - 2022-01-03 08:44:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:44:02 --> Controller Class Initialized
INFO - 2022-01-03 08:44:02 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:44:02 --> Config Class Initialized
INFO - 2022-01-03 08:44:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:44:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:44:02 --> Utf8 Class Initialized
INFO - 2022-01-03 08:44:02 --> URI Class Initialized
INFO - 2022-01-03 08:44:02 --> Router Class Initialized
INFO - 2022-01-03 08:44:02 --> Output Class Initialized
INFO - 2022-01-03 08:44:02 --> Security Class Initialized
DEBUG - 2022-01-03 08:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:44:02 --> Input Class Initialized
INFO - 2022-01-03 08:44:02 --> Language Class Initialized
INFO - 2022-01-03 08:44:02 --> Loader Class Initialized
INFO - 2022-01-03 08:44:02 --> Helper loaded: url_helper
INFO - 2022-01-03 08:44:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:44:02 --> Controller Class Initialized
INFO - 2022-01-03 08:44:02 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:44:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:44:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:44:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:44:02 --> Final output sent to browser
DEBUG - 2022-01-03 08:44:02 --> Total execution time: 0.0499
INFO - 2022-01-03 08:44:08 --> Config Class Initialized
INFO - 2022-01-03 08:44:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:44:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:44:08 --> Utf8 Class Initialized
INFO - 2022-01-03 08:44:08 --> URI Class Initialized
INFO - 2022-01-03 08:44:08 --> Router Class Initialized
INFO - 2022-01-03 08:44:08 --> Output Class Initialized
INFO - 2022-01-03 08:44:08 --> Security Class Initialized
DEBUG - 2022-01-03 08:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:44:08 --> Input Class Initialized
INFO - 2022-01-03 08:44:08 --> Language Class Initialized
INFO - 2022-01-03 08:44:08 --> Loader Class Initialized
INFO - 2022-01-03 08:44:08 --> Helper loaded: url_helper
INFO - 2022-01-03 08:44:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:44:08 --> Controller Class Initialized
INFO - 2022-01-03 08:44:08 --> Model "LoginModel" initialized
ERROR - 2022-01-03 08:44:08 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 08:44:08 --> Config Class Initialized
INFO - 2022-01-03 08:44:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:44:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:44:08 --> Utf8 Class Initialized
INFO - 2022-01-03 08:44:08 --> URI Class Initialized
DEBUG - 2022-01-03 08:44:08 --> No URI present. Default controller set.
INFO - 2022-01-03 08:44:08 --> Router Class Initialized
INFO - 2022-01-03 08:44:08 --> Output Class Initialized
INFO - 2022-01-03 08:44:08 --> Security Class Initialized
DEBUG - 2022-01-03 08:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:44:08 --> Input Class Initialized
INFO - 2022-01-03 08:44:08 --> Language Class Initialized
INFO - 2022-01-03 08:44:08 --> Loader Class Initialized
INFO - 2022-01-03 08:44:08 --> Helper loaded: url_helper
INFO - 2022-01-03 08:44:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:44:08 --> Controller Class Initialized
INFO - 2022-01-03 08:44:08 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:44:08 --> Model "UserModel" initialized
INFO - 2022-01-03 08:44:08 --> Model "AdminModel" initialized
INFO - 2022-01-03 08:44:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 08:44:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 08:44:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:44:08 --> Final output sent to browser
DEBUG - 2022-01-03 08:44:08 --> Total execution time: 0.0495
INFO - 2022-01-03 08:44:08 --> Config Class Initialized
INFO - 2022-01-03 08:44:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:44:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:44:08 --> Utf8 Class Initialized
INFO - 2022-01-03 08:44:08 --> URI Class Initialized
INFO - 2022-01-03 08:44:08 --> Router Class Initialized
INFO - 2022-01-03 08:44:08 --> Output Class Initialized
INFO - 2022-01-03 08:44:08 --> Security Class Initialized
DEBUG - 2022-01-03 08:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:44:08 --> Input Class Initialized
INFO - 2022-01-03 08:44:08 --> Language Class Initialized
ERROR - 2022-01-03 08:44:08 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 08:44:08 --> Config Class Initialized
INFO - 2022-01-03 08:44:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:44:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:44:08 --> Utf8 Class Initialized
INFO - 2022-01-03 08:44:08 --> URI Class Initialized
INFO - 2022-01-03 08:44:08 --> Router Class Initialized
INFO - 2022-01-03 08:44:08 --> Output Class Initialized
INFO - 2022-01-03 08:44:08 --> Security Class Initialized
DEBUG - 2022-01-03 08:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:44:08 --> Input Class Initialized
INFO - 2022-01-03 08:44:08 --> Language Class Initialized
ERROR - 2022-01-03 08:44:08 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 08:44:09 --> Config Class Initialized
INFO - 2022-01-03 08:44:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:44:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:44:09 --> Utf8 Class Initialized
INFO - 2022-01-03 08:44:09 --> URI Class Initialized
INFO - 2022-01-03 08:44:09 --> Router Class Initialized
INFO - 2022-01-03 08:44:09 --> Output Class Initialized
INFO - 2022-01-03 08:44:09 --> Security Class Initialized
DEBUG - 2022-01-03 08:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:44:09 --> Input Class Initialized
INFO - 2022-01-03 08:44:09 --> Language Class Initialized
INFO - 2022-01-03 08:44:09 --> Loader Class Initialized
INFO - 2022-01-03 08:44:09 --> Helper loaded: url_helper
INFO - 2022-01-03 08:44:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:44:09 --> Controller Class Initialized
INFO - 2022-01-03 08:44:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:44:09 --> Config Class Initialized
INFO - 2022-01-03 08:44:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:44:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:44:09 --> Utf8 Class Initialized
INFO - 2022-01-03 08:44:09 --> URI Class Initialized
INFO - 2022-01-03 08:44:09 --> Router Class Initialized
INFO - 2022-01-03 08:44:09 --> Output Class Initialized
INFO - 2022-01-03 08:44:09 --> Security Class Initialized
DEBUG - 2022-01-03 08:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:44:09 --> Input Class Initialized
INFO - 2022-01-03 08:44:09 --> Language Class Initialized
INFO - 2022-01-03 08:44:09 --> Loader Class Initialized
INFO - 2022-01-03 08:44:09 --> Helper loaded: url_helper
INFO - 2022-01-03 08:44:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:44:09 --> Controller Class Initialized
INFO - 2022-01-03 08:44:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:44:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:44:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:44:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:44:09 --> Final output sent to browser
DEBUG - 2022-01-03 08:44:09 --> Total execution time: 0.0621
INFO - 2022-01-03 08:50:43 --> Config Class Initialized
INFO - 2022-01-03 08:50:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:50:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:50:43 --> Utf8 Class Initialized
INFO - 2022-01-03 08:50:43 --> URI Class Initialized
INFO - 2022-01-03 08:50:43 --> Router Class Initialized
INFO - 2022-01-03 08:50:43 --> Output Class Initialized
INFO - 2022-01-03 08:50:43 --> Security Class Initialized
DEBUG - 2022-01-03 08:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:50:43 --> Input Class Initialized
INFO - 2022-01-03 08:50:43 --> Language Class Initialized
INFO - 2022-01-03 08:50:43 --> Loader Class Initialized
INFO - 2022-01-03 08:50:43 --> Helper loaded: url_helper
INFO - 2022-01-03 08:50:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:50:43 --> Controller Class Initialized
INFO - 2022-01-03 08:50:43 --> Model "LoginModel" initialized
ERROR - 2022-01-03 08:50:43 --> Severity: error --> Exception: Too few arguments to function LoginModel::validateUser(), 1 passed in C:\xampp\htdocs\OJT\application\controllers\Login.php on line 66 and exactly 2 expected C:\xampp\htdocs\OJT\application\models\LoginModel.php 15
INFO - 2022-01-03 08:51:03 --> Config Class Initialized
INFO - 2022-01-03 08:51:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:51:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:51:03 --> Utf8 Class Initialized
INFO - 2022-01-03 08:51:03 --> URI Class Initialized
INFO - 2022-01-03 08:51:03 --> Router Class Initialized
INFO - 2022-01-03 08:51:03 --> Output Class Initialized
INFO - 2022-01-03 08:51:03 --> Security Class Initialized
DEBUG - 2022-01-03 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:51:03 --> Input Class Initialized
INFO - 2022-01-03 08:51:03 --> Language Class Initialized
INFO - 2022-01-03 08:51:03 --> Loader Class Initialized
INFO - 2022-01-03 08:51:03 --> Helper loaded: url_helper
INFO - 2022-01-03 08:51:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:51:03 --> Controller Class Initialized
INFO - 2022-01-03 08:51:03 --> Model "LoginModel" initialized
ERROR - 2022-01-03 08:51:03 --> Severity: Warning --> foreach() argument must be of type array|object, int given C:\xampp\htdocs\OJT\application\controllers\Login.php 66
INFO - 2022-01-03 08:51:03 --> Final output sent to browser
DEBUG - 2022-01-03 08:51:03 --> Total execution time: 0.1010
INFO - 2022-01-03 08:51:16 --> Config Class Initialized
INFO - 2022-01-03 08:51:16 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:51:16 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:51:16 --> Utf8 Class Initialized
INFO - 2022-01-03 08:51:16 --> URI Class Initialized
INFO - 2022-01-03 08:51:16 --> Router Class Initialized
INFO - 2022-01-03 08:51:16 --> Output Class Initialized
INFO - 2022-01-03 08:51:16 --> Security Class Initialized
DEBUG - 2022-01-03 08:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:51:16 --> Input Class Initialized
INFO - 2022-01-03 08:51:16 --> Language Class Initialized
INFO - 2022-01-03 08:51:16 --> Loader Class Initialized
INFO - 2022-01-03 08:51:16 --> Helper loaded: url_helper
INFO - 2022-01-03 08:51:16 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:51:16 --> Controller Class Initialized
INFO - 2022-01-03 08:51:16 --> Model "LoginModel" initialized
ERROR - 2022-01-03 08:51:16 --> Severity: Warning --> foreach() argument must be of type array|object, int given C:\xampp\htdocs\OJT\application\controllers\Login.php 66
INFO - 2022-01-03 08:51:16 --> Final output sent to browser
DEBUG - 2022-01-03 08:51:16 --> Total execution time: 0.0870
INFO - 2022-01-03 08:51:35 --> Config Class Initialized
INFO - 2022-01-03 08:51:35 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:51:35 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:51:35 --> Utf8 Class Initialized
INFO - 2022-01-03 08:51:35 --> URI Class Initialized
INFO - 2022-01-03 08:51:35 --> Router Class Initialized
INFO - 2022-01-03 08:51:35 --> Output Class Initialized
INFO - 2022-01-03 08:51:35 --> Security Class Initialized
DEBUG - 2022-01-03 08:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:51:35 --> Input Class Initialized
INFO - 2022-01-03 08:51:35 --> Language Class Initialized
INFO - 2022-01-03 08:51:35 --> Loader Class Initialized
INFO - 2022-01-03 08:51:35 --> Helper loaded: url_helper
INFO - 2022-01-03 08:51:35 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:51:35 --> Controller Class Initialized
INFO - 2022-01-03 08:51:35 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:51:35 --> Final output sent to browser
DEBUG - 2022-01-03 08:51:35 --> Total execution time: 0.0869
INFO - 2022-01-03 08:51:43 --> Config Class Initialized
INFO - 2022-01-03 08:51:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:51:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:51:43 --> Utf8 Class Initialized
INFO - 2022-01-03 08:51:43 --> URI Class Initialized
INFO - 2022-01-03 08:51:43 --> Router Class Initialized
INFO - 2022-01-03 08:51:43 --> Output Class Initialized
INFO - 2022-01-03 08:51:43 --> Security Class Initialized
DEBUG - 2022-01-03 08:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:51:43 --> Input Class Initialized
INFO - 2022-01-03 08:51:43 --> Language Class Initialized
INFO - 2022-01-03 08:51:43 --> Loader Class Initialized
INFO - 2022-01-03 08:51:43 --> Helper loaded: url_helper
INFO - 2022-01-03 08:51:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:51:43 --> Controller Class Initialized
INFO - 2022-01-03 08:51:43 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:51:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:51:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:51:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:51:43 --> Final output sent to browser
DEBUG - 2022-01-03 08:51:43 --> Total execution time: 0.0669
INFO - 2022-01-03 08:51:47 --> Config Class Initialized
INFO - 2022-01-03 08:51:47 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:51:47 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:51:47 --> Utf8 Class Initialized
INFO - 2022-01-03 08:51:47 --> URI Class Initialized
INFO - 2022-01-03 08:51:47 --> Router Class Initialized
INFO - 2022-01-03 08:51:47 --> Output Class Initialized
INFO - 2022-01-03 08:51:47 --> Security Class Initialized
DEBUG - 2022-01-03 08:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:51:47 --> Input Class Initialized
INFO - 2022-01-03 08:51:47 --> Language Class Initialized
INFO - 2022-01-03 08:51:48 --> Loader Class Initialized
INFO - 2022-01-03 08:51:48 --> Helper loaded: url_helper
INFO - 2022-01-03 08:51:48 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:51:48 --> Controller Class Initialized
INFO - 2022-01-03 08:51:48 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:51:48 --> Final output sent to browser
DEBUG - 2022-01-03 08:51:48 --> Total execution time: 0.0784
INFO - 2022-01-03 08:52:11 --> Config Class Initialized
INFO - 2022-01-03 08:52:11 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:52:11 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:52:11 --> Utf8 Class Initialized
INFO - 2022-01-03 08:52:11 --> URI Class Initialized
INFO - 2022-01-03 08:52:11 --> Router Class Initialized
INFO - 2022-01-03 08:52:11 --> Output Class Initialized
INFO - 2022-01-03 08:52:12 --> Security Class Initialized
DEBUG - 2022-01-03 08:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:52:12 --> Input Class Initialized
INFO - 2022-01-03 08:52:12 --> Language Class Initialized
INFO - 2022-01-03 08:52:12 --> Loader Class Initialized
INFO - 2022-01-03 08:52:12 --> Helper loaded: url_helper
INFO - 2022-01-03 08:52:12 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:52:12 --> Controller Class Initialized
INFO - 2022-01-03 08:52:12 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:52:12 --> Final output sent to browser
DEBUG - 2022-01-03 08:52:12 --> Total execution time: 0.0773
INFO - 2022-01-03 08:52:19 --> Config Class Initialized
INFO - 2022-01-03 08:52:19 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:52:19 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:52:19 --> Utf8 Class Initialized
INFO - 2022-01-03 08:52:19 --> URI Class Initialized
INFO - 2022-01-03 08:52:19 --> Router Class Initialized
INFO - 2022-01-03 08:52:19 --> Output Class Initialized
INFO - 2022-01-03 08:52:19 --> Security Class Initialized
DEBUG - 2022-01-03 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:52:19 --> Input Class Initialized
INFO - 2022-01-03 08:52:19 --> Language Class Initialized
INFO - 2022-01-03 08:52:19 --> Loader Class Initialized
INFO - 2022-01-03 08:52:19 --> Helper loaded: url_helper
INFO - 2022-01-03 08:52:19 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:52:19 --> Controller Class Initialized
INFO - 2022-01-03 08:52:19 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:52:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:52:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:52:19 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:52:19 --> Final output sent to browser
DEBUG - 2022-01-03 08:52:19 --> Total execution time: 0.0611
INFO - 2022-01-03 08:52:28 --> Config Class Initialized
INFO - 2022-01-03 08:52:28 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:52:28 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:52:28 --> Utf8 Class Initialized
INFO - 2022-01-03 08:52:28 --> URI Class Initialized
INFO - 2022-01-03 08:52:28 --> Router Class Initialized
INFO - 2022-01-03 08:52:28 --> Output Class Initialized
INFO - 2022-01-03 08:52:28 --> Security Class Initialized
DEBUG - 2022-01-03 08:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:52:28 --> Input Class Initialized
INFO - 2022-01-03 08:52:28 --> Language Class Initialized
INFO - 2022-01-03 08:52:28 --> Loader Class Initialized
INFO - 2022-01-03 08:52:28 --> Helper loaded: url_helper
INFO - 2022-01-03 08:52:28 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:52:28 --> Controller Class Initialized
INFO - 2022-01-03 08:52:28 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:52:28 --> Final output sent to browser
DEBUG - 2022-01-03 08:52:28 --> Total execution time: 0.0765
INFO - 2022-01-03 08:52:44 --> Config Class Initialized
INFO - 2022-01-03 08:52:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:52:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:52:44 --> Utf8 Class Initialized
INFO - 2022-01-03 08:52:44 --> URI Class Initialized
INFO - 2022-01-03 08:52:44 --> Router Class Initialized
INFO - 2022-01-03 08:52:44 --> Output Class Initialized
INFO - 2022-01-03 08:52:44 --> Security Class Initialized
DEBUG - 2022-01-03 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:52:44 --> Input Class Initialized
INFO - 2022-01-03 08:52:44 --> Language Class Initialized
INFO - 2022-01-03 08:52:44 --> Loader Class Initialized
INFO - 2022-01-03 08:52:44 --> Helper loaded: url_helper
INFO - 2022-01-03 08:52:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:52:44 --> Controller Class Initialized
INFO - 2022-01-03 08:52:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:52:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:52:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:52:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:52:44 --> Final output sent to browser
DEBUG - 2022-01-03 08:52:44 --> Total execution time: 0.0767
INFO - 2022-01-03 08:52:49 --> Config Class Initialized
INFO - 2022-01-03 08:52:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:52:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:52:49 --> Utf8 Class Initialized
INFO - 2022-01-03 08:52:49 --> URI Class Initialized
INFO - 2022-01-03 08:52:49 --> Router Class Initialized
INFO - 2022-01-03 08:52:49 --> Output Class Initialized
INFO - 2022-01-03 08:52:49 --> Security Class Initialized
DEBUG - 2022-01-03 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:52:49 --> Input Class Initialized
INFO - 2022-01-03 08:52:49 --> Language Class Initialized
INFO - 2022-01-03 08:52:49 --> Loader Class Initialized
INFO - 2022-01-03 08:52:49 --> Helper loaded: url_helper
INFO - 2022-01-03 08:52:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:52:49 --> Controller Class Initialized
INFO - 2022-01-03 08:52:49 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:52:49 --> Final output sent to browser
DEBUG - 2022-01-03 08:52:49 --> Total execution time: 0.0989
INFO - 2022-01-03 08:54:38 --> Config Class Initialized
INFO - 2022-01-03 08:54:38 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:54:38 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:54:38 --> Utf8 Class Initialized
INFO - 2022-01-03 08:54:38 --> URI Class Initialized
INFO - 2022-01-03 08:54:38 --> Router Class Initialized
INFO - 2022-01-03 08:54:38 --> Output Class Initialized
INFO - 2022-01-03 08:54:38 --> Security Class Initialized
DEBUG - 2022-01-03 08:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:54:38 --> Input Class Initialized
INFO - 2022-01-03 08:54:38 --> Language Class Initialized
INFO - 2022-01-03 08:54:38 --> Loader Class Initialized
INFO - 2022-01-03 08:54:38 --> Helper loaded: url_helper
INFO - 2022-01-03 08:54:38 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:54:38 --> Controller Class Initialized
INFO - 2022-01-03 08:54:38 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:54:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:54:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:54:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:54:38 --> Final output sent to browser
DEBUG - 2022-01-03 08:54:38 --> Total execution time: 0.0947
INFO - 2022-01-03 08:54:51 --> Config Class Initialized
INFO - 2022-01-03 08:54:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:54:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:54:51 --> Utf8 Class Initialized
INFO - 2022-01-03 08:54:51 --> URI Class Initialized
INFO - 2022-01-03 08:54:51 --> Router Class Initialized
INFO - 2022-01-03 08:54:51 --> Output Class Initialized
INFO - 2022-01-03 08:54:51 --> Security Class Initialized
DEBUG - 2022-01-03 08:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:54:51 --> Input Class Initialized
INFO - 2022-01-03 08:54:51 --> Language Class Initialized
INFO - 2022-01-03 08:54:51 --> Loader Class Initialized
INFO - 2022-01-03 08:54:51 --> Helper loaded: url_helper
INFO - 2022-01-03 08:54:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:54:51 --> Controller Class Initialized
INFO - 2022-01-03 08:54:51 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:54:51 --> Config Class Initialized
INFO - 2022-01-03 08:54:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:54:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:54:51 --> Utf8 Class Initialized
INFO - 2022-01-03 08:54:51 --> URI Class Initialized
INFO - 2022-01-03 08:54:51 --> Router Class Initialized
INFO - 2022-01-03 08:54:51 --> Output Class Initialized
INFO - 2022-01-03 08:54:51 --> Security Class Initialized
DEBUG - 2022-01-03 08:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:54:51 --> Input Class Initialized
INFO - 2022-01-03 08:54:51 --> Language Class Initialized
INFO - 2022-01-03 08:54:51 --> Loader Class Initialized
INFO - 2022-01-03 08:54:51 --> Helper loaded: url_helper
INFO - 2022-01-03 08:54:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:54:51 --> Controller Class Initialized
INFO - 2022-01-03 08:54:51 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:54:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:54:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:54:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:54:51 --> Final output sent to browser
DEBUG - 2022-01-03 08:54:51 --> Total execution time: 0.0735
INFO - 2022-01-03 08:54:56 --> Config Class Initialized
INFO - 2022-01-03 08:54:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:54:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:54:56 --> Utf8 Class Initialized
INFO - 2022-01-03 08:54:56 --> URI Class Initialized
INFO - 2022-01-03 08:54:56 --> Router Class Initialized
INFO - 2022-01-03 08:54:56 --> Output Class Initialized
INFO - 2022-01-03 08:54:56 --> Security Class Initialized
DEBUG - 2022-01-03 08:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:54:56 --> Input Class Initialized
INFO - 2022-01-03 08:54:56 --> Language Class Initialized
INFO - 2022-01-03 08:54:56 --> Loader Class Initialized
INFO - 2022-01-03 08:54:56 --> Helper loaded: url_helper
INFO - 2022-01-03 08:54:56 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:54:56 --> Controller Class Initialized
INFO - 2022-01-03 08:54:56 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:54:56 --> Final output sent to browser
DEBUG - 2022-01-03 08:54:56 --> Total execution time: 0.1050
INFO - 2022-01-03 08:55:15 --> Config Class Initialized
INFO - 2022-01-03 08:55:15 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:55:15 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:55:15 --> Utf8 Class Initialized
INFO - 2022-01-03 08:55:15 --> URI Class Initialized
INFO - 2022-01-03 08:55:15 --> Router Class Initialized
INFO - 2022-01-03 08:55:15 --> Output Class Initialized
INFO - 2022-01-03 08:55:15 --> Security Class Initialized
DEBUG - 2022-01-03 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:55:15 --> Input Class Initialized
INFO - 2022-01-03 08:55:15 --> Language Class Initialized
INFO - 2022-01-03 08:55:15 --> Loader Class Initialized
INFO - 2022-01-03 08:55:15 --> Helper loaded: url_helper
INFO - 2022-01-03 08:55:15 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:55:15 --> Controller Class Initialized
INFO - 2022-01-03 08:55:15 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:55:15 --> Final output sent to browser
DEBUG - 2022-01-03 08:55:15 --> Total execution time: 0.0839
INFO - 2022-01-03 08:55:17 --> Config Class Initialized
INFO - 2022-01-03 08:55:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:55:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:55:17 --> Utf8 Class Initialized
INFO - 2022-01-03 08:55:17 --> URI Class Initialized
INFO - 2022-01-03 08:55:17 --> Router Class Initialized
INFO - 2022-01-03 08:55:17 --> Output Class Initialized
INFO - 2022-01-03 08:55:17 --> Security Class Initialized
DEBUG - 2022-01-03 08:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:55:17 --> Input Class Initialized
INFO - 2022-01-03 08:55:17 --> Language Class Initialized
INFO - 2022-01-03 08:55:17 --> Loader Class Initialized
INFO - 2022-01-03 08:55:17 --> Helper loaded: url_helper
INFO - 2022-01-03 08:55:17 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:55:17 --> Controller Class Initialized
INFO - 2022-01-03 08:55:17 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:55:17 --> Final output sent to browser
DEBUG - 2022-01-03 08:55:17 --> Total execution time: 0.0694
INFO - 2022-01-03 08:55:17 --> Config Class Initialized
INFO - 2022-01-03 08:55:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:55:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:55:17 --> Utf8 Class Initialized
INFO - 2022-01-03 08:55:17 --> URI Class Initialized
INFO - 2022-01-03 08:55:17 --> Router Class Initialized
INFO - 2022-01-03 08:55:17 --> Output Class Initialized
INFO - 2022-01-03 08:55:17 --> Security Class Initialized
DEBUG - 2022-01-03 08:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:55:17 --> Input Class Initialized
INFO - 2022-01-03 08:55:17 --> Language Class Initialized
INFO - 2022-01-03 08:55:17 --> Loader Class Initialized
INFO - 2022-01-03 08:55:17 --> Helper loaded: url_helper
INFO - 2022-01-03 08:55:17 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:55:17 --> Controller Class Initialized
INFO - 2022-01-03 08:55:17 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:55:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:55:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:55:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:55:17 --> Final output sent to browser
DEBUG - 2022-01-03 08:55:17 --> Total execution time: 0.0737
INFO - 2022-01-03 08:55:21 --> Config Class Initialized
INFO - 2022-01-03 08:55:21 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:55:21 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:55:21 --> Utf8 Class Initialized
INFO - 2022-01-03 08:55:21 --> URI Class Initialized
INFO - 2022-01-03 08:55:21 --> Router Class Initialized
INFO - 2022-01-03 08:55:21 --> Output Class Initialized
INFO - 2022-01-03 08:55:21 --> Security Class Initialized
DEBUG - 2022-01-03 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:55:21 --> Input Class Initialized
INFO - 2022-01-03 08:55:21 --> Language Class Initialized
INFO - 2022-01-03 08:55:21 --> Loader Class Initialized
INFO - 2022-01-03 08:55:21 --> Helper loaded: url_helper
INFO - 2022-01-03 08:55:21 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:55:21 --> Controller Class Initialized
INFO - 2022-01-03 08:55:21 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:55:21 --> Final output sent to browser
DEBUG - 2022-01-03 08:55:21 --> Total execution time: 0.0883
INFO - 2022-01-03 08:56:36 --> Config Class Initialized
INFO - 2022-01-03 08:56:36 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:56:36 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:56:36 --> Utf8 Class Initialized
INFO - 2022-01-03 08:56:36 --> URI Class Initialized
INFO - 2022-01-03 08:56:36 --> Router Class Initialized
INFO - 2022-01-03 08:56:36 --> Output Class Initialized
INFO - 2022-01-03 08:56:36 --> Security Class Initialized
DEBUG - 2022-01-03 08:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:56:36 --> Input Class Initialized
INFO - 2022-01-03 08:56:36 --> Language Class Initialized
INFO - 2022-01-03 08:56:36 --> Loader Class Initialized
INFO - 2022-01-03 08:56:36 --> Helper loaded: url_helper
INFO - 2022-01-03 08:56:36 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:56:36 --> Controller Class Initialized
INFO - 2022-01-03 08:56:36 --> Model "LoginModel" initialized
ERROR - 2022-01-03 08:56:36 --> Severity: Warning --> Undefined variable $registration_data C:\xampp\htdocs\OJT\application\views\test2.php 3
INFO - 2022-01-03 08:56:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 08:56:36 --> Final output sent to browser
DEBUG - 2022-01-03 08:56:36 --> Total execution time: 0.0731
INFO - 2022-01-03 08:56:45 --> Config Class Initialized
INFO - 2022-01-03 08:56:45 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:56:45 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:56:45 --> Utf8 Class Initialized
INFO - 2022-01-03 08:56:45 --> URI Class Initialized
INFO - 2022-01-03 08:56:45 --> Router Class Initialized
INFO - 2022-01-03 08:56:45 --> Output Class Initialized
INFO - 2022-01-03 08:56:45 --> Security Class Initialized
DEBUG - 2022-01-03 08:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:56:45 --> Input Class Initialized
INFO - 2022-01-03 08:56:45 --> Language Class Initialized
INFO - 2022-01-03 08:56:45 --> Loader Class Initialized
INFO - 2022-01-03 08:56:45 --> Helper loaded: url_helper
INFO - 2022-01-03 08:56:45 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:56:45 --> Controller Class Initialized
INFO - 2022-01-03 08:56:45 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:56:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:56:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:56:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:56:45 --> Final output sent to browser
DEBUG - 2022-01-03 08:56:45 --> Total execution time: 0.1153
INFO - 2022-01-03 08:56:50 --> Config Class Initialized
INFO - 2022-01-03 08:56:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:56:50 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:56:50 --> Utf8 Class Initialized
INFO - 2022-01-03 08:56:50 --> URI Class Initialized
INFO - 2022-01-03 08:56:50 --> Router Class Initialized
INFO - 2022-01-03 08:56:50 --> Output Class Initialized
INFO - 2022-01-03 08:56:50 --> Security Class Initialized
DEBUG - 2022-01-03 08:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:56:50 --> Input Class Initialized
INFO - 2022-01-03 08:56:50 --> Language Class Initialized
INFO - 2022-01-03 08:56:50 --> Loader Class Initialized
INFO - 2022-01-03 08:56:50 --> Helper loaded: url_helper
INFO - 2022-01-03 08:56:50 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:56:50 --> Controller Class Initialized
INFO - 2022-01-03 08:56:50 --> Model "LoginModel" initialized
ERROR - 2022-01-03 08:56:50 --> Severity: Warning --> Undefined variable $registration_data C:\xampp\htdocs\OJT\application\views\test2.php 3
INFO - 2022-01-03 08:56:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 08:56:50 --> Final output sent to browser
DEBUG - 2022-01-03 08:56:50 --> Total execution time: 0.1244
INFO - 2022-01-03 08:57:07 --> Config Class Initialized
INFO - 2022-01-03 08:57:07 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:57:07 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:57:07 --> Utf8 Class Initialized
INFO - 2022-01-03 08:57:07 --> URI Class Initialized
INFO - 2022-01-03 08:57:07 --> Router Class Initialized
INFO - 2022-01-03 08:57:07 --> Output Class Initialized
INFO - 2022-01-03 08:57:07 --> Security Class Initialized
DEBUG - 2022-01-03 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:57:07 --> Input Class Initialized
INFO - 2022-01-03 08:57:07 --> Language Class Initialized
INFO - 2022-01-03 08:57:07 --> Loader Class Initialized
INFO - 2022-01-03 08:57:07 --> Helper loaded: url_helper
INFO - 2022-01-03 08:57:07 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:57:07 --> Controller Class Initialized
INFO - 2022-01-03 08:57:07 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:57:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 08:57:07 --> Final output sent to browser
DEBUG - 2022-01-03 08:57:07 --> Total execution time: 0.0781
INFO - 2022-01-03 08:57:09 --> Config Class Initialized
INFO - 2022-01-03 08:57:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:57:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:57:09 --> Utf8 Class Initialized
INFO - 2022-01-03 08:57:09 --> URI Class Initialized
INFO - 2022-01-03 08:57:09 --> Router Class Initialized
INFO - 2022-01-03 08:57:09 --> Output Class Initialized
INFO - 2022-01-03 08:57:09 --> Security Class Initialized
DEBUG - 2022-01-03 08:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:57:09 --> Input Class Initialized
INFO - 2022-01-03 08:57:09 --> Language Class Initialized
INFO - 2022-01-03 08:57:09 --> Loader Class Initialized
INFO - 2022-01-03 08:57:09 --> Helper loaded: url_helper
INFO - 2022-01-03 08:57:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:57:09 --> Controller Class Initialized
INFO - 2022-01-03 08:57:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:57:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:57:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:57:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:57:09 --> Final output sent to browser
DEBUG - 2022-01-03 08:57:09 --> Total execution time: 0.1052
INFO - 2022-01-03 08:57:13 --> Config Class Initialized
INFO - 2022-01-03 08:57:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:57:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:57:13 --> Utf8 Class Initialized
INFO - 2022-01-03 08:57:13 --> URI Class Initialized
INFO - 2022-01-03 08:57:13 --> Router Class Initialized
INFO - 2022-01-03 08:57:13 --> Output Class Initialized
INFO - 2022-01-03 08:57:13 --> Security Class Initialized
DEBUG - 2022-01-03 08:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:57:13 --> Input Class Initialized
INFO - 2022-01-03 08:57:13 --> Language Class Initialized
INFO - 2022-01-03 08:57:13 --> Loader Class Initialized
INFO - 2022-01-03 08:57:13 --> Helper loaded: url_helper
INFO - 2022-01-03 08:57:13 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:57:13 --> Controller Class Initialized
INFO - 2022-01-03 08:57:13 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:57:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 08:57:13 --> Final output sent to browser
DEBUG - 2022-01-03 08:57:13 --> Total execution time: 0.1007
INFO - 2022-01-03 08:57:14 --> Config Class Initialized
INFO - 2022-01-03 08:57:14 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:57:14 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:57:14 --> Utf8 Class Initialized
INFO - 2022-01-03 08:57:14 --> URI Class Initialized
INFO - 2022-01-03 08:57:14 --> Router Class Initialized
INFO - 2022-01-03 08:57:14 --> Output Class Initialized
INFO - 2022-01-03 08:57:14 --> Security Class Initialized
DEBUG - 2022-01-03 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:57:14 --> Input Class Initialized
INFO - 2022-01-03 08:57:14 --> Language Class Initialized
INFO - 2022-01-03 08:57:14 --> Loader Class Initialized
INFO - 2022-01-03 08:57:14 --> Helper loaded: url_helper
INFO - 2022-01-03 08:57:14 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:57:14 --> Controller Class Initialized
INFO - 2022-01-03 08:57:14 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:57:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 08:57:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 08:57:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 08:57:14 --> Final output sent to browser
DEBUG - 2022-01-03 08:57:14 --> Total execution time: 0.1009
INFO - 2022-01-03 08:57:26 --> Config Class Initialized
INFO - 2022-01-03 08:57:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 08:57:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 08:57:26 --> Utf8 Class Initialized
INFO - 2022-01-03 08:57:26 --> URI Class Initialized
INFO - 2022-01-03 08:57:26 --> Router Class Initialized
INFO - 2022-01-03 08:57:26 --> Output Class Initialized
INFO - 2022-01-03 08:57:26 --> Security Class Initialized
DEBUG - 2022-01-03 08:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 08:57:26 --> Input Class Initialized
INFO - 2022-01-03 08:57:26 --> Language Class Initialized
INFO - 2022-01-03 08:57:26 --> Loader Class Initialized
INFO - 2022-01-03 08:57:26 --> Helper loaded: url_helper
INFO - 2022-01-03 08:57:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 08:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 08:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 08:57:26 --> Controller Class Initialized
INFO - 2022-01-03 08:57:26 --> Model "LoginModel" initialized
INFO - 2022-01-03 08:57:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 08:57:26 --> Final output sent to browser
DEBUG - 2022-01-03 08:57:26 --> Total execution time: 0.0825
INFO - 2022-01-03 09:02:00 --> Config Class Initialized
INFO - 2022-01-03 09:02:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:00 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:00 --> URI Class Initialized
INFO - 2022-01-03 09:02:00 --> Router Class Initialized
INFO - 2022-01-03 09:02:00 --> Output Class Initialized
INFO - 2022-01-03 09:02:00 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:00 --> Input Class Initialized
INFO - 2022-01-03 09:02:00 --> Language Class Initialized
INFO - 2022-01-03 09:02:00 --> Loader Class Initialized
INFO - 2022-01-03 09:02:00 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:00 --> Controller Class Initialized
INFO - 2022-01-03 09:02:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:00 --> Config Class Initialized
INFO - 2022-01-03 09:02:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:00 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:00 --> URI Class Initialized
INFO - 2022-01-03 09:02:00 --> Router Class Initialized
INFO - 2022-01-03 09:02:00 --> Output Class Initialized
INFO - 2022-01-03 09:02:00 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:00 --> Input Class Initialized
INFO - 2022-01-03 09:02:00 --> Language Class Initialized
INFO - 2022-01-03 09:02:00 --> Loader Class Initialized
INFO - 2022-01-03 09:02:00 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:00 --> Controller Class Initialized
INFO - 2022-01-03 09:02:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:02:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:02:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:02:00 --> Final output sent to browser
DEBUG - 2022-01-03 09:02:00 --> Total execution time: 0.0827
INFO - 2022-01-03 09:02:06 --> Config Class Initialized
INFO - 2022-01-03 09:02:06 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:06 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:06 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:06 --> URI Class Initialized
INFO - 2022-01-03 09:02:06 --> Router Class Initialized
INFO - 2022-01-03 09:02:06 --> Output Class Initialized
INFO - 2022-01-03 09:02:06 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:06 --> Input Class Initialized
INFO - 2022-01-03 09:02:06 --> Language Class Initialized
INFO - 2022-01-03 09:02:06 --> Loader Class Initialized
INFO - 2022-01-03 09:02:06 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:06 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:06 --> Controller Class Initialized
INFO - 2022-01-03 09:02:06 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:06 --> Config Class Initialized
INFO - 2022-01-03 09:02:06 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:06 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:06 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:06 --> URI Class Initialized
INFO - 2022-01-03 09:02:06 --> Router Class Initialized
INFO - 2022-01-03 09:02:06 --> Output Class Initialized
INFO - 2022-01-03 09:02:06 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:06 --> Input Class Initialized
INFO - 2022-01-03 09:02:06 --> Language Class Initialized
INFO - 2022-01-03 09:02:06 --> Loader Class Initialized
INFO - 2022-01-03 09:02:06 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:06 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:06 --> Controller Class Initialized
INFO - 2022-01-03 09:02:06 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:02:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:02:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:02:06 --> Final output sent to browser
DEBUG - 2022-01-03 09:02:06 --> Total execution time: 0.0754
INFO - 2022-01-03 09:02:14 --> Config Class Initialized
INFO - 2022-01-03 09:02:14 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:14 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:14 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:14 --> URI Class Initialized
INFO - 2022-01-03 09:02:14 --> Router Class Initialized
INFO - 2022-01-03 09:02:14 --> Output Class Initialized
INFO - 2022-01-03 09:02:14 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:14 --> Input Class Initialized
INFO - 2022-01-03 09:02:14 --> Language Class Initialized
INFO - 2022-01-03 09:02:14 --> Loader Class Initialized
INFO - 2022-01-03 09:02:14 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:14 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:14 --> Controller Class Initialized
INFO - 2022-01-03 09:02:14 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:14 --> Config Class Initialized
INFO - 2022-01-03 09:02:14 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:14 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:14 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:14 --> URI Class Initialized
INFO - 2022-01-03 09:02:14 --> Router Class Initialized
INFO - 2022-01-03 09:02:14 --> Output Class Initialized
INFO - 2022-01-03 09:02:14 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:14 --> Input Class Initialized
INFO - 2022-01-03 09:02:14 --> Language Class Initialized
INFO - 2022-01-03 09:02:14 --> Loader Class Initialized
INFO - 2022-01-03 09:02:14 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:14 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:14 --> Controller Class Initialized
INFO - 2022-01-03 09:02:14 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:02:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:02:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:02:14 --> Final output sent to browser
DEBUG - 2022-01-03 09:02:14 --> Total execution time: 0.0807
INFO - 2022-01-03 09:02:33 --> Config Class Initialized
INFO - 2022-01-03 09:02:33 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:33 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:33 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:33 --> URI Class Initialized
INFO - 2022-01-03 09:02:33 --> Router Class Initialized
INFO - 2022-01-03 09:02:33 --> Output Class Initialized
INFO - 2022-01-03 09:02:33 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:33 --> Input Class Initialized
INFO - 2022-01-03 09:02:33 --> Language Class Initialized
INFO - 2022-01-03 09:02:33 --> Loader Class Initialized
INFO - 2022-01-03 09:02:33 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:33 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:33 --> Controller Class Initialized
INFO - 2022-01-03 09:02:33 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:02:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:02:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:02:33 --> Final output sent to browser
DEBUG - 2022-01-03 09:02:33 --> Total execution time: 0.0846
INFO - 2022-01-03 09:02:42 --> Config Class Initialized
INFO - 2022-01-03 09:02:42 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:42 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:42 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:42 --> URI Class Initialized
INFO - 2022-01-03 09:02:42 --> Router Class Initialized
INFO - 2022-01-03 09:02:42 --> Output Class Initialized
INFO - 2022-01-03 09:02:42 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:42 --> Input Class Initialized
INFO - 2022-01-03 09:02:42 --> Language Class Initialized
INFO - 2022-01-03 09:02:42 --> Loader Class Initialized
INFO - 2022-01-03 09:02:42 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:42 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:42 --> Controller Class Initialized
INFO - 2022-01-03 09:02:42 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 09:02:42 --> Final output sent to browser
DEBUG - 2022-01-03 09:02:42 --> Total execution time: 0.1161
INFO - 2022-01-03 09:02:44 --> Config Class Initialized
INFO - 2022-01-03 09:02:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:44 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:44 --> URI Class Initialized
INFO - 2022-01-03 09:02:44 --> Router Class Initialized
INFO - 2022-01-03 09:02:44 --> Output Class Initialized
INFO - 2022-01-03 09:02:44 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:44 --> Input Class Initialized
INFO - 2022-01-03 09:02:44 --> Language Class Initialized
INFO - 2022-01-03 09:02:44 --> Loader Class Initialized
INFO - 2022-01-03 09:02:44 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:44 --> Controller Class Initialized
INFO - 2022-01-03 09:02:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:02:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:02:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:02:44 --> Final output sent to browser
DEBUG - 2022-01-03 09:02:44 --> Total execution time: 0.1003
INFO - 2022-01-03 09:02:56 --> Config Class Initialized
INFO - 2022-01-03 09:02:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:56 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:56 --> URI Class Initialized
INFO - 2022-01-03 09:02:56 --> Router Class Initialized
INFO - 2022-01-03 09:02:56 --> Output Class Initialized
INFO - 2022-01-03 09:02:56 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:56 --> Input Class Initialized
INFO - 2022-01-03 09:02:56 --> Language Class Initialized
INFO - 2022-01-03 09:02:56 --> Loader Class Initialized
INFO - 2022-01-03 09:02:56 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:56 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:56 --> Controller Class Initialized
INFO - 2022-01-03 09:02:56 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:56 --> Config Class Initialized
INFO - 2022-01-03 09:02:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:02:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:02:56 --> Utf8 Class Initialized
INFO - 2022-01-03 09:02:56 --> URI Class Initialized
INFO - 2022-01-03 09:02:56 --> Router Class Initialized
INFO - 2022-01-03 09:02:56 --> Output Class Initialized
INFO - 2022-01-03 09:02:56 --> Security Class Initialized
DEBUG - 2022-01-03 09:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:02:56 --> Input Class Initialized
INFO - 2022-01-03 09:02:56 --> Language Class Initialized
INFO - 2022-01-03 09:02:56 --> Loader Class Initialized
INFO - 2022-01-03 09:02:56 --> Helper loaded: url_helper
INFO - 2022-01-03 09:02:56 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:02:56 --> Controller Class Initialized
INFO - 2022-01-03 09:02:56 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:02:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:02:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:02:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:02:56 --> Final output sent to browser
DEBUG - 2022-01-03 09:02:56 --> Total execution time: 0.0780
INFO - 2022-01-03 09:05:49 --> Config Class Initialized
INFO - 2022-01-03 09:05:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:05:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:05:49 --> Utf8 Class Initialized
INFO - 2022-01-03 09:05:49 --> URI Class Initialized
INFO - 2022-01-03 09:05:49 --> Router Class Initialized
INFO - 2022-01-03 09:05:49 --> Output Class Initialized
INFO - 2022-01-03 09:05:49 --> Security Class Initialized
DEBUG - 2022-01-03 09:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:05:49 --> Input Class Initialized
INFO - 2022-01-03 09:05:49 --> Language Class Initialized
INFO - 2022-01-03 09:05:49 --> Loader Class Initialized
INFO - 2022-01-03 09:05:49 --> Helper loaded: url_helper
INFO - 2022-01-03 09:05:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:05:49 --> Controller Class Initialized
INFO - 2022-01-03 09:05:49 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:05:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:05:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:05:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:05:49 --> Final output sent to browser
DEBUG - 2022-01-03 09:05:49 --> Total execution time: 0.0630
INFO - 2022-01-03 09:09:18 --> Config Class Initialized
INFO - 2022-01-03 09:09:18 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:09:18 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:09:18 --> Utf8 Class Initialized
INFO - 2022-01-03 09:09:18 --> URI Class Initialized
INFO - 2022-01-03 09:09:18 --> Router Class Initialized
INFO - 2022-01-03 09:09:18 --> Output Class Initialized
INFO - 2022-01-03 09:09:18 --> Security Class Initialized
DEBUG - 2022-01-03 09:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:09:18 --> Input Class Initialized
INFO - 2022-01-03 09:09:18 --> Language Class Initialized
INFO - 2022-01-03 09:09:18 --> Loader Class Initialized
INFO - 2022-01-03 09:09:18 --> Helper loaded: url_helper
INFO - 2022-01-03 09:09:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:09:18 --> Controller Class Initialized
INFO - 2022-01-03 09:09:18 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:09:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
ERROR - 2022-01-03 09:09:18 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\OJT\application\views\login\index.php 74
INFO - 2022-01-03 09:09:41 --> Config Class Initialized
INFO - 2022-01-03 09:09:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:09:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:09:41 --> Utf8 Class Initialized
INFO - 2022-01-03 09:09:41 --> URI Class Initialized
INFO - 2022-01-03 09:09:41 --> Router Class Initialized
INFO - 2022-01-03 09:09:41 --> Output Class Initialized
INFO - 2022-01-03 09:09:41 --> Security Class Initialized
DEBUG - 2022-01-03 09:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:09:41 --> Input Class Initialized
INFO - 2022-01-03 09:09:41 --> Language Class Initialized
INFO - 2022-01-03 09:09:41 --> Loader Class Initialized
INFO - 2022-01-03 09:09:41 --> Helper loaded: url_helper
INFO - 2022-01-03 09:09:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:09:41 --> Controller Class Initialized
INFO - 2022-01-03 09:09:41 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:09:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:09:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:09:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:09:41 --> Final output sent to browser
DEBUG - 2022-01-03 09:09:41 --> Total execution time: 0.0518
INFO - 2022-01-03 09:10:10 --> Config Class Initialized
INFO - 2022-01-03 09:10:10 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:10:10 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:10:10 --> Utf8 Class Initialized
INFO - 2022-01-03 09:10:10 --> URI Class Initialized
INFO - 2022-01-03 09:10:10 --> Router Class Initialized
INFO - 2022-01-03 09:10:10 --> Output Class Initialized
INFO - 2022-01-03 09:10:10 --> Security Class Initialized
DEBUG - 2022-01-03 09:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:10:10 --> Input Class Initialized
INFO - 2022-01-03 09:10:10 --> Language Class Initialized
INFO - 2022-01-03 09:10:10 --> Loader Class Initialized
INFO - 2022-01-03 09:10:10 --> Helper loaded: url_helper
INFO - 2022-01-03 09:10:10 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:10:10 --> Controller Class Initialized
INFO - 2022-01-03 09:10:10 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:10:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:10:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:10:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:10:10 --> Final output sent to browser
DEBUG - 2022-01-03 09:10:10 --> Total execution time: 0.0468
INFO - 2022-01-03 09:10:26 --> Config Class Initialized
INFO - 2022-01-03 09:10:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:10:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:10:26 --> Utf8 Class Initialized
INFO - 2022-01-03 09:10:26 --> URI Class Initialized
INFO - 2022-01-03 09:10:26 --> Router Class Initialized
INFO - 2022-01-03 09:10:26 --> Output Class Initialized
INFO - 2022-01-03 09:10:26 --> Security Class Initialized
DEBUG - 2022-01-03 09:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:10:26 --> Input Class Initialized
INFO - 2022-01-03 09:10:26 --> Language Class Initialized
INFO - 2022-01-03 09:10:26 --> Loader Class Initialized
INFO - 2022-01-03 09:10:26 --> Helper loaded: url_helper
INFO - 2022-01-03 09:10:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:10:26 --> Controller Class Initialized
INFO - 2022-01-03 09:10:26 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:10:26 --> Config Class Initialized
INFO - 2022-01-03 09:10:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:10:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:10:26 --> Utf8 Class Initialized
INFO - 2022-01-03 09:10:26 --> URI Class Initialized
INFO - 2022-01-03 09:10:26 --> Router Class Initialized
INFO - 2022-01-03 09:10:26 --> Output Class Initialized
INFO - 2022-01-03 09:10:26 --> Security Class Initialized
DEBUG - 2022-01-03 09:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:10:26 --> Input Class Initialized
INFO - 2022-01-03 09:10:26 --> Language Class Initialized
INFO - 2022-01-03 09:10:26 --> Loader Class Initialized
INFO - 2022-01-03 09:10:26 --> Helper loaded: url_helper
INFO - 2022-01-03 09:10:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:10:26 --> Controller Class Initialized
INFO - 2022-01-03 09:10:26 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:10:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:10:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:10:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:10:26 --> Final output sent to browser
DEBUG - 2022-01-03 09:10:26 --> Total execution time: 0.0487
INFO - 2022-01-03 09:10:48 --> Config Class Initialized
INFO - 2022-01-03 09:10:48 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:10:48 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:10:48 --> Utf8 Class Initialized
INFO - 2022-01-03 09:10:48 --> URI Class Initialized
INFO - 2022-01-03 09:10:48 --> Router Class Initialized
INFO - 2022-01-03 09:10:48 --> Output Class Initialized
INFO - 2022-01-03 09:10:48 --> Security Class Initialized
DEBUG - 2022-01-03 09:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:10:48 --> Input Class Initialized
INFO - 2022-01-03 09:10:48 --> Language Class Initialized
INFO - 2022-01-03 09:10:48 --> Loader Class Initialized
INFO - 2022-01-03 09:10:48 --> Helper loaded: url_helper
INFO - 2022-01-03 09:10:48 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:10:48 --> Controller Class Initialized
INFO - 2022-01-03 09:10:48 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:10:48 --> Config Class Initialized
INFO - 2022-01-03 09:10:48 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:10:48 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:10:48 --> Utf8 Class Initialized
INFO - 2022-01-03 09:10:48 --> URI Class Initialized
INFO - 2022-01-03 09:10:48 --> Router Class Initialized
INFO - 2022-01-03 09:10:48 --> Output Class Initialized
INFO - 2022-01-03 09:10:48 --> Security Class Initialized
DEBUG - 2022-01-03 09:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:10:48 --> Input Class Initialized
INFO - 2022-01-03 09:10:48 --> Language Class Initialized
INFO - 2022-01-03 09:10:48 --> Loader Class Initialized
INFO - 2022-01-03 09:10:48 --> Helper loaded: url_helper
INFO - 2022-01-03 09:10:48 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:10:48 --> Controller Class Initialized
INFO - 2022-01-03 09:10:48 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:10:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:10:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:10:48 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:10:48 --> Final output sent to browser
DEBUG - 2022-01-03 09:10:48 --> Total execution time: 0.0632
INFO - 2022-01-03 09:12:41 --> Config Class Initialized
INFO - 2022-01-03 09:12:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:41 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:41 --> URI Class Initialized
INFO - 2022-01-03 09:12:41 --> Router Class Initialized
INFO - 2022-01-03 09:12:41 --> Output Class Initialized
INFO - 2022-01-03 09:12:41 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:41 --> Input Class Initialized
INFO - 2022-01-03 09:12:41 --> Language Class Initialized
INFO - 2022-01-03 09:12:41 --> Loader Class Initialized
INFO - 2022-01-03 09:12:41 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:41 --> Controller Class Initialized
INFO - 2022-01-03 09:12:41 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:12:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:12:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:12:41 --> Final output sent to browser
DEBUG - 2022-01-03 09:12:41 --> Total execution time: 0.0522
INFO - 2022-01-03 09:12:44 --> Config Class Initialized
INFO - 2022-01-03 09:12:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:44 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:44 --> URI Class Initialized
INFO - 2022-01-03 09:12:44 --> Router Class Initialized
INFO - 2022-01-03 09:12:44 --> Output Class Initialized
INFO - 2022-01-03 09:12:44 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:44 --> Input Class Initialized
INFO - 2022-01-03 09:12:44 --> Language Class Initialized
INFO - 2022-01-03 09:12:44 --> Loader Class Initialized
INFO - 2022-01-03 09:12:44 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:44 --> Controller Class Initialized
INFO - 2022-01-03 09:12:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:44 --> Config Class Initialized
INFO - 2022-01-03 09:12:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:44 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:44 --> URI Class Initialized
INFO - 2022-01-03 09:12:44 --> Router Class Initialized
INFO - 2022-01-03 09:12:44 --> Output Class Initialized
INFO - 2022-01-03 09:12:44 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:44 --> Input Class Initialized
INFO - 2022-01-03 09:12:44 --> Language Class Initialized
INFO - 2022-01-03 09:12:44 --> Loader Class Initialized
INFO - 2022-01-03 09:12:44 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:44 --> Controller Class Initialized
INFO - 2022-01-03 09:12:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:12:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:12:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:12:44 --> Final output sent to browser
DEBUG - 2022-01-03 09:12:44 --> Total execution time: 0.0485
INFO - 2022-01-03 09:12:50 --> Config Class Initialized
INFO - 2022-01-03 09:12:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:50 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:50 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:50 --> URI Class Initialized
INFO - 2022-01-03 09:12:50 --> Router Class Initialized
INFO - 2022-01-03 09:12:50 --> Output Class Initialized
INFO - 2022-01-03 09:12:50 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:50 --> Input Class Initialized
INFO - 2022-01-03 09:12:50 --> Language Class Initialized
INFO - 2022-01-03 09:12:50 --> Loader Class Initialized
INFO - 2022-01-03 09:12:50 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:50 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:50 --> Controller Class Initialized
INFO - 2022-01-03 09:12:50 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:12:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:12:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:12:50 --> Final output sent to browser
DEBUG - 2022-01-03 09:12:50 --> Total execution time: 0.0952
INFO - 2022-01-03 09:12:52 --> Config Class Initialized
INFO - 2022-01-03 09:12:52 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:52 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:52 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:52 --> URI Class Initialized
INFO - 2022-01-03 09:12:52 --> Router Class Initialized
INFO - 2022-01-03 09:12:52 --> Output Class Initialized
INFO - 2022-01-03 09:12:52 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:52 --> Input Class Initialized
INFO - 2022-01-03 09:12:52 --> Language Class Initialized
INFO - 2022-01-03 09:12:52 --> Loader Class Initialized
INFO - 2022-01-03 09:12:52 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:52 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:52 --> Controller Class Initialized
INFO - 2022-01-03 09:12:52 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:12:52 --> Final output sent to browser
DEBUG - 2022-01-03 09:12:52 --> Total execution time: 0.0480
INFO - 2022-01-03 09:12:52 --> Config Class Initialized
INFO - 2022-01-03 09:12:52 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:52 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:52 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:52 --> URI Class Initialized
INFO - 2022-01-03 09:12:52 --> Router Class Initialized
INFO - 2022-01-03 09:12:52 --> Output Class Initialized
INFO - 2022-01-03 09:12:52 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:52 --> Input Class Initialized
INFO - 2022-01-03 09:12:52 --> Language Class Initialized
INFO - 2022-01-03 09:12:52 --> Loader Class Initialized
INFO - 2022-01-03 09:12:52 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:52 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:52 --> Controller Class Initialized
INFO - 2022-01-03 09:12:52 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:12:52 --> Final output sent to browser
DEBUG - 2022-01-03 09:12:52 --> Total execution time: 0.0442
INFO - 2022-01-03 09:12:52 --> Config Class Initialized
INFO - 2022-01-03 09:12:52 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:52 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:52 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:52 --> URI Class Initialized
INFO - 2022-01-03 09:12:52 --> Router Class Initialized
INFO - 2022-01-03 09:12:52 --> Output Class Initialized
INFO - 2022-01-03 09:12:52 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:52 --> Input Class Initialized
INFO - 2022-01-03 09:12:52 --> Language Class Initialized
INFO - 2022-01-03 09:12:52 --> Loader Class Initialized
INFO - 2022-01-03 09:12:52 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:52 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:52 --> Controller Class Initialized
INFO - 2022-01-03 09:12:52 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:12:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:12:52 --> Final output sent to browser
DEBUG - 2022-01-03 09:12:52 --> Total execution time: 0.0584
INFO - 2022-01-03 09:12:54 --> Config Class Initialized
INFO - 2022-01-03 09:12:54 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:54 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:54 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:54 --> URI Class Initialized
INFO - 2022-01-03 09:12:54 --> Router Class Initialized
INFO - 2022-01-03 09:12:54 --> Output Class Initialized
INFO - 2022-01-03 09:12:54 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:54 --> Input Class Initialized
INFO - 2022-01-03 09:12:54 --> Language Class Initialized
INFO - 2022-01-03 09:12:54 --> Loader Class Initialized
INFO - 2022-01-03 09:12:54 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:54 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:54 --> Controller Class Initialized
INFO - 2022-01-03 09:12:54 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:54 --> Config Class Initialized
INFO - 2022-01-03 09:12:54 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:12:54 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:12:54 --> Utf8 Class Initialized
INFO - 2022-01-03 09:12:54 --> URI Class Initialized
INFO - 2022-01-03 09:12:54 --> Router Class Initialized
INFO - 2022-01-03 09:12:54 --> Output Class Initialized
INFO - 2022-01-03 09:12:54 --> Security Class Initialized
DEBUG - 2022-01-03 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:12:54 --> Input Class Initialized
INFO - 2022-01-03 09:12:54 --> Language Class Initialized
INFO - 2022-01-03 09:12:54 --> Loader Class Initialized
INFO - 2022-01-03 09:12:54 --> Helper loaded: url_helper
INFO - 2022-01-03 09:12:54 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:12:55 --> Controller Class Initialized
INFO - 2022-01-03 09:12:55 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:12:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:12:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:12:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:12:55 --> Final output sent to browser
DEBUG - 2022-01-03 09:12:55 --> Total execution time: 0.0486
INFO - 2022-01-03 09:13:00 --> Config Class Initialized
INFO - 2022-01-03 09:13:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:13:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:13:00 --> Utf8 Class Initialized
INFO - 2022-01-03 09:13:00 --> URI Class Initialized
INFO - 2022-01-03 09:13:00 --> Router Class Initialized
INFO - 2022-01-03 09:13:00 --> Output Class Initialized
INFO - 2022-01-03 09:13:00 --> Security Class Initialized
DEBUG - 2022-01-03 09:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:13:00 --> Input Class Initialized
INFO - 2022-01-03 09:13:00 --> Language Class Initialized
INFO - 2022-01-03 09:13:00 --> Loader Class Initialized
INFO - 2022-01-03 09:13:00 --> Helper loaded: url_helper
INFO - 2022-01-03 09:13:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:13:00 --> Controller Class Initialized
INFO - 2022-01-03 09:13:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:13:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:13:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:13:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:13:00 --> Final output sent to browser
DEBUG - 2022-01-03 09:13:00 --> Total execution time: 0.0567
INFO - 2022-01-03 09:13:02 --> Config Class Initialized
INFO - 2022-01-03 09:13:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:13:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:13:02 --> Utf8 Class Initialized
INFO - 2022-01-03 09:13:02 --> URI Class Initialized
INFO - 2022-01-03 09:13:02 --> Router Class Initialized
INFO - 2022-01-03 09:13:02 --> Output Class Initialized
INFO - 2022-01-03 09:13:02 --> Security Class Initialized
DEBUG - 2022-01-03 09:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:13:02 --> Input Class Initialized
INFO - 2022-01-03 09:13:02 --> Language Class Initialized
INFO - 2022-01-03 09:13:02 --> Loader Class Initialized
INFO - 2022-01-03 09:13:02 --> Helper loaded: url_helper
INFO - 2022-01-03 09:13:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:13:02 --> Controller Class Initialized
INFO - 2022-01-03 09:13:02 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:13:02 --> Config Class Initialized
INFO - 2022-01-03 09:13:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:13:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:13:02 --> Utf8 Class Initialized
INFO - 2022-01-03 09:13:02 --> URI Class Initialized
INFO - 2022-01-03 09:13:02 --> Router Class Initialized
INFO - 2022-01-03 09:13:02 --> Output Class Initialized
INFO - 2022-01-03 09:13:02 --> Security Class Initialized
DEBUG - 2022-01-03 09:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:13:02 --> Input Class Initialized
INFO - 2022-01-03 09:13:02 --> Language Class Initialized
INFO - 2022-01-03 09:13:02 --> Loader Class Initialized
INFO - 2022-01-03 09:13:02 --> Helper loaded: url_helper
INFO - 2022-01-03 09:13:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:13:02 --> Controller Class Initialized
INFO - 2022-01-03 09:13:02 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:13:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:13:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:13:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:13:02 --> Final output sent to browser
DEBUG - 2022-01-03 09:13:02 --> Total execution time: 0.0527
INFO - 2022-01-03 09:13:30 --> Config Class Initialized
INFO - 2022-01-03 09:13:30 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:13:30 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:13:30 --> Utf8 Class Initialized
INFO - 2022-01-03 09:13:30 --> URI Class Initialized
INFO - 2022-01-03 09:13:30 --> Router Class Initialized
INFO - 2022-01-03 09:13:30 --> Output Class Initialized
INFO - 2022-01-03 09:13:30 --> Security Class Initialized
DEBUG - 2022-01-03 09:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:13:30 --> Input Class Initialized
INFO - 2022-01-03 09:13:30 --> Language Class Initialized
INFO - 2022-01-03 09:13:30 --> Loader Class Initialized
INFO - 2022-01-03 09:13:30 --> Helper loaded: url_helper
INFO - 2022-01-03 09:13:30 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:13:30 --> Controller Class Initialized
INFO - 2022-01-03 09:13:30 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:13:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:13:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:13:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:13:30 --> Final output sent to browser
DEBUG - 2022-01-03 09:13:30 --> Total execution time: 0.0593
INFO - 2022-01-03 09:13:35 --> Config Class Initialized
INFO - 2022-01-03 09:13:35 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:13:35 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:13:35 --> Utf8 Class Initialized
INFO - 2022-01-03 09:13:35 --> URI Class Initialized
INFO - 2022-01-03 09:13:35 --> Router Class Initialized
INFO - 2022-01-03 09:13:35 --> Output Class Initialized
INFO - 2022-01-03 09:13:35 --> Security Class Initialized
DEBUG - 2022-01-03 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:13:35 --> Input Class Initialized
INFO - 2022-01-03 09:13:35 --> Language Class Initialized
INFO - 2022-01-03 09:13:35 --> Loader Class Initialized
INFO - 2022-01-03 09:13:35 --> Helper loaded: url_helper
INFO - 2022-01-03 09:13:35 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:13:35 --> Controller Class Initialized
INFO - 2022-01-03 09:13:35 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:13:35 --> Config Class Initialized
INFO - 2022-01-03 09:13:35 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:13:35 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:13:35 --> Utf8 Class Initialized
INFO - 2022-01-03 09:13:35 --> URI Class Initialized
INFO - 2022-01-03 09:13:35 --> Router Class Initialized
INFO - 2022-01-03 09:13:35 --> Output Class Initialized
INFO - 2022-01-03 09:13:35 --> Security Class Initialized
DEBUG - 2022-01-03 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:13:35 --> Input Class Initialized
INFO - 2022-01-03 09:13:35 --> Language Class Initialized
INFO - 2022-01-03 09:13:35 --> Loader Class Initialized
INFO - 2022-01-03 09:13:35 --> Helper loaded: url_helper
INFO - 2022-01-03 09:13:35 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:13:35 --> Controller Class Initialized
INFO - 2022-01-03 09:13:35 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:13:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:13:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:13:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:13:35 --> Final output sent to browser
DEBUG - 2022-01-03 09:13:35 --> Total execution time: 0.0580
INFO - 2022-01-03 09:13:43 --> Config Class Initialized
INFO - 2022-01-03 09:13:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:13:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:13:43 --> Utf8 Class Initialized
INFO - 2022-01-03 09:13:43 --> URI Class Initialized
INFO - 2022-01-03 09:13:43 --> Router Class Initialized
INFO - 2022-01-03 09:13:43 --> Output Class Initialized
INFO - 2022-01-03 09:13:43 --> Security Class Initialized
DEBUG - 2022-01-03 09:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:13:43 --> Input Class Initialized
INFO - 2022-01-03 09:13:43 --> Language Class Initialized
INFO - 2022-01-03 09:13:43 --> Loader Class Initialized
INFO - 2022-01-03 09:13:43 --> Helper loaded: url_helper
INFO - 2022-01-03 09:13:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:13:43 --> Controller Class Initialized
INFO - 2022-01-03 09:13:43 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:13:43 --> Config Class Initialized
INFO - 2022-01-03 09:13:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:13:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:13:43 --> Utf8 Class Initialized
INFO - 2022-01-03 09:13:43 --> URI Class Initialized
INFO - 2022-01-03 09:13:43 --> Router Class Initialized
INFO - 2022-01-03 09:13:43 --> Output Class Initialized
INFO - 2022-01-03 09:13:43 --> Security Class Initialized
DEBUG - 2022-01-03 09:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:13:43 --> Input Class Initialized
INFO - 2022-01-03 09:13:43 --> Language Class Initialized
INFO - 2022-01-03 09:13:43 --> Loader Class Initialized
INFO - 2022-01-03 09:13:43 --> Helper loaded: url_helper
INFO - 2022-01-03 09:13:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:13:43 --> Controller Class Initialized
INFO - 2022-01-03 09:13:43 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:13:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:13:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:13:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:13:43 --> Final output sent to browser
DEBUG - 2022-01-03 09:13:43 --> Total execution time: 0.0459
INFO - 2022-01-03 09:15:30 --> Config Class Initialized
INFO - 2022-01-03 09:15:30 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:15:30 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:15:30 --> Utf8 Class Initialized
INFO - 2022-01-03 09:15:30 --> URI Class Initialized
INFO - 2022-01-03 09:15:30 --> Router Class Initialized
INFO - 2022-01-03 09:15:30 --> Output Class Initialized
INFO - 2022-01-03 09:15:30 --> Security Class Initialized
DEBUG - 2022-01-03 09:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:15:30 --> Input Class Initialized
INFO - 2022-01-03 09:15:30 --> Language Class Initialized
INFO - 2022-01-03 09:15:30 --> Loader Class Initialized
INFO - 2022-01-03 09:15:30 --> Helper loaded: url_helper
INFO - 2022-01-03 09:15:30 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:15:30 --> Controller Class Initialized
INFO - 2022-01-03 09:15:30 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:15:30 --> Config Class Initialized
INFO - 2022-01-03 09:15:30 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:15:30 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:15:30 --> Utf8 Class Initialized
INFO - 2022-01-03 09:15:30 --> URI Class Initialized
INFO - 2022-01-03 09:15:30 --> Router Class Initialized
INFO - 2022-01-03 09:15:30 --> Output Class Initialized
INFO - 2022-01-03 09:15:30 --> Security Class Initialized
DEBUG - 2022-01-03 09:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:15:30 --> Input Class Initialized
INFO - 2022-01-03 09:15:30 --> Language Class Initialized
INFO - 2022-01-03 09:15:30 --> Loader Class Initialized
INFO - 2022-01-03 09:15:30 --> Helper loaded: url_helper
INFO - 2022-01-03 09:15:30 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:15:30 --> Controller Class Initialized
INFO - 2022-01-03 09:15:30 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:15:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:15:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:15:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:15:30 --> Final output sent to browser
DEBUG - 2022-01-03 09:15:30 --> Total execution time: 0.0487
INFO - 2022-01-03 09:15:43 --> Config Class Initialized
INFO - 2022-01-03 09:15:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:15:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:15:43 --> Utf8 Class Initialized
INFO - 2022-01-03 09:15:43 --> URI Class Initialized
INFO - 2022-01-03 09:15:43 --> Router Class Initialized
INFO - 2022-01-03 09:15:43 --> Output Class Initialized
INFO - 2022-01-03 09:15:43 --> Security Class Initialized
DEBUG - 2022-01-03 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:15:43 --> Input Class Initialized
INFO - 2022-01-03 09:15:43 --> Language Class Initialized
INFO - 2022-01-03 09:15:43 --> Loader Class Initialized
INFO - 2022-01-03 09:15:43 --> Helper loaded: url_helper
INFO - 2022-01-03 09:15:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:15:43 --> Controller Class Initialized
INFO - 2022-01-03 09:15:43 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:15:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:15:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:15:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:15:43 --> Final output sent to browser
DEBUG - 2022-01-03 09:15:43 --> Total execution time: 0.0490
INFO - 2022-01-03 09:15:44 --> Config Class Initialized
INFO - 2022-01-03 09:15:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:15:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:15:44 --> Utf8 Class Initialized
INFO - 2022-01-03 09:15:44 --> URI Class Initialized
INFO - 2022-01-03 09:15:44 --> Router Class Initialized
INFO - 2022-01-03 09:15:44 --> Output Class Initialized
INFO - 2022-01-03 09:15:44 --> Security Class Initialized
DEBUG - 2022-01-03 09:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:15:44 --> Input Class Initialized
INFO - 2022-01-03 09:15:44 --> Language Class Initialized
INFO - 2022-01-03 09:15:44 --> Loader Class Initialized
INFO - 2022-01-03 09:15:44 --> Helper loaded: url_helper
INFO - 2022-01-03 09:15:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:15:44 --> Controller Class Initialized
INFO - 2022-01-03 09:15:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:15:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:15:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:15:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:15:44 --> Final output sent to browser
DEBUG - 2022-01-03 09:15:44 --> Total execution time: 0.0539
INFO - 2022-01-03 09:15:45 --> Config Class Initialized
INFO - 2022-01-03 09:15:45 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:15:45 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:15:45 --> Utf8 Class Initialized
INFO - 2022-01-03 09:15:45 --> URI Class Initialized
INFO - 2022-01-03 09:15:45 --> Router Class Initialized
INFO - 2022-01-03 09:15:45 --> Output Class Initialized
INFO - 2022-01-03 09:15:45 --> Security Class Initialized
DEBUG - 2022-01-03 09:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:15:45 --> Input Class Initialized
INFO - 2022-01-03 09:15:45 --> Language Class Initialized
INFO - 2022-01-03 09:15:45 --> Loader Class Initialized
INFO - 2022-01-03 09:15:45 --> Helper loaded: url_helper
INFO - 2022-01-03 09:15:45 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:15:45 --> Controller Class Initialized
INFO - 2022-01-03 09:15:45 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:15:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:15:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:15:45 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:15:45 --> Final output sent to browser
DEBUG - 2022-01-03 09:15:45 --> Total execution time: 0.0616
INFO - 2022-01-03 09:15:53 --> Config Class Initialized
INFO - 2022-01-03 09:15:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:15:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:15:53 --> Utf8 Class Initialized
INFO - 2022-01-03 09:15:53 --> URI Class Initialized
INFO - 2022-01-03 09:15:53 --> Router Class Initialized
INFO - 2022-01-03 09:15:53 --> Output Class Initialized
INFO - 2022-01-03 09:15:53 --> Security Class Initialized
DEBUG - 2022-01-03 09:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:15:53 --> Input Class Initialized
INFO - 2022-01-03 09:15:53 --> Language Class Initialized
INFO - 2022-01-03 09:15:53 --> Loader Class Initialized
INFO - 2022-01-03 09:15:53 --> Helper loaded: url_helper
INFO - 2022-01-03 09:15:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:15:53 --> Controller Class Initialized
INFO - 2022-01-03 09:15:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:15:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:15:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:15:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:15:53 --> Final output sent to browser
DEBUG - 2022-01-03 09:15:53 --> Total execution time: 0.0546
INFO - 2022-01-03 09:16:02 --> Config Class Initialized
INFO - 2022-01-03 09:16:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:02 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:02 --> URI Class Initialized
INFO - 2022-01-03 09:16:02 --> Router Class Initialized
INFO - 2022-01-03 09:16:02 --> Output Class Initialized
INFO - 2022-01-03 09:16:02 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:02 --> Input Class Initialized
INFO - 2022-01-03 09:16:02 --> Language Class Initialized
INFO - 2022-01-03 09:16:02 --> Loader Class Initialized
INFO - 2022-01-03 09:16:02 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:02 --> Controller Class Initialized
INFO - 2022-01-03 09:16:02 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 09:16:02 --> Final output sent to browser
DEBUG - 2022-01-03 09:16:02 --> Total execution time: 0.0583
INFO - 2022-01-03 09:16:04 --> Config Class Initialized
INFO - 2022-01-03 09:16:04 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:04 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:04 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:04 --> URI Class Initialized
INFO - 2022-01-03 09:16:04 --> Router Class Initialized
INFO - 2022-01-03 09:16:04 --> Output Class Initialized
INFO - 2022-01-03 09:16:04 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:04 --> Input Class Initialized
INFO - 2022-01-03 09:16:04 --> Language Class Initialized
INFO - 2022-01-03 09:16:04 --> Loader Class Initialized
INFO - 2022-01-03 09:16:04 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:04 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:04 --> Controller Class Initialized
INFO - 2022-01-03 09:16:04 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:16:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:16:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:16:04 --> Final output sent to browser
DEBUG - 2022-01-03 09:16:04 --> Total execution time: 0.0535
INFO - 2022-01-03 09:16:27 --> Config Class Initialized
INFO - 2022-01-03 09:16:27 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:27 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:27 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:27 --> URI Class Initialized
INFO - 2022-01-03 09:16:27 --> Router Class Initialized
INFO - 2022-01-03 09:16:27 --> Output Class Initialized
INFO - 2022-01-03 09:16:27 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:27 --> Input Class Initialized
INFO - 2022-01-03 09:16:27 --> Language Class Initialized
INFO - 2022-01-03 09:16:27 --> Loader Class Initialized
INFO - 2022-01-03 09:16:27 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:27 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:27 --> Controller Class Initialized
INFO - 2022-01-03 09:16:27 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:16:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:16:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:16:27 --> Final output sent to browser
DEBUG - 2022-01-03 09:16:27 --> Total execution time: 0.0508
INFO - 2022-01-03 09:16:31 --> Config Class Initialized
INFO - 2022-01-03 09:16:31 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:31 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:31 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:31 --> URI Class Initialized
INFO - 2022-01-03 09:16:31 --> Router Class Initialized
INFO - 2022-01-03 09:16:31 --> Output Class Initialized
INFO - 2022-01-03 09:16:31 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:31 --> Input Class Initialized
INFO - 2022-01-03 09:16:31 --> Language Class Initialized
INFO - 2022-01-03 09:16:31 --> Loader Class Initialized
INFO - 2022-01-03 09:16:31 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:31 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:31 --> Controller Class Initialized
INFO - 2022-01-03 09:16:31 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:16:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:16:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:16:31 --> Final output sent to browser
DEBUG - 2022-01-03 09:16:31 --> Total execution time: 0.0542
INFO - 2022-01-03 09:16:41 --> Config Class Initialized
INFO - 2022-01-03 09:16:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:41 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:41 --> URI Class Initialized
INFO - 2022-01-03 09:16:41 --> Router Class Initialized
INFO - 2022-01-03 09:16:41 --> Output Class Initialized
INFO - 2022-01-03 09:16:41 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:41 --> Input Class Initialized
INFO - 2022-01-03 09:16:41 --> Language Class Initialized
INFO - 2022-01-03 09:16:41 --> Loader Class Initialized
INFO - 2022-01-03 09:16:41 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:42 --> Controller Class Initialized
INFO - 2022-01-03 09:16:42 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:42 --> Config Class Initialized
INFO - 2022-01-03 09:16:42 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:42 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:42 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:42 --> URI Class Initialized
INFO - 2022-01-03 09:16:42 --> Router Class Initialized
INFO - 2022-01-03 09:16:42 --> Output Class Initialized
INFO - 2022-01-03 09:16:42 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:42 --> Input Class Initialized
INFO - 2022-01-03 09:16:42 --> Language Class Initialized
INFO - 2022-01-03 09:16:42 --> Loader Class Initialized
INFO - 2022-01-03 09:16:42 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:42 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:42 --> Controller Class Initialized
INFO - 2022-01-03 09:16:42 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:16:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:16:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:16:42 --> Final output sent to browser
DEBUG - 2022-01-03 09:16:42 --> Total execution time: 0.0472
INFO - 2022-01-03 09:16:47 --> Config Class Initialized
INFO - 2022-01-03 09:16:47 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:47 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:47 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:47 --> URI Class Initialized
INFO - 2022-01-03 09:16:47 --> Router Class Initialized
INFO - 2022-01-03 09:16:47 --> Output Class Initialized
INFO - 2022-01-03 09:16:47 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:47 --> Input Class Initialized
INFO - 2022-01-03 09:16:47 --> Language Class Initialized
INFO - 2022-01-03 09:16:47 --> Loader Class Initialized
INFO - 2022-01-03 09:16:47 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:47 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:47 --> Controller Class Initialized
INFO - 2022-01-03 09:16:47 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:47 --> Config Class Initialized
INFO - 2022-01-03 09:16:47 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:47 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:47 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:47 --> URI Class Initialized
INFO - 2022-01-03 09:16:47 --> Router Class Initialized
INFO - 2022-01-03 09:16:47 --> Output Class Initialized
INFO - 2022-01-03 09:16:47 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:47 --> Input Class Initialized
INFO - 2022-01-03 09:16:47 --> Language Class Initialized
INFO - 2022-01-03 09:16:47 --> Loader Class Initialized
INFO - 2022-01-03 09:16:47 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:47 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:47 --> Controller Class Initialized
INFO - 2022-01-03 09:16:47 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:16:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:16:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:16:47 --> Final output sent to browser
DEBUG - 2022-01-03 09:16:47 --> Total execution time: 0.0468
INFO - 2022-01-03 09:16:58 --> Config Class Initialized
INFO - 2022-01-03 09:16:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:58 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:58 --> URI Class Initialized
INFO - 2022-01-03 09:16:58 --> Router Class Initialized
INFO - 2022-01-03 09:16:58 --> Output Class Initialized
INFO - 2022-01-03 09:16:58 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:58 --> Input Class Initialized
INFO - 2022-01-03 09:16:58 --> Language Class Initialized
INFO - 2022-01-03 09:16:58 --> Loader Class Initialized
INFO - 2022-01-03 09:16:58 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:59 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:59 --> Controller Class Initialized
INFO - 2022-01-03 09:16:59 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:59 --> Config Class Initialized
INFO - 2022-01-03 09:16:59 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:16:59 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:16:59 --> Utf8 Class Initialized
INFO - 2022-01-03 09:16:59 --> URI Class Initialized
INFO - 2022-01-03 09:16:59 --> Router Class Initialized
INFO - 2022-01-03 09:16:59 --> Output Class Initialized
INFO - 2022-01-03 09:16:59 --> Security Class Initialized
DEBUG - 2022-01-03 09:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:16:59 --> Input Class Initialized
INFO - 2022-01-03 09:16:59 --> Language Class Initialized
INFO - 2022-01-03 09:16:59 --> Loader Class Initialized
INFO - 2022-01-03 09:16:59 --> Helper loaded: url_helper
INFO - 2022-01-03 09:16:59 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:16:59 --> Controller Class Initialized
INFO - 2022-01-03 09:16:59 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:16:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:16:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:16:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:16:59 --> Final output sent to browser
DEBUG - 2022-01-03 09:16:59 --> Total execution time: 0.0501
INFO - 2022-01-03 09:17:07 --> Config Class Initialized
INFO - 2022-01-03 09:17:07 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:17:07 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:17:07 --> Utf8 Class Initialized
INFO - 2022-01-03 09:17:07 --> URI Class Initialized
INFO - 2022-01-03 09:17:07 --> Router Class Initialized
INFO - 2022-01-03 09:17:07 --> Output Class Initialized
INFO - 2022-01-03 09:17:07 --> Security Class Initialized
DEBUG - 2022-01-03 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:17:07 --> Input Class Initialized
INFO - 2022-01-03 09:17:07 --> Language Class Initialized
INFO - 2022-01-03 09:17:07 --> Loader Class Initialized
INFO - 2022-01-03 09:17:07 --> Helper loaded: url_helper
INFO - 2022-01-03 09:17:07 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:17:07 --> Controller Class Initialized
INFO - 2022-01-03 09:17:07 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:17:07 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 09:17:07 --> Config Class Initialized
INFO - 2022-01-03 09:17:07 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:17:07 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:17:07 --> Utf8 Class Initialized
INFO - 2022-01-03 09:17:07 --> URI Class Initialized
DEBUG - 2022-01-03 09:17:07 --> No URI present. Default controller set.
INFO - 2022-01-03 09:17:07 --> Router Class Initialized
INFO - 2022-01-03 09:17:07 --> Output Class Initialized
INFO - 2022-01-03 09:17:07 --> Security Class Initialized
DEBUG - 2022-01-03 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:17:07 --> Input Class Initialized
INFO - 2022-01-03 09:17:07 --> Language Class Initialized
INFO - 2022-01-03 09:17:07 --> Loader Class Initialized
INFO - 2022-01-03 09:17:07 --> Helper loaded: url_helper
INFO - 2022-01-03 09:17:07 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:17:07 --> Controller Class Initialized
INFO - 2022-01-03 09:17:07 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:17:07 --> Model "UserModel" initialized
INFO - 2022-01-03 09:17:07 --> Model "AdminModel" initialized
INFO - 2022-01-03 09:17:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 09:17:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 09:17:07 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:17:07 --> Final output sent to browser
DEBUG - 2022-01-03 09:17:07 --> Total execution time: 0.0504
INFO - 2022-01-03 09:17:07 --> Config Class Initialized
INFO - 2022-01-03 09:17:07 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:17:07 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:17:07 --> Utf8 Class Initialized
INFO - 2022-01-03 09:17:07 --> URI Class Initialized
INFO - 2022-01-03 09:17:07 --> Router Class Initialized
INFO - 2022-01-03 09:17:07 --> Output Class Initialized
INFO - 2022-01-03 09:17:07 --> Security Class Initialized
DEBUG - 2022-01-03 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:17:07 --> Input Class Initialized
INFO - 2022-01-03 09:17:07 --> Language Class Initialized
ERROR - 2022-01-03 09:17:07 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:17:07 --> Config Class Initialized
INFO - 2022-01-03 09:17:07 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:17:07 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:17:07 --> Utf8 Class Initialized
INFO - 2022-01-03 09:17:07 --> URI Class Initialized
INFO - 2022-01-03 09:17:07 --> Router Class Initialized
INFO - 2022-01-03 09:17:07 --> Output Class Initialized
INFO - 2022-01-03 09:17:07 --> Security Class Initialized
DEBUG - 2022-01-03 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:17:07 --> Input Class Initialized
INFO - 2022-01-03 09:17:07 --> Language Class Initialized
ERROR - 2022-01-03 09:17:07 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:17:10 --> Config Class Initialized
INFO - 2022-01-03 09:17:10 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:17:10 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:17:10 --> Utf8 Class Initialized
INFO - 2022-01-03 09:17:10 --> URI Class Initialized
INFO - 2022-01-03 09:17:10 --> Router Class Initialized
INFO - 2022-01-03 09:17:10 --> Output Class Initialized
INFO - 2022-01-03 09:17:10 --> Security Class Initialized
DEBUG - 2022-01-03 09:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:17:10 --> Input Class Initialized
INFO - 2022-01-03 09:17:10 --> Language Class Initialized
INFO - 2022-01-03 09:17:10 --> Loader Class Initialized
INFO - 2022-01-03 09:17:10 --> Helper loaded: url_helper
INFO - 2022-01-03 09:17:10 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:17:10 --> Controller Class Initialized
INFO - 2022-01-03 09:17:10 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:17:10 --> Config Class Initialized
INFO - 2022-01-03 09:17:10 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:17:10 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:17:10 --> Utf8 Class Initialized
INFO - 2022-01-03 09:17:10 --> URI Class Initialized
INFO - 2022-01-03 09:17:10 --> Router Class Initialized
INFO - 2022-01-03 09:17:10 --> Output Class Initialized
INFO - 2022-01-03 09:17:10 --> Security Class Initialized
DEBUG - 2022-01-03 09:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:17:10 --> Input Class Initialized
INFO - 2022-01-03 09:17:10 --> Language Class Initialized
INFO - 2022-01-03 09:17:10 --> Loader Class Initialized
INFO - 2022-01-03 09:17:10 --> Helper loaded: url_helper
INFO - 2022-01-03 09:17:10 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:17:10 --> Controller Class Initialized
INFO - 2022-01-03 09:17:10 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:17:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:17:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:17:10 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:17:10 --> Final output sent to browser
DEBUG - 2022-01-03 09:17:10 --> Total execution time: 0.0498
INFO - 2022-01-03 09:17:41 --> Config Class Initialized
INFO - 2022-01-03 09:17:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:17:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:17:41 --> Utf8 Class Initialized
INFO - 2022-01-03 09:17:41 --> URI Class Initialized
INFO - 2022-01-03 09:17:41 --> Router Class Initialized
INFO - 2022-01-03 09:17:41 --> Output Class Initialized
INFO - 2022-01-03 09:17:41 --> Security Class Initialized
DEBUG - 2022-01-03 09:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:17:41 --> Input Class Initialized
INFO - 2022-01-03 09:17:41 --> Language Class Initialized
INFO - 2022-01-03 09:17:41 --> Loader Class Initialized
INFO - 2022-01-03 09:17:41 --> Helper loaded: url_helper
INFO - 2022-01-03 09:17:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:17:41 --> Controller Class Initialized
INFO - 2022-01-03 09:17:41 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:17:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
ERROR - 2022-01-03 09:17:41 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\OJT\application\views\login\index.php 74
INFO - 2022-01-03 09:18:24 --> Config Class Initialized
INFO - 2022-01-03 09:18:24 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:24 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:24 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:24 --> URI Class Initialized
INFO - 2022-01-03 09:18:24 --> Router Class Initialized
INFO - 2022-01-03 09:18:24 --> Output Class Initialized
INFO - 2022-01-03 09:18:24 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:24 --> Input Class Initialized
INFO - 2022-01-03 09:18:24 --> Language Class Initialized
INFO - 2022-01-03 09:18:25 --> Loader Class Initialized
INFO - 2022-01-03 09:18:25 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:25 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:25 --> Controller Class Initialized
INFO - 2022-01-03 09:18:25 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:18:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:18:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:18:25 --> Final output sent to browser
DEBUG - 2022-01-03 09:18:25 --> Total execution time: 0.0449
INFO - 2022-01-03 09:18:26 --> Config Class Initialized
INFO - 2022-01-03 09:18:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:26 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:26 --> URI Class Initialized
INFO - 2022-01-03 09:18:26 --> Router Class Initialized
INFO - 2022-01-03 09:18:26 --> Output Class Initialized
INFO - 2022-01-03 09:18:26 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:26 --> Input Class Initialized
INFO - 2022-01-03 09:18:26 --> Language Class Initialized
INFO - 2022-01-03 09:18:26 --> Loader Class Initialized
INFO - 2022-01-03 09:18:26 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:26 --> Controller Class Initialized
INFO - 2022-01-03 09:18:26 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:18:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:18:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:18:26 --> Final output sent to browser
DEBUG - 2022-01-03 09:18:26 --> Total execution time: 0.0482
INFO - 2022-01-03 09:18:33 --> Config Class Initialized
INFO - 2022-01-03 09:18:33 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:33 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:33 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:33 --> URI Class Initialized
INFO - 2022-01-03 09:18:33 --> Router Class Initialized
INFO - 2022-01-03 09:18:33 --> Output Class Initialized
INFO - 2022-01-03 09:18:33 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:33 --> Input Class Initialized
INFO - 2022-01-03 09:18:33 --> Language Class Initialized
INFO - 2022-01-03 09:18:33 --> Loader Class Initialized
INFO - 2022-01-03 09:18:33 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:33 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:33 --> Controller Class Initialized
INFO - 2022-01-03 09:18:33 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:33 --> Config Class Initialized
INFO - 2022-01-03 09:18:33 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:33 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:33 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:33 --> URI Class Initialized
INFO - 2022-01-03 09:18:33 --> Router Class Initialized
INFO - 2022-01-03 09:18:33 --> Output Class Initialized
INFO - 2022-01-03 09:18:33 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:33 --> Input Class Initialized
INFO - 2022-01-03 09:18:33 --> Language Class Initialized
INFO - 2022-01-03 09:18:33 --> Loader Class Initialized
INFO - 2022-01-03 09:18:33 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:33 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:33 --> Controller Class Initialized
INFO - 2022-01-03 09:18:33 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:18:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:18:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:18:33 --> Final output sent to browser
DEBUG - 2022-01-03 09:18:33 --> Total execution time: 0.0544
INFO - 2022-01-03 09:18:43 --> Config Class Initialized
INFO - 2022-01-03 09:18:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:43 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:43 --> URI Class Initialized
INFO - 2022-01-03 09:18:43 --> Router Class Initialized
INFO - 2022-01-03 09:18:43 --> Output Class Initialized
INFO - 2022-01-03 09:18:43 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:43 --> Input Class Initialized
INFO - 2022-01-03 09:18:43 --> Language Class Initialized
INFO - 2022-01-03 09:18:43 --> Loader Class Initialized
INFO - 2022-01-03 09:18:43 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:43 --> Controller Class Initialized
INFO - 2022-01-03 09:18:43 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\test2.php
INFO - 2022-01-03 09:18:43 --> Final output sent to browser
DEBUG - 2022-01-03 09:18:43 --> Total execution time: 0.0533
INFO - 2022-01-03 09:18:47 --> Config Class Initialized
INFO - 2022-01-03 09:18:47 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:47 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:47 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:47 --> URI Class Initialized
INFO - 2022-01-03 09:18:47 --> Router Class Initialized
INFO - 2022-01-03 09:18:47 --> Output Class Initialized
INFO - 2022-01-03 09:18:47 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:47 --> Input Class Initialized
INFO - 2022-01-03 09:18:47 --> Language Class Initialized
INFO - 2022-01-03 09:18:47 --> Loader Class Initialized
INFO - 2022-01-03 09:18:47 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:47 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:47 --> Controller Class Initialized
INFO - 2022-01-03 09:18:47 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:47 --> Config Class Initialized
INFO - 2022-01-03 09:18:47 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:47 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:47 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:47 --> URI Class Initialized
INFO - 2022-01-03 09:18:47 --> Router Class Initialized
INFO - 2022-01-03 09:18:47 --> Output Class Initialized
INFO - 2022-01-03 09:18:47 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:47 --> Input Class Initialized
INFO - 2022-01-03 09:18:47 --> Language Class Initialized
INFO - 2022-01-03 09:18:47 --> Loader Class Initialized
INFO - 2022-01-03 09:18:47 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:47 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:47 --> Controller Class Initialized
INFO - 2022-01-03 09:18:47 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:18:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:18:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:18:47 --> Final output sent to browser
DEBUG - 2022-01-03 09:18:47 --> Total execution time: 0.0436
INFO - 2022-01-03 09:18:58 --> Config Class Initialized
INFO - 2022-01-03 09:18:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:58 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:58 --> URI Class Initialized
INFO - 2022-01-03 09:18:58 --> Router Class Initialized
INFO - 2022-01-03 09:18:58 --> Output Class Initialized
INFO - 2022-01-03 09:18:58 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:58 --> Input Class Initialized
INFO - 2022-01-03 09:18:58 --> Language Class Initialized
INFO - 2022-01-03 09:18:58 --> Loader Class Initialized
INFO - 2022-01-03 09:18:58 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:58 --> Controller Class Initialized
INFO - 2022-01-03 09:18:58 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:58 --> Config Class Initialized
INFO - 2022-01-03 09:18:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:18:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:18:58 --> Utf8 Class Initialized
INFO - 2022-01-03 09:18:58 --> URI Class Initialized
INFO - 2022-01-03 09:18:58 --> Router Class Initialized
INFO - 2022-01-03 09:18:58 --> Output Class Initialized
INFO - 2022-01-03 09:18:58 --> Security Class Initialized
DEBUG - 2022-01-03 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:18:58 --> Input Class Initialized
INFO - 2022-01-03 09:18:58 --> Language Class Initialized
INFO - 2022-01-03 09:18:58 --> Loader Class Initialized
INFO - 2022-01-03 09:18:58 --> Helper loaded: url_helper
INFO - 2022-01-03 09:18:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:18:58 --> Controller Class Initialized
INFO - 2022-01-03 09:18:58 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:18:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:18:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:18:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:18:58 --> Final output sent to browser
DEBUG - 2022-01-03 09:18:58 --> Total execution time: 0.0497
INFO - 2022-01-03 09:19:05 --> Config Class Initialized
INFO - 2022-01-03 09:19:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:05 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:05 --> URI Class Initialized
INFO - 2022-01-03 09:19:05 --> Router Class Initialized
INFO - 2022-01-03 09:19:05 --> Output Class Initialized
INFO - 2022-01-03 09:19:05 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:05 --> Input Class Initialized
INFO - 2022-01-03 09:19:05 --> Language Class Initialized
INFO - 2022-01-03 09:19:05 --> Loader Class Initialized
INFO - 2022-01-03 09:19:05 --> Helper loaded: url_helper
INFO - 2022-01-03 09:19:05 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:19:05 --> Controller Class Initialized
INFO - 2022-01-03 09:19:05 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:19:05 --> Config Class Initialized
INFO - 2022-01-03 09:19:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:05 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:05 --> URI Class Initialized
INFO - 2022-01-03 09:19:05 --> Router Class Initialized
INFO - 2022-01-03 09:19:05 --> Output Class Initialized
INFO - 2022-01-03 09:19:05 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:05 --> Input Class Initialized
INFO - 2022-01-03 09:19:05 --> Language Class Initialized
INFO - 2022-01-03 09:19:05 --> Loader Class Initialized
INFO - 2022-01-03 09:19:05 --> Helper loaded: url_helper
INFO - 2022-01-03 09:19:05 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:19:05 --> Controller Class Initialized
INFO - 2022-01-03 09:19:05 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:19:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:19:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:19:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:19:05 --> Final output sent to browser
DEBUG - 2022-01-03 09:19:05 --> Total execution time: 0.0455
INFO - 2022-01-03 09:19:13 --> Config Class Initialized
INFO - 2022-01-03 09:19:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:13 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:13 --> URI Class Initialized
INFO - 2022-01-03 09:19:13 --> Router Class Initialized
INFO - 2022-01-03 09:19:13 --> Output Class Initialized
INFO - 2022-01-03 09:19:13 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:13 --> Input Class Initialized
INFO - 2022-01-03 09:19:13 --> Language Class Initialized
INFO - 2022-01-03 09:19:13 --> Loader Class Initialized
INFO - 2022-01-03 09:19:13 --> Helper loaded: url_helper
INFO - 2022-01-03 09:19:13 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:19:13 --> Controller Class Initialized
INFO - 2022-01-03 09:19:13 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:19:13 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 09:19:13 --> Config Class Initialized
INFO - 2022-01-03 09:19:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:13 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:13 --> URI Class Initialized
DEBUG - 2022-01-03 09:19:13 --> No URI present. Default controller set.
INFO - 2022-01-03 09:19:13 --> Router Class Initialized
INFO - 2022-01-03 09:19:13 --> Output Class Initialized
INFO - 2022-01-03 09:19:13 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:13 --> Input Class Initialized
INFO - 2022-01-03 09:19:13 --> Language Class Initialized
INFO - 2022-01-03 09:19:13 --> Loader Class Initialized
INFO - 2022-01-03 09:19:13 --> Helper loaded: url_helper
INFO - 2022-01-03 09:19:13 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:19:13 --> Controller Class Initialized
INFO - 2022-01-03 09:19:13 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:19:13 --> Model "UserModel" initialized
INFO - 2022-01-03 09:19:13 --> Model "AdminModel" initialized
INFO - 2022-01-03 09:19:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 09:19:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 09:19:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:19:13 --> Final output sent to browser
DEBUG - 2022-01-03 09:19:13 --> Total execution time: 0.0664
INFO - 2022-01-03 09:19:13 --> Config Class Initialized
INFO - 2022-01-03 09:19:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:13 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:13 --> URI Class Initialized
INFO - 2022-01-03 09:19:14 --> Router Class Initialized
INFO - 2022-01-03 09:19:14 --> Output Class Initialized
INFO - 2022-01-03 09:19:14 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:14 --> Input Class Initialized
INFO - 2022-01-03 09:19:14 --> Language Class Initialized
ERROR - 2022-01-03 09:19:14 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:19:14 --> Config Class Initialized
INFO - 2022-01-03 09:19:14 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:14 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:14 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:14 --> URI Class Initialized
INFO - 2022-01-03 09:19:14 --> Router Class Initialized
INFO - 2022-01-03 09:19:14 --> Output Class Initialized
INFO - 2022-01-03 09:19:14 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:14 --> Input Class Initialized
INFO - 2022-01-03 09:19:14 --> Language Class Initialized
ERROR - 2022-01-03 09:19:14 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:19:21 --> Config Class Initialized
INFO - 2022-01-03 09:19:21 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:21 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:21 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:21 --> URI Class Initialized
INFO - 2022-01-03 09:19:21 --> Router Class Initialized
INFO - 2022-01-03 09:19:21 --> Output Class Initialized
INFO - 2022-01-03 09:19:21 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:21 --> Input Class Initialized
INFO - 2022-01-03 09:19:21 --> Language Class Initialized
INFO - 2022-01-03 09:19:21 --> Loader Class Initialized
INFO - 2022-01-03 09:19:21 --> Helper loaded: url_helper
INFO - 2022-01-03 09:19:21 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:19:21 --> Controller Class Initialized
INFO - 2022-01-03 09:19:21 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:19:21 --> Config Class Initialized
INFO - 2022-01-03 09:19:21 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:21 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:21 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:21 --> URI Class Initialized
INFO - 2022-01-03 09:19:21 --> Router Class Initialized
INFO - 2022-01-03 09:19:21 --> Output Class Initialized
INFO - 2022-01-03 09:19:21 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:21 --> Input Class Initialized
INFO - 2022-01-03 09:19:21 --> Language Class Initialized
INFO - 2022-01-03 09:19:21 --> Loader Class Initialized
INFO - 2022-01-03 09:19:21 --> Helper loaded: url_helper
INFO - 2022-01-03 09:19:21 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:19:21 --> Controller Class Initialized
INFO - 2022-01-03 09:19:21 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:19:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:19:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:19:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:19:21 --> Final output sent to browser
DEBUG - 2022-01-03 09:19:21 --> Total execution time: 0.0489
INFO - 2022-01-03 09:19:35 --> Config Class Initialized
INFO - 2022-01-03 09:19:35 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:35 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:35 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:35 --> URI Class Initialized
INFO - 2022-01-03 09:19:35 --> Router Class Initialized
INFO - 2022-01-03 09:19:35 --> Output Class Initialized
INFO - 2022-01-03 09:19:35 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:35 --> Input Class Initialized
INFO - 2022-01-03 09:19:35 --> Language Class Initialized
INFO - 2022-01-03 09:19:35 --> Loader Class Initialized
INFO - 2022-01-03 09:19:35 --> Helper loaded: url_helper
INFO - 2022-01-03 09:19:35 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:19:35 --> Controller Class Initialized
INFO - 2022-01-03 09:19:35 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:19:35 --> Config Class Initialized
INFO - 2022-01-03 09:19:35 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:19:35 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:19:35 --> Utf8 Class Initialized
INFO - 2022-01-03 09:19:35 --> URI Class Initialized
INFO - 2022-01-03 09:19:35 --> Router Class Initialized
INFO - 2022-01-03 09:19:35 --> Output Class Initialized
INFO - 2022-01-03 09:19:35 --> Security Class Initialized
DEBUG - 2022-01-03 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:19:35 --> Input Class Initialized
INFO - 2022-01-03 09:19:35 --> Language Class Initialized
INFO - 2022-01-03 09:19:35 --> Loader Class Initialized
INFO - 2022-01-03 09:19:35 --> Helper loaded: url_helper
INFO - 2022-01-03 09:19:35 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:19:35 --> Controller Class Initialized
INFO - 2022-01-03 09:19:35 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:19:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:19:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:19:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:19:35 --> Final output sent to browser
DEBUG - 2022-01-03 09:19:36 --> Total execution time: 0.0541
INFO - 2022-01-03 09:20:57 --> Config Class Initialized
INFO - 2022-01-03 09:20:57 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:20:57 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:20:57 --> Utf8 Class Initialized
INFO - 2022-01-03 09:20:57 --> URI Class Initialized
INFO - 2022-01-03 09:20:57 --> Router Class Initialized
INFO - 2022-01-03 09:20:57 --> Output Class Initialized
INFO - 2022-01-03 09:20:57 --> Security Class Initialized
DEBUG - 2022-01-03 09:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:20:57 --> Input Class Initialized
INFO - 2022-01-03 09:20:57 --> Language Class Initialized
INFO - 2022-01-03 09:20:57 --> Loader Class Initialized
INFO - 2022-01-03 09:20:57 --> Helper loaded: url_helper
INFO - 2022-01-03 09:20:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:20:58 --> Controller Class Initialized
INFO - 2022-01-03 09:20:58 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:20:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:20:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:20:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:20:58 --> Final output sent to browser
DEBUG - 2022-01-03 09:20:58 --> Total execution time: 0.0642
INFO - 2022-01-03 09:21:00 --> Config Class Initialized
INFO - 2022-01-03 09:21:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:00 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:00 --> URI Class Initialized
INFO - 2022-01-03 09:21:00 --> Router Class Initialized
INFO - 2022-01-03 09:21:00 --> Output Class Initialized
INFO - 2022-01-03 09:21:00 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:00 --> Input Class Initialized
INFO - 2022-01-03 09:21:00 --> Language Class Initialized
INFO - 2022-01-03 09:21:00 --> Loader Class Initialized
INFO - 2022-01-03 09:21:00 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:00 --> Controller Class Initialized
INFO - 2022-01-03 09:21:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:21:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:21:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:21:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:21:00 --> Final output sent to browser
DEBUG - 2022-01-03 09:21:00 --> Total execution time: 0.0748
INFO - 2022-01-03 09:21:08 --> Config Class Initialized
INFO - 2022-01-03 09:21:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:08 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:08 --> URI Class Initialized
INFO - 2022-01-03 09:21:08 --> Router Class Initialized
INFO - 2022-01-03 09:21:08 --> Output Class Initialized
INFO - 2022-01-03 09:21:08 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:08 --> Input Class Initialized
INFO - 2022-01-03 09:21:08 --> Language Class Initialized
INFO - 2022-01-03 09:21:08 --> Loader Class Initialized
INFO - 2022-01-03 09:21:08 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:08 --> Controller Class Initialized
INFO - 2022-01-03 09:21:08 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:21:08 --> Config Class Initialized
INFO - 2022-01-03 09:21:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:08 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:08 --> URI Class Initialized
INFO - 2022-01-03 09:21:08 --> Router Class Initialized
INFO - 2022-01-03 09:21:08 --> Output Class Initialized
INFO - 2022-01-03 09:21:08 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:08 --> Input Class Initialized
INFO - 2022-01-03 09:21:08 --> Language Class Initialized
INFO - 2022-01-03 09:21:08 --> Loader Class Initialized
INFO - 2022-01-03 09:21:08 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:08 --> Controller Class Initialized
INFO - 2022-01-03 09:21:08 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:21:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:21:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:21:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:21:08 --> Final output sent to browser
DEBUG - 2022-01-03 09:21:08 --> Total execution time: 0.0516
INFO - 2022-01-03 09:21:50 --> Config Class Initialized
INFO - 2022-01-03 09:21:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:51 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:51 --> URI Class Initialized
INFO - 2022-01-03 09:21:51 --> Router Class Initialized
INFO - 2022-01-03 09:21:51 --> Output Class Initialized
INFO - 2022-01-03 09:21:51 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:51 --> Input Class Initialized
INFO - 2022-01-03 09:21:51 --> Language Class Initialized
INFO - 2022-01-03 09:21:51 --> Loader Class Initialized
INFO - 2022-01-03 09:21:51 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:51 --> Controller Class Initialized
INFO - 2022-01-03 09:21:51 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:21:51 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 09:21:51 --> Config Class Initialized
INFO - 2022-01-03 09:21:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:51 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:51 --> URI Class Initialized
DEBUG - 2022-01-03 09:21:51 --> No URI present. Default controller set.
INFO - 2022-01-03 09:21:51 --> Router Class Initialized
INFO - 2022-01-03 09:21:51 --> Output Class Initialized
INFO - 2022-01-03 09:21:51 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:51 --> Input Class Initialized
INFO - 2022-01-03 09:21:51 --> Language Class Initialized
INFO - 2022-01-03 09:21:51 --> Loader Class Initialized
INFO - 2022-01-03 09:21:51 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:51 --> Controller Class Initialized
INFO - 2022-01-03 09:21:51 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:21:51 --> Model "UserModel" initialized
INFO - 2022-01-03 09:21:51 --> Model "AdminModel" initialized
INFO - 2022-01-03 09:21:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 09:21:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 09:21:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:21:51 --> Final output sent to browser
DEBUG - 2022-01-03 09:21:51 --> Total execution time: 0.0488
INFO - 2022-01-03 09:21:51 --> Config Class Initialized
INFO - 2022-01-03 09:21:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:51 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:51 --> URI Class Initialized
INFO - 2022-01-03 09:21:51 --> Router Class Initialized
INFO - 2022-01-03 09:21:51 --> Output Class Initialized
INFO - 2022-01-03 09:21:51 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:51 --> Input Class Initialized
INFO - 2022-01-03 09:21:51 --> Language Class Initialized
ERROR - 2022-01-03 09:21:51 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:21:51 --> Config Class Initialized
INFO - 2022-01-03 09:21:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:51 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:51 --> URI Class Initialized
INFO - 2022-01-03 09:21:51 --> Router Class Initialized
INFO - 2022-01-03 09:21:51 --> Output Class Initialized
INFO - 2022-01-03 09:21:51 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:51 --> Input Class Initialized
INFO - 2022-01-03 09:21:51 --> Language Class Initialized
ERROR - 2022-01-03 09:21:51 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:21:53 --> Config Class Initialized
INFO - 2022-01-03 09:21:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:53 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:53 --> URI Class Initialized
INFO - 2022-01-03 09:21:53 --> Router Class Initialized
INFO - 2022-01-03 09:21:53 --> Output Class Initialized
INFO - 2022-01-03 09:21:53 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:53 --> Input Class Initialized
INFO - 2022-01-03 09:21:53 --> Language Class Initialized
INFO - 2022-01-03 09:21:53 --> Loader Class Initialized
INFO - 2022-01-03 09:21:53 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:53 --> Controller Class Initialized
INFO - 2022-01-03 09:21:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:21:53 --> Config Class Initialized
INFO - 2022-01-03 09:21:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:53 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:53 --> URI Class Initialized
INFO - 2022-01-03 09:21:53 --> Router Class Initialized
INFO - 2022-01-03 09:21:53 --> Output Class Initialized
INFO - 2022-01-03 09:21:53 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:53 --> Input Class Initialized
INFO - 2022-01-03 09:21:53 --> Language Class Initialized
INFO - 2022-01-03 09:21:53 --> Loader Class Initialized
INFO - 2022-01-03 09:21:53 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:53 --> Controller Class Initialized
INFO - 2022-01-03 09:21:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:21:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:21:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:21:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:21:53 --> Final output sent to browser
DEBUG - 2022-01-03 09:21:53 --> Total execution time: 0.0598
INFO - 2022-01-03 09:21:58 --> Config Class Initialized
INFO - 2022-01-03 09:21:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:58 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:58 --> URI Class Initialized
INFO - 2022-01-03 09:21:58 --> Router Class Initialized
INFO - 2022-01-03 09:21:58 --> Output Class Initialized
INFO - 2022-01-03 09:21:58 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:58 --> Input Class Initialized
INFO - 2022-01-03 09:21:58 --> Language Class Initialized
INFO - 2022-01-03 09:21:58 --> Loader Class Initialized
INFO - 2022-01-03 09:21:58 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:58 --> Controller Class Initialized
INFO - 2022-01-03 09:21:58 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:21:58 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 09:21:58 --> Config Class Initialized
INFO - 2022-01-03 09:21:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:58 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:58 --> URI Class Initialized
DEBUG - 2022-01-03 09:21:58 --> No URI present. Default controller set.
INFO - 2022-01-03 09:21:58 --> Router Class Initialized
INFO - 2022-01-03 09:21:58 --> Output Class Initialized
INFO - 2022-01-03 09:21:58 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:58 --> Input Class Initialized
INFO - 2022-01-03 09:21:58 --> Language Class Initialized
INFO - 2022-01-03 09:21:58 --> Loader Class Initialized
INFO - 2022-01-03 09:21:58 --> Helper loaded: url_helper
INFO - 2022-01-03 09:21:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:21:58 --> Controller Class Initialized
INFO - 2022-01-03 09:21:58 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:21:58 --> Model "UserModel" initialized
INFO - 2022-01-03 09:21:58 --> Model "AdminModel" initialized
INFO - 2022-01-03 09:21:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 09:21:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 09:21:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:21:58 --> Final output sent to browser
DEBUG - 2022-01-03 09:21:58 --> Total execution time: 0.0550
INFO - 2022-01-03 09:21:58 --> Config Class Initialized
INFO - 2022-01-03 09:21:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:21:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:21:58 --> Utf8 Class Initialized
INFO - 2022-01-03 09:21:58 --> URI Class Initialized
INFO - 2022-01-03 09:21:58 --> Router Class Initialized
INFO - 2022-01-03 09:21:58 --> Output Class Initialized
INFO - 2022-01-03 09:21:58 --> Security Class Initialized
DEBUG - 2022-01-03 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:21:58 --> Input Class Initialized
INFO - 2022-01-03 09:21:58 --> Language Class Initialized
ERROR - 2022-01-03 09:21:58 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:22:00 --> Config Class Initialized
INFO - 2022-01-03 09:22:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:22:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:22:00 --> Utf8 Class Initialized
INFO - 2022-01-03 09:22:00 --> URI Class Initialized
INFO - 2022-01-03 09:22:00 --> Router Class Initialized
INFO - 2022-01-03 09:22:00 --> Output Class Initialized
INFO - 2022-01-03 09:22:00 --> Security Class Initialized
DEBUG - 2022-01-03 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:22:00 --> Input Class Initialized
INFO - 2022-01-03 09:22:00 --> Language Class Initialized
INFO - 2022-01-03 09:22:00 --> Loader Class Initialized
INFO - 2022-01-03 09:22:00 --> Helper loaded: url_helper
INFO - 2022-01-03 09:22:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:22:00 --> Controller Class Initialized
INFO - 2022-01-03 09:22:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:22:00 --> Config Class Initialized
INFO - 2022-01-03 09:22:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:22:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:22:00 --> Utf8 Class Initialized
INFO - 2022-01-03 09:22:00 --> URI Class Initialized
INFO - 2022-01-03 09:22:00 --> Router Class Initialized
INFO - 2022-01-03 09:22:00 --> Output Class Initialized
INFO - 2022-01-03 09:22:00 --> Security Class Initialized
DEBUG - 2022-01-03 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:22:00 --> Input Class Initialized
INFO - 2022-01-03 09:22:00 --> Language Class Initialized
INFO - 2022-01-03 09:22:01 --> Loader Class Initialized
INFO - 2022-01-03 09:22:01 --> Helper loaded: url_helper
INFO - 2022-01-03 09:22:01 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:22:01 --> Controller Class Initialized
INFO - 2022-01-03 09:22:01 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:22:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:22:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:22:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:22:01 --> Final output sent to browser
DEBUG - 2022-01-03 09:22:01 --> Total execution time: 0.0730
INFO - 2022-01-03 09:22:50 --> Config Class Initialized
INFO - 2022-01-03 09:22:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:22:50 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:22:50 --> Utf8 Class Initialized
INFO - 2022-01-03 09:22:50 --> URI Class Initialized
INFO - 2022-01-03 09:22:50 --> Router Class Initialized
INFO - 2022-01-03 09:22:50 --> Output Class Initialized
INFO - 2022-01-03 09:22:50 --> Security Class Initialized
DEBUG - 2022-01-03 09:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:22:50 --> Input Class Initialized
INFO - 2022-01-03 09:22:50 --> Language Class Initialized
INFO - 2022-01-03 09:22:50 --> Loader Class Initialized
INFO - 2022-01-03 09:22:50 --> Helper loaded: url_helper
INFO - 2022-01-03 09:22:50 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:22:50 --> Controller Class Initialized
INFO - 2022-01-03 09:22:50 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:22:50 --> Config Class Initialized
INFO - 2022-01-03 09:22:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:22:50 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:22:50 --> Utf8 Class Initialized
INFO - 2022-01-03 09:22:50 --> URI Class Initialized
INFO - 2022-01-03 09:22:50 --> Router Class Initialized
INFO - 2022-01-03 09:22:50 --> Output Class Initialized
INFO - 2022-01-03 09:22:50 --> Security Class Initialized
DEBUG - 2022-01-03 09:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:22:50 --> Input Class Initialized
INFO - 2022-01-03 09:22:50 --> Language Class Initialized
INFO - 2022-01-03 09:22:50 --> Loader Class Initialized
INFO - 2022-01-03 09:22:50 --> Helper loaded: url_helper
INFO - 2022-01-03 09:22:50 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:22:50 --> Controller Class Initialized
INFO - 2022-01-03 09:22:50 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:22:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:22:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:22:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:22:50 --> Final output sent to browser
DEBUG - 2022-01-03 09:22:50 --> Total execution time: 0.0496
INFO - 2022-01-03 09:23:17 --> Config Class Initialized
INFO - 2022-01-03 09:23:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:23:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:23:17 --> Utf8 Class Initialized
INFO - 2022-01-03 09:23:17 --> URI Class Initialized
INFO - 2022-01-03 09:23:17 --> Router Class Initialized
INFO - 2022-01-03 09:23:17 --> Output Class Initialized
INFO - 2022-01-03 09:23:17 --> Security Class Initialized
DEBUG - 2022-01-03 09:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:23:17 --> Input Class Initialized
INFO - 2022-01-03 09:23:17 --> Language Class Initialized
INFO - 2022-01-03 09:23:17 --> Loader Class Initialized
INFO - 2022-01-03 09:23:17 --> Helper loaded: url_helper
INFO - 2022-01-03 09:23:17 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:23:17 --> Controller Class Initialized
INFO - 2022-01-03 09:23:17 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:23:17 --> Config Class Initialized
INFO - 2022-01-03 09:23:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:23:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:23:17 --> Utf8 Class Initialized
INFO - 2022-01-03 09:23:18 --> URI Class Initialized
INFO - 2022-01-03 09:23:18 --> Router Class Initialized
INFO - 2022-01-03 09:23:18 --> Output Class Initialized
INFO - 2022-01-03 09:23:18 --> Security Class Initialized
DEBUG - 2022-01-03 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:23:18 --> Input Class Initialized
INFO - 2022-01-03 09:23:18 --> Language Class Initialized
INFO - 2022-01-03 09:23:18 --> Loader Class Initialized
INFO - 2022-01-03 09:23:18 --> Helper loaded: url_helper
INFO - 2022-01-03 09:23:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:23:18 --> Controller Class Initialized
INFO - 2022-01-03 09:23:18 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:23:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:23:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:23:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:23:18 --> Final output sent to browser
DEBUG - 2022-01-03 09:23:18 --> Total execution time: 0.0617
INFO - 2022-01-03 09:26:51 --> Config Class Initialized
INFO - 2022-01-03 09:26:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:26:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:26:51 --> Utf8 Class Initialized
INFO - 2022-01-03 09:26:51 --> URI Class Initialized
INFO - 2022-01-03 09:26:51 --> Router Class Initialized
INFO - 2022-01-03 09:26:51 --> Output Class Initialized
INFO - 2022-01-03 09:26:51 --> Security Class Initialized
DEBUG - 2022-01-03 09:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:26:51 --> Input Class Initialized
INFO - 2022-01-03 09:26:51 --> Language Class Initialized
INFO - 2022-01-03 09:26:51 --> Loader Class Initialized
INFO - 2022-01-03 09:26:51 --> Helper loaded: url_helper
INFO - 2022-01-03 09:26:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:26:51 --> Controller Class Initialized
INFO - 2022-01-03 09:26:51 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:26:51 --> Config Class Initialized
INFO - 2022-01-03 09:26:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:26:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:26:51 --> Utf8 Class Initialized
INFO - 2022-01-03 09:26:51 --> URI Class Initialized
INFO - 2022-01-03 09:26:51 --> Router Class Initialized
INFO - 2022-01-03 09:26:51 --> Output Class Initialized
INFO - 2022-01-03 09:26:51 --> Security Class Initialized
DEBUG - 2022-01-03 09:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:26:51 --> Input Class Initialized
INFO - 2022-01-03 09:26:51 --> Language Class Initialized
INFO - 2022-01-03 09:26:51 --> Loader Class Initialized
INFO - 2022-01-03 09:26:51 --> Helper loaded: url_helper
INFO - 2022-01-03 09:26:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:26:51 --> Controller Class Initialized
INFO - 2022-01-03 09:26:51 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:26:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:26:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:26:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:26:51 --> Final output sent to browser
DEBUG - 2022-01-03 09:26:51 --> Total execution time: 0.0517
INFO - 2022-01-03 09:27:00 --> Config Class Initialized
INFO - 2022-01-03 09:27:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:27:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:27:00 --> Utf8 Class Initialized
INFO - 2022-01-03 09:27:00 --> URI Class Initialized
INFO - 2022-01-03 09:27:00 --> Router Class Initialized
INFO - 2022-01-03 09:27:00 --> Output Class Initialized
INFO - 2022-01-03 09:27:00 --> Security Class Initialized
DEBUG - 2022-01-03 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:27:00 --> Input Class Initialized
INFO - 2022-01-03 09:27:00 --> Language Class Initialized
INFO - 2022-01-03 09:27:00 --> Loader Class Initialized
INFO - 2022-01-03 09:27:00 --> Helper loaded: url_helper
INFO - 2022-01-03 09:27:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:27:00 --> Controller Class Initialized
INFO - 2022-01-03 09:27:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:27:00 --> Config Class Initialized
INFO - 2022-01-03 09:27:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:27:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:27:00 --> Utf8 Class Initialized
INFO - 2022-01-03 09:27:00 --> URI Class Initialized
INFO - 2022-01-03 09:27:00 --> Router Class Initialized
INFO - 2022-01-03 09:27:00 --> Output Class Initialized
INFO - 2022-01-03 09:27:00 --> Security Class Initialized
DEBUG - 2022-01-03 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:27:00 --> Input Class Initialized
INFO - 2022-01-03 09:27:00 --> Language Class Initialized
INFO - 2022-01-03 09:27:00 --> Loader Class Initialized
INFO - 2022-01-03 09:27:00 --> Helper loaded: url_helper
INFO - 2022-01-03 09:27:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:27:00 --> Controller Class Initialized
INFO - 2022-01-03 09:27:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:27:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:27:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:27:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:27:00 --> Final output sent to browser
DEBUG - 2022-01-03 09:27:00 --> Total execution time: 0.0462
INFO - 2022-01-03 09:27:56 --> Config Class Initialized
INFO - 2022-01-03 09:27:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:27:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:27:56 --> Utf8 Class Initialized
INFO - 2022-01-03 09:27:56 --> URI Class Initialized
INFO - 2022-01-03 09:27:56 --> Router Class Initialized
INFO - 2022-01-03 09:27:56 --> Output Class Initialized
INFO - 2022-01-03 09:27:56 --> Security Class Initialized
DEBUG - 2022-01-03 09:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:27:56 --> Input Class Initialized
INFO - 2022-01-03 09:27:56 --> Language Class Initialized
INFO - 2022-01-03 09:27:56 --> Loader Class Initialized
INFO - 2022-01-03 09:27:56 --> Helper loaded: url_helper
INFO - 2022-01-03 09:27:56 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:27:56 --> Controller Class Initialized
INFO - 2022-01-03 09:27:56 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:27:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:27:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:27:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:27:56 --> Final output sent to browser
DEBUG - 2022-01-03 09:27:56 --> Total execution time: 0.0475
INFO - 2022-01-03 09:31:16 --> Config Class Initialized
INFO - 2022-01-03 09:31:16 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:31:16 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:31:16 --> Utf8 Class Initialized
INFO - 2022-01-03 09:31:16 --> URI Class Initialized
INFO - 2022-01-03 09:31:16 --> Router Class Initialized
INFO - 2022-01-03 09:31:16 --> Output Class Initialized
INFO - 2022-01-03 09:31:16 --> Security Class Initialized
DEBUG - 2022-01-03 09:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:31:16 --> Input Class Initialized
INFO - 2022-01-03 09:31:16 --> Language Class Initialized
INFO - 2022-01-03 09:31:16 --> Loader Class Initialized
INFO - 2022-01-03 09:31:16 --> Helper loaded: url_helper
INFO - 2022-01-03 09:31:16 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:31:16 --> Controller Class Initialized
INFO - 2022-01-03 09:31:16 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:31:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:31:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:31:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:31:16 --> Final output sent to browser
DEBUG - 2022-01-03 09:31:16 --> Total execution time: 0.0679
INFO - 2022-01-03 09:31:25 --> Config Class Initialized
INFO - 2022-01-03 09:31:25 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:31:25 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:31:25 --> Utf8 Class Initialized
INFO - 2022-01-03 09:31:25 --> URI Class Initialized
INFO - 2022-01-03 09:31:25 --> Router Class Initialized
INFO - 2022-01-03 09:31:25 --> Output Class Initialized
INFO - 2022-01-03 09:31:25 --> Security Class Initialized
DEBUG - 2022-01-03 09:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:31:25 --> Input Class Initialized
INFO - 2022-01-03 09:31:25 --> Language Class Initialized
INFO - 2022-01-03 09:31:25 --> Loader Class Initialized
INFO - 2022-01-03 09:31:25 --> Helper loaded: url_helper
INFO - 2022-01-03 09:31:25 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:31:25 --> Controller Class Initialized
INFO - 2022-01-03 09:31:25 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:31:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:31:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:31:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:31:25 --> Final output sent to browser
DEBUG - 2022-01-03 09:31:25 --> Total execution time: 0.0716
INFO - 2022-01-03 09:31:29 --> Config Class Initialized
INFO - 2022-01-03 09:31:29 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:31:29 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:31:29 --> Utf8 Class Initialized
INFO - 2022-01-03 09:31:29 --> URI Class Initialized
INFO - 2022-01-03 09:31:29 --> Router Class Initialized
INFO - 2022-01-03 09:31:29 --> Output Class Initialized
INFO - 2022-01-03 09:31:29 --> Security Class Initialized
DEBUG - 2022-01-03 09:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:31:29 --> Input Class Initialized
INFO - 2022-01-03 09:31:29 --> Language Class Initialized
INFO - 2022-01-03 09:31:29 --> Loader Class Initialized
INFO - 2022-01-03 09:31:29 --> Helper loaded: url_helper
INFO - 2022-01-03 09:31:29 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:31:29 --> Controller Class Initialized
INFO - 2022-01-03 09:31:29 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:31:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:31:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:31:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:31:29 --> Final output sent to browser
DEBUG - 2022-01-03 09:31:29 --> Total execution time: 0.0564
INFO - 2022-01-03 09:31:40 --> Config Class Initialized
INFO - 2022-01-03 09:31:40 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:31:40 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:31:40 --> Utf8 Class Initialized
INFO - 2022-01-03 09:31:40 --> URI Class Initialized
INFO - 2022-01-03 09:31:40 --> Router Class Initialized
INFO - 2022-01-03 09:31:40 --> Output Class Initialized
INFO - 2022-01-03 09:31:40 --> Security Class Initialized
DEBUG - 2022-01-03 09:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:31:40 --> Input Class Initialized
INFO - 2022-01-03 09:31:40 --> Language Class Initialized
INFO - 2022-01-03 09:31:40 --> Loader Class Initialized
INFO - 2022-01-03 09:31:40 --> Helper loaded: url_helper
INFO - 2022-01-03 09:31:40 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:31:40 --> Controller Class Initialized
INFO - 2022-01-03 09:31:40 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:31:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:31:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:31:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:31:40 --> Final output sent to browser
DEBUG - 2022-01-03 09:31:40 --> Total execution time: 0.0933
INFO - 2022-01-03 09:33:46 --> Config Class Initialized
INFO - 2022-01-03 09:33:46 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:33:46 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:33:46 --> Utf8 Class Initialized
INFO - 2022-01-03 09:33:46 --> URI Class Initialized
INFO - 2022-01-03 09:33:46 --> Router Class Initialized
INFO - 2022-01-03 09:33:46 --> Output Class Initialized
INFO - 2022-01-03 09:33:46 --> Security Class Initialized
DEBUG - 2022-01-03 09:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:33:46 --> Input Class Initialized
INFO - 2022-01-03 09:33:46 --> Language Class Initialized
INFO - 2022-01-03 09:33:46 --> Loader Class Initialized
INFO - 2022-01-03 09:33:46 --> Helper loaded: url_helper
INFO - 2022-01-03 09:33:46 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:33:46 --> Controller Class Initialized
INFO - 2022-01-03 09:33:46 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:33:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:33:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:33:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:33:46 --> Final output sent to browser
DEBUG - 2022-01-03 09:33:46 --> Total execution time: 0.1133
INFO - 2022-01-03 09:34:20 --> Config Class Initialized
INFO - 2022-01-03 09:34:20 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:34:20 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:34:20 --> Utf8 Class Initialized
INFO - 2022-01-03 09:34:20 --> URI Class Initialized
INFO - 2022-01-03 09:34:20 --> Router Class Initialized
INFO - 2022-01-03 09:34:20 --> Output Class Initialized
INFO - 2022-01-03 09:34:20 --> Security Class Initialized
DEBUG - 2022-01-03 09:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:34:20 --> Input Class Initialized
INFO - 2022-01-03 09:34:20 --> Language Class Initialized
INFO - 2022-01-03 09:34:20 --> Loader Class Initialized
INFO - 2022-01-03 09:34:20 --> Helper loaded: url_helper
INFO - 2022-01-03 09:34:20 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:34:20 --> Controller Class Initialized
INFO - 2022-01-03 09:34:20 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:34:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:34:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:34:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:34:20 --> Final output sent to browser
DEBUG - 2022-01-03 09:34:20 --> Total execution time: 0.0933
INFO - 2022-01-03 09:34:34 --> Config Class Initialized
INFO - 2022-01-03 09:34:34 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:34:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:34:34 --> Utf8 Class Initialized
INFO - 2022-01-03 09:34:34 --> URI Class Initialized
INFO - 2022-01-03 09:34:34 --> Router Class Initialized
INFO - 2022-01-03 09:34:34 --> Output Class Initialized
INFO - 2022-01-03 09:34:34 --> Security Class Initialized
DEBUG - 2022-01-03 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:34:34 --> Input Class Initialized
INFO - 2022-01-03 09:34:34 --> Language Class Initialized
INFO - 2022-01-03 09:34:34 --> Loader Class Initialized
INFO - 2022-01-03 09:34:34 --> Helper loaded: url_helper
INFO - 2022-01-03 09:34:34 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:34:34 --> Controller Class Initialized
INFO - 2022-01-03 09:34:34 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:34:34 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 09:34:34 --> Config Class Initialized
INFO - 2022-01-03 09:34:34 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:34:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:34:34 --> Utf8 Class Initialized
INFO - 2022-01-03 09:34:34 --> URI Class Initialized
DEBUG - 2022-01-03 09:34:34 --> No URI present. Default controller set.
INFO - 2022-01-03 09:34:34 --> Router Class Initialized
INFO - 2022-01-03 09:34:34 --> Output Class Initialized
INFO - 2022-01-03 09:34:34 --> Security Class Initialized
DEBUG - 2022-01-03 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:34:34 --> Input Class Initialized
INFO - 2022-01-03 09:34:34 --> Language Class Initialized
INFO - 2022-01-03 09:34:34 --> Loader Class Initialized
INFO - 2022-01-03 09:34:34 --> Helper loaded: url_helper
INFO - 2022-01-03 09:34:34 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:34:34 --> Controller Class Initialized
INFO - 2022-01-03 09:34:34 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:34:34 --> Model "UserModel" initialized
INFO - 2022-01-03 09:34:34 --> Model "AdminModel" initialized
INFO - 2022-01-03 09:34:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 09:34:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 09:34:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:34:34 --> Final output sent to browser
DEBUG - 2022-01-03 09:34:34 --> Total execution time: 0.0669
INFO - 2022-01-03 09:34:34 --> Config Class Initialized
INFO - 2022-01-03 09:34:34 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:34:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:34:34 --> Utf8 Class Initialized
INFO - 2022-01-03 09:34:34 --> URI Class Initialized
INFO - 2022-01-03 09:34:34 --> Router Class Initialized
INFO - 2022-01-03 09:34:34 --> Output Class Initialized
INFO - 2022-01-03 09:34:34 --> Security Class Initialized
DEBUG - 2022-01-03 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:34:34 --> Input Class Initialized
INFO - 2022-01-03 09:34:34 --> Language Class Initialized
ERROR - 2022-01-03 09:34:34 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:34:34 --> Config Class Initialized
INFO - 2022-01-03 09:34:34 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:34:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:34:34 --> Utf8 Class Initialized
INFO - 2022-01-03 09:34:34 --> URI Class Initialized
INFO - 2022-01-03 09:34:34 --> Router Class Initialized
INFO - 2022-01-03 09:34:34 --> Output Class Initialized
INFO - 2022-01-03 09:34:34 --> Security Class Initialized
DEBUG - 2022-01-03 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:34:34 --> Input Class Initialized
INFO - 2022-01-03 09:34:34 --> Language Class Initialized
ERROR - 2022-01-03 09:34:34 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:34:36 --> Config Class Initialized
INFO - 2022-01-03 09:34:36 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:34:36 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:34:36 --> Utf8 Class Initialized
INFO - 2022-01-03 09:34:36 --> URI Class Initialized
INFO - 2022-01-03 09:34:36 --> Router Class Initialized
INFO - 2022-01-03 09:34:36 --> Output Class Initialized
INFO - 2022-01-03 09:34:36 --> Security Class Initialized
DEBUG - 2022-01-03 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:34:36 --> Input Class Initialized
INFO - 2022-01-03 09:34:36 --> Language Class Initialized
INFO - 2022-01-03 09:34:36 --> Loader Class Initialized
INFO - 2022-01-03 09:34:36 --> Helper loaded: url_helper
INFO - 2022-01-03 09:34:36 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:34:36 --> Controller Class Initialized
INFO - 2022-01-03 09:34:36 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:34:36 --> Config Class Initialized
INFO - 2022-01-03 09:34:36 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:34:36 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:34:36 --> Utf8 Class Initialized
INFO - 2022-01-03 09:34:36 --> URI Class Initialized
INFO - 2022-01-03 09:34:36 --> Router Class Initialized
INFO - 2022-01-03 09:34:36 --> Output Class Initialized
INFO - 2022-01-03 09:34:36 --> Security Class Initialized
DEBUG - 2022-01-03 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:34:36 --> Input Class Initialized
INFO - 2022-01-03 09:34:36 --> Language Class Initialized
INFO - 2022-01-03 09:34:36 --> Loader Class Initialized
INFO - 2022-01-03 09:34:36 --> Helper loaded: url_helper
INFO - 2022-01-03 09:34:36 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:34:36 --> Controller Class Initialized
INFO - 2022-01-03 09:34:36 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:34:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:34:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:34:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:34:36 --> Final output sent to browser
DEBUG - 2022-01-03 09:34:36 --> Total execution time: 0.0760
INFO - 2022-01-03 09:35:13 --> Config Class Initialized
INFO - 2022-01-03 09:35:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:35:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:35:13 --> Utf8 Class Initialized
INFO - 2022-01-03 09:35:13 --> URI Class Initialized
INFO - 2022-01-03 09:35:13 --> Router Class Initialized
INFO - 2022-01-03 09:35:13 --> Output Class Initialized
INFO - 2022-01-03 09:35:13 --> Security Class Initialized
DEBUG - 2022-01-03 09:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:35:13 --> Input Class Initialized
INFO - 2022-01-03 09:35:13 --> Language Class Initialized
INFO - 2022-01-03 09:35:13 --> Loader Class Initialized
INFO - 2022-01-03 09:35:13 --> Helper loaded: url_helper
INFO - 2022-01-03 09:35:13 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:35:13 --> Controller Class Initialized
INFO - 2022-01-03 09:35:13 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:35:13 --> Config Class Initialized
INFO - 2022-01-03 09:35:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:35:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:35:13 --> Utf8 Class Initialized
INFO - 2022-01-03 09:35:13 --> URI Class Initialized
INFO - 2022-01-03 09:35:13 --> Router Class Initialized
INFO - 2022-01-03 09:35:13 --> Output Class Initialized
INFO - 2022-01-03 09:35:13 --> Security Class Initialized
DEBUG - 2022-01-03 09:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:35:13 --> Input Class Initialized
INFO - 2022-01-03 09:35:13 --> Language Class Initialized
INFO - 2022-01-03 09:35:13 --> Loader Class Initialized
INFO - 2022-01-03 09:35:13 --> Helper loaded: url_helper
INFO - 2022-01-03 09:35:13 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:35:13 --> Controller Class Initialized
INFO - 2022-01-03 09:35:13 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:35:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:35:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:35:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:35:13 --> Final output sent to browser
DEBUG - 2022-01-03 09:35:13 --> Total execution time: 0.0550
INFO - 2022-01-03 09:37:17 --> Config Class Initialized
INFO - 2022-01-03 09:37:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:37:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:37:17 --> Utf8 Class Initialized
INFO - 2022-01-03 09:37:17 --> URI Class Initialized
INFO - 2022-01-03 09:37:17 --> Router Class Initialized
INFO - 2022-01-03 09:37:17 --> Output Class Initialized
INFO - 2022-01-03 09:37:17 --> Security Class Initialized
DEBUG - 2022-01-03 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:37:17 --> Input Class Initialized
INFO - 2022-01-03 09:37:17 --> Language Class Initialized
INFO - 2022-01-03 09:37:17 --> Loader Class Initialized
INFO - 2022-01-03 09:37:17 --> Helper loaded: url_helper
INFO - 2022-01-03 09:37:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:37:18 --> Controller Class Initialized
INFO - 2022-01-03 09:37:18 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:37:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:37:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:37:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:37:18 --> Final output sent to browser
DEBUG - 2022-01-03 09:37:18 --> Total execution time: 0.0941
INFO - 2022-01-03 09:38:43 --> Config Class Initialized
INFO - 2022-01-03 09:38:43 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:38:43 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:38:43 --> Utf8 Class Initialized
INFO - 2022-01-03 09:38:43 --> URI Class Initialized
INFO - 2022-01-03 09:38:43 --> Router Class Initialized
INFO - 2022-01-03 09:38:43 --> Output Class Initialized
INFO - 2022-01-03 09:38:43 --> Security Class Initialized
DEBUG - 2022-01-03 09:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:38:43 --> Input Class Initialized
INFO - 2022-01-03 09:38:43 --> Language Class Initialized
INFO - 2022-01-03 09:38:43 --> Loader Class Initialized
INFO - 2022-01-03 09:38:43 --> Helper loaded: url_helper
INFO - 2022-01-03 09:38:43 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:38:43 --> Controller Class Initialized
ERROR - 2022-01-03 09:38:43 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\OJT\application\models\LoginModel.php 24
INFO - 2022-01-03 09:38:44 --> Config Class Initialized
INFO - 2022-01-03 09:38:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:38:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:38:44 --> Utf8 Class Initialized
INFO - 2022-01-03 09:38:44 --> URI Class Initialized
INFO - 2022-01-03 09:38:44 --> Router Class Initialized
INFO - 2022-01-03 09:38:44 --> Output Class Initialized
INFO - 2022-01-03 09:38:44 --> Security Class Initialized
DEBUG - 2022-01-03 09:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:38:44 --> Input Class Initialized
INFO - 2022-01-03 09:38:44 --> Language Class Initialized
INFO - 2022-01-03 09:38:44 --> Loader Class Initialized
INFO - 2022-01-03 09:38:44 --> Helper loaded: url_helper
INFO - 2022-01-03 09:38:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:38:44 --> Controller Class Initialized
ERROR - 2022-01-03 09:38:44 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\OJT\application\models\LoginModel.php 24
INFO - 2022-01-03 09:38:54 --> Config Class Initialized
INFO - 2022-01-03 09:38:54 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:38:54 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:38:54 --> Utf8 Class Initialized
INFO - 2022-01-03 09:38:54 --> URI Class Initialized
INFO - 2022-01-03 09:38:54 --> Router Class Initialized
INFO - 2022-01-03 09:38:54 --> Output Class Initialized
INFO - 2022-01-03 09:38:54 --> Security Class Initialized
DEBUG - 2022-01-03 09:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:38:54 --> Input Class Initialized
INFO - 2022-01-03 09:38:54 --> Language Class Initialized
INFO - 2022-01-03 09:38:54 --> Loader Class Initialized
INFO - 2022-01-03 09:38:54 --> Helper loaded: url_helper
INFO - 2022-01-03 09:38:54 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:38:54 --> Controller Class Initialized
INFO - 2022-01-03 09:38:54 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:38:54 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:38:54 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:38:54 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:38:54 --> Final output sent to browser
DEBUG - 2022-01-03 09:38:54 --> Total execution time: 0.0735
INFO - 2022-01-03 09:39:04 --> Config Class Initialized
INFO - 2022-01-03 09:39:04 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:39:04 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:39:04 --> Utf8 Class Initialized
INFO - 2022-01-03 09:39:04 --> URI Class Initialized
INFO - 2022-01-03 09:39:04 --> Router Class Initialized
INFO - 2022-01-03 09:39:04 --> Output Class Initialized
INFO - 2022-01-03 09:39:04 --> Security Class Initialized
DEBUG - 2022-01-03 09:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:39:04 --> Input Class Initialized
INFO - 2022-01-03 09:39:04 --> Language Class Initialized
INFO - 2022-01-03 09:39:04 --> Loader Class Initialized
INFO - 2022-01-03 09:39:04 --> Helper loaded: url_helper
INFO - 2022-01-03 09:39:04 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:39:04 --> Controller Class Initialized
INFO - 2022-01-03 09:39:04 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:39:04 --> Config Class Initialized
INFO - 2022-01-03 09:39:04 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:39:04 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:39:04 --> Utf8 Class Initialized
INFO - 2022-01-03 09:39:04 --> URI Class Initialized
INFO - 2022-01-03 09:39:04 --> Router Class Initialized
INFO - 2022-01-03 09:39:04 --> Output Class Initialized
INFO - 2022-01-03 09:39:04 --> Security Class Initialized
DEBUG - 2022-01-03 09:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:39:04 --> Input Class Initialized
INFO - 2022-01-03 09:39:04 --> Language Class Initialized
INFO - 2022-01-03 09:39:04 --> Loader Class Initialized
INFO - 2022-01-03 09:39:04 --> Helper loaded: url_helper
INFO - 2022-01-03 09:39:04 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:39:04 --> Controller Class Initialized
INFO - 2022-01-03 09:39:04 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:39:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:39:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:39:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:39:04 --> Final output sent to browser
DEBUG - 2022-01-03 09:39:04 --> Total execution time: 0.0638
INFO - 2022-01-03 09:39:17 --> Config Class Initialized
INFO - 2022-01-03 09:39:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:39:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:39:17 --> Utf8 Class Initialized
INFO - 2022-01-03 09:39:17 --> URI Class Initialized
INFO - 2022-01-03 09:39:17 --> Router Class Initialized
INFO - 2022-01-03 09:39:17 --> Output Class Initialized
INFO - 2022-01-03 09:39:17 --> Security Class Initialized
DEBUG - 2022-01-03 09:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:39:17 --> Input Class Initialized
INFO - 2022-01-03 09:39:17 --> Language Class Initialized
INFO - 2022-01-03 09:39:17 --> Loader Class Initialized
INFO - 2022-01-03 09:39:17 --> Helper loaded: url_helper
INFO - 2022-01-03 09:39:17 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:39:17 --> Controller Class Initialized
INFO - 2022-01-03 09:39:17 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:39:17 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 09:39:17 --> Config Class Initialized
INFO - 2022-01-03 09:39:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:39:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:39:17 --> Utf8 Class Initialized
INFO - 2022-01-03 09:39:17 --> URI Class Initialized
DEBUG - 2022-01-03 09:39:17 --> No URI present. Default controller set.
INFO - 2022-01-03 09:39:17 --> Router Class Initialized
INFO - 2022-01-03 09:39:17 --> Output Class Initialized
INFO - 2022-01-03 09:39:17 --> Security Class Initialized
DEBUG - 2022-01-03 09:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:39:17 --> Input Class Initialized
INFO - 2022-01-03 09:39:17 --> Language Class Initialized
INFO - 2022-01-03 09:39:17 --> Loader Class Initialized
INFO - 2022-01-03 09:39:17 --> Helper loaded: url_helper
INFO - 2022-01-03 09:39:17 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:39:17 --> Controller Class Initialized
INFO - 2022-01-03 09:39:17 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:39:17 --> Model "UserModel" initialized
INFO - 2022-01-03 09:39:17 --> Model "AdminModel" initialized
INFO - 2022-01-03 09:39:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 09:39:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 09:39:17 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:39:17 --> Final output sent to browser
DEBUG - 2022-01-03 09:39:17 --> Total execution time: 0.0589
INFO - 2022-01-03 09:39:17 --> Config Class Initialized
INFO - 2022-01-03 09:39:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:39:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:39:17 --> Utf8 Class Initialized
INFO - 2022-01-03 09:39:17 --> URI Class Initialized
INFO - 2022-01-03 09:39:17 --> Router Class Initialized
INFO - 2022-01-03 09:39:18 --> Output Class Initialized
INFO - 2022-01-03 09:39:18 --> Security Class Initialized
DEBUG - 2022-01-03 09:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:39:18 --> Input Class Initialized
INFO - 2022-01-03 09:39:18 --> Language Class Initialized
ERROR - 2022-01-03 09:39:18 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:39:18 --> Config Class Initialized
INFO - 2022-01-03 09:39:18 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:39:18 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:39:18 --> Utf8 Class Initialized
INFO - 2022-01-03 09:39:18 --> URI Class Initialized
INFO - 2022-01-03 09:39:18 --> Router Class Initialized
INFO - 2022-01-03 09:39:18 --> Output Class Initialized
INFO - 2022-01-03 09:39:18 --> Security Class Initialized
DEBUG - 2022-01-03 09:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:39:18 --> Input Class Initialized
INFO - 2022-01-03 09:39:18 --> Language Class Initialized
ERROR - 2022-01-03 09:39:18 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:39:20 --> Config Class Initialized
INFO - 2022-01-03 09:39:20 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:39:20 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:39:20 --> Utf8 Class Initialized
INFO - 2022-01-03 09:39:20 --> URI Class Initialized
INFO - 2022-01-03 09:39:20 --> Router Class Initialized
INFO - 2022-01-03 09:39:20 --> Output Class Initialized
INFO - 2022-01-03 09:39:20 --> Security Class Initialized
DEBUG - 2022-01-03 09:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:39:20 --> Input Class Initialized
INFO - 2022-01-03 09:39:20 --> Language Class Initialized
INFO - 2022-01-03 09:39:20 --> Loader Class Initialized
INFO - 2022-01-03 09:39:20 --> Helper loaded: url_helper
INFO - 2022-01-03 09:39:20 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:39:20 --> Controller Class Initialized
INFO - 2022-01-03 09:39:20 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:39:20 --> Config Class Initialized
INFO - 2022-01-03 09:39:20 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:39:20 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:39:20 --> Utf8 Class Initialized
INFO - 2022-01-03 09:39:20 --> URI Class Initialized
INFO - 2022-01-03 09:39:20 --> Router Class Initialized
INFO - 2022-01-03 09:39:20 --> Output Class Initialized
INFO - 2022-01-03 09:39:20 --> Security Class Initialized
DEBUG - 2022-01-03 09:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:39:20 --> Input Class Initialized
INFO - 2022-01-03 09:39:20 --> Language Class Initialized
INFO - 2022-01-03 09:39:20 --> Loader Class Initialized
INFO - 2022-01-03 09:39:20 --> Helper loaded: url_helper
INFO - 2022-01-03 09:39:20 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:39:20 --> Controller Class Initialized
INFO - 2022-01-03 09:39:20 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:39:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:39:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:39:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:39:20 --> Final output sent to browser
DEBUG - 2022-01-03 09:39:20 --> Total execution time: 0.0681
INFO - 2022-01-03 09:42:38 --> Config Class Initialized
INFO - 2022-01-03 09:42:38 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:42:38 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:42:38 --> Utf8 Class Initialized
INFO - 2022-01-03 09:42:38 --> URI Class Initialized
INFO - 2022-01-03 09:42:38 --> Router Class Initialized
INFO - 2022-01-03 09:42:38 --> Output Class Initialized
INFO - 2022-01-03 09:42:38 --> Security Class Initialized
DEBUG - 2022-01-03 09:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:42:38 --> Input Class Initialized
INFO - 2022-01-03 09:42:38 --> Language Class Initialized
INFO - 2022-01-03 09:42:38 --> Loader Class Initialized
INFO - 2022-01-03 09:42:38 --> Helper loaded: url_helper
INFO - 2022-01-03 09:42:38 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:42:38 --> Controller Class Initialized
INFO - 2022-01-03 09:42:38 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:42:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:42:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:42:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:42:38 --> Final output sent to browser
DEBUG - 2022-01-03 09:42:38 --> Total execution time: 0.0740
INFO - 2022-01-03 09:42:44 --> Config Class Initialized
INFO - 2022-01-03 09:42:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:42:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:42:44 --> Utf8 Class Initialized
INFO - 2022-01-03 09:42:44 --> URI Class Initialized
INFO - 2022-01-03 09:42:44 --> Router Class Initialized
INFO - 2022-01-03 09:42:44 --> Output Class Initialized
INFO - 2022-01-03 09:42:44 --> Security Class Initialized
DEBUG - 2022-01-03 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:42:44 --> Input Class Initialized
INFO - 2022-01-03 09:42:44 --> Language Class Initialized
INFO - 2022-01-03 09:42:44 --> Loader Class Initialized
INFO - 2022-01-03 09:42:44 --> Helper loaded: url_helper
INFO - 2022-01-03 09:42:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:42:44 --> Controller Class Initialized
INFO - 2022-01-03 09:42:44 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:42:44 --> Severity: Warning --> Undefined array key "check_if_activated" C:\xampp\htdocs\OJT\application\controllers\Login.php 60
INFO - 2022-01-03 09:42:44 --> Config Class Initialized
INFO - 2022-01-03 09:42:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:42:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:42:44 --> Utf8 Class Initialized
INFO - 2022-01-03 09:42:44 --> URI Class Initialized
INFO - 2022-01-03 09:42:44 --> Router Class Initialized
INFO - 2022-01-03 09:42:44 --> Output Class Initialized
INFO - 2022-01-03 09:42:44 --> Security Class Initialized
DEBUG - 2022-01-03 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:42:44 --> Input Class Initialized
INFO - 2022-01-03 09:42:44 --> Language Class Initialized
INFO - 2022-01-03 09:42:44 --> Loader Class Initialized
INFO - 2022-01-03 09:42:44 --> Helper loaded: url_helper
INFO - 2022-01-03 09:42:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:42:44 --> Controller Class Initialized
INFO - 2022-01-03 09:42:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:42:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:42:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:42:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:42:44 --> Final output sent to browser
DEBUG - 2022-01-03 09:42:44 --> Total execution time: 0.0658
INFO - 2022-01-03 09:43:49 --> Config Class Initialized
INFO - 2022-01-03 09:43:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:43:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:43:49 --> Utf8 Class Initialized
INFO - 2022-01-03 09:43:49 --> URI Class Initialized
INFO - 2022-01-03 09:43:49 --> Router Class Initialized
INFO - 2022-01-03 09:43:49 --> Output Class Initialized
INFO - 2022-01-03 09:43:49 --> Security Class Initialized
DEBUG - 2022-01-03 09:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:43:49 --> Input Class Initialized
INFO - 2022-01-03 09:43:49 --> Language Class Initialized
INFO - 2022-01-03 09:43:49 --> Loader Class Initialized
INFO - 2022-01-03 09:43:49 --> Helper loaded: url_helper
INFO - 2022-01-03 09:43:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:43:49 --> Controller Class Initialized
INFO - 2022-01-03 09:43:49 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:43:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:43:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:43:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:43:49 --> Final output sent to browser
DEBUG - 2022-01-03 09:43:49 --> Total execution time: 0.0639
INFO - 2022-01-03 09:43:55 --> Config Class Initialized
INFO - 2022-01-03 09:43:55 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:43:55 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:43:55 --> Utf8 Class Initialized
INFO - 2022-01-03 09:43:55 --> URI Class Initialized
INFO - 2022-01-03 09:43:55 --> Router Class Initialized
INFO - 2022-01-03 09:43:55 --> Output Class Initialized
INFO - 2022-01-03 09:43:55 --> Security Class Initialized
DEBUG - 2022-01-03 09:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:43:55 --> Input Class Initialized
INFO - 2022-01-03 09:43:55 --> Language Class Initialized
INFO - 2022-01-03 09:43:55 --> Loader Class Initialized
INFO - 2022-01-03 09:43:55 --> Helper loaded: url_helper
INFO - 2022-01-03 09:43:55 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:43:55 --> Controller Class Initialized
INFO - 2022-01-03 09:43:55 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:43:55 --> Severity: Warning --> Undefined variable $check_if_activate C:\xampp\htdocs\OJT\application\controllers\Login.php 60
INFO - 2022-01-03 09:43:55 --> Config Class Initialized
INFO - 2022-01-03 09:43:55 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:43:55 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:43:55 --> Utf8 Class Initialized
INFO - 2022-01-03 09:43:55 --> URI Class Initialized
INFO - 2022-01-03 09:43:55 --> Router Class Initialized
INFO - 2022-01-03 09:43:55 --> Output Class Initialized
INFO - 2022-01-03 09:43:55 --> Security Class Initialized
DEBUG - 2022-01-03 09:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:43:55 --> Input Class Initialized
INFO - 2022-01-03 09:43:55 --> Language Class Initialized
INFO - 2022-01-03 09:43:55 --> Loader Class Initialized
INFO - 2022-01-03 09:43:55 --> Helper loaded: url_helper
INFO - 2022-01-03 09:43:55 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:43:55 --> Controller Class Initialized
INFO - 2022-01-03 09:43:55 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:43:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:43:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:43:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:43:55 --> Final output sent to browser
DEBUG - 2022-01-03 09:43:55 --> Total execution time: 0.0622
INFO - 2022-01-03 09:44:53 --> Config Class Initialized
INFO - 2022-01-03 09:44:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:44:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:44:53 --> Utf8 Class Initialized
INFO - 2022-01-03 09:44:53 --> URI Class Initialized
INFO - 2022-01-03 09:44:53 --> Router Class Initialized
INFO - 2022-01-03 09:44:53 --> Output Class Initialized
INFO - 2022-01-03 09:44:53 --> Security Class Initialized
DEBUG - 2022-01-03 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:44:53 --> Input Class Initialized
INFO - 2022-01-03 09:44:53 --> Language Class Initialized
INFO - 2022-01-03 09:44:53 --> Loader Class Initialized
INFO - 2022-01-03 09:44:53 --> Helper loaded: url_helper
INFO - 2022-01-03 09:44:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:44:53 --> Controller Class Initialized
INFO - 2022-01-03 09:44:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:44:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:44:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:44:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:44:53 --> Final output sent to browser
DEBUG - 2022-01-03 09:44:53 --> Total execution time: 0.0558
INFO - 2022-01-03 09:45:02 --> Config Class Initialized
INFO - 2022-01-03 09:45:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:02 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:02 --> URI Class Initialized
INFO - 2022-01-03 09:45:02 --> Router Class Initialized
INFO - 2022-01-03 09:45:02 --> Output Class Initialized
INFO - 2022-01-03 09:45:02 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:02 --> Input Class Initialized
INFO - 2022-01-03 09:45:02 --> Language Class Initialized
INFO - 2022-01-03 09:45:02 --> Loader Class Initialized
INFO - 2022-01-03 09:45:02 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:02 --> Controller Class Initialized
INFO - 2022-01-03 09:45:02 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:45:02 --> Severity: Warning --> Undefined variable $check_if_activate C:\xampp\htdocs\OJT\application\controllers\Login.php 60
INFO - 2022-01-03 09:45:02 --> Config Class Initialized
INFO - 2022-01-03 09:45:02 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:02 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:02 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:02 --> URI Class Initialized
INFO - 2022-01-03 09:45:02 --> Router Class Initialized
INFO - 2022-01-03 09:45:02 --> Output Class Initialized
INFO - 2022-01-03 09:45:02 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:02 --> Input Class Initialized
INFO - 2022-01-03 09:45:02 --> Language Class Initialized
INFO - 2022-01-03 09:45:02 --> Loader Class Initialized
INFO - 2022-01-03 09:45:02 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:02 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:02 --> Controller Class Initialized
INFO - 2022-01-03 09:45:02 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:45:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:45:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:45:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:45:02 --> Final output sent to browser
DEBUG - 2022-01-03 09:45:02 --> Total execution time: 0.0593
INFO - 2022-01-03 09:45:09 --> Config Class Initialized
INFO - 2022-01-03 09:45:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:09 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:09 --> URI Class Initialized
INFO - 2022-01-03 09:45:09 --> Router Class Initialized
INFO - 2022-01-03 09:45:09 --> Output Class Initialized
INFO - 2022-01-03 09:45:09 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:09 --> Input Class Initialized
INFO - 2022-01-03 09:45:09 --> Language Class Initialized
INFO - 2022-01-03 09:45:09 --> Loader Class Initialized
INFO - 2022-01-03 09:45:09 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:09 --> Controller Class Initialized
INFO - 2022-01-03 09:45:09 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:45:09 --> Severity: Warning --> Undefined variable $check_if_activate C:\xampp\htdocs\OJT\application\controllers\Login.php 60
INFO - 2022-01-03 09:45:09 --> Config Class Initialized
INFO - 2022-01-03 09:45:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:09 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:09 --> URI Class Initialized
INFO - 2022-01-03 09:45:09 --> Router Class Initialized
INFO - 2022-01-03 09:45:09 --> Output Class Initialized
INFO - 2022-01-03 09:45:09 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:09 --> Input Class Initialized
INFO - 2022-01-03 09:45:09 --> Language Class Initialized
INFO - 2022-01-03 09:45:09 --> Loader Class Initialized
INFO - 2022-01-03 09:45:09 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:09 --> Controller Class Initialized
INFO - 2022-01-03 09:45:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:45:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:45:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:45:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:45:09 --> Final output sent to browser
DEBUG - 2022-01-03 09:45:09 --> Total execution time: 0.0536
INFO - 2022-01-03 09:45:18 --> Config Class Initialized
INFO - 2022-01-03 09:45:18 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:18 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:18 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:18 --> URI Class Initialized
INFO - 2022-01-03 09:45:18 --> Router Class Initialized
INFO - 2022-01-03 09:45:18 --> Output Class Initialized
INFO - 2022-01-03 09:45:18 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:18 --> Input Class Initialized
INFO - 2022-01-03 09:45:18 --> Language Class Initialized
INFO - 2022-01-03 09:45:18 --> Loader Class Initialized
INFO - 2022-01-03 09:45:18 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:18 --> Controller Class Initialized
INFO - 2022-01-03 09:45:18 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:45:18 --> Severity: Warning --> Undefined variable $check_if_activate C:\xampp\htdocs\OJT\application\controllers\Login.php 60
INFO - 2022-01-03 09:45:18 --> Config Class Initialized
INFO - 2022-01-03 09:45:18 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:18 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:18 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:18 --> URI Class Initialized
INFO - 2022-01-03 09:45:18 --> Router Class Initialized
INFO - 2022-01-03 09:45:18 --> Output Class Initialized
INFO - 2022-01-03 09:45:18 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:18 --> Input Class Initialized
INFO - 2022-01-03 09:45:18 --> Language Class Initialized
INFO - 2022-01-03 09:45:18 --> Loader Class Initialized
INFO - 2022-01-03 09:45:18 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:18 --> Controller Class Initialized
INFO - 2022-01-03 09:45:18 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:45:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:45:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:45:18 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:45:18 --> Final output sent to browser
DEBUG - 2022-01-03 09:45:18 --> Total execution time: 0.0580
INFO - 2022-01-03 09:45:26 --> Config Class Initialized
INFO - 2022-01-03 09:45:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:26 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:26 --> URI Class Initialized
INFO - 2022-01-03 09:45:26 --> Router Class Initialized
INFO - 2022-01-03 09:45:26 --> Output Class Initialized
INFO - 2022-01-03 09:45:26 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:26 --> Input Class Initialized
INFO - 2022-01-03 09:45:26 --> Language Class Initialized
INFO - 2022-01-03 09:45:26 --> Loader Class Initialized
INFO - 2022-01-03 09:45:26 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:26 --> Controller Class Initialized
INFO - 2022-01-03 09:45:26 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:45:26 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 51
INFO - 2022-01-03 09:45:26 --> Config Class Initialized
INFO - 2022-01-03 09:45:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:26 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:26 --> URI Class Initialized
DEBUG - 2022-01-03 09:45:26 --> No URI present. Default controller set.
INFO - 2022-01-03 09:45:26 --> Router Class Initialized
INFO - 2022-01-03 09:45:26 --> Output Class Initialized
INFO - 2022-01-03 09:45:26 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:26 --> Input Class Initialized
INFO - 2022-01-03 09:45:26 --> Language Class Initialized
INFO - 2022-01-03 09:45:26 --> Loader Class Initialized
INFO - 2022-01-03 09:45:26 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:26 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:26 --> Controller Class Initialized
INFO - 2022-01-03 09:45:26 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:45:26 --> Model "UserModel" initialized
INFO - 2022-01-03 09:45:26 --> Model "AdminModel" initialized
INFO - 2022-01-03 09:45:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 09:45:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 09:45:26 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:45:26 --> Final output sent to browser
DEBUG - 2022-01-03 09:45:26 --> Total execution time: 0.0568
INFO - 2022-01-03 09:45:26 --> Config Class Initialized
INFO - 2022-01-03 09:45:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:26 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:26 --> URI Class Initialized
INFO - 2022-01-03 09:45:26 --> Router Class Initialized
INFO - 2022-01-03 09:45:26 --> Output Class Initialized
INFO - 2022-01-03 09:45:26 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:26 --> Input Class Initialized
INFO - 2022-01-03 09:45:26 --> Language Class Initialized
ERROR - 2022-01-03 09:45:26 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:45:26 --> Config Class Initialized
INFO - 2022-01-03 09:45:26 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:26 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:26 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:26 --> URI Class Initialized
INFO - 2022-01-03 09:45:26 --> Router Class Initialized
INFO - 2022-01-03 09:45:26 --> Output Class Initialized
INFO - 2022-01-03 09:45:26 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:26 --> Input Class Initialized
INFO - 2022-01-03 09:45:26 --> Language Class Initialized
ERROR - 2022-01-03 09:45:26 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 09:45:29 --> Config Class Initialized
INFO - 2022-01-03 09:45:29 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:29 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:29 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:29 --> URI Class Initialized
INFO - 2022-01-03 09:45:29 --> Router Class Initialized
INFO - 2022-01-03 09:45:29 --> Output Class Initialized
INFO - 2022-01-03 09:45:29 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:29 --> Input Class Initialized
INFO - 2022-01-03 09:45:29 --> Language Class Initialized
INFO - 2022-01-03 09:45:29 --> Loader Class Initialized
INFO - 2022-01-03 09:45:29 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:29 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:29 --> Controller Class Initialized
INFO - 2022-01-03 09:45:29 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:45:29 --> Config Class Initialized
INFO - 2022-01-03 09:45:29 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:29 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:29 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:29 --> URI Class Initialized
INFO - 2022-01-03 09:45:29 --> Router Class Initialized
INFO - 2022-01-03 09:45:29 --> Output Class Initialized
INFO - 2022-01-03 09:45:29 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:29 --> Input Class Initialized
INFO - 2022-01-03 09:45:29 --> Language Class Initialized
INFO - 2022-01-03 09:45:29 --> Loader Class Initialized
INFO - 2022-01-03 09:45:29 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:29 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:29 --> Controller Class Initialized
INFO - 2022-01-03 09:45:29 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:45:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:45:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:45:29 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:45:29 --> Final output sent to browser
DEBUG - 2022-01-03 09:45:29 --> Total execution time: 0.0801
INFO - 2022-01-03 09:45:58 --> Config Class Initialized
INFO - 2022-01-03 09:45:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:58 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:58 --> URI Class Initialized
INFO - 2022-01-03 09:45:58 --> Router Class Initialized
INFO - 2022-01-03 09:45:58 --> Output Class Initialized
INFO - 2022-01-03 09:45:58 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:58 --> Input Class Initialized
INFO - 2022-01-03 09:45:58 --> Language Class Initialized
INFO - 2022-01-03 09:45:58 --> Loader Class Initialized
INFO - 2022-01-03 09:45:58 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:58 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:58 --> Controller Class Initialized
INFO - 2022-01-03 09:45:58 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:45:58 --> Severity: Warning --> Undefined variable $check_if_activate C:\xampp\htdocs\OJT\application\controllers\Login.php 60
INFO - 2022-01-03 09:45:58 --> Config Class Initialized
INFO - 2022-01-03 09:45:58 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:45:58 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:45:58 --> Utf8 Class Initialized
INFO - 2022-01-03 09:45:58 --> URI Class Initialized
INFO - 2022-01-03 09:45:58 --> Router Class Initialized
INFO - 2022-01-03 09:45:58 --> Output Class Initialized
INFO - 2022-01-03 09:45:58 --> Security Class Initialized
DEBUG - 2022-01-03 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:45:58 --> Input Class Initialized
INFO - 2022-01-03 09:45:58 --> Language Class Initialized
INFO - 2022-01-03 09:45:58 --> Loader Class Initialized
INFO - 2022-01-03 09:45:59 --> Helper loaded: url_helper
INFO - 2022-01-03 09:45:59 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:45:59 --> Controller Class Initialized
INFO - 2022-01-03 09:45:59 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:45:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:45:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:45:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:45:59 --> Final output sent to browser
DEBUG - 2022-01-03 09:45:59 --> Total execution time: 0.0640
INFO - 2022-01-03 09:46:05 --> Config Class Initialized
INFO - 2022-01-03 09:46:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:46:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:46:05 --> Utf8 Class Initialized
INFO - 2022-01-03 09:46:05 --> URI Class Initialized
INFO - 2022-01-03 09:46:05 --> Router Class Initialized
INFO - 2022-01-03 09:46:05 --> Output Class Initialized
INFO - 2022-01-03 09:46:05 --> Security Class Initialized
DEBUG - 2022-01-03 09:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:46:05 --> Input Class Initialized
INFO - 2022-01-03 09:46:05 --> Language Class Initialized
INFO - 2022-01-03 09:46:05 --> Loader Class Initialized
INFO - 2022-01-03 09:46:05 --> Helper loaded: url_helper
INFO - 2022-01-03 09:46:05 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:46:05 --> Controller Class Initialized
INFO - 2022-01-03 09:46:05 --> Model "LoginModel" initialized
ERROR - 2022-01-03 09:46:05 --> Severity: Warning --> Undefined variable $check_if_activate C:\xampp\htdocs\OJT\application\controllers\Login.php 60
INFO - 2022-01-03 09:46:05 --> Config Class Initialized
INFO - 2022-01-03 09:46:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:46:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:46:05 --> Utf8 Class Initialized
INFO - 2022-01-03 09:46:05 --> URI Class Initialized
INFO - 2022-01-03 09:46:05 --> Router Class Initialized
INFO - 2022-01-03 09:46:05 --> Output Class Initialized
INFO - 2022-01-03 09:46:05 --> Security Class Initialized
DEBUG - 2022-01-03 09:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:46:05 --> Input Class Initialized
INFO - 2022-01-03 09:46:05 --> Language Class Initialized
INFO - 2022-01-03 09:46:05 --> Loader Class Initialized
INFO - 2022-01-03 09:46:05 --> Helper loaded: url_helper
INFO - 2022-01-03 09:46:05 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:46:05 --> Controller Class Initialized
INFO - 2022-01-03 09:46:05 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:46:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:46:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:46:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:46:05 --> Final output sent to browser
DEBUG - 2022-01-03 09:46:05 --> Total execution time: 0.0570
INFO - 2022-01-03 09:47:51 --> Config Class Initialized
INFO - 2022-01-03 09:47:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:47:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:47:51 --> Utf8 Class Initialized
INFO - 2022-01-03 09:47:51 --> URI Class Initialized
INFO - 2022-01-03 09:47:51 --> Router Class Initialized
INFO - 2022-01-03 09:47:51 --> Output Class Initialized
INFO - 2022-01-03 09:47:51 --> Security Class Initialized
DEBUG - 2022-01-03 09:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:47:51 --> Input Class Initialized
INFO - 2022-01-03 09:47:51 --> Language Class Initialized
INFO - 2022-01-03 09:47:51 --> Loader Class Initialized
INFO - 2022-01-03 09:47:51 --> Helper loaded: url_helper
INFO - 2022-01-03 09:47:51 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:47:51 --> Controller Class Initialized
INFO - 2022-01-03 09:47:51 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:47:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:47:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:47:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:47:51 --> Final output sent to browser
DEBUG - 2022-01-03 09:47:51 --> Total execution time: 0.0810
INFO - 2022-01-03 09:47:54 --> Config Class Initialized
INFO - 2022-01-03 09:47:54 --> Hooks Class Initialized
DEBUG - 2022-01-03 09:47:54 --> UTF-8 Support Enabled
INFO - 2022-01-03 09:47:54 --> Utf8 Class Initialized
INFO - 2022-01-03 09:47:54 --> URI Class Initialized
INFO - 2022-01-03 09:47:54 --> Router Class Initialized
INFO - 2022-01-03 09:47:54 --> Output Class Initialized
INFO - 2022-01-03 09:47:54 --> Security Class Initialized
DEBUG - 2022-01-03 09:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 09:47:54 --> Input Class Initialized
INFO - 2022-01-03 09:47:54 --> Language Class Initialized
INFO - 2022-01-03 09:47:54 --> Loader Class Initialized
INFO - 2022-01-03 09:47:54 --> Helper loaded: url_helper
INFO - 2022-01-03 09:47:55 --> Database Driver Class Initialized
DEBUG - 2022-01-03 09:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 09:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 09:47:55 --> Controller Class Initialized
INFO - 2022-01-03 09:47:55 --> Model "LoginModel" initialized
INFO - 2022-01-03 09:47:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 09:47:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 09:47:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 09:47:55 --> Final output sent to browser
DEBUG - 2022-01-03 09:47:55 --> Total execution time: 0.0817
INFO - 2022-01-03 10:00:27 --> Config Class Initialized
INFO - 2022-01-03 10:00:27 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:00:27 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:00:27 --> Utf8 Class Initialized
INFO - 2022-01-03 10:00:27 --> URI Class Initialized
INFO - 2022-01-03 10:00:27 --> Router Class Initialized
INFO - 2022-01-03 10:00:27 --> Output Class Initialized
INFO - 2022-01-03 10:00:27 --> Security Class Initialized
DEBUG - 2022-01-03 10:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:00:27 --> Input Class Initialized
INFO - 2022-01-03 10:00:27 --> Language Class Initialized
ERROR - 2022-01-03 10:00:27 --> Severity: error --> Exception: syntax error, unexpected identifier "redirect" C:\xampp\htdocs\OJT\application\controllers\Login.php 89
INFO - 2022-01-03 10:00:42 --> Config Class Initialized
INFO - 2022-01-03 10:00:42 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:00:42 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:00:42 --> Utf8 Class Initialized
INFO - 2022-01-03 10:00:42 --> URI Class Initialized
INFO - 2022-01-03 10:00:42 --> Router Class Initialized
INFO - 2022-01-03 10:00:42 --> Output Class Initialized
INFO - 2022-01-03 10:00:42 --> Security Class Initialized
DEBUG - 2022-01-03 10:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:00:42 --> Input Class Initialized
INFO - 2022-01-03 10:00:42 --> Language Class Initialized
INFO - 2022-01-03 10:00:42 --> Loader Class Initialized
INFO - 2022-01-03 10:00:42 --> Helper loaded: url_helper
INFO - 2022-01-03 10:00:42 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:00:42 --> Controller Class Initialized
INFO - 2022-01-03 17:00:42 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:00:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:00:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:00:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:00:42 --> Final output sent to browser
DEBUG - 2022-01-03 17:00:42 --> Total execution time: 0.0900
INFO - 2022-01-03 10:00:54 --> Config Class Initialized
INFO - 2022-01-03 10:00:54 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:00:54 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:00:54 --> Utf8 Class Initialized
INFO - 2022-01-03 10:00:54 --> URI Class Initialized
INFO - 2022-01-03 10:00:54 --> Router Class Initialized
INFO - 2022-01-03 10:00:54 --> Output Class Initialized
INFO - 2022-01-03 10:00:54 --> Security Class Initialized
DEBUG - 2022-01-03 10:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:00:54 --> Input Class Initialized
INFO - 2022-01-03 10:00:54 --> Language Class Initialized
INFO - 2022-01-03 10:00:54 --> Loader Class Initialized
INFO - 2022-01-03 10:00:54 --> Helper loaded: url_helper
INFO - 2022-01-03 10:00:54 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:00:54 --> Controller Class Initialized
INFO - 2022-01-03 17:00:54 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:00:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '201702003' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:00:54 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:02:34 --> Config Class Initialized
INFO - 2022-01-03 10:02:34 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:02:34 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:02:34 --> Utf8 Class Initialized
INFO - 2022-01-03 10:02:34 --> URI Class Initialized
INFO - 2022-01-03 10:02:34 --> Router Class Initialized
INFO - 2022-01-03 10:02:34 --> Output Class Initialized
INFO - 2022-01-03 10:02:34 --> Security Class Initialized
DEBUG - 2022-01-03 10:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:02:34 --> Input Class Initialized
INFO - 2022-01-03 10:02:34 --> Language Class Initialized
INFO - 2022-01-03 10:02:34 --> Loader Class Initialized
INFO - 2022-01-03 10:02:34 --> Helper loaded: url_helper
INFO - 2022-01-03 10:02:34 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:02:34 --> Controller Class Initialized
INFO - 2022-01-03 17:02:34 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:02:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '201702003' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:02:34 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:02:35 --> Config Class Initialized
INFO - 2022-01-03 10:02:35 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:02:35 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:02:35 --> Utf8 Class Initialized
INFO - 2022-01-03 10:02:35 --> URI Class Initialized
INFO - 2022-01-03 10:02:35 --> Router Class Initialized
INFO - 2022-01-03 10:02:35 --> Output Class Initialized
INFO - 2022-01-03 10:02:35 --> Security Class Initialized
DEBUG - 2022-01-03 10:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:02:35 --> Input Class Initialized
INFO - 2022-01-03 10:02:35 --> Language Class Initialized
INFO - 2022-01-03 10:02:35 --> Loader Class Initialized
INFO - 2022-01-03 10:02:35 --> Helper loaded: url_helper
INFO - 2022-01-03 10:02:35 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:02:35 --> Controller Class Initialized
INFO - 2022-01-03 17:02:35 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:02:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:02:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:02:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:02:35 --> Final output sent to browser
DEBUG - 2022-01-03 17:02:35 --> Total execution time: 0.0467
INFO - 2022-01-03 10:02:39 --> Config Class Initialized
INFO - 2022-01-03 10:02:39 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:02:39 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:02:39 --> Utf8 Class Initialized
INFO - 2022-01-03 10:02:39 --> URI Class Initialized
INFO - 2022-01-03 10:02:39 --> Router Class Initialized
INFO - 2022-01-03 10:02:39 --> Output Class Initialized
INFO - 2022-01-03 10:02:39 --> Security Class Initialized
DEBUG - 2022-01-03 10:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:02:39 --> Input Class Initialized
INFO - 2022-01-03 10:02:39 --> Language Class Initialized
INFO - 2022-01-03 10:02:39 --> Loader Class Initialized
INFO - 2022-01-03 10:02:39 --> Helper loaded: url_helper
INFO - 2022-01-03 10:02:39 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:02:39 --> Controller Class Initialized
INFO - 2022-01-03 17:02:39 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:02:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '201702003' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:02:39 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:02:49 --> Config Class Initialized
INFO - 2022-01-03 10:02:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:02:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:02:49 --> Utf8 Class Initialized
INFO - 2022-01-03 10:02:49 --> URI Class Initialized
INFO - 2022-01-03 10:02:49 --> Router Class Initialized
INFO - 2022-01-03 10:02:49 --> Output Class Initialized
INFO - 2022-01-03 10:02:49 --> Security Class Initialized
DEBUG - 2022-01-03 10:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:02:49 --> Input Class Initialized
INFO - 2022-01-03 10:02:49 --> Language Class Initialized
INFO - 2022-01-03 10:02:49 --> Loader Class Initialized
INFO - 2022-01-03 10:02:49 --> Helper loaded: url_helper
INFO - 2022-01-03 10:02:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:02:49 --> Controller Class Initialized
INFO - 2022-01-03 17:02:49 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:02:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '201702003' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:02:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:03:09 --> Config Class Initialized
INFO - 2022-01-03 10:03:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:03:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:03:09 --> Utf8 Class Initialized
INFO - 2022-01-03 10:03:09 --> URI Class Initialized
INFO - 2022-01-03 10:03:09 --> Router Class Initialized
INFO - 2022-01-03 10:03:09 --> Output Class Initialized
INFO - 2022-01-03 10:03:09 --> Security Class Initialized
DEBUG - 2022-01-03 10:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:03:09 --> Input Class Initialized
INFO - 2022-01-03 10:03:09 --> Language Class Initialized
INFO - 2022-01-03 10:03:09 --> Loader Class Initialized
INFO - 2022-01-03 10:03:09 --> Helper loaded: url_helper
INFO - 2022-01-03 10:03:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:03:09 --> Controller Class Initialized
INFO - 2022-01-03 17:03:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 10:03:09 --> Config Class Initialized
INFO - 2022-01-03 10:03:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:03:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:03:09 --> Utf8 Class Initialized
INFO - 2022-01-03 10:03:09 --> URI Class Initialized
INFO - 2022-01-03 10:03:09 --> Router Class Initialized
INFO - 2022-01-03 10:03:09 --> Output Class Initialized
INFO - 2022-01-03 10:03:09 --> Security Class Initialized
DEBUG - 2022-01-03 10:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:03:09 --> Input Class Initialized
INFO - 2022-01-03 10:03:09 --> Language Class Initialized
INFO - 2022-01-03 10:03:09 --> Loader Class Initialized
INFO - 2022-01-03 10:03:09 --> Helper loaded: url_helper
INFO - 2022-01-03 10:03:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:03:09 --> Controller Class Initialized
INFO - 2022-01-03 17:03:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:03:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:03:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:03:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:03:09 --> Final output sent to browser
DEBUG - 2022-01-03 17:03:09 --> Total execution time: 0.0486
INFO - 2022-01-03 10:03:17 --> Config Class Initialized
INFO - 2022-01-03 10:03:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:03:18 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:03:18 --> Utf8 Class Initialized
INFO - 2022-01-03 10:03:18 --> URI Class Initialized
INFO - 2022-01-03 10:03:18 --> Router Class Initialized
INFO - 2022-01-03 10:03:18 --> Output Class Initialized
INFO - 2022-01-03 10:03:18 --> Security Class Initialized
DEBUG - 2022-01-03 10:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:03:18 --> Input Class Initialized
INFO - 2022-01-03 10:03:18 --> Language Class Initialized
INFO - 2022-01-03 10:03:18 --> Loader Class Initialized
INFO - 2022-01-03 10:03:18 --> Helper loaded: url_helper
INFO - 2022-01-03 10:03:18 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:03:18 --> Controller Class Initialized
INFO - 2022-01-03 17:03:18 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:03:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '123' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:03:18 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:04:39 --> Config Class Initialized
INFO - 2022-01-03 10:04:39 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:39 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:39 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:39 --> URI Class Initialized
INFO - 2022-01-03 10:04:39 --> Router Class Initialized
INFO - 2022-01-03 10:04:39 --> Output Class Initialized
INFO - 2022-01-03 10:04:39 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:39 --> Input Class Initialized
INFO - 2022-01-03 10:04:39 --> Language Class Initialized
INFO - 2022-01-03 10:04:39 --> Loader Class Initialized
INFO - 2022-01-03 10:04:39 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:39 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:39 --> Controller Class Initialized
INFO - 2022-01-03 17:04:39 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:04:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '123' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:04:39 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:04:41 --> Config Class Initialized
INFO - 2022-01-03 10:04:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:41 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:41 --> URI Class Initialized
INFO - 2022-01-03 10:04:41 --> Router Class Initialized
INFO - 2022-01-03 10:04:41 --> Output Class Initialized
INFO - 2022-01-03 10:04:41 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:41 --> Input Class Initialized
INFO - 2022-01-03 10:04:41 --> Language Class Initialized
INFO - 2022-01-03 10:04:41 --> Loader Class Initialized
INFO - 2022-01-03 10:04:41 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:41 --> Controller Class Initialized
INFO - 2022-01-03 17:04:41 --> Model "LoginModel" initialized
INFO - 2022-01-03 10:04:41 --> Config Class Initialized
INFO - 2022-01-03 10:04:41 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:41 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:41 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:41 --> URI Class Initialized
INFO - 2022-01-03 10:04:41 --> Router Class Initialized
INFO - 2022-01-03 10:04:41 --> Output Class Initialized
INFO - 2022-01-03 10:04:41 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:41 --> Input Class Initialized
INFO - 2022-01-03 10:04:41 --> Language Class Initialized
INFO - 2022-01-03 10:04:41 --> Loader Class Initialized
INFO - 2022-01-03 10:04:41 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:41 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:41 --> Controller Class Initialized
INFO - 2022-01-03 17:04:41 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:04:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:04:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:04:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:04:41 --> Final output sent to browser
DEBUG - 2022-01-03 17:04:41 --> Total execution time: 0.0621
INFO - 2022-01-03 10:04:44 --> Config Class Initialized
INFO - 2022-01-03 10:04:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:44 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:44 --> URI Class Initialized
INFO - 2022-01-03 10:04:44 --> Router Class Initialized
INFO - 2022-01-03 10:04:44 --> Output Class Initialized
INFO - 2022-01-03 10:04:44 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:44 --> Input Class Initialized
INFO - 2022-01-03 10:04:44 --> Language Class Initialized
INFO - 2022-01-03 10:04:44 --> Loader Class Initialized
INFO - 2022-01-03 10:04:44 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:44 --> Controller Class Initialized
INFO - 2022-01-03 17:04:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 10:04:44 --> Config Class Initialized
INFO - 2022-01-03 10:04:44 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:44 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:44 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:44 --> URI Class Initialized
INFO - 2022-01-03 10:04:44 --> Router Class Initialized
INFO - 2022-01-03 10:04:44 --> Output Class Initialized
INFO - 2022-01-03 10:04:44 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:44 --> Input Class Initialized
INFO - 2022-01-03 10:04:44 --> Language Class Initialized
INFO - 2022-01-03 10:04:44 --> Loader Class Initialized
INFO - 2022-01-03 10:04:44 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:44 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:44 --> Controller Class Initialized
INFO - 2022-01-03 17:04:44 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:04:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:04:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:04:44 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:04:44 --> Final output sent to browser
DEBUG - 2022-01-03 17:04:44 --> Total execution time: 0.0749
INFO - 2022-01-03 10:04:50 --> Config Class Initialized
INFO - 2022-01-03 10:04:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:50 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:50 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:50 --> URI Class Initialized
INFO - 2022-01-03 10:04:50 --> Router Class Initialized
INFO - 2022-01-03 10:04:50 --> Output Class Initialized
INFO - 2022-01-03 10:04:50 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:50 --> Input Class Initialized
INFO - 2022-01-03 10:04:50 --> Language Class Initialized
INFO - 2022-01-03 10:04:50 --> Loader Class Initialized
INFO - 2022-01-03 10:04:50 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:50 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:50 --> Controller Class Initialized
INFO - 2022-01-03 17:04:50 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:04:50 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 10:04:50 --> Config Class Initialized
INFO - 2022-01-03 10:04:50 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:50 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:50 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:50 --> URI Class Initialized
DEBUG - 2022-01-03 10:04:50 --> No URI present. Default controller set.
INFO - 2022-01-03 10:04:50 --> Router Class Initialized
INFO - 2022-01-03 10:04:50 --> Output Class Initialized
INFO - 2022-01-03 10:04:50 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:50 --> Input Class Initialized
INFO - 2022-01-03 10:04:50 --> Language Class Initialized
INFO - 2022-01-03 10:04:50 --> Loader Class Initialized
INFO - 2022-01-03 10:04:50 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:50 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:50 --> Controller Class Initialized
INFO - 2022-01-03 17:04:50 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:04:50 --> Model "UserModel" initialized
INFO - 2022-01-03 17:04:50 --> Model "AdminModel" initialized
INFO - 2022-01-03 17:04:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 17:04:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 17:04:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:04:50 --> Final output sent to browser
DEBUG - 2022-01-03 17:04:50 --> Total execution time: 0.0603
INFO - 2022-01-03 10:04:51 --> Config Class Initialized
INFO - 2022-01-03 10:04:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:51 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:51 --> URI Class Initialized
INFO - 2022-01-03 10:04:51 --> Router Class Initialized
INFO - 2022-01-03 10:04:51 --> Output Class Initialized
INFO - 2022-01-03 10:04:51 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:51 --> Input Class Initialized
INFO - 2022-01-03 10:04:51 --> Language Class Initialized
ERROR - 2022-01-03 10:04:51 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 10:04:51 --> Config Class Initialized
INFO - 2022-01-03 10:04:51 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:51 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:51 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:51 --> URI Class Initialized
INFO - 2022-01-03 10:04:51 --> Router Class Initialized
INFO - 2022-01-03 10:04:51 --> Output Class Initialized
INFO - 2022-01-03 10:04:51 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:51 --> Input Class Initialized
INFO - 2022-01-03 10:04:51 --> Language Class Initialized
ERROR - 2022-01-03 10:04:51 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 10:04:53 --> Config Class Initialized
INFO - 2022-01-03 10:04:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:53 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:53 --> URI Class Initialized
INFO - 2022-01-03 10:04:53 --> Router Class Initialized
INFO - 2022-01-03 10:04:53 --> Output Class Initialized
INFO - 2022-01-03 10:04:53 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:53 --> Input Class Initialized
INFO - 2022-01-03 10:04:53 --> Language Class Initialized
INFO - 2022-01-03 10:04:53 --> Loader Class Initialized
INFO - 2022-01-03 10:04:53 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:53 --> Controller Class Initialized
INFO - 2022-01-03 17:04:53 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:04:53 --> Model "UserModel" initialized
INFO - 2022-01-03 17:04:53 --> Model "AdminModel" initialized
INFO - 2022-01-03 17:04:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 17:04:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-03 17:04:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:04:53 --> Final output sent to browser
DEBUG - 2022-01-03 17:04:53 --> Total execution time: 0.0979
INFO - 2022-01-03 10:04:53 --> Config Class Initialized
INFO - 2022-01-03 10:04:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:53 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:53 --> URI Class Initialized
INFO - 2022-01-03 10:04:53 --> Router Class Initialized
INFO - 2022-01-03 10:04:53 --> Output Class Initialized
INFO - 2022-01-03 10:04:53 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:53 --> Input Class Initialized
INFO - 2022-01-03 10:04:53 --> Language Class Initialized
ERROR - 2022-01-03 10:04:53 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 10:04:54 --> Config Class Initialized
INFO - 2022-01-03 10:04:54 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:54 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:54 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:54 --> URI Class Initialized
INFO - 2022-01-03 10:04:54 --> Router Class Initialized
INFO - 2022-01-03 10:04:54 --> Output Class Initialized
INFO - 2022-01-03 10:04:54 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:54 --> Input Class Initialized
INFO - 2022-01-03 10:04:54 --> Language Class Initialized
INFO - 2022-01-03 10:04:54 --> Loader Class Initialized
INFO - 2022-01-03 10:04:54 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:54 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:54 --> Controller Class Initialized
INFO - 2022-01-03 17:04:54 --> Model "LoginModel" initialized
INFO - 2022-01-03 10:04:54 --> Config Class Initialized
INFO - 2022-01-03 10:04:54 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:04:54 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:04:54 --> Utf8 Class Initialized
INFO - 2022-01-03 10:04:54 --> URI Class Initialized
INFO - 2022-01-03 10:04:54 --> Router Class Initialized
INFO - 2022-01-03 10:04:54 --> Output Class Initialized
INFO - 2022-01-03 10:04:54 --> Security Class Initialized
DEBUG - 2022-01-03 10:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:04:54 --> Input Class Initialized
INFO - 2022-01-03 10:04:54 --> Language Class Initialized
INFO - 2022-01-03 10:04:54 --> Loader Class Initialized
INFO - 2022-01-03 10:04:54 --> Helper loaded: url_helper
INFO - 2022-01-03 10:04:54 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:04:54 --> Controller Class Initialized
INFO - 2022-01-03 17:04:54 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:04:54 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:04:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:04:55 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:04:55 --> Final output sent to browser
DEBUG - 2022-01-03 17:04:55 --> Total execution time: 0.0682
INFO - 2022-01-03 10:05:03 --> Config Class Initialized
INFO - 2022-01-03 10:05:03 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:05:03 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:05:03 --> Utf8 Class Initialized
INFO - 2022-01-03 10:05:03 --> URI Class Initialized
INFO - 2022-01-03 10:05:03 --> Router Class Initialized
INFO - 2022-01-03 10:05:03 --> Output Class Initialized
INFO - 2022-01-03 10:05:03 --> Security Class Initialized
DEBUG - 2022-01-03 10:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:05:03 --> Input Class Initialized
INFO - 2022-01-03 10:05:03 --> Language Class Initialized
INFO - 2022-01-03 10:05:03 --> Loader Class Initialized
INFO - 2022-01-03 10:05:03 --> Helper loaded: url_helper
INFO - 2022-01-03 10:05:03 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:05:03 --> Controller Class Initialized
INFO - 2022-01-03 17:05:03 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:05:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:05:03 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:53 --> Config Class Initialized
INFO - 2022-01-03 10:07:53 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:53 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:53 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:53 --> URI Class Initialized
INFO - 2022-01-03 10:07:53 --> Router Class Initialized
INFO - 2022-01-03 10:07:53 --> Output Class Initialized
INFO - 2022-01-03 10:07:53 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:53 --> Input Class Initialized
INFO - 2022-01-03 10:07:53 --> Language Class Initialized
INFO - 2022-01-03 10:07:53 --> Loader Class Initialized
INFO - 2022-01-03 10:07:53 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:53 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:53 --> Controller Class Initialized
INFO - 2022-01-03 17:07:53 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:53 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:55 --> Config Class Initialized
INFO - 2022-01-03 10:07:55 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:55 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:55 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:55 --> URI Class Initialized
INFO - 2022-01-03 10:07:55 --> Router Class Initialized
INFO - 2022-01-03 10:07:55 --> Output Class Initialized
INFO - 2022-01-03 10:07:55 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:55 --> Input Class Initialized
INFO - 2022-01-03 10:07:55 --> Language Class Initialized
INFO - 2022-01-03 10:07:55 --> Loader Class Initialized
INFO - 2022-01-03 10:07:55 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:55 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:55 --> Controller Class Initialized
INFO - 2022-01-03 17:07:55 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:55 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:56 --> Config Class Initialized
INFO - 2022-01-03 10:07:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:56 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:56 --> URI Class Initialized
INFO - 2022-01-03 10:07:56 --> Router Class Initialized
INFO - 2022-01-03 10:07:56 --> Output Class Initialized
INFO - 2022-01-03 10:07:56 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:56 --> Input Class Initialized
INFO - 2022-01-03 10:07:56 --> Language Class Initialized
INFO - 2022-01-03 10:07:56 --> Loader Class Initialized
INFO - 2022-01-03 10:07:56 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:56 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:56 --> Controller Class Initialized
INFO - 2022-01-03 17:07:56 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:56 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:56 --> Config Class Initialized
INFO - 2022-01-03 10:07:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:56 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:56 --> URI Class Initialized
INFO - 2022-01-03 10:07:56 --> Router Class Initialized
INFO - 2022-01-03 10:07:56 --> Output Class Initialized
INFO - 2022-01-03 10:07:56 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:56 --> Input Class Initialized
INFO - 2022-01-03 10:07:56 --> Language Class Initialized
INFO - 2022-01-03 10:07:56 --> Loader Class Initialized
INFO - 2022-01-03 10:07:56 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:56 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:56 --> Controller Class Initialized
INFO - 2022-01-03 17:07:56 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:56 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:56 --> Config Class Initialized
INFO - 2022-01-03 10:07:56 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:56 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:56 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:56 --> URI Class Initialized
INFO - 2022-01-03 10:07:56 --> Router Class Initialized
INFO - 2022-01-03 10:07:56 --> Output Class Initialized
INFO - 2022-01-03 10:07:56 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:56 --> Input Class Initialized
INFO - 2022-01-03 10:07:56 --> Language Class Initialized
INFO - 2022-01-03 10:07:57 --> Loader Class Initialized
INFO - 2022-01-03 10:07:57 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:57 --> Controller Class Initialized
INFO - 2022-01-03 17:07:57 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:57 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:57 --> Config Class Initialized
INFO - 2022-01-03 10:07:57 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:57 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:57 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:57 --> URI Class Initialized
INFO - 2022-01-03 10:07:57 --> Router Class Initialized
INFO - 2022-01-03 10:07:57 --> Output Class Initialized
INFO - 2022-01-03 10:07:57 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:57 --> Input Class Initialized
INFO - 2022-01-03 10:07:57 --> Language Class Initialized
INFO - 2022-01-03 10:07:57 --> Loader Class Initialized
INFO - 2022-01-03 10:07:57 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:57 --> Controller Class Initialized
INFO - 2022-01-03 17:07:57 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:57 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:57 --> Config Class Initialized
INFO - 2022-01-03 10:07:57 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:57 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:57 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:57 --> URI Class Initialized
INFO - 2022-01-03 10:07:57 --> Router Class Initialized
INFO - 2022-01-03 10:07:57 --> Output Class Initialized
INFO - 2022-01-03 10:07:57 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:57 --> Input Class Initialized
INFO - 2022-01-03 10:07:57 --> Language Class Initialized
INFO - 2022-01-03 10:07:57 --> Loader Class Initialized
INFO - 2022-01-03 10:07:57 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:57 --> Controller Class Initialized
INFO - 2022-01-03 17:07:57 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:57 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:57 --> Config Class Initialized
INFO - 2022-01-03 10:07:57 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:57 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:57 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:57 --> URI Class Initialized
INFO - 2022-01-03 10:07:57 --> Router Class Initialized
INFO - 2022-01-03 10:07:57 --> Output Class Initialized
INFO - 2022-01-03 10:07:57 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:57 --> Input Class Initialized
INFO - 2022-01-03 10:07:57 --> Language Class Initialized
INFO - 2022-01-03 10:07:57 --> Loader Class Initialized
INFO - 2022-01-03 10:07:57 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:57 --> Controller Class Initialized
INFO - 2022-01-03 17:07:57 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:57 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:07:57 --> Config Class Initialized
INFO - 2022-01-03 10:07:57 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:07:57 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:07:57 --> Utf8 Class Initialized
INFO - 2022-01-03 10:07:57 --> URI Class Initialized
INFO - 2022-01-03 10:07:57 --> Router Class Initialized
INFO - 2022-01-03 10:07:57 --> Output Class Initialized
INFO - 2022-01-03 10:07:57 --> Security Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:07:57 --> Input Class Initialized
INFO - 2022-01-03 10:07:57 --> Language Class Initialized
INFO - 2022-01-03 10:07:57 --> Loader Class Initialized
INFO - 2022-01-03 10:07:57 --> Helper loaded: url_helper
INFO - 2022-01-03 10:07:57 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:07:57 --> Controller Class Initialized
INFO - 2022-01-03 17:07:57 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '2213485' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:07:57 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:08:30 --> Config Class Initialized
INFO - 2022-01-03 10:08:30 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:08:30 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:08:30 --> Utf8 Class Initialized
INFO - 2022-01-03 10:08:30 --> URI Class Initialized
INFO - 2022-01-03 10:08:30 --> Router Class Initialized
INFO - 2022-01-03 10:08:30 --> Output Class Initialized
INFO - 2022-01-03 10:08:30 --> Security Class Initialized
DEBUG - 2022-01-03 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:08:30 --> Input Class Initialized
INFO - 2022-01-03 10:08:30 --> Language Class Initialized
INFO - 2022-01-03 10:08:30 --> Loader Class Initialized
INFO - 2022-01-03 10:08:30 --> Helper loaded: url_helper
INFO - 2022-01-03 10:08:30 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:08:30 --> Controller Class Initialized
INFO - 2022-01-03 17:08:30 --> Model "LoginModel" initialized
INFO - 2022-01-03 10:08:30 --> Config Class Initialized
INFO - 2022-01-03 10:08:30 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:08:30 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:08:30 --> Utf8 Class Initialized
INFO - 2022-01-03 10:08:30 --> URI Class Initialized
INFO - 2022-01-03 10:08:30 --> Router Class Initialized
INFO - 2022-01-03 10:08:30 --> Output Class Initialized
INFO - 2022-01-03 10:08:30 --> Security Class Initialized
DEBUG - 2022-01-03 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:08:30 --> Input Class Initialized
INFO - 2022-01-03 10:08:30 --> Language Class Initialized
INFO - 2022-01-03 10:08:30 --> Loader Class Initialized
INFO - 2022-01-03 10:08:30 --> Helper loaded: url_helper
INFO - 2022-01-03 10:08:30 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:08:30 --> Controller Class Initialized
INFO - 2022-01-03 17:08:30 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:08:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:08:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:08:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:08:30 --> Final output sent to browser
DEBUG - 2022-01-03 17:08:30 --> Total execution time: 0.0455
INFO - 2022-01-03 10:09:05 --> Config Class Initialized
INFO - 2022-01-03 10:09:05 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:09:05 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:09:05 --> Utf8 Class Initialized
INFO - 2022-01-03 10:09:05 --> URI Class Initialized
INFO - 2022-01-03 10:09:05 --> Router Class Initialized
INFO - 2022-01-03 10:09:05 --> Output Class Initialized
INFO - 2022-01-03 10:09:05 --> Security Class Initialized
DEBUG - 2022-01-03 10:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:09:05 --> Input Class Initialized
INFO - 2022-01-03 10:09:05 --> Language Class Initialized
INFO - 2022-01-03 10:09:05 --> Loader Class Initialized
INFO - 2022-01-03 10:09:05 --> Helper loaded: url_helper
INFO - 2022-01-03 10:09:05 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:09:05 --> Controller Class Initialized
INFO - 2022-01-03 17:09:05 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:09:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:09:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:09:05 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:09:05 --> Final output sent to browser
DEBUG - 2022-01-03 17:09:05 --> Total execution time: 0.0489
INFO - 2022-01-03 10:09:14 --> Config Class Initialized
INFO - 2022-01-03 10:09:14 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:09:14 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:09:14 --> Utf8 Class Initialized
INFO - 2022-01-03 10:09:14 --> URI Class Initialized
INFO - 2022-01-03 10:09:14 --> Router Class Initialized
INFO - 2022-01-03 10:09:14 --> Output Class Initialized
INFO - 2022-01-03 10:09:14 --> Security Class Initialized
DEBUG - 2022-01-03 10:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:09:14 --> Input Class Initialized
INFO - 2022-01-03 10:09:14 --> Language Class Initialized
INFO - 2022-01-03 10:09:14 --> Loader Class Initialized
INFO - 2022-01-03 10:09:14 --> Helper loaded: url_helper
INFO - 2022-01-03 10:09:14 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:09:14 --> Controller Class Initialized
INFO - 2022-01-03 17:09:14 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:09:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '123123' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:09:14 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:10:13 --> Config Class Initialized
INFO - 2022-01-03 10:10:13 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:10:13 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:10:13 --> Utf8 Class Initialized
INFO - 2022-01-03 10:10:13 --> URI Class Initialized
INFO - 2022-01-03 10:10:13 --> Router Class Initialized
INFO - 2022-01-03 10:10:13 --> Output Class Initialized
INFO - 2022-01-03 10:10:13 --> Security Class Initialized
DEBUG - 2022-01-03 10:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:10:13 --> Input Class Initialized
INFO - 2022-01-03 10:10:13 --> Language Class Initialized
INFO - 2022-01-03 10:10:13 --> Loader Class Initialized
INFO - 2022-01-03 10:10:13 --> Helper loaded: url_helper
INFO - 2022-01-03 10:10:13 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:10:13 --> Controller Class Initialized
INFO - 2022-01-03 17:10:13 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:10:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '123123' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:10:13 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:18:27 --> Config Class Initialized
INFO - 2022-01-03 10:18:27 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:18:27 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:18:27 --> Utf8 Class Initialized
INFO - 2022-01-03 10:18:27 --> URI Class Initialized
INFO - 2022-01-03 10:18:27 --> Router Class Initialized
INFO - 2022-01-03 10:18:27 --> Output Class Initialized
INFO - 2022-01-03 10:18:27 --> Security Class Initialized
DEBUG - 2022-01-03 10:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:18:27 --> Input Class Initialized
INFO - 2022-01-03 10:18:27 --> Language Class Initialized
INFO - 2022-01-03 10:18:27 --> Loader Class Initialized
INFO - 2022-01-03 10:18:27 --> Helper loaded: url_helper
INFO - 2022-01-03 10:18:27 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:18:27 --> Controller Class Initialized
INFO - 2022-01-03 17:18:27 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:18:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:18:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:18:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:18:27 --> Final output sent to browser
DEBUG - 2022-01-03 17:18:27 --> Total execution time: 0.5323
INFO - 2022-01-03 10:18:28 --> Config Class Initialized
INFO - 2022-01-03 10:18:28 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:18:28 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:18:28 --> Utf8 Class Initialized
INFO - 2022-01-03 10:18:28 --> URI Class Initialized
INFO - 2022-01-03 10:18:28 --> Router Class Initialized
INFO - 2022-01-03 10:18:28 --> Output Class Initialized
INFO - 2022-01-03 10:18:28 --> Security Class Initialized
DEBUG - 2022-01-03 10:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:18:28 --> Input Class Initialized
INFO - 2022-01-03 10:18:28 --> Language Class Initialized
ERROR - 2022-01-03 10:18:28 --> 404 Page Not Found: Login/assets
INFO - 2022-01-03 10:18:28 --> Config Class Initialized
INFO - 2022-01-03 10:18:28 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:18:28 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:18:28 --> Utf8 Class Initialized
INFO - 2022-01-03 10:18:28 --> URI Class Initialized
INFO - 2022-01-03 10:18:28 --> Router Class Initialized
INFO - 2022-01-03 10:18:28 --> Output Class Initialized
INFO - 2022-01-03 10:18:28 --> Security Class Initialized
DEBUG - 2022-01-03 10:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:18:28 --> Input Class Initialized
INFO - 2022-01-03 10:18:28 --> Language Class Initialized
ERROR - 2022-01-03 10:18:28 --> 404 Page Not Found: Login/assets
INFO - 2022-01-03 10:18:31 --> Config Class Initialized
INFO - 2022-01-03 10:18:31 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:18:31 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:18:31 --> Utf8 Class Initialized
INFO - 2022-01-03 10:18:31 --> URI Class Initialized
INFO - 2022-01-03 10:18:31 --> Router Class Initialized
INFO - 2022-01-03 10:18:31 --> Output Class Initialized
INFO - 2022-01-03 10:18:31 --> Security Class Initialized
DEBUG - 2022-01-03 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:18:31 --> Input Class Initialized
INFO - 2022-01-03 10:18:31 --> Language Class Initialized
INFO - 2022-01-03 10:18:31 --> Loader Class Initialized
INFO - 2022-01-03 10:18:31 --> Helper loaded: url_helper
INFO - 2022-01-03 10:18:31 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:18:31 --> Controller Class Initialized
INFO - 2022-01-03 17:18:31 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:18:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:18:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:18:31 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:18:31 --> Final output sent to browser
DEBUG - 2022-01-03 17:18:31 --> Total execution time: 0.0856
INFO - 2022-01-03 10:18:49 --> Config Class Initialized
INFO - 2022-01-03 10:18:49 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:18:49 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:18:49 --> Utf8 Class Initialized
INFO - 2022-01-03 10:18:49 --> URI Class Initialized
INFO - 2022-01-03 10:18:49 --> Router Class Initialized
INFO - 2022-01-03 10:18:49 --> Output Class Initialized
INFO - 2022-01-03 10:18:49 --> Security Class Initialized
DEBUG - 2022-01-03 10:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:18:49 --> Input Class Initialized
INFO - 2022-01-03 10:18:49 --> Language Class Initialized
INFO - 2022-01-03 10:18:49 --> Loader Class Initialized
INFO - 2022-01-03 10:18:49 --> Helper loaded: url_helper
INFO - 2022-01-03 10:18:49 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:18:49 --> Controller Class Initialized
INFO - 2022-01-03 17:18:50 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:18:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '123123123123' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-03 17:18:50 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-03 10:19:00 --> Config Class Initialized
INFO - 2022-01-03 10:19:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:00 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:00 --> URI Class Initialized
DEBUG - 2022-01-03 10:19:00 --> No URI present. Default controller set.
INFO - 2022-01-03 10:19:00 --> Router Class Initialized
INFO - 2022-01-03 10:19:00 --> Output Class Initialized
INFO - 2022-01-03 10:19:00 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:00 --> Input Class Initialized
INFO - 2022-01-03 10:19:00 --> Language Class Initialized
INFO - 2022-01-03 10:19:00 --> Loader Class Initialized
INFO - 2022-01-03 10:19:00 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:00 --> Controller Class Initialized
INFO - 2022-01-03 17:19:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:00 --> Model "UserModel" initialized
INFO - 2022-01-03 17:19:00 --> Model "AdminModel" initialized
INFO - 2022-01-03 10:19:00 --> Config Class Initialized
INFO - 2022-01-03 10:19:00 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:00 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:00 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:00 --> URI Class Initialized
INFO - 2022-01-03 10:19:00 --> Router Class Initialized
INFO - 2022-01-03 10:19:00 --> Output Class Initialized
INFO - 2022-01-03 10:19:00 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:00 --> Input Class Initialized
INFO - 2022-01-03 10:19:00 --> Language Class Initialized
INFO - 2022-01-03 10:19:00 --> Loader Class Initialized
INFO - 2022-01-03 10:19:00 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:00 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:00 --> Controller Class Initialized
INFO - 2022-01-03 17:19:00 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:19:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:19:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:19:00 --> Final output sent to browser
DEBUG - 2022-01-03 17:19:00 --> Total execution time: 0.0618
INFO - 2022-01-03 10:19:08 --> Config Class Initialized
INFO - 2022-01-03 10:19:08 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:08 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:08 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:08 --> URI Class Initialized
INFO - 2022-01-03 10:19:08 --> Router Class Initialized
INFO - 2022-01-03 10:19:08 --> Output Class Initialized
INFO - 2022-01-03 10:19:08 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:08 --> Input Class Initialized
INFO - 2022-01-03 10:19:08 --> Language Class Initialized
INFO - 2022-01-03 10:19:08 --> Loader Class Initialized
INFO - 2022-01-03 10:19:08 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:08 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:08 --> Controller Class Initialized
INFO - 2022-01-03 17:19:08 --> Model "LoginModel" initialized
ERROR - 2022-01-03 17:19:08 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-03 10:19:09 --> Config Class Initialized
INFO - 2022-01-03 10:19:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:09 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:09 --> URI Class Initialized
DEBUG - 2022-01-03 10:19:09 --> No URI present. Default controller set.
INFO - 2022-01-03 10:19:09 --> Router Class Initialized
INFO - 2022-01-03 10:19:09 --> Output Class Initialized
INFO - 2022-01-03 10:19:09 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:09 --> Input Class Initialized
INFO - 2022-01-03 10:19:09 --> Language Class Initialized
INFO - 2022-01-03 10:19:09 --> Loader Class Initialized
INFO - 2022-01-03 10:19:09 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:09 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:09 --> Controller Class Initialized
INFO - 2022-01-03 17:19:09 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:09 --> Model "UserModel" initialized
INFO - 2022-01-03 17:19:09 --> Model "AdminModel" initialized
INFO - 2022-01-03 17:19:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 17:19:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 17:19:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:19:09 --> Final output sent to browser
DEBUG - 2022-01-03 17:19:09 --> Total execution time: 0.0645
INFO - 2022-01-03 10:19:09 --> Config Class Initialized
INFO - 2022-01-03 10:19:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:09 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:09 --> URI Class Initialized
INFO - 2022-01-03 10:19:09 --> Router Class Initialized
INFO - 2022-01-03 10:19:09 --> Output Class Initialized
INFO - 2022-01-03 10:19:09 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:09 --> Input Class Initialized
INFO - 2022-01-03 10:19:09 --> Language Class Initialized
ERROR - 2022-01-03 10:19:09 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 10:19:09 --> Config Class Initialized
INFO - 2022-01-03 10:19:09 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:09 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:09 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:09 --> URI Class Initialized
INFO - 2022-01-03 10:19:09 --> Router Class Initialized
INFO - 2022-01-03 10:19:09 --> Output Class Initialized
INFO - 2022-01-03 10:19:09 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:09 --> Input Class Initialized
INFO - 2022-01-03 10:19:09 --> Language Class Initialized
ERROR - 2022-01-03 10:19:09 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 10:19:12 --> Config Class Initialized
INFO - 2022-01-03 10:19:12 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:12 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:12 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:12 --> URI Class Initialized
INFO - 2022-01-03 10:19:12 --> Router Class Initialized
INFO - 2022-01-03 10:19:12 --> Output Class Initialized
INFO - 2022-01-03 10:19:12 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:12 --> Input Class Initialized
INFO - 2022-01-03 10:19:12 --> Language Class Initialized
INFO - 2022-01-03 10:19:12 --> Loader Class Initialized
INFO - 2022-01-03 10:19:12 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:12 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:12 --> Controller Class Initialized
INFO - 2022-01-03 17:19:12 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:12 --> Model "UserModel" initialized
INFO - 2022-01-03 17:19:12 --> Model "AdminModel" initialized
INFO - 2022-01-03 17:19:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 17:19:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-03 17:19:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:19:12 --> Final output sent to browser
DEBUG - 2022-01-03 17:19:12 --> Total execution time: 0.0850
INFO - 2022-01-03 10:19:12 --> Config Class Initialized
INFO - 2022-01-03 10:19:12 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:12 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:12 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:12 --> URI Class Initialized
INFO - 2022-01-03 10:19:12 --> Router Class Initialized
INFO - 2022-01-03 10:19:12 --> Output Class Initialized
INFO - 2022-01-03 10:19:12 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:12 --> Input Class Initialized
INFO - 2022-01-03 10:19:12 --> Language Class Initialized
ERROR - 2022-01-03 10:19:12 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 10:19:14 --> Config Class Initialized
INFO - 2022-01-03 10:19:14 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:14 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:14 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:14 --> URI Class Initialized
INFO - 2022-01-03 10:19:14 --> Router Class Initialized
INFO - 2022-01-03 10:19:14 --> Output Class Initialized
INFO - 2022-01-03 10:19:14 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:14 --> Input Class Initialized
INFO - 2022-01-03 10:19:14 --> Language Class Initialized
INFO - 2022-01-03 10:19:14 --> Loader Class Initialized
INFO - 2022-01-03 10:19:14 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:14 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:14 --> Controller Class Initialized
INFO - 2022-01-03 17:19:14 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:14 --> Model "UserModel" initialized
INFO - 2022-01-03 17:19:14 --> Model "AdminModel" initialized
INFO - 2022-01-03 17:19:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 17:19:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-03 17:19:14 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:19:14 --> Final output sent to browser
DEBUG - 2022-01-03 17:19:14 --> Total execution time: 0.0671
INFO - 2022-01-03 10:19:14 --> Config Class Initialized
INFO - 2022-01-03 10:19:14 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:14 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:14 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:14 --> URI Class Initialized
INFO - 2022-01-03 10:19:14 --> Router Class Initialized
INFO - 2022-01-03 10:19:14 --> Output Class Initialized
INFO - 2022-01-03 10:19:14 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:14 --> Input Class Initialized
INFO - 2022-01-03 10:19:14 --> Language Class Initialized
ERROR - 2022-01-03 10:19:14 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 10:19:16 --> Config Class Initialized
INFO - 2022-01-03 10:19:16 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:16 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:16 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:16 --> URI Class Initialized
DEBUG - 2022-01-03 10:19:16 --> No URI present. Default controller set.
INFO - 2022-01-03 10:19:16 --> Router Class Initialized
INFO - 2022-01-03 10:19:16 --> Output Class Initialized
INFO - 2022-01-03 10:19:16 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:16 --> Input Class Initialized
INFO - 2022-01-03 10:19:16 --> Language Class Initialized
INFO - 2022-01-03 10:19:16 --> Loader Class Initialized
INFO - 2022-01-03 10:19:16 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:16 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:16 --> Controller Class Initialized
INFO - 2022-01-03 17:19:16 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:16 --> Model "UserModel" initialized
INFO - 2022-01-03 17:19:16 --> Model "AdminModel" initialized
INFO - 2022-01-03 17:19:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-03 17:19:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-03 17:19:16 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:19:16 --> Final output sent to browser
DEBUG - 2022-01-03 17:19:16 --> Total execution time: 0.0796
INFO - 2022-01-03 10:19:17 --> Config Class Initialized
INFO - 2022-01-03 10:19:17 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:17 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:17 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:17 --> URI Class Initialized
INFO - 2022-01-03 10:19:17 --> Router Class Initialized
INFO - 2022-01-03 10:19:17 --> Output Class Initialized
INFO - 2022-01-03 10:19:17 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:17 --> Input Class Initialized
INFO - 2022-01-03 10:19:17 --> Language Class Initialized
ERROR - 2022-01-03 10:19:17 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-03 10:19:21 --> Config Class Initialized
INFO - 2022-01-03 10:19:21 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:21 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:21 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:21 --> URI Class Initialized
INFO - 2022-01-03 10:19:21 --> Router Class Initialized
INFO - 2022-01-03 10:19:21 --> Output Class Initialized
INFO - 2022-01-03 10:19:21 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:21 --> Input Class Initialized
INFO - 2022-01-03 10:19:21 --> Language Class Initialized
INFO - 2022-01-03 10:19:21 --> Loader Class Initialized
INFO - 2022-01-03 10:19:21 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:21 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:21 --> Controller Class Initialized
INFO - 2022-01-03 17:19:21 --> Model "LoginModel" initialized
INFO - 2022-01-03 10:19:21 --> Config Class Initialized
INFO - 2022-01-03 10:19:21 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:21 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:21 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:21 --> URI Class Initialized
INFO - 2022-01-03 10:19:21 --> Router Class Initialized
INFO - 2022-01-03 10:19:21 --> Output Class Initialized
INFO - 2022-01-03 10:19:21 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:21 --> Input Class Initialized
INFO - 2022-01-03 10:19:21 --> Language Class Initialized
INFO - 2022-01-03 10:19:21 --> Loader Class Initialized
INFO - 2022-01-03 10:19:21 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:21 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:21 --> Controller Class Initialized
INFO - 2022-01-03 17:19:21 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:19:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:19:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:19:21 --> Final output sent to browser
DEBUG - 2022-01-03 17:19:21 --> Total execution time: 0.0730
INFO - 2022-01-03 10:19:24 --> Config Class Initialized
INFO - 2022-01-03 10:19:24 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:24 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:24 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:24 --> URI Class Initialized
INFO - 2022-01-03 10:19:24 --> Router Class Initialized
INFO - 2022-01-03 10:19:24 --> Output Class Initialized
INFO - 2022-01-03 10:19:24 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:24 --> Input Class Initialized
INFO - 2022-01-03 10:19:24 --> Language Class Initialized
INFO - 2022-01-03 10:19:24 --> Loader Class Initialized
INFO - 2022-01-03 10:19:24 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:24 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:24 --> Controller Class Initialized
INFO - 2022-01-03 17:19:24 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:24 --> Model "UserModel" initialized
INFO - 2022-01-03 17:19:24 --> Model "AdminModel" initialized
INFO - 2022-01-03 10:19:24 --> Config Class Initialized
INFO - 2022-01-03 10:19:24 --> Hooks Class Initialized
DEBUG - 2022-01-03 10:19:24 --> UTF-8 Support Enabled
INFO - 2022-01-03 10:19:24 --> Utf8 Class Initialized
INFO - 2022-01-03 10:19:24 --> URI Class Initialized
INFO - 2022-01-03 10:19:24 --> Router Class Initialized
INFO - 2022-01-03 10:19:24 --> Output Class Initialized
INFO - 2022-01-03 10:19:24 --> Security Class Initialized
DEBUG - 2022-01-03 10:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-03 10:19:24 --> Input Class Initialized
INFO - 2022-01-03 10:19:24 --> Language Class Initialized
INFO - 2022-01-03 10:19:24 --> Loader Class Initialized
INFO - 2022-01-03 10:19:24 --> Helper loaded: url_helper
INFO - 2022-01-03 10:19:24 --> Database Driver Class Initialized
DEBUG - 2022-01-03 10:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-03 10:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-03 10:19:24 --> Controller Class Initialized
INFO - 2022-01-03 17:19:24 --> Model "LoginModel" initialized
INFO - 2022-01-03 17:19:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-03 17:19:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-03 17:19:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-03 17:19:24 --> Final output sent to browser
DEBUG - 2022-01-03 17:19:24 --> Total execution time: 0.0750
