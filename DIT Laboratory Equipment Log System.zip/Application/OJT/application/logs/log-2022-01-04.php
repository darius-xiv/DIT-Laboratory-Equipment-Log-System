<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-01-04 01:10:49 --> Config Class Initialized
INFO - 2022-01-04 01:10:49 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:10:49 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:10:49 --> Utf8 Class Initialized
INFO - 2022-01-04 01:10:49 --> URI Class Initialized
INFO - 2022-01-04 01:10:49 --> Router Class Initialized
INFO - 2022-01-04 01:10:49 --> Output Class Initialized
INFO - 2022-01-04 01:10:49 --> Security Class Initialized
DEBUG - 2022-01-04 01:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:10:49 --> Input Class Initialized
INFO - 2022-01-04 01:10:49 --> Language Class Initialized
INFO - 2022-01-04 01:10:49 --> Loader Class Initialized
INFO - 2022-01-04 01:10:49 --> Helper loaded: url_helper
INFO - 2022-01-04 01:10:50 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:10:50 --> Controller Class Initialized
INFO - 2022-01-04 08:10:50 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:10:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 08:10:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 08:10:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:10:50 --> Final output sent to browser
DEBUG - 2022-01-04 08:10:50 --> Total execution time: 0.6734
INFO - 2022-01-04 01:23:47 --> Config Class Initialized
INFO - 2022-01-04 01:23:47 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:23:47 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:23:47 --> Utf8 Class Initialized
INFO - 2022-01-04 01:23:47 --> URI Class Initialized
INFO - 2022-01-04 01:23:47 --> Router Class Initialized
INFO - 2022-01-04 01:23:47 --> Output Class Initialized
INFO - 2022-01-04 01:23:47 --> Security Class Initialized
DEBUG - 2022-01-04 01:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:23:47 --> Input Class Initialized
INFO - 2022-01-04 01:23:47 --> Language Class Initialized
INFO - 2022-01-04 01:23:47 --> Loader Class Initialized
INFO - 2022-01-04 01:23:47 --> Helper loaded: url_helper
INFO - 2022-01-04 01:23:47 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:23:47 --> Controller Class Initialized
INFO - 2022-01-04 08:23:47 --> Model "LoginModel" initialized
ERROR - 2022-01-04 08:23:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '')
 LIMIT 1' at line 3 - Invalid query: SELECT `student_id`
FROM `users`
WHERE (`student_id` = '22222' AND `is_active` = 1')
 LIMIT 1
INFO - 2022-01-04 08:23:47 --> Language file loaded: language/english/db_lang.php
INFO - 2022-01-04 01:24:56 --> Config Class Initialized
INFO - 2022-01-04 01:24:56 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:24:56 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:24:56 --> Utf8 Class Initialized
INFO - 2022-01-04 01:24:56 --> URI Class Initialized
INFO - 2022-01-04 01:24:56 --> Router Class Initialized
INFO - 2022-01-04 01:24:56 --> Output Class Initialized
INFO - 2022-01-04 01:24:56 --> Security Class Initialized
DEBUG - 2022-01-04 01:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:24:56 --> Input Class Initialized
INFO - 2022-01-04 01:24:56 --> Language Class Initialized
INFO - 2022-01-04 01:24:56 --> Loader Class Initialized
INFO - 2022-01-04 01:24:56 --> Helper loaded: url_helper
INFO - 2022-01-04 01:24:56 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:24:56 --> Controller Class Initialized
INFO - 2022-01-04 08:24:56 --> Model "LoginModel" initialized
INFO - 2022-01-04 01:24:56 --> Config Class Initialized
INFO - 2022-01-04 01:24:56 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:24:56 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:24:56 --> Utf8 Class Initialized
INFO - 2022-01-04 01:24:56 --> URI Class Initialized
INFO - 2022-01-04 01:24:56 --> Router Class Initialized
INFO - 2022-01-04 01:24:56 --> Output Class Initialized
INFO - 2022-01-04 01:24:56 --> Security Class Initialized
DEBUG - 2022-01-04 01:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:24:56 --> Input Class Initialized
INFO - 2022-01-04 01:24:56 --> Language Class Initialized
INFO - 2022-01-04 01:24:56 --> Loader Class Initialized
INFO - 2022-01-04 01:24:56 --> Helper loaded: url_helper
INFO - 2022-01-04 01:24:56 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:24:56 --> Controller Class Initialized
INFO - 2022-01-04 08:24:56 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:24:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 08:24:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 08:24:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:24:56 --> Final output sent to browser
DEBUG - 2022-01-04 08:24:56 --> Total execution time: 0.0543
INFO - 2022-01-04 01:25:06 --> Config Class Initialized
INFO - 2022-01-04 01:25:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:25:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:25:06 --> Utf8 Class Initialized
INFO - 2022-01-04 01:25:06 --> URI Class Initialized
DEBUG - 2022-01-04 01:25:06 --> No URI present. Default controller set.
INFO - 2022-01-04 01:25:06 --> Router Class Initialized
INFO - 2022-01-04 01:25:06 --> Output Class Initialized
INFO - 2022-01-04 01:25:06 --> Security Class Initialized
DEBUG - 2022-01-04 01:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:25:06 --> Input Class Initialized
INFO - 2022-01-04 01:25:06 --> Language Class Initialized
INFO - 2022-01-04 01:25:06 --> Loader Class Initialized
INFO - 2022-01-04 01:25:06 --> Helper loaded: url_helper
INFO - 2022-01-04 01:25:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:25:06 --> Controller Class Initialized
INFO - 2022-01-04 08:25:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:25:06 --> Model "UserModel" initialized
INFO - 2022-01-04 08:25:06 --> Model "AdminModel" initialized
INFO - 2022-01-04 01:25:06 --> Config Class Initialized
INFO - 2022-01-04 01:25:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:25:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:25:06 --> Utf8 Class Initialized
INFO - 2022-01-04 01:25:06 --> URI Class Initialized
INFO - 2022-01-04 01:25:06 --> Router Class Initialized
INFO - 2022-01-04 01:25:06 --> Output Class Initialized
INFO - 2022-01-04 01:25:06 --> Security Class Initialized
DEBUG - 2022-01-04 01:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:25:06 --> Input Class Initialized
INFO - 2022-01-04 01:25:06 --> Language Class Initialized
INFO - 2022-01-04 01:25:06 --> Loader Class Initialized
INFO - 2022-01-04 01:25:06 --> Helper loaded: url_helper
INFO - 2022-01-04 01:25:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:25:06 --> Controller Class Initialized
INFO - 2022-01-04 08:25:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:25:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 08:25:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 08:25:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:25:06 --> Final output sent to browser
DEBUG - 2022-01-04 08:25:06 --> Total execution time: 0.0703
INFO - 2022-01-04 01:25:25 --> Config Class Initialized
INFO - 2022-01-04 01:25:25 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:25:25 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:25:25 --> Utf8 Class Initialized
INFO - 2022-01-04 01:25:25 --> URI Class Initialized
INFO - 2022-01-04 01:25:25 --> Router Class Initialized
INFO - 2022-01-04 01:25:25 --> Output Class Initialized
INFO - 2022-01-04 01:25:25 --> Security Class Initialized
DEBUG - 2022-01-04 01:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:25:25 --> Input Class Initialized
INFO - 2022-01-04 01:25:25 --> Language Class Initialized
INFO - 2022-01-04 01:25:25 --> Loader Class Initialized
INFO - 2022-01-04 01:25:25 --> Helper loaded: url_helper
INFO - 2022-01-04 01:25:25 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:25:25 --> Controller Class Initialized
INFO - 2022-01-04 08:25:25 --> Model "LoginModel" initialized
INFO - 2022-01-04 01:25:25 --> Config Class Initialized
INFO - 2022-01-04 01:25:25 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:25:25 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:25:25 --> Utf8 Class Initialized
INFO - 2022-01-04 01:25:25 --> URI Class Initialized
INFO - 2022-01-04 01:25:25 --> Router Class Initialized
INFO - 2022-01-04 01:25:25 --> Output Class Initialized
INFO - 2022-01-04 01:25:25 --> Security Class Initialized
DEBUG - 2022-01-04 01:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:25:25 --> Input Class Initialized
INFO - 2022-01-04 01:25:25 --> Language Class Initialized
INFO - 2022-01-04 01:25:25 --> Loader Class Initialized
INFO - 2022-01-04 01:25:25 --> Helper loaded: url_helper
INFO - 2022-01-04 01:25:25 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:25:25 --> Controller Class Initialized
INFO - 2022-01-04 08:25:25 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:25:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 08:25:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 08:25:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:25:25 --> Final output sent to browser
DEBUG - 2022-01-04 08:25:25 --> Total execution time: 0.0713
INFO - 2022-01-04 01:27:23 --> Config Class Initialized
INFO - 2022-01-04 01:27:23 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:27:23 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:27:23 --> Utf8 Class Initialized
INFO - 2022-01-04 01:27:23 --> URI Class Initialized
INFO - 2022-01-04 01:27:23 --> Router Class Initialized
INFO - 2022-01-04 01:27:23 --> Output Class Initialized
INFO - 2022-01-04 01:27:23 --> Security Class Initialized
DEBUG - 2022-01-04 01:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:27:23 --> Input Class Initialized
INFO - 2022-01-04 01:27:23 --> Language Class Initialized
INFO - 2022-01-04 01:27:23 --> Loader Class Initialized
INFO - 2022-01-04 01:27:23 --> Helper loaded: url_helper
INFO - 2022-01-04 01:27:23 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:27:23 --> Controller Class Initialized
INFO - 2022-01-04 08:27:23 --> Model "LoginModel" initialized
INFO - 2022-01-04 01:27:23 --> Config Class Initialized
INFO - 2022-01-04 01:27:23 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:27:23 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:27:23 --> Utf8 Class Initialized
INFO - 2022-01-04 01:27:23 --> URI Class Initialized
INFO - 2022-01-04 01:27:23 --> Router Class Initialized
INFO - 2022-01-04 01:27:23 --> Output Class Initialized
INFO - 2022-01-04 01:27:23 --> Security Class Initialized
DEBUG - 2022-01-04 01:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:27:23 --> Input Class Initialized
INFO - 2022-01-04 01:27:23 --> Language Class Initialized
INFO - 2022-01-04 01:27:23 --> Loader Class Initialized
INFO - 2022-01-04 01:27:23 --> Helper loaded: url_helper
INFO - 2022-01-04 01:27:23 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:27:23 --> Controller Class Initialized
INFO - 2022-01-04 08:27:23 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:27:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 08:27:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 08:27:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:27:23 --> Final output sent to browser
DEBUG - 2022-01-04 08:27:23 --> Total execution time: 0.0586
INFO - 2022-01-04 01:28:02 --> Config Class Initialized
INFO - 2022-01-04 01:28:02 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:28:02 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:28:02 --> Utf8 Class Initialized
INFO - 2022-01-04 01:28:02 --> URI Class Initialized
INFO - 2022-01-04 01:28:02 --> Router Class Initialized
INFO - 2022-01-04 01:28:02 --> Output Class Initialized
INFO - 2022-01-04 01:28:02 --> Security Class Initialized
DEBUG - 2022-01-04 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:28:02 --> Input Class Initialized
INFO - 2022-01-04 01:28:02 --> Language Class Initialized
INFO - 2022-01-04 01:28:02 --> Loader Class Initialized
INFO - 2022-01-04 01:28:02 --> Helper loaded: url_helper
INFO - 2022-01-04 01:28:02 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:28:02 --> Controller Class Initialized
INFO - 2022-01-04 08:28:02 --> Model "LoginModel" initialized
ERROR - 2022-01-04 08:28:02 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-04 01:28:02 --> Config Class Initialized
INFO - 2022-01-04 01:28:02 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:28:02 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:28:02 --> Utf8 Class Initialized
INFO - 2022-01-04 01:28:02 --> URI Class Initialized
DEBUG - 2022-01-04 01:28:02 --> No URI present. Default controller set.
INFO - 2022-01-04 01:28:02 --> Router Class Initialized
INFO - 2022-01-04 01:28:02 --> Output Class Initialized
INFO - 2022-01-04 01:28:02 --> Security Class Initialized
DEBUG - 2022-01-04 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:28:02 --> Input Class Initialized
INFO - 2022-01-04 01:28:02 --> Language Class Initialized
INFO - 2022-01-04 01:28:02 --> Loader Class Initialized
INFO - 2022-01-04 01:28:02 --> Helper loaded: url_helper
INFO - 2022-01-04 01:28:02 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:28:02 --> Controller Class Initialized
INFO - 2022-01-04 08:28:02 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:28:02 --> Model "UserModel" initialized
INFO - 2022-01-04 08:28:02 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:28:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:28:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 08:28:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:28:02 --> Final output sent to browser
DEBUG - 2022-01-04 08:28:02 --> Total execution time: 0.1127
INFO - 2022-01-04 01:28:02 --> Config Class Initialized
INFO - 2022-01-04 01:28:02 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:28:02 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:28:02 --> Utf8 Class Initialized
INFO - 2022-01-04 01:28:02 --> URI Class Initialized
INFO - 2022-01-04 01:28:02 --> Router Class Initialized
INFO - 2022-01-04 01:28:02 --> Output Class Initialized
INFO - 2022-01-04 01:28:02 --> Security Class Initialized
DEBUG - 2022-01-04 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:28:02 --> Input Class Initialized
INFO - 2022-01-04 01:28:02 --> Language Class Initialized
ERROR - 2022-01-04 01:28:02 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:28:03 --> Config Class Initialized
INFO - 2022-01-04 01:28:03 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:28:03 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:28:03 --> Utf8 Class Initialized
INFO - 2022-01-04 01:28:03 --> URI Class Initialized
INFO - 2022-01-04 01:28:03 --> Router Class Initialized
INFO - 2022-01-04 01:28:03 --> Output Class Initialized
INFO - 2022-01-04 01:28:03 --> Security Class Initialized
DEBUG - 2022-01-04 01:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:28:03 --> Input Class Initialized
INFO - 2022-01-04 01:28:03 --> Language Class Initialized
ERROR - 2022-01-04 01:28:03 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:29:28 --> Config Class Initialized
INFO - 2022-01-04 01:29:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:29:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:29:28 --> Utf8 Class Initialized
INFO - 2022-01-04 01:29:28 --> URI Class Initialized
INFO - 2022-01-04 01:29:28 --> Router Class Initialized
INFO - 2022-01-04 01:29:28 --> Output Class Initialized
INFO - 2022-01-04 01:29:28 --> Security Class Initialized
DEBUG - 2022-01-04 01:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:29:28 --> Input Class Initialized
INFO - 2022-01-04 01:29:28 --> Language Class Initialized
INFO - 2022-01-04 01:29:28 --> Loader Class Initialized
INFO - 2022-01-04 01:29:28 --> Helper loaded: url_helper
INFO - 2022-01-04 01:29:28 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:29:28 --> Controller Class Initialized
INFO - 2022-01-04 08:29:28 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:29:28 --> Model "UserModel" initialized
INFO - 2022-01-04 08:29:28 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:29:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:29:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-04 08:29:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:29:28 --> Final output sent to browser
DEBUG - 2022-01-04 08:29:28 --> Total execution time: 0.1246
INFO - 2022-01-04 01:29:28 --> Config Class Initialized
INFO - 2022-01-04 01:29:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:29:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:29:28 --> Utf8 Class Initialized
INFO - 2022-01-04 01:29:28 --> URI Class Initialized
INFO - 2022-01-04 01:29:28 --> Router Class Initialized
INFO - 2022-01-04 01:29:28 --> Output Class Initialized
INFO - 2022-01-04 01:29:28 --> Security Class Initialized
DEBUG - 2022-01-04 01:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:29:28 --> Input Class Initialized
INFO - 2022-01-04 01:29:28 --> Language Class Initialized
ERROR - 2022-01-04 01:29:28 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:29:28 --> Config Class Initialized
INFO - 2022-01-04 01:29:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:29:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:29:28 --> Utf8 Class Initialized
INFO - 2022-01-04 01:29:28 --> URI Class Initialized
INFO - 2022-01-04 01:29:28 --> Router Class Initialized
INFO - 2022-01-04 01:29:28 --> Output Class Initialized
INFO - 2022-01-04 01:29:28 --> Security Class Initialized
DEBUG - 2022-01-04 01:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:29:28 --> Input Class Initialized
INFO - 2022-01-04 01:29:28 --> Language Class Initialized
ERROR - 2022-01-04 01:29:28 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:29:32 --> Config Class Initialized
INFO - 2022-01-04 01:29:32 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:29:32 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:29:32 --> Utf8 Class Initialized
INFO - 2022-01-04 01:29:32 --> URI Class Initialized
INFO - 2022-01-04 01:29:32 --> Router Class Initialized
INFO - 2022-01-04 01:29:32 --> Output Class Initialized
INFO - 2022-01-04 01:29:32 --> Security Class Initialized
DEBUG - 2022-01-04 01:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:29:32 --> Input Class Initialized
INFO - 2022-01-04 01:29:32 --> Language Class Initialized
INFO - 2022-01-04 01:29:32 --> Loader Class Initialized
INFO - 2022-01-04 01:29:32 --> Helper loaded: url_helper
INFO - 2022-01-04 01:29:32 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:29:32 --> Controller Class Initialized
INFO - 2022-01-04 08:29:32 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:29:32 --> Model "UserModel" initialized
INFO - 2022-01-04 08:29:32 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:29:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:29:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-04 08:29:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:29:32 --> Final output sent to browser
DEBUG - 2022-01-04 08:29:32 --> Total execution time: 0.0931
INFO - 2022-01-04 01:29:32 --> Config Class Initialized
INFO - 2022-01-04 01:29:32 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:29:32 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:29:32 --> Utf8 Class Initialized
INFO - 2022-01-04 01:29:32 --> URI Class Initialized
INFO - 2022-01-04 01:29:32 --> Router Class Initialized
INFO - 2022-01-04 01:29:32 --> Output Class Initialized
INFO - 2022-01-04 01:29:32 --> Security Class Initialized
DEBUG - 2022-01-04 01:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:29:32 --> Input Class Initialized
INFO - 2022-01-04 01:29:32 --> Language Class Initialized
ERROR - 2022-01-04 01:29:32 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:29:32 --> Config Class Initialized
INFO - 2022-01-04 01:29:32 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:29:32 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:29:32 --> Utf8 Class Initialized
INFO - 2022-01-04 01:29:32 --> URI Class Initialized
INFO - 2022-01-04 01:29:32 --> Router Class Initialized
INFO - 2022-01-04 01:29:32 --> Output Class Initialized
INFO - 2022-01-04 01:29:32 --> Security Class Initialized
DEBUG - 2022-01-04 01:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:29:32 --> Input Class Initialized
INFO - 2022-01-04 01:29:32 --> Language Class Initialized
ERROR - 2022-01-04 01:29:32 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:29:55 --> Config Class Initialized
INFO - 2022-01-04 01:29:55 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:29:55 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:29:55 --> Utf8 Class Initialized
INFO - 2022-01-04 01:29:55 --> URI Class Initialized
DEBUG - 2022-01-04 01:29:55 --> No URI present. Default controller set.
INFO - 2022-01-04 01:29:55 --> Router Class Initialized
INFO - 2022-01-04 01:29:55 --> Output Class Initialized
INFO - 2022-01-04 01:29:55 --> Security Class Initialized
DEBUG - 2022-01-04 01:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:29:55 --> Input Class Initialized
INFO - 2022-01-04 01:29:55 --> Language Class Initialized
INFO - 2022-01-04 01:29:55 --> Loader Class Initialized
INFO - 2022-01-04 01:29:55 --> Helper loaded: url_helper
INFO - 2022-01-04 01:29:55 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:30:03 --> Controller Class Initialized
INFO - 2022-01-04 08:30:03 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:30:03 --> Model "UserModel" initialized
INFO - 2022-01-04 08:30:03 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:30:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:30:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 08:30:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:30:03 --> Final output sent to browser
DEBUG - 2022-01-04 08:30:03 --> Total execution time: 8.0227
INFO - 2022-01-04 01:30:03 --> Config Class Initialized
INFO - 2022-01-04 01:30:03 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:30:03 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:30:03 --> Utf8 Class Initialized
INFO - 2022-01-04 01:30:03 --> URI Class Initialized
INFO - 2022-01-04 01:30:03 --> Router Class Initialized
INFO - 2022-01-04 01:30:03 --> Output Class Initialized
INFO - 2022-01-04 01:30:03 --> Security Class Initialized
DEBUG - 2022-01-04 01:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:30:03 --> Input Class Initialized
INFO - 2022-01-04 01:30:03 --> Language Class Initialized
ERROR - 2022-01-04 01:30:03 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:30:03 --> Config Class Initialized
INFO - 2022-01-04 01:30:03 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:30:03 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:30:03 --> Utf8 Class Initialized
INFO - 2022-01-04 01:30:03 --> URI Class Initialized
INFO - 2022-01-04 01:30:03 --> Router Class Initialized
INFO - 2022-01-04 01:30:03 --> Output Class Initialized
INFO - 2022-01-04 01:30:03 --> Security Class Initialized
DEBUG - 2022-01-04 01:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:30:03 --> Input Class Initialized
INFO - 2022-01-04 01:30:03 --> Language Class Initialized
ERROR - 2022-01-04 01:30:03 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:31:30 --> Config Class Initialized
INFO - 2022-01-04 01:31:30 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:31:30 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:31:30 --> Utf8 Class Initialized
INFO - 2022-01-04 01:31:30 --> URI Class Initialized
INFO - 2022-01-04 01:31:30 --> Router Class Initialized
INFO - 2022-01-04 01:31:30 --> Output Class Initialized
INFO - 2022-01-04 01:31:30 --> Security Class Initialized
DEBUG - 2022-01-04 01:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:31:30 --> Input Class Initialized
INFO - 2022-01-04 01:31:30 --> Language Class Initialized
INFO - 2022-01-04 01:31:30 --> Loader Class Initialized
INFO - 2022-01-04 01:31:30 --> Helper loaded: url_helper
INFO - 2022-01-04 01:31:30 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:31:30 --> Controller Class Initialized
INFO - 2022-01-04 08:31:30 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:31:30 --> Model "UserModel" initialized
INFO - 2022-01-04 08:31:30 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:31:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:31:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/about.php
INFO - 2022-01-04 08:31:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:31:30 --> Final output sent to browser
DEBUG - 2022-01-04 08:31:30 --> Total execution time: 0.1104
INFO - 2022-01-04 01:31:30 --> Config Class Initialized
INFO - 2022-01-04 01:31:30 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:31:30 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:31:30 --> Utf8 Class Initialized
INFO - 2022-01-04 01:31:30 --> URI Class Initialized
INFO - 2022-01-04 01:31:30 --> Router Class Initialized
INFO - 2022-01-04 01:31:30 --> Output Class Initialized
INFO - 2022-01-04 01:31:30 --> Security Class Initialized
DEBUG - 2022-01-04 01:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:31:30 --> Input Class Initialized
INFO - 2022-01-04 01:31:30 --> Language Class Initialized
ERROR - 2022-01-04 01:31:30 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:31:30 --> Config Class Initialized
INFO - 2022-01-04 01:31:30 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:31:30 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:31:30 --> Utf8 Class Initialized
INFO - 2022-01-04 01:31:30 --> URI Class Initialized
INFO - 2022-01-04 01:31:30 --> Router Class Initialized
INFO - 2022-01-04 01:31:30 --> Output Class Initialized
INFO - 2022-01-04 01:31:30 --> Security Class Initialized
DEBUG - 2022-01-04 01:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:31:30 --> Input Class Initialized
INFO - 2022-01-04 01:31:30 --> Language Class Initialized
ERROR - 2022-01-04 01:31:30 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:31:32 --> Config Class Initialized
INFO - 2022-01-04 01:31:32 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:31:32 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:31:32 --> Utf8 Class Initialized
INFO - 2022-01-04 01:31:32 --> URI Class Initialized
INFO - 2022-01-04 01:31:32 --> Router Class Initialized
INFO - 2022-01-04 01:31:32 --> Output Class Initialized
INFO - 2022-01-04 01:31:32 --> Security Class Initialized
DEBUG - 2022-01-04 01:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:31:32 --> Input Class Initialized
INFO - 2022-01-04 01:31:32 --> Language Class Initialized
INFO - 2022-01-04 01:31:32 --> Loader Class Initialized
INFO - 2022-01-04 01:31:32 --> Helper loaded: url_helper
INFO - 2022-01-04 01:31:32 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:31:32 --> Controller Class Initialized
INFO - 2022-01-04 08:31:32 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:31:32 --> Model "UserModel" initialized
INFO - 2022-01-04 08:31:32 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:31:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:31:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-04 08:31:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:31:32 --> Final output sent to browser
DEBUG - 2022-01-04 08:31:32 --> Total execution time: 0.0766
INFO - 2022-01-04 01:31:32 --> Config Class Initialized
INFO - 2022-01-04 01:31:32 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:31:32 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:31:32 --> Utf8 Class Initialized
INFO - 2022-01-04 01:31:32 --> URI Class Initialized
INFO - 2022-01-04 01:31:32 --> Router Class Initialized
INFO - 2022-01-04 01:31:32 --> Output Class Initialized
INFO - 2022-01-04 01:31:32 --> Security Class Initialized
DEBUG - 2022-01-04 01:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:31:32 --> Input Class Initialized
INFO - 2022-01-04 01:31:32 --> Language Class Initialized
ERROR - 2022-01-04 01:31:32 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:31:56 --> Config Class Initialized
INFO - 2022-01-04 01:31:56 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:31:56 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:31:56 --> Utf8 Class Initialized
INFO - 2022-01-04 01:31:56 --> URI Class Initialized
DEBUG - 2022-01-04 01:31:56 --> No URI present. Default controller set.
INFO - 2022-01-04 01:31:56 --> Router Class Initialized
INFO - 2022-01-04 01:31:56 --> Output Class Initialized
INFO - 2022-01-04 01:31:56 --> Security Class Initialized
DEBUG - 2022-01-04 01:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:31:56 --> Input Class Initialized
INFO - 2022-01-04 01:31:56 --> Language Class Initialized
INFO - 2022-01-04 01:31:56 --> Loader Class Initialized
INFO - 2022-01-04 01:31:56 --> Helper loaded: url_helper
INFO - 2022-01-04 01:31:56 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:31:56 --> Controller Class Initialized
INFO - 2022-01-04 08:31:56 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:31:56 --> Model "UserModel" initialized
INFO - 2022-01-04 08:31:56 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:31:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:31:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 08:31:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:31:56 --> Final output sent to browser
DEBUG - 2022-01-04 08:31:56 --> Total execution time: 0.0765
INFO - 2022-01-04 01:31:56 --> Config Class Initialized
INFO - 2022-01-04 01:31:56 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:31:56 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:31:56 --> Utf8 Class Initialized
INFO - 2022-01-04 01:31:56 --> URI Class Initialized
INFO - 2022-01-04 01:31:56 --> Router Class Initialized
INFO - 2022-01-04 01:31:56 --> Output Class Initialized
INFO - 2022-01-04 01:31:56 --> Security Class Initialized
DEBUG - 2022-01-04 01:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:31:56 --> Input Class Initialized
INFO - 2022-01-04 01:31:56 --> Language Class Initialized
ERROR - 2022-01-04 01:31:56 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:32:03 --> Config Class Initialized
INFO - 2022-01-04 01:32:03 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:03 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:03 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:03 --> URI Class Initialized
INFO - 2022-01-04 01:32:03 --> Router Class Initialized
INFO - 2022-01-04 01:32:03 --> Output Class Initialized
INFO - 2022-01-04 01:32:03 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:03 --> Input Class Initialized
INFO - 2022-01-04 01:32:03 --> Language Class Initialized
INFO - 2022-01-04 01:32:03 --> Loader Class Initialized
INFO - 2022-01-04 01:32:03 --> Helper loaded: url_helper
INFO - 2022-01-04 01:32:03 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:32:03 --> Controller Class Initialized
INFO - 2022-01-04 08:32:03 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:32:03 --> Model "UserModel" initialized
INFO - 2022-01-04 08:32:03 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:32:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:32:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-04 08:32:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:32:03 --> Final output sent to browser
DEBUG - 2022-01-04 08:32:03 --> Total execution time: 0.0959
INFO - 2022-01-04 01:32:03 --> Config Class Initialized
INFO - 2022-01-04 01:32:03 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:03 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:03 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:03 --> URI Class Initialized
INFO - 2022-01-04 01:32:03 --> Router Class Initialized
INFO - 2022-01-04 01:32:03 --> Output Class Initialized
INFO - 2022-01-04 01:32:03 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:03 --> Input Class Initialized
INFO - 2022-01-04 01:32:03 --> Language Class Initialized
ERROR - 2022-01-04 01:32:03 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:32:09 --> Config Class Initialized
INFO - 2022-01-04 01:32:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:09 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:09 --> URI Class Initialized
INFO - 2022-01-04 01:32:09 --> Router Class Initialized
INFO - 2022-01-04 01:32:09 --> Output Class Initialized
INFO - 2022-01-04 01:32:09 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:09 --> Input Class Initialized
INFO - 2022-01-04 01:32:09 --> Language Class Initialized
INFO - 2022-01-04 01:32:09 --> Loader Class Initialized
INFO - 2022-01-04 01:32:09 --> Helper loaded: url_helper
INFO - 2022-01-04 01:32:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:32:09 --> Controller Class Initialized
INFO - 2022-01-04 08:32:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:32:09 --> Model "UserModel" initialized
INFO - 2022-01-04 08:32:09 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:32:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:32:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-04 08:32:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:32:09 --> Final output sent to browser
DEBUG - 2022-01-04 08:32:09 --> Total execution time: 0.0805
INFO - 2022-01-04 01:32:09 --> Config Class Initialized
INFO - 2022-01-04 01:32:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:09 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:09 --> URI Class Initialized
INFO - 2022-01-04 01:32:09 --> Router Class Initialized
INFO - 2022-01-04 01:32:09 --> Output Class Initialized
INFO - 2022-01-04 01:32:09 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:09 --> Input Class Initialized
INFO - 2022-01-04 01:32:09 --> Language Class Initialized
ERROR - 2022-01-04 01:32:09 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:32:10 --> Config Class Initialized
INFO - 2022-01-04 01:32:10 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:10 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:10 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:10 --> URI Class Initialized
INFO - 2022-01-04 01:32:10 --> Router Class Initialized
INFO - 2022-01-04 01:32:10 --> Output Class Initialized
INFO - 2022-01-04 01:32:10 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:10 --> Input Class Initialized
INFO - 2022-01-04 01:32:10 --> Language Class Initialized
INFO - 2022-01-04 01:32:10 --> Loader Class Initialized
INFO - 2022-01-04 01:32:10 --> Helper loaded: url_helper
INFO - 2022-01-04 01:32:10 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:32:10 --> Controller Class Initialized
INFO - 2022-01-04 08:32:10 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:32:10 --> Model "UserModel" initialized
INFO - 2022-01-04 08:32:10 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:32:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:32:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/about.php
INFO - 2022-01-04 08:32:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:32:11 --> Final output sent to browser
DEBUG - 2022-01-04 08:32:11 --> Total execution time: 0.0940
INFO - 2022-01-04 01:32:11 --> Config Class Initialized
INFO - 2022-01-04 01:32:11 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:11 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:11 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:11 --> URI Class Initialized
INFO - 2022-01-04 01:32:11 --> Router Class Initialized
INFO - 2022-01-04 01:32:11 --> Output Class Initialized
INFO - 2022-01-04 01:32:11 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:11 --> Input Class Initialized
INFO - 2022-01-04 01:32:11 --> Language Class Initialized
ERROR - 2022-01-04 01:32:11 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:32:13 --> Config Class Initialized
INFO - 2022-01-04 01:32:13 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:13 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:13 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:13 --> URI Class Initialized
INFO - 2022-01-04 01:32:13 --> Router Class Initialized
INFO - 2022-01-04 01:32:13 --> Output Class Initialized
INFO - 2022-01-04 01:32:13 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:13 --> Input Class Initialized
INFO - 2022-01-04 01:32:13 --> Language Class Initialized
INFO - 2022-01-04 01:32:13 --> Loader Class Initialized
INFO - 2022-01-04 01:32:13 --> Helper loaded: url_helper
INFO - 2022-01-04 01:32:13 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:32:13 --> Controller Class Initialized
INFO - 2022-01-04 08:32:13 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:32:13 --> Model "UserModel" initialized
INFO - 2022-01-04 08:32:13 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:32:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:32:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-04 08:32:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:32:13 --> Final output sent to browser
DEBUG - 2022-01-04 08:32:13 --> Total execution time: 0.0787
INFO - 2022-01-04 01:32:13 --> Config Class Initialized
INFO - 2022-01-04 01:32:13 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:13 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:13 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:13 --> URI Class Initialized
INFO - 2022-01-04 01:32:13 --> Router Class Initialized
INFO - 2022-01-04 01:32:13 --> Output Class Initialized
INFO - 2022-01-04 01:32:13 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:13 --> Input Class Initialized
INFO - 2022-01-04 01:32:13 --> Language Class Initialized
ERROR - 2022-01-04 01:32:13 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:32:23 --> Config Class Initialized
INFO - 2022-01-04 01:32:23 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:23 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:23 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:23 --> URI Class Initialized
INFO - 2022-01-04 01:32:23 --> Router Class Initialized
INFO - 2022-01-04 01:32:23 --> Output Class Initialized
INFO - 2022-01-04 01:32:23 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:23 --> Input Class Initialized
INFO - 2022-01-04 01:32:23 --> Language Class Initialized
INFO - 2022-01-04 01:32:23 --> Loader Class Initialized
INFO - 2022-01-04 01:32:23 --> Helper loaded: url_helper
INFO - 2022-01-04 01:32:23 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:32:23 --> Controller Class Initialized
INFO - 2022-01-04 08:32:23 --> Model "LoginModel" initialized
INFO - 2022-01-04 01:32:23 --> Config Class Initialized
INFO - 2022-01-04 01:32:23 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:23 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:23 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:23 --> URI Class Initialized
INFO - 2022-01-04 01:32:23 --> Router Class Initialized
INFO - 2022-01-04 01:32:23 --> Output Class Initialized
INFO - 2022-01-04 01:32:23 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:23 --> Input Class Initialized
INFO - 2022-01-04 01:32:23 --> Language Class Initialized
INFO - 2022-01-04 01:32:23 --> Loader Class Initialized
INFO - 2022-01-04 01:32:23 --> Helper loaded: url_helper
INFO - 2022-01-04 01:32:23 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:32:23 --> Controller Class Initialized
INFO - 2022-01-04 08:32:23 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:32:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 08:32:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 08:32:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:32:23 --> Final output sent to browser
DEBUG - 2022-01-04 08:32:23 --> Total execution time: 0.0721
INFO - 2022-01-04 01:32:34 --> Config Class Initialized
INFO - 2022-01-04 01:32:34 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:34 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:34 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:34 --> URI Class Initialized
INFO - 2022-01-04 01:32:34 --> Router Class Initialized
INFO - 2022-01-04 01:32:34 --> Output Class Initialized
INFO - 2022-01-04 01:32:34 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:34 --> Input Class Initialized
INFO - 2022-01-04 01:32:34 --> Language Class Initialized
INFO - 2022-01-04 01:32:34 --> Loader Class Initialized
INFO - 2022-01-04 01:32:34 --> Helper loaded: url_helper
INFO - 2022-01-04 01:32:34 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:32:34 --> Controller Class Initialized
INFO - 2022-01-04 08:32:34 --> Model "LoginModel" initialized
ERROR - 2022-01-04 08:32:34 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-04 01:32:34 --> Config Class Initialized
INFO - 2022-01-04 01:32:34 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:34 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:34 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:34 --> URI Class Initialized
DEBUG - 2022-01-04 01:32:34 --> No URI present. Default controller set.
INFO - 2022-01-04 01:32:34 --> Router Class Initialized
INFO - 2022-01-04 01:32:34 --> Output Class Initialized
INFO - 2022-01-04 01:32:34 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:34 --> Input Class Initialized
INFO - 2022-01-04 01:32:34 --> Language Class Initialized
INFO - 2022-01-04 01:32:34 --> Loader Class Initialized
INFO - 2022-01-04 01:32:34 --> Helper loaded: url_helper
INFO - 2022-01-04 01:32:34 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:32:34 --> Controller Class Initialized
INFO - 2022-01-04 08:32:34 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:32:34 --> Model "UserModel" initialized
INFO - 2022-01-04 08:32:34 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:32:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:32:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 08:32:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:32:34 --> Final output sent to browser
DEBUG - 2022-01-04 08:32:34 --> Total execution time: 0.0644
INFO - 2022-01-04 01:32:34 --> Config Class Initialized
INFO - 2022-01-04 01:32:34 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:34 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:34 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:34 --> URI Class Initialized
INFO - 2022-01-04 01:32:34 --> Router Class Initialized
INFO - 2022-01-04 01:32:34 --> Output Class Initialized
INFO - 2022-01-04 01:32:35 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:35 --> Input Class Initialized
INFO - 2022-01-04 01:32:35 --> Language Class Initialized
ERROR - 2022-01-04 01:32:35 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:32:35 --> Config Class Initialized
INFO - 2022-01-04 01:32:35 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:32:35 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:32:35 --> Utf8 Class Initialized
INFO - 2022-01-04 01:32:35 --> URI Class Initialized
INFO - 2022-01-04 01:32:35 --> Router Class Initialized
INFO - 2022-01-04 01:32:35 --> Output Class Initialized
INFO - 2022-01-04 01:32:35 --> Security Class Initialized
DEBUG - 2022-01-04 01:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:32:35 --> Input Class Initialized
INFO - 2022-01-04 01:32:35 --> Language Class Initialized
ERROR - 2022-01-04 01:32:35 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:33:08 --> Config Class Initialized
INFO - 2022-01-04 01:33:08 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:33:08 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:33:08 --> Utf8 Class Initialized
INFO - 2022-01-04 01:33:08 --> URI Class Initialized
INFO - 2022-01-04 01:33:08 --> Router Class Initialized
INFO - 2022-01-04 01:33:08 --> Output Class Initialized
INFO - 2022-01-04 01:33:08 --> Security Class Initialized
DEBUG - 2022-01-04 01:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:33:08 --> Input Class Initialized
INFO - 2022-01-04 01:33:08 --> Language Class Initialized
INFO - 2022-01-04 01:33:08 --> Loader Class Initialized
INFO - 2022-01-04 01:33:08 --> Helper loaded: url_helper
INFO - 2022-01-04 01:33:08 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:33:08 --> Controller Class Initialized
INFO - 2022-01-04 08:33:08 --> Model "LoginModel" initialized
INFO - 2022-01-04 01:33:09 --> Config Class Initialized
INFO - 2022-01-04 01:33:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:33:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:33:09 --> Utf8 Class Initialized
INFO - 2022-01-04 01:33:09 --> URI Class Initialized
INFO - 2022-01-04 01:33:09 --> Router Class Initialized
INFO - 2022-01-04 01:33:09 --> Output Class Initialized
INFO - 2022-01-04 01:33:09 --> Security Class Initialized
DEBUG - 2022-01-04 01:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:33:09 --> Input Class Initialized
INFO - 2022-01-04 01:33:09 --> Language Class Initialized
INFO - 2022-01-04 01:33:09 --> Loader Class Initialized
INFO - 2022-01-04 01:33:09 --> Helper loaded: url_helper
INFO - 2022-01-04 01:33:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:33:09 --> Controller Class Initialized
INFO - 2022-01-04 08:33:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:33:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 08:33:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 08:33:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:33:09 --> Final output sent to browser
DEBUG - 2022-01-04 08:33:09 --> Total execution time: 0.0507
INFO - 2022-01-04 01:33:58 --> Config Class Initialized
INFO - 2022-01-04 01:33:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:33:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:33:58 --> Utf8 Class Initialized
INFO - 2022-01-04 01:33:58 --> URI Class Initialized
INFO - 2022-01-04 01:33:58 --> Router Class Initialized
INFO - 2022-01-04 01:33:58 --> Output Class Initialized
INFO - 2022-01-04 01:33:58 --> Security Class Initialized
DEBUG - 2022-01-04 01:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:33:58 --> Input Class Initialized
INFO - 2022-01-04 01:33:58 --> Language Class Initialized
INFO - 2022-01-04 01:33:58 --> Loader Class Initialized
INFO - 2022-01-04 01:33:58 --> Helper loaded: url_helper
INFO - 2022-01-04 01:33:58 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:33:58 --> Controller Class Initialized
INFO - 2022-01-04 08:33:58 --> Model "LoginModel" initialized
ERROR - 2022-01-04 08:33:58 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-04 01:33:58 --> Config Class Initialized
INFO - 2022-01-04 01:33:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:33:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:33:58 --> Utf8 Class Initialized
INFO - 2022-01-04 01:33:58 --> URI Class Initialized
DEBUG - 2022-01-04 01:33:58 --> No URI present. Default controller set.
INFO - 2022-01-04 01:33:58 --> Router Class Initialized
INFO - 2022-01-04 01:33:58 --> Output Class Initialized
INFO - 2022-01-04 01:33:58 --> Security Class Initialized
DEBUG - 2022-01-04 01:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:33:58 --> Input Class Initialized
INFO - 2022-01-04 01:33:58 --> Language Class Initialized
INFO - 2022-01-04 01:33:58 --> Loader Class Initialized
INFO - 2022-01-04 01:33:58 --> Helper loaded: url_helper
INFO - 2022-01-04 01:33:58 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:33:58 --> Controller Class Initialized
INFO - 2022-01-04 08:33:58 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:33:58 --> Model "UserModel" initialized
INFO - 2022-01-04 08:33:58 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:33:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:33:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 08:33:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:33:58 --> Final output sent to browser
DEBUG - 2022-01-04 08:33:58 --> Total execution time: 0.0524
INFO - 2022-01-04 01:33:58 --> Config Class Initialized
INFO - 2022-01-04 01:33:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:33:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:33:58 --> Utf8 Class Initialized
INFO - 2022-01-04 01:33:58 --> URI Class Initialized
INFO - 2022-01-04 01:33:58 --> Router Class Initialized
INFO - 2022-01-04 01:33:58 --> Output Class Initialized
INFO - 2022-01-04 01:33:58 --> Security Class Initialized
DEBUG - 2022-01-04 01:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:33:58 --> Input Class Initialized
INFO - 2022-01-04 01:33:58 --> Language Class Initialized
ERROR - 2022-01-04 01:33:58 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:33:58 --> Config Class Initialized
INFO - 2022-01-04 01:33:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:33:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:33:58 --> Utf8 Class Initialized
INFO - 2022-01-04 01:33:58 --> URI Class Initialized
INFO - 2022-01-04 01:33:58 --> Router Class Initialized
INFO - 2022-01-04 01:33:58 --> Output Class Initialized
INFO - 2022-01-04 01:33:58 --> Security Class Initialized
DEBUG - 2022-01-04 01:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:33:58 --> Input Class Initialized
INFO - 2022-01-04 01:33:58 --> Language Class Initialized
ERROR - 2022-01-04 01:33:58 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:34:08 --> Config Class Initialized
INFO - 2022-01-04 01:34:08 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:34:08 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:34:08 --> Utf8 Class Initialized
INFO - 2022-01-04 01:34:08 --> URI Class Initialized
INFO - 2022-01-04 01:34:08 --> Router Class Initialized
INFO - 2022-01-04 01:34:08 --> Output Class Initialized
INFO - 2022-01-04 01:34:08 --> Security Class Initialized
DEBUG - 2022-01-04 01:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:34:08 --> Input Class Initialized
INFO - 2022-01-04 01:34:08 --> Language Class Initialized
INFO - 2022-01-04 01:34:08 --> Loader Class Initialized
INFO - 2022-01-04 01:34:08 --> Helper loaded: url_helper
INFO - 2022-01-04 01:34:08 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:34:08 --> Controller Class Initialized
INFO - 2022-01-04 08:34:08 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:34:08 --> Model "UserModel" initialized
INFO - 2022-01-04 08:34:08 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:34:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:34:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-04 08:34:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:34:08 --> Final output sent to browser
DEBUG - 2022-01-04 08:34:08 --> Total execution time: 0.0706
INFO - 2022-01-04 01:34:08 --> Config Class Initialized
INFO - 2022-01-04 01:34:08 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:34:08 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:34:08 --> Utf8 Class Initialized
INFO - 2022-01-04 01:34:08 --> URI Class Initialized
INFO - 2022-01-04 01:34:08 --> Router Class Initialized
INFO - 2022-01-04 01:34:08 --> Output Class Initialized
INFO - 2022-01-04 01:34:08 --> Security Class Initialized
DEBUG - 2022-01-04 01:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:34:08 --> Input Class Initialized
INFO - 2022-01-04 01:34:08 --> Language Class Initialized
ERROR - 2022-01-04 01:34:08 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:34:10 --> Config Class Initialized
INFO - 2022-01-04 01:34:10 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:34:10 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:34:10 --> Utf8 Class Initialized
INFO - 2022-01-04 01:34:10 --> URI Class Initialized
INFO - 2022-01-04 01:34:10 --> Router Class Initialized
INFO - 2022-01-04 01:34:10 --> Output Class Initialized
INFO - 2022-01-04 01:34:10 --> Security Class Initialized
DEBUG - 2022-01-04 01:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:34:10 --> Input Class Initialized
INFO - 2022-01-04 01:34:10 --> Language Class Initialized
INFO - 2022-01-04 01:34:10 --> Loader Class Initialized
INFO - 2022-01-04 01:34:11 --> Helper loaded: url_helper
INFO - 2022-01-04 01:34:11 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:34:11 --> Controller Class Initialized
INFO - 2022-01-04 08:34:11 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:34:11 --> Model "UserModel" initialized
INFO - 2022-01-04 08:34:11 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:34:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:34:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/admin-page.php
INFO - 2022-01-04 08:34:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:34:11 --> Final output sent to browser
DEBUG - 2022-01-04 08:34:11 --> Total execution time: 0.0555
INFO - 2022-01-04 01:34:11 --> Config Class Initialized
INFO - 2022-01-04 01:34:11 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:34:11 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:34:11 --> Utf8 Class Initialized
INFO - 2022-01-04 01:34:11 --> URI Class Initialized
INFO - 2022-01-04 01:34:11 --> Router Class Initialized
INFO - 2022-01-04 01:34:11 --> Output Class Initialized
INFO - 2022-01-04 01:34:11 --> Security Class Initialized
DEBUG - 2022-01-04 01:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:34:11 --> Input Class Initialized
INFO - 2022-01-04 01:34:11 --> Language Class Initialized
ERROR - 2022-01-04 01:34:11 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 01:40:02 --> Config Class Initialized
INFO - 2022-01-04 01:40:02 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:40:02 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:40:02 --> Utf8 Class Initialized
INFO - 2022-01-04 01:40:02 --> URI Class Initialized
INFO - 2022-01-04 01:40:02 --> Router Class Initialized
INFO - 2022-01-04 01:40:02 --> Output Class Initialized
INFO - 2022-01-04 01:40:02 --> Security Class Initialized
DEBUG - 2022-01-04 01:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:40:02 --> Input Class Initialized
INFO - 2022-01-04 01:40:02 --> Language Class Initialized
INFO - 2022-01-04 01:40:02 --> Loader Class Initialized
INFO - 2022-01-04 01:40:02 --> Helper loaded: url_helper
INFO - 2022-01-04 01:40:02 --> Database Driver Class Initialized
DEBUG - 2022-01-04 01:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 01:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 01:40:02 --> Controller Class Initialized
INFO - 2022-01-04 08:40:02 --> Model "LoginModel" initialized
INFO - 2022-01-04 08:40:02 --> Model "UserModel" initialized
INFO - 2022-01-04 08:40:02 --> Model "AdminModel" initialized
INFO - 2022-01-04 08:40:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 08:40:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 08:40:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 08:40:02 --> Final output sent to browser
DEBUG - 2022-01-04 08:40:02 --> Total execution time: 0.0983
INFO - 2022-01-04 01:40:02 --> Config Class Initialized
INFO - 2022-01-04 01:40:02 --> Hooks Class Initialized
DEBUG - 2022-01-04 01:40:02 --> UTF-8 Support Enabled
INFO - 2022-01-04 01:40:02 --> Utf8 Class Initialized
INFO - 2022-01-04 01:40:02 --> URI Class Initialized
INFO - 2022-01-04 01:40:02 --> Router Class Initialized
INFO - 2022-01-04 01:40:02 --> Output Class Initialized
INFO - 2022-01-04 01:40:02 --> Security Class Initialized
DEBUG - 2022-01-04 01:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 01:40:02 --> Input Class Initialized
INFO - 2022-01-04 01:40:02 --> Language Class Initialized
ERROR - 2022-01-04 01:40:02 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 02:04:36 --> Config Class Initialized
INFO - 2022-01-04 02:04:36 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:04:36 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:04:36 --> Utf8 Class Initialized
INFO - 2022-01-04 02:04:36 --> URI Class Initialized
INFO - 2022-01-04 02:04:36 --> Router Class Initialized
INFO - 2022-01-04 02:04:36 --> Output Class Initialized
INFO - 2022-01-04 02:04:36 --> Security Class Initialized
DEBUG - 2022-01-04 02:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:04:36 --> Input Class Initialized
INFO - 2022-01-04 02:04:36 --> Language Class Initialized
INFO - 2022-01-04 02:04:36 --> Loader Class Initialized
INFO - 2022-01-04 02:04:36 --> Helper loaded: url_helper
INFO - 2022-01-04 02:04:36 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:04:36 --> Controller Class Initialized
INFO - 2022-01-04 09:04:36 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:04:36 --> Model "UserModel" initialized
INFO - 2022-01-04 09:04:36 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:04:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:04:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:04:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:04:36 --> Final output sent to browser
DEBUG - 2022-01-04 09:04:36 --> Total execution time: 0.0765
INFO - 2022-01-04 02:04:36 --> Config Class Initialized
INFO - 2022-01-04 02:04:36 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:04:36 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:04:36 --> Utf8 Class Initialized
INFO - 2022-01-04 02:04:36 --> URI Class Initialized
INFO - 2022-01-04 02:04:36 --> Router Class Initialized
INFO - 2022-01-04 02:04:36 --> Output Class Initialized
INFO - 2022-01-04 02:04:36 --> Security Class Initialized
DEBUG - 2022-01-04 02:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:04:36 --> Input Class Initialized
INFO - 2022-01-04 02:04:36 --> Language Class Initialized
ERROR - 2022-01-04 02:04:36 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 02:04:36 --> Config Class Initialized
INFO - 2022-01-04 02:04:36 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:04:36 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:04:36 --> Utf8 Class Initialized
INFO - 2022-01-04 02:04:36 --> URI Class Initialized
INFO - 2022-01-04 02:04:36 --> Router Class Initialized
INFO - 2022-01-04 02:04:36 --> Output Class Initialized
INFO - 2022-01-04 02:04:36 --> Security Class Initialized
DEBUG - 2022-01-04 02:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:04:36 --> Input Class Initialized
INFO - 2022-01-04 02:04:36 --> Language Class Initialized
INFO - 2022-01-04 02:04:36 --> Loader Class Initialized
INFO - 2022-01-04 02:04:36 --> Helper loaded: url_helper
INFO - 2022-01-04 02:04:36 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:04:36 --> Controller Class Initialized
INFO - 2022-01-04 09:04:36 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:04:36 --> Model "UserModel" initialized
ERROR - 2022-01-04 09:04:36 --> Severity: error --> Exception: Class "AdminModel" not found C:\xampp\htdocs\OJT\application\controllers\Admin.php 47
INFO - 2022-01-04 02:06:58 --> Config Class Initialized
INFO - 2022-01-04 02:06:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:06:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:06:58 --> Utf8 Class Initialized
INFO - 2022-01-04 02:06:58 --> URI Class Initialized
INFO - 2022-01-04 02:06:58 --> Router Class Initialized
INFO - 2022-01-04 02:06:58 --> Output Class Initialized
INFO - 2022-01-04 02:06:58 --> Security Class Initialized
DEBUG - 2022-01-04 02:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:06:58 --> Input Class Initialized
INFO - 2022-01-04 02:06:58 --> Language Class Initialized
INFO - 2022-01-04 02:06:58 --> Loader Class Initialized
INFO - 2022-01-04 02:06:58 --> Helper loaded: url_helper
INFO - 2022-01-04 02:06:58 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:06:58 --> Controller Class Initialized
INFO - 2022-01-04 09:06:58 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:06:58 --> Model "UserModel" initialized
INFO - 2022-01-04 09:06:58 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:06:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:06:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:06:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:06:58 --> Final output sent to browser
DEBUG - 2022-01-04 09:06:58 --> Total execution time: 0.0620
INFO - 2022-01-04 02:06:58 --> Config Class Initialized
INFO - 2022-01-04 02:06:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:06:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:06:58 --> Utf8 Class Initialized
INFO - 2022-01-04 02:06:58 --> URI Class Initialized
INFO - 2022-01-04 02:06:58 --> Router Class Initialized
INFO - 2022-01-04 02:06:58 --> Output Class Initialized
INFO - 2022-01-04 02:06:58 --> Security Class Initialized
DEBUG - 2022-01-04 02:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:06:58 --> Input Class Initialized
INFO - 2022-01-04 02:06:58 --> Language Class Initialized
ERROR - 2022-01-04 02:06:58 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 02:06:58 --> Config Class Initialized
INFO - 2022-01-04 02:06:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:06:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:06:58 --> Utf8 Class Initialized
INFO - 2022-01-04 02:06:58 --> URI Class Initialized
INFO - 2022-01-04 02:06:58 --> Router Class Initialized
INFO - 2022-01-04 02:06:58 --> Output Class Initialized
INFO - 2022-01-04 02:06:58 --> Security Class Initialized
DEBUG - 2022-01-04 02:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:06:58 --> Input Class Initialized
INFO - 2022-01-04 02:06:58 --> Language Class Initialized
ERROR - 2022-01-04 02:06:58 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 02:06:59 --> Config Class Initialized
INFO - 2022-01-04 02:06:59 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:06:59 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:06:59 --> Utf8 Class Initialized
INFO - 2022-01-04 02:06:59 --> URI Class Initialized
INFO - 2022-01-04 02:06:59 --> Router Class Initialized
INFO - 2022-01-04 02:06:59 --> Output Class Initialized
INFO - 2022-01-04 02:06:59 --> Security Class Initialized
DEBUG - 2022-01-04 02:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:06:59 --> Input Class Initialized
INFO - 2022-01-04 02:06:59 --> Language Class Initialized
INFO - 2022-01-04 02:06:59 --> Loader Class Initialized
INFO - 2022-01-04 02:06:59 --> Helper loaded: url_helper
INFO - 2022-01-04 02:06:59 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:06:59 --> Controller Class Initialized
INFO - 2022-01-04 09:06:59 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:06:59 --> Model "UserModel" initialized
ERROR - 2022-01-04 09:06:59 --> Severity: error --> Exception: Class "AdminModel" not found C:\xampp\htdocs\OJT\application\controllers\Admin.php 47
INFO - 2022-01-04 02:07:12 --> Config Class Initialized
INFO - 2022-01-04 02:07:12 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:07:12 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:07:12 --> Utf8 Class Initialized
INFO - 2022-01-04 02:07:12 --> URI Class Initialized
INFO - 2022-01-04 02:07:12 --> Router Class Initialized
INFO - 2022-01-04 02:07:12 --> Output Class Initialized
INFO - 2022-01-04 02:07:12 --> Security Class Initialized
DEBUG - 2022-01-04 02:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:07:12 --> Input Class Initialized
INFO - 2022-01-04 02:07:12 --> Language Class Initialized
INFO - 2022-01-04 02:07:12 --> Loader Class Initialized
INFO - 2022-01-04 02:07:12 --> Helper loaded: url_helper
INFO - 2022-01-04 02:07:12 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:07:12 --> Controller Class Initialized
INFO - 2022-01-04 09:07:12 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:07:12 --> Model "UserModel" initialized
INFO - 2022-01-04 09:07:12 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:07:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:07:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:07:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:07:12 --> Final output sent to browser
DEBUG - 2022-01-04 09:07:12 --> Total execution time: 0.0658
INFO - 2022-01-04 02:07:12 --> Config Class Initialized
INFO - 2022-01-04 02:07:12 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:07:12 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:07:12 --> Utf8 Class Initialized
INFO - 2022-01-04 02:07:12 --> URI Class Initialized
INFO - 2022-01-04 02:07:12 --> Router Class Initialized
INFO - 2022-01-04 02:07:12 --> Output Class Initialized
INFO - 2022-01-04 02:07:12 --> Security Class Initialized
DEBUG - 2022-01-04 02:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:07:12 --> Input Class Initialized
INFO - 2022-01-04 02:07:12 --> Language Class Initialized
ERROR - 2022-01-04 02:07:12 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 02:07:13 --> Config Class Initialized
INFO - 2022-01-04 02:07:13 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:07:13 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:07:13 --> Utf8 Class Initialized
INFO - 2022-01-04 02:07:13 --> URI Class Initialized
INFO - 2022-01-04 02:07:13 --> Router Class Initialized
INFO - 2022-01-04 02:07:13 --> Output Class Initialized
INFO - 2022-01-04 02:07:13 --> Security Class Initialized
DEBUG - 2022-01-04 02:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:07:13 --> Input Class Initialized
INFO - 2022-01-04 02:07:13 --> Language Class Initialized
ERROR - 2022-01-04 02:07:13 --> 404 Page Not Found: Toastrjs/index
INFO - 2022-01-04 02:07:13 --> Config Class Initialized
INFO - 2022-01-04 02:07:13 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:07:13 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:07:13 --> Utf8 Class Initialized
INFO - 2022-01-04 02:07:13 --> URI Class Initialized
INFO - 2022-01-04 02:07:13 --> Router Class Initialized
INFO - 2022-01-04 02:07:13 --> Output Class Initialized
INFO - 2022-01-04 02:07:13 --> Security Class Initialized
DEBUG - 2022-01-04 02:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:07:13 --> Input Class Initialized
INFO - 2022-01-04 02:07:13 --> Language Class Initialized
INFO - 2022-01-04 02:07:13 --> Loader Class Initialized
INFO - 2022-01-04 02:07:13 --> Helper loaded: url_helper
INFO - 2022-01-04 02:07:13 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:07:13 --> Controller Class Initialized
INFO - 2022-01-04 09:07:13 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:07:13 --> Model "UserModel" initialized
ERROR - 2022-01-04 09:07:13 --> Severity: error --> Exception: Class "AdminModel" not found C:\xampp\htdocs\OJT\application\controllers\Admin.php 47
INFO - 2022-01-04 02:08:47 --> Config Class Initialized
INFO - 2022-01-04 02:08:47 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:08:47 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:08:47 --> Utf8 Class Initialized
INFO - 2022-01-04 02:08:47 --> URI Class Initialized
INFO - 2022-01-04 02:08:47 --> Router Class Initialized
INFO - 2022-01-04 02:08:47 --> Output Class Initialized
INFO - 2022-01-04 02:08:47 --> Security Class Initialized
DEBUG - 2022-01-04 02:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:08:47 --> Input Class Initialized
INFO - 2022-01-04 02:08:47 --> Language Class Initialized
INFO - 2022-01-04 02:08:47 --> Loader Class Initialized
INFO - 2022-01-04 02:08:47 --> Helper loaded: url_helper
INFO - 2022-01-04 02:08:47 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:08:47 --> Controller Class Initialized
INFO - 2022-01-04 09:08:47 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:08:47 --> Model "UserModel" initialized
INFO - 2022-01-04 09:08:47 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:08:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:08:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:08:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:08:47 --> Final output sent to browser
DEBUG - 2022-01-04 09:08:47 --> Total execution time: 0.0727
INFO - 2022-01-04 02:08:48 --> Config Class Initialized
INFO - 2022-01-04 02:08:48 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:08:48 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:08:48 --> Utf8 Class Initialized
INFO - 2022-01-04 02:08:48 --> URI Class Initialized
INFO - 2022-01-04 02:08:48 --> Router Class Initialized
INFO - 2022-01-04 02:08:48 --> Output Class Initialized
INFO - 2022-01-04 02:08:48 --> Security Class Initialized
DEBUG - 2022-01-04 02:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:08:48 --> Input Class Initialized
INFO - 2022-01-04 02:08:48 --> Language Class Initialized
INFO - 2022-01-04 02:08:48 --> Loader Class Initialized
INFO - 2022-01-04 02:08:48 --> Helper loaded: url_helper
INFO - 2022-01-04 02:08:48 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:08:48 --> Controller Class Initialized
INFO - 2022-01-04 09:08:48 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:08:48 --> Model "UserModel" initialized
ERROR - 2022-01-04 09:08:48 --> Severity: error --> Exception: Class "AdminModel" not found C:\xampp\htdocs\OJT\application\controllers\Admin.php 47
INFO - 2022-01-04 02:09:23 --> Config Class Initialized
INFO - 2022-01-04 02:09:23 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:09:23 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:09:23 --> Utf8 Class Initialized
INFO - 2022-01-04 02:09:23 --> URI Class Initialized
INFO - 2022-01-04 02:09:23 --> Router Class Initialized
INFO - 2022-01-04 02:09:23 --> Output Class Initialized
INFO - 2022-01-04 02:09:23 --> Security Class Initialized
DEBUG - 2022-01-04 02:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:09:23 --> Input Class Initialized
INFO - 2022-01-04 02:09:23 --> Language Class Initialized
INFO - 2022-01-04 02:09:23 --> Loader Class Initialized
INFO - 2022-01-04 02:09:23 --> Helper loaded: url_helper
INFO - 2022-01-04 02:09:23 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:09:23 --> Controller Class Initialized
INFO - 2022-01-04 09:09:23 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:09:23 --> Model "UserModel" initialized
INFO - 2022-01-04 09:09:23 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:09:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:09:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:09:23 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:09:23 --> Final output sent to browser
DEBUG - 2022-01-04 09:09:23 --> Total execution time: 0.0858
INFO - 2022-01-04 02:09:25 --> Config Class Initialized
INFO - 2022-01-04 02:09:25 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:09:25 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:09:25 --> Utf8 Class Initialized
INFO - 2022-01-04 02:09:25 --> URI Class Initialized
INFO - 2022-01-04 02:09:25 --> Router Class Initialized
INFO - 2022-01-04 02:09:25 --> Output Class Initialized
INFO - 2022-01-04 02:09:25 --> Security Class Initialized
DEBUG - 2022-01-04 02:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:09:25 --> Input Class Initialized
INFO - 2022-01-04 02:09:25 --> Language Class Initialized
INFO - 2022-01-04 02:09:25 --> Loader Class Initialized
INFO - 2022-01-04 02:09:25 --> Helper loaded: url_helper
INFO - 2022-01-04 02:09:25 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:09:25 --> Controller Class Initialized
INFO - 2022-01-04 09:09:25 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:09:25 --> Model "UserModel" initialized
ERROR - 2022-01-04 09:09:25 --> Severity: error --> Exception: Class "AdminModel" not found C:\xampp\htdocs\OJT\application\controllers\Admin.php 47
INFO - 2022-01-04 02:09:56 --> Config Class Initialized
INFO - 2022-01-04 02:09:56 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:09:56 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:09:56 --> Utf8 Class Initialized
INFO - 2022-01-04 02:09:56 --> URI Class Initialized
INFO - 2022-01-04 02:09:56 --> Router Class Initialized
INFO - 2022-01-04 02:09:56 --> Output Class Initialized
INFO - 2022-01-04 02:09:56 --> Security Class Initialized
DEBUG - 2022-01-04 02:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:09:56 --> Input Class Initialized
INFO - 2022-01-04 02:09:56 --> Language Class Initialized
INFO - 2022-01-04 02:09:56 --> Loader Class Initialized
INFO - 2022-01-04 02:09:56 --> Helper loaded: url_helper
INFO - 2022-01-04 02:09:56 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:09:56 --> Controller Class Initialized
INFO - 2022-01-04 09:09:56 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:09:56 --> Model "UserModel" initialized
INFO - 2022-01-04 09:09:56 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:09:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:09:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:09:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:09:56 --> Final output sent to browser
DEBUG - 2022-01-04 09:09:56 --> Total execution time: 0.1129
INFO - 2022-01-04 02:09:57 --> Config Class Initialized
INFO - 2022-01-04 02:09:57 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:09:57 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:09:57 --> Utf8 Class Initialized
INFO - 2022-01-04 02:09:57 --> URI Class Initialized
INFO - 2022-01-04 02:09:57 --> Router Class Initialized
INFO - 2022-01-04 02:09:57 --> Output Class Initialized
INFO - 2022-01-04 02:09:57 --> Security Class Initialized
DEBUG - 2022-01-04 02:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:09:57 --> Input Class Initialized
INFO - 2022-01-04 02:09:57 --> Language Class Initialized
INFO - 2022-01-04 02:09:57 --> Loader Class Initialized
INFO - 2022-01-04 02:09:57 --> Helper loaded: url_helper
INFO - 2022-01-04 02:09:57 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:09:57 --> Controller Class Initialized
INFO - 2022-01-04 09:09:57 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:09:57 --> Model "UserModel" initialized
ERROR - 2022-01-04 09:09:57 --> Severity: error --> Exception: Class "AdminModel" not found C:\xampp\htdocs\OJT\application\controllers\Admin.php 47
INFO - 2022-01-04 02:10:34 --> Config Class Initialized
INFO - 2022-01-04 02:10:34 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:10:34 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:10:34 --> Utf8 Class Initialized
INFO - 2022-01-04 02:10:34 --> URI Class Initialized
INFO - 2022-01-04 02:10:34 --> Router Class Initialized
INFO - 2022-01-04 02:10:34 --> Output Class Initialized
INFO - 2022-01-04 02:10:34 --> Security Class Initialized
DEBUG - 2022-01-04 02:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:10:34 --> Input Class Initialized
INFO - 2022-01-04 02:10:34 --> Language Class Initialized
INFO - 2022-01-04 02:10:34 --> Loader Class Initialized
INFO - 2022-01-04 02:10:34 --> Helper loaded: url_helper
INFO - 2022-01-04 02:10:34 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:10:34 --> Controller Class Initialized
INFO - 2022-01-04 09:10:34 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:10:34 --> Model "UserModel" initialized
INFO - 2022-01-04 09:10:34 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:10:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:10:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:10:34 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:10:34 --> Final output sent to browser
DEBUG - 2022-01-04 09:10:34 --> Total execution time: 0.0798
INFO - 2022-01-04 02:10:35 --> Config Class Initialized
INFO - 2022-01-04 02:10:35 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:10:35 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:10:35 --> Utf8 Class Initialized
INFO - 2022-01-04 02:10:35 --> URI Class Initialized
INFO - 2022-01-04 02:10:35 --> Router Class Initialized
INFO - 2022-01-04 02:10:35 --> Output Class Initialized
INFO - 2022-01-04 02:10:35 --> Security Class Initialized
DEBUG - 2022-01-04 02:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:10:35 --> Input Class Initialized
INFO - 2022-01-04 02:10:35 --> Language Class Initialized
INFO - 2022-01-04 02:10:35 --> Loader Class Initialized
INFO - 2022-01-04 02:10:35 --> Helper loaded: url_helper
INFO - 2022-01-04 02:10:35 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:10:35 --> Controller Class Initialized
INFO - 2022-01-04 09:10:35 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:10:35 --> Model "UserModel" initialized
INFO - 2022-01-04 09:10:35 --> Model "AdminModel" initialized
ERROR - 2022-01-04 09:10:35 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 58
ERROR - 2022-01-04 09:10:35 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 58
ERROR - 2022-01-04 09:10:35 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 58
INFO - 2022-01-04 09:10:35 --> Final output sent to browser
DEBUG - 2022-01-04 09:10:35 --> Total execution time: 0.1044
INFO - 2022-01-04 02:10:49 --> Config Class Initialized
INFO - 2022-01-04 02:10:49 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:10:49 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:10:49 --> Utf8 Class Initialized
INFO - 2022-01-04 02:10:49 --> URI Class Initialized
INFO - 2022-01-04 02:10:49 --> Router Class Initialized
INFO - 2022-01-04 02:10:49 --> Output Class Initialized
INFO - 2022-01-04 02:10:49 --> Security Class Initialized
DEBUG - 2022-01-04 02:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:10:49 --> Input Class Initialized
INFO - 2022-01-04 02:10:49 --> Language Class Initialized
INFO - 2022-01-04 02:10:49 --> Loader Class Initialized
INFO - 2022-01-04 02:10:49 --> Helper loaded: url_helper
INFO - 2022-01-04 02:10:49 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:10:49 --> Controller Class Initialized
INFO - 2022-01-04 09:10:49 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:10:49 --> Model "UserModel" initialized
INFO - 2022-01-04 09:10:49 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:10:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:10:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:10:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:10:49 --> Final output sent to browser
DEBUG - 2022-01-04 09:10:49 --> Total execution time: 0.0945
INFO - 2022-01-04 02:10:50 --> Config Class Initialized
INFO - 2022-01-04 02:10:50 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:10:50 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:10:50 --> Utf8 Class Initialized
INFO - 2022-01-04 02:10:50 --> URI Class Initialized
INFO - 2022-01-04 02:10:50 --> Router Class Initialized
INFO - 2022-01-04 02:10:50 --> Output Class Initialized
INFO - 2022-01-04 02:10:50 --> Security Class Initialized
DEBUG - 2022-01-04 02:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:10:50 --> Input Class Initialized
INFO - 2022-01-04 02:10:50 --> Language Class Initialized
INFO - 2022-01-04 02:10:50 --> Loader Class Initialized
INFO - 2022-01-04 02:10:50 --> Helper loaded: url_helper
INFO - 2022-01-04 02:10:50 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:10:50 --> Controller Class Initialized
INFO - 2022-01-04 09:10:50 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:10:50 --> Model "UserModel" initialized
INFO - 2022-01-04 09:10:50 --> Model "AdminModel" initialized
ERROR - 2022-01-04 09:10:50 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 58
ERROR - 2022-01-04 09:10:50 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 58
ERROR - 2022-01-04 09:10:50 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 58
INFO - 2022-01-04 09:10:50 --> Final output sent to browser
DEBUG - 2022-01-04 09:10:50 --> Total execution time: 0.0863
INFO - 2022-01-04 02:13:21 --> Config Class Initialized
INFO - 2022-01-04 02:13:21 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:13:21 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:13:21 --> Utf8 Class Initialized
INFO - 2022-01-04 02:13:21 --> URI Class Initialized
INFO - 2022-01-04 02:13:21 --> Router Class Initialized
INFO - 2022-01-04 02:13:21 --> Output Class Initialized
INFO - 2022-01-04 02:13:21 --> Security Class Initialized
DEBUG - 2022-01-04 02:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:13:21 --> Input Class Initialized
INFO - 2022-01-04 02:13:21 --> Language Class Initialized
INFO - 2022-01-04 02:13:21 --> Loader Class Initialized
INFO - 2022-01-04 02:13:21 --> Helper loaded: url_helper
INFO - 2022-01-04 02:13:21 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:13:21 --> Controller Class Initialized
INFO - 2022-01-04 09:13:21 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:13:21 --> Model "UserModel" initialized
INFO - 2022-01-04 09:13:21 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:13:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:13:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:13:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:13:21 --> Final output sent to browser
DEBUG - 2022-01-04 09:13:21 --> Total execution time: 0.1268
INFO - 2022-01-04 02:13:22 --> Config Class Initialized
INFO - 2022-01-04 02:13:22 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:13:22 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:13:22 --> Utf8 Class Initialized
INFO - 2022-01-04 02:13:22 --> URI Class Initialized
INFO - 2022-01-04 02:13:22 --> Router Class Initialized
INFO - 2022-01-04 02:13:22 --> Output Class Initialized
INFO - 2022-01-04 02:13:22 --> Security Class Initialized
DEBUG - 2022-01-04 02:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:13:22 --> Input Class Initialized
INFO - 2022-01-04 02:13:22 --> Language Class Initialized
ERROR - 2022-01-04 02:13:22 --> Severity: error --> Exception: syntax error, unexpected identifier "array_push" C:\xampp\htdocs\OJT\application\controllers\Admin.php 53
INFO - 2022-01-04 02:13:28 --> Config Class Initialized
INFO - 2022-01-04 02:13:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:13:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:13:28 --> Utf8 Class Initialized
INFO - 2022-01-04 02:13:28 --> URI Class Initialized
INFO - 2022-01-04 02:13:28 --> Router Class Initialized
INFO - 2022-01-04 02:13:28 --> Output Class Initialized
INFO - 2022-01-04 02:13:28 --> Security Class Initialized
DEBUG - 2022-01-04 02:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:13:28 --> Input Class Initialized
INFO - 2022-01-04 02:13:28 --> Language Class Initialized
INFO - 2022-01-04 02:13:28 --> Loader Class Initialized
INFO - 2022-01-04 02:13:28 --> Helper loaded: url_helper
INFO - 2022-01-04 02:13:28 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:13:28 --> Controller Class Initialized
INFO - 2022-01-04 09:13:28 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:13:28 --> Model "UserModel" initialized
INFO - 2022-01-04 09:13:28 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:13:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:13:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:13:28 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:13:28 --> Final output sent to browser
DEBUG - 2022-01-04 09:13:28 --> Total execution time: 0.0979
INFO - 2022-01-04 02:13:28 --> Config Class Initialized
INFO - 2022-01-04 02:13:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:13:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:13:28 --> Utf8 Class Initialized
INFO - 2022-01-04 02:13:28 --> URI Class Initialized
INFO - 2022-01-04 02:13:28 --> Router Class Initialized
INFO - 2022-01-04 02:13:28 --> Output Class Initialized
INFO - 2022-01-04 02:13:28 --> Security Class Initialized
DEBUG - 2022-01-04 02:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:13:28 --> Input Class Initialized
INFO - 2022-01-04 02:13:28 --> Language Class Initialized
INFO - 2022-01-04 02:13:28 --> Loader Class Initialized
INFO - 2022-01-04 02:13:28 --> Helper loaded: url_helper
INFO - 2022-01-04 02:13:28 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:13:28 --> Controller Class Initialized
INFO - 2022-01-04 09:13:28 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:13:28 --> Model "UserModel" initialized
INFO - 2022-01-04 09:13:28 --> Model "AdminModel" initialized
ERROR - 2022-01-04 09:13:28 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 52
ERROR - 2022-01-04 09:13:28 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 52
ERROR - 2022-01-04 09:13:28 --> Severity: Warning --> Undefined variable $last_name C:\xampp\htdocs\OJT\application\controllers\Admin.php 52
INFO - 2022-01-04 09:13:28 --> Final output sent to browser
DEBUG - 2022-01-04 09:13:28 --> Total execution time: 0.1408
INFO - 2022-01-04 02:13:57 --> Config Class Initialized
INFO - 2022-01-04 02:13:57 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:13:57 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:13:57 --> Utf8 Class Initialized
INFO - 2022-01-04 02:13:57 --> URI Class Initialized
INFO - 2022-01-04 02:13:57 --> Router Class Initialized
INFO - 2022-01-04 02:13:57 --> Output Class Initialized
INFO - 2022-01-04 02:13:57 --> Security Class Initialized
DEBUG - 2022-01-04 02:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:13:57 --> Input Class Initialized
INFO - 2022-01-04 02:13:57 --> Language Class Initialized
INFO - 2022-01-04 02:13:58 --> Loader Class Initialized
INFO - 2022-01-04 02:13:58 --> Helper loaded: url_helper
INFO - 2022-01-04 02:13:58 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:13:58 --> Controller Class Initialized
INFO - 2022-01-04 09:13:58 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:13:58 --> Model "UserModel" initialized
INFO - 2022-01-04 09:13:58 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:13:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:13:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:13:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:13:58 --> Final output sent to browser
DEBUG - 2022-01-04 09:13:58 --> Total execution time: 0.1207
INFO - 2022-01-04 02:13:58 --> Config Class Initialized
INFO - 2022-01-04 02:13:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:13:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:13:58 --> Utf8 Class Initialized
INFO - 2022-01-04 02:13:58 --> URI Class Initialized
INFO - 2022-01-04 02:13:58 --> Router Class Initialized
INFO - 2022-01-04 02:13:58 --> Output Class Initialized
INFO - 2022-01-04 02:13:58 --> Security Class Initialized
DEBUG - 2022-01-04 02:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:13:58 --> Input Class Initialized
INFO - 2022-01-04 02:13:58 --> Language Class Initialized
INFO - 2022-01-04 02:13:58 --> Loader Class Initialized
INFO - 2022-01-04 02:13:58 --> Helper loaded: url_helper
INFO - 2022-01-04 02:13:58 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:13:58 --> Controller Class Initialized
INFO - 2022-01-04 09:13:58 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:13:58 --> Model "UserModel" initialized
INFO - 2022-01-04 09:13:58 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:13:58 --> Final output sent to browser
DEBUG - 2022-01-04 09:13:58 --> Total execution time: 0.1514
INFO - 2022-01-04 02:17:56 --> Config Class Initialized
INFO - 2022-01-04 02:17:56 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:17:56 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:17:56 --> Utf8 Class Initialized
INFO - 2022-01-04 02:17:56 --> URI Class Initialized
INFO - 2022-01-04 02:17:56 --> Router Class Initialized
INFO - 2022-01-04 02:17:56 --> Output Class Initialized
INFO - 2022-01-04 02:17:56 --> Security Class Initialized
DEBUG - 2022-01-04 02:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:17:56 --> Input Class Initialized
INFO - 2022-01-04 02:17:56 --> Language Class Initialized
INFO - 2022-01-04 02:17:56 --> Loader Class Initialized
INFO - 2022-01-04 02:17:56 --> Helper loaded: url_helper
INFO - 2022-01-04 02:17:56 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:17:56 --> Controller Class Initialized
INFO - 2022-01-04 09:17:56 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:17:56 --> Model "UserModel" initialized
INFO - 2022-01-04 09:17:56 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:17:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:17:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:17:56 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:17:56 --> Final output sent to browser
DEBUG - 2022-01-04 09:17:56 --> Total execution time: 0.0708
INFO - 2022-01-04 02:17:56 --> Config Class Initialized
INFO - 2022-01-04 02:17:56 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:17:56 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:17:56 --> Utf8 Class Initialized
INFO - 2022-01-04 02:17:56 --> URI Class Initialized
INFO - 2022-01-04 02:17:56 --> Router Class Initialized
INFO - 2022-01-04 02:17:56 --> Output Class Initialized
INFO - 2022-01-04 02:17:56 --> Security Class Initialized
DEBUG - 2022-01-04 02:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:17:56 --> Input Class Initialized
INFO - 2022-01-04 02:17:56 --> Language Class Initialized
INFO - 2022-01-04 02:17:56 --> Loader Class Initialized
INFO - 2022-01-04 02:17:56 --> Helper loaded: url_helper
INFO - 2022-01-04 02:17:56 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:17:56 --> Controller Class Initialized
INFO - 2022-01-04 09:17:56 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:17:56 --> Model "UserModel" initialized
INFO - 2022-01-04 09:17:56 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:17:56 --> Final output sent to browser
DEBUG - 2022-01-04 09:17:56 --> Total execution time: 0.0686
INFO - 2022-01-04 02:22:51 --> Config Class Initialized
INFO - 2022-01-04 02:22:51 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:22:51 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:22:51 --> Utf8 Class Initialized
INFO - 2022-01-04 02:22:51 --> URI Class Initialized
INFO - 2022-01-04 02:22:51 --> Router Class Initialized
INFO - 2022-01-04 02:22:51 --> Output Class Initialized
INFO - 2022-01-04 02:22:51 --> Security Class Initialized
DEBUG - 2022-01-04 02:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:22:51 --> Input Class Initialized
INFO - 2022-01-04 02:22:51 --> Language Class Initialized
INFO - 2022-01-04 02:22:51 --> Loader Class Initialized
INFO - 2022-01-04 02:22:51 --> Helper loaded: url_helper
INFO - 2022-01-04 02:22:51 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:22:52 --> Controller Class Initialized
INFO - 2022-01-04 09:22:52 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:22:52 --> Model "UserModel" initialized
INFO - 2022-01-04 09:22:52 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:22:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:22:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:22:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:22:52 --> Final output sent to browser
DEBUG - 2022-01-04 09:22:52 --> Total execution time: 0.0547
INFO - 2022-01-04 02:22:53 --> Config Class Initialized
INFO - 2022-01-04 02:22:53 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:22:53 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:22:53 --> Utf8 Class Initialized
INFO - 2022-01-04 02:22:53 --> URI Class Initialized
INFO - 2022-01-04 02:22:53 --> Router Class Initialized
INFO - 2022-01-04 02:22:53 --> Output Class Initialized
INFO - 2022-01-04 02:22:53 --> Security Class Initialized
DEBUG - 2022-01-04 02:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:22:53 --> Input Class Initialized
INFO - 2022-01-04 02:22:53 --> Language Class Initialized
INFO - 2022-01-04 02:22:53 --> Loader Class Initialized
INFO - 2022-01-04 02:22:53 --> Helper loaded: url_helper
INFO - 2022-01-04 02:22:53 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:22:53 --> Controller Class Initialized
INFO - 2022-01-04 09:22:53 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:22:53 --> Model "UserModel" initialized
INFO - 2022-01-04 09:22:53 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:22:53 --> Final output sent to browser
DEBUG - 2022-01-04 09:22:53 --> Total execution time: 0.0476
INFO - 2022-01-04 02:22:54 --> Config Class Initialized
INFO - 2022-01-04 02:22:54 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:22:54 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:22:54 --> Utf8 Class Initialized
INFO - 2022-01-04 02:22:54 --> URI Class Initialized
INFO - 2022-01-04 02:22:54 --> Router Class Initialized
INFO - 2022-01-04 02:22:54 --> Output Class Initialized
INFO - 2022-01-04 02:22:54 --> Security Class Initialized
DEBUG - 2022-01-04 02:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:22:54 --> Input Class Initialized
INFO - 2022-01-04 02:22:54 --> Language Class Initialized
INFO - 2022-01-04 02:22:54 --> Loader Class Initialized
INFO - 2022-01-04 02:22:54 --> Helper loaded: url_helper
INFO - 2022-01-04 02:22:54 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:22:54 --> Controller Class Initialized
INFO - 2022-01-04 09:22:54 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:22:54 --> Model "UserModel" initialized
INFO - 2022-01-04 09:22:54 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:22:54 --> Final output sent to browser
DEBUG - 2022-01-04 09:22:54 --> Total execution time: 0.0493
INFO - 2022-01-04 02:22:58 --> Config Class Initialized
INFO - 2022-01-04 02:22:58 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:22:58 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:22:58 --> Utf8 Class Initialized
INFO - 2022-01-04 02:22:58 --> URI Class Initialized
INFO - 2022-01-04 02:22:58 --> Router Class Initialized
INFO - 2022-01-04 02:22:58 --> Output Class Initialized
INFO - 2022-01-04 02:22:58 --> Security Class Initialized
DEBUG - 2022-01-04 02:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:22:58 --> Input Class Initialized
INFO - 2022-01-04 02:22:58 --> Language Class Initialized
INFO - 2022-01-04 02:22:58 --> Loader Class Initialized
INFO - 2022-01-04 02:22:58 --> Helper loaded: url_helper
INFO - 2022-01-04 02:22:58 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:22:58 --> Controller Class Initialized
INFO - 2022-01-04 09:22:58 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:22:58 --> Model "UserModel" initialized
INFO - 2022-01-04 09:22:58 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:22:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:22:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:22:58 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:22:58 --> Final output sent to browser
DEBUG - 2022-01-04 09:22:58 --> Total execution time: 0.0564
INFO - 2022-01-04 02:22:59 --> Config Class Initialized
INFO - 2022-01-04 02:22:59 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:22:59 --> Utf8 Class Initialized
INFO - 2022-01-04 02:22:59 --> URI Class Initialized
INFO - 2022-01-04 02:22:59 --> Router Class Initialized
INFO - 2022-01-04 02:22:59 --> Output Class Initialized
INFO - 2022-01-04 02:22:59 --> Security Class Initialized
DEBUG - 2022-01-04 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:22:59 --> Input Class Initialized
INFO - 2022-01-04 02:22:59 --> Language Class Initialized
INFO - 2022-01-04 02:22:59 --> Loader Class Initialized
INFO - 2022-01-04 02:22:59 --> Helper loaded: url_helper
INFO - 2022-01-04 02:22:59 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:22:59 --> Controller Class Initialized
INFO - 2022-01-04 09:22:59 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:22:59 --> Model "UserModel" initialized
INFO - 2022-01-04 09:22:59 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:22:59 --> Final output sent to browser
DEBUG - 2022-01-04 09:22:59 --> Total execution time: 0.0433
INFO - 2022-01-04 02:24:00 --> Config Class Initialized
INFO - 2022-01-04 02:24:00 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:24:00 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:24:00 --> Utf8 Class Initialized
INFO - 2022-01-04 02:24:00 --> URI Class Initialized
INFO - 2022-01-04 02:24:00 --> Router Class Initialized
INFO - 2022-01-04 02:24:00 --> Output Class Initialized
INFO - 2022-01-04 02:24:00 --> Security Class Initialized
DEBUG - 2022-01-04 02:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:24:00 --> Input Class Initialized
INFO - 2022-01-04 02:24:00 --> Language Class Initialized
INFO - 2022-01-04 02:24:00 --> Loader Class Initialized
INFO - 2022-01-04 02:24:00 --> Helper loaded: url_helper
INFO - 2022-01-04 02:24:00 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:24:00 --> Controller Class Initialized
INFO - 2022-01-04 09:24:00 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:24:00 --> Model "UserModel" initialized
INFO - 2022-01-04 09:24:00 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:24:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:24:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:24:00 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:24:00 --> Final output sent to browser
DEBUG - 2022-01-04 09:24:00 --> Total execution time: 0.0696
INFO - 2022-01-04 02:24:01 --> Config Class Initialized
INFO - 2022-01-04 02:24:01 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:24:01 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:24:01 --> Utf8 Class Initialized
INFO - 2022-01-04 02:24:01 --> URI Class Initialized
INFO - 2022-01-04 02:24:01 --> Router Class Initialized
INFO - 2022-01-04 02:24:02 --> Output Class Initialized
INFO - 2022-01-04 02:24:02 --> Security Class Initialized
DEBUG - 2022-01-04 02:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:24:02 --> Input Class Initialized
INFO - 2022-01-04 02:24:02 --> Language Class Initialized
INFO - 2022-01-04 02:24:02 --> Loader Class Initialized
INFO - 2022-01-04 02:24:02 --> Helper loaded: url_helper
INFO - 2022-01-04 02:24:02 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:24:02 --> Controller Class Initialized
INFO - 2022-01-04 09:24:02 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:24:02 --> Model "UserModel" initialized
INFO - 2022-01-04 09:24:02 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:24:02 --> Final output sent to browser
DEBUG - 2022-01-04 09:24:02 --> Total execution time: 0.0556
INFO - 2022-01-04 02:24:03 --> Config Class Initialized
INFO - 2022-01-04 02:24:03 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:24:03 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:24:03 --> Utf8 Class Initialized
INFO - 2022-01-04 02:24:03 --> URI Class Initialized
INFO - 2022-01-04 02:24:03 --> Router Class Initialized
INFO - 2022-01-04 02:24:03 --> Output Class Initialized
INFO - 2022-01-04 02:24:03 --> Security Class Initialized
DEBUG - 2022-01-04 02:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:24:03 --> Input Class Initialized
INFO - 2022-01-04 02:24:03 --> Language Class Initialized
INFO - 2022-01-04 02:24:03 --> Loader Class Initialized
INFO - 2022-01-04 02:24:03 --> Helper loaded: url_helper
INFO - 2022-01-04 02:24:03 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:24:03 --> Controller Class Initialized
INFO - 2022-01-04 09:24:03 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:24:03 --> Model "UserModel" initialized
INFO - 2022-01-04 09:24:03 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:24:03 --> Final output sent to browser
DEBUG - 2022-01-04 09:24:03 --> Total execution time: 0.0492
INFO - 2022-01-04 02:24:24 --> Config Class Initialized
INFO - 2022-01-04 02:24:24 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:24:24 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:24:24 --> Utf8 Class Initialized
INFO - 2022-01-04 02:24:24 --> URI Class Initialized
INFO - 2022-01-04 02:24:24 --> Router Class Initialized
INFO - 2022-01-04 02:24:24 --> Output Class Initialized
INFO - 2022-01-04 02:24:24 --> Security Class Initialized
DEBUG - 2022-01-04 02:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:24:24 --> Input Class Initialized
INFO - 2022-01-04 02:24:24 --> Language Class Initialized
INFO - 2022-01-04 02:24:24 --> Loader Class Initialized
INFO - 2022-01-04 02:24:24 --> Helper loaded: url_helper
INFO - 2022-01-04 02:24:24 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:24:24 --> Controller Class Initialized
INFO - 2022-01-04 09:24:24 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:24:24 --> Model "UserModel" initialized
INFO - 2022-01-04 09:24:24 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:24:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:24:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:24:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:24:24 --> Final output sent to browser
DEBUG - 2022-01-04 09:24:24 --> Total execution time: 0.0499
INFO - 2022-01-04 02:24:25 --> Config Class Initialized
INFO - 2022-01-04 02:24:25 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:24:25 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:24:25 --> Utf8 Class Initialized
INFO - 2022-01-04 02:24:25 --> URI Class Initialized
INFO - 2022-01-04 02:24:25 --> Router Class Initialized
INFO - 2022-01-04 02:24:25 --> Output Class Initialized
INFO - 2022-01-04 02:24:25 --> Security Class Initialized
DEBUG - 2022-01-04 02:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:24:25 --> Input Class Initialized
INFO - 2022-01-04 02:24:25 --> Language Class Initialized
INFO - 2022-01-04 02:24:25 --> Loader Class Initialized
INFO - 2022-01-04 02:24:25 --> Helper loaded: url_helper
INFO - 2022-01-04 02:24:25 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:24:25 --> Controller Class Initialized
INFO - 2022-01-04 09:24:25 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:24:25 --> Model "UserModel" initialized
INFO - 2022-01-04 09:24:25 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:24:25 --> Final output sent to browser
DEBUG - 2022-01-04 09:24:25 --> Total execution time: 0.0506
INFO - 2022-01-04 02:24:28 --> Config Class Initialized
INFO - 2022-01-04 02:24:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:24:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:24:28 --> Utf8 Class Initialized
INFO - 2022-01-04 02:24:28 --> URI Class Initialized
INFO - 2022-01-04 02:24:28 --> Router Class Initialized
INFO - 2022-01-04 02:24:28 --> Output Class Initialized
INFO - 2022-01-04 02:24:28 --> Security Class Initialized
DEBUG - 2022-01-04 02:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:24:28 --> Input Class Initialized
INFO - 2022-01-04 02:24:28 --> Language Class Initialized
INFO - 2022-01-04 02:24:28 --> Loader Class Initialized
INFO - 2022-01-04 02:24:28 --> Helper loaded: url_helper
INFO - 2022-01-04 02:24:28 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:24:28 --> Controller Class Initialized
INFO - 2022-01-04 09:24:28 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:24:28 --> Model "UserModel" initialized
INFO - 2022-01-04 09:24:28 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:24:28 --> Final output sent to browser
DEBUG - 2022-01-04 09:24:28 --> Total execution time: 0.0509
INFO - 2022-01-04 02:26:06 --> Config Class Initialized
INFO - 2022-01-04 02:26:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:26:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:26:06 --> Utf8 Class Initialized
INFO - 2022-01-04 02:26:06 --> URI Class Initialized
INFO - 2022-01-04 02:26:06 --> Router Class Initialized
INFO - 2022-01-04 02:26:06 --> Output Class Initialized
INFO - 2022-01-04 02:26:06 --> Security Class Initialized
DEBUG - 2022-01-04 02:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:26:06 --> Input Class Initialized
INFO - 2022-01-04 02:26:06 --> Language Class Initialized
INFO - 2022-01-04 02:26:06 --> Loader Class Initialized
INFO - 2022-01-04 02:26:06 --> Helper loaded: url_helper
INFO - 2022-01-04 02:26:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:26:06 --> Controller Class Initialized
INFO - 2022-01-04 09:26:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:26:06 --> Model "UserModel" initialized
INFO - 2022-01-04 09:26:06 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:26:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:26:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:26:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:26:06 --> Final output sent to browser
DEBUG - 2022-01-04 09:26:06 --> Total execution time: 0.0607
INFO - 2022-01-04 02:26:09 --> Config Class Initialized
INFO - 2022-01-04 02:26:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:26:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:26:09 --> Utf8 Class Initialized
INFO - 2022-01-04 02:26:09 --> URI Class Initialized
INFO - 2022-01-04 02:26:09 --> Router Class Initialized
INFO - 2022-01-04 02:26:09 --> Output Class Initialized
INFO - 2022-01-04 02:26:09 --> Security Class Initialized
DEBUG - 2022-01-04 02:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:26:09 --> Input Class Initialized
INFO - 2022-01-04 02:26:09 --> Language Class Initialized
INFO - 2022-01-04 02:26:09 --> Loader Class Initialized
INFO - 2022-01-04 02:26:09 --> Helper loaded: url_helper
INFO - 2022-01-04 02:26:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:26:09 --> Controller Class Initialized
INFO - 2022-01-04 09:26:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:26:09 --> Model "UserModel" initialized
INFO - 2022-01-04 09:26:09 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:26:09 --> Final output sent to browser
DEBUG - 2022-01-04 09:26:09 --> Total execution time: 0.0459
INFO - 2022-01-04 02:26:15 --> Config Class Initialized
INFO - 2022-01-04 02:26:15 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:26:15 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:26:15 --> Utf8 Class Initialized
INFO - 2022-01-04 02:26:15 --> URI Class Initialized
INFO - 2022-01-04 02:26:15 --> Router Class Initialized
INFO - 2022-01-04 02:26:15 --> Output Class Initialized
INFO - 2022-01-04 02:26:15 --> Security Class Initialized
DEBUG - 2022-01-04 02:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:26:15 --> Input Class Initialized
INFO - 2022-01-04 02:26:15 --> Language Class Initialized
INFO - 2022-01-04 02:26:15 --> Loader Class Initialized
INFO - 2022-01-04 02:26:15 --> Helper loaded: url_helper
INFO - 2022-01-04 02:26:15 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:26:15 --> Controller Class Initialized
INFO - 2022-01-04 09:26:15 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:26:15 --> Model "UserModel" initialized
INFO - 2022-01-04 09:26:15 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:26:15 --> Final output sent to browser
DEBUG - 2022-01-04 09:26:15 --> Total execution time: 0.0583
INFO - 2022-01-04 02:26:33 --> Config Class Initialized
INFO - 2022-01-04 02:26:33 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:26:33 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:26:33 --> Utf8 Class Initialized
INFO - 2022-01-04 02:26:33 --> URI Class Initialized
INFO - 2022-01-04 02:26:33 --> Router Class Initialized
INFO - 2022-01-04 02:26:33 --> Output Class Initialized
INFO - 2022-01-04 02:26:33 --> Security Class Initialized
DEBUG - 2022-01-04 02:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:26:33 --> Input Class Initialized
INFO - 2022-01-04 02:26:33 --> Language Class Initialized
INFO - 2022-01-04 02:26:33 --> Loader Class Initialized
INFO - 2022-01-04 02:26:33 --> Helper loaded: url_helper
INFO - 2022-01-04 02:26:33 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:26:33 --> Controller Class Initialized
INFO - 2022-01-04 09:26:33 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:26:33 --> Model "UserModel" initialized
INFO - 2022-01-04 09:26:33 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:26:33 --> Final output sent to browser
DEBUG - 2022-01-04 09:26:33 --> Total execution time: 0.0522
INFO - 2022-01-04 02:26:53 --> Config Class Initialized
INFO - 2022-01-04 02:26:53 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:26:53 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:26:53 --> Utf8 Class Initialized
INFO - 2022-01-04 02:26:53 --> URI Class Initialized
INFO - 2022-01-04 02:26:53 --> Router Class Initialized
INFO - 2022-01-04 02:26:53 --> Output Class Initialized
INFO - 2022-01-04 02:26:53 --> Security Class Initialized
DEBUG - 2022-01-04 02:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:26:53 --> Input Class Initialized
INFO - 2022-01-04 02:26:53 --> Language Class Initialized
INFO - 2022-01-04 02:26:53 --> Loader Class Initialized
INFO - 2022-01-04 02:26:53 --> Helper loaded: url_helper
INFO - 2022-01-04 02:26:53 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:26:53 --> Controller Class Initialized
INFO - 2022-01-04 09:26:53 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:26:53 --> Model "UserModel" initialized
INFO - 2022-01-04 09:26:53 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:26:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:26:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:26:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:26:53 --> Final output sent to browser
DEBUG - 2022-01-04 09:26:53 --> Total execution time: 0.0541
INFO - 2022-01-04 02:26:56 --> Config Class Initialized
INFO - 2022-01-04 02:26:56 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:26:56 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:26:56 --> Utf8 Class Initialized
INFO - 2022-01-04 02:26:56 --> URI Class Initialized
INFO - 2022-01-04 02:26:56 --> Router Class Initialized
INFO - 2022-01-04 02:26:56 --> Output Class Initialized
INFO - 2022-01-04 02:26:56 --> Security Class Initialized
DEBUG - 2022-01-04 02:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:26:56 --> Input Class Initialized
INFO - 2022-01-04 02:26:56 --> Language Class Initialized
INFO - 2022-01-04 02:26:56 --> Loader Class Initialized
INFO - 2022-01-04 02:26:56 --> Helper loaded: url_helper
INFO - 2022-01-04 02:26:56 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:26:56 --> Controller Class Initialized
INFO - 2022-01-04 09:26:56 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:26:56 --> Model "UserModel" initialized
INFO - 2022-01-04 09:26:56 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:26:56 --> Final output sent to browser
DEBUG - 2022-01-04 09:26:56 --> Total execution time: 0.0505
INFO - 2022-01-04 02:27:30 --> Config Class Initialized
INFO - 2022-01-04 02:27:30 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:27:30 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:27:30 --> Utf8 Class Initialized
INFO - 2022-01-04 02:27:30 --> URI Class Initialized
INFO - 2022-01-04 02:27:30 --> Router Class Initialized
INFO - 2022-01-04 02:27:30 --> Output Class Initialized
INFO - 2022-01-04 02:27:30 --> Security Class Initialized
DEBUG - 2022-01-04 02:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:27:30 --> Input Class Initialized
INFO - 2022-01-04 02:27:30 --> Language Class Initialized
INFO - 2022-01-04 02:27:30 --> Loader Class Initialized
INFO - 2022-01-04 02:27:30 --> Helper loaded: url_helper
INFO - 2022-01-04 02:27:30 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:27:30 --> Controller Class Initialized
INFO - 2022-01-04 09:27:30 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:27:30 --> Model "UserModel" initialized
INFO - 2022-01-04 09:27:30 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:27:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:27:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:27:30 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:27:30 --> Final output sent to browser
DEBUG - 2022-01-04 09:27:30 --> Total execution time: 0.0547
INFO - 2022-01-04 02:27:53 --> Config Class Initialized
INFO - 2022-01-04 02:27:53 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:27:53 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:27:53 --> Utf8 Class Initialized
INFO - 2022-01-04 02:27:53 --> URI Class Initialized
INFO - 2022-01-04 02:27:53 --> Router Class Initialized
INFO - 2022-01-04 02:27:53 --> Output Class Initialized
INFO - 2022-01-04 02:27:53 --> Security Class Initialized
DEBUG - 2022-01-04 02:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:27:53 --> Input Class Initialized
INFO - 2022-01-04 02:27:53 --> Language Class Initialized
INFO - 2022-01-04 02:27:53 --> Loader Class Initialized
INFO - 2022-01-04 02:27:53 --> Helper loaded: url_helper
INFO - 2022-01-04 02:27:53 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:27:53 --> Controller Class Initialized
INFO - 2022-01-04 09:27:53 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:27:53 --> Model "UserModel" initialized
INFO - 2022-01-04 09:27:53 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:27:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:27:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:27:53 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:27:53 --> Final output sent to browser
DEBUG - 2022-01-04 09:27:53 --> Total execution time: 0.0501
INFO - 2022-01-04 02:27:59 --> Config Class Initialized
INFO - 2022-01-04 02:27:59 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:27:59 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:27:59 --> Utf8 Class Initialized
INFO - 2022-01-04 02:27:59 --> URI Class Initialized
INFO - 2022-01-04 02:27:59 --> Router Class Initialized
INFO - 2022-01-04 02:27:59 --> Output Class Initialized
INFO - 2022-01-04 02:27:59 --> Security Class Initialized
DEBUG - 2022-01-04 02:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:27:59 --> Input Class Initialized
INFO - 2022-01-04 02:27:59 --> Language Class Initialized
INFO - 2022-01-04 02:27:59 --> Loader Class Initialized
INFO - 2022-01-04 02:27:59 --> Helper loaded: url_helper
INFO - 2022-01-04 02:27:59 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:27:59 --> Controller Class Initialized
INFO - 2022-01-04 09:27:59 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:27:59 --> Model "UserModel" initialized
INFO - 2022-01-04 09:27:59 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:27:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:27:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:27:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:27:59 --> Final output sent to browser
DEBUG - 2022-01-04 09:27:59 --> Total execution time: 0.0891
INFO - 2022-01-04 02:28:27 --> Config Class Initialized
INFO - 2022-01-04 02:28:27 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:28:27 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:28:27 --> Utf8 Class Initialized
INFO - 2022-01-04 02:28:27 --> URI Class Initialized
INFO - 2022-01-04 02:28:27 --> Router Class Initialized
INFO - 2022-01-04 02:28:27 --> Output Class Initialized
INFO - 2022-01-04 02:28:27 --> Security Class Initialized
DEBUG - 2022-01-04 02:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:28:27 --> Input Class Initialized
INFO - 2022-01-04 02:28:27 --> Language Class Initialized
INFO - 2022-01-04 02:28:27 --> Loader Class Initialized
INFO - 2022-01-04 02:28:27 --> Helper loaded: url_helper
INFO - 2022-01-04 02:28:27 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:28:27 --> Controller Class Initialized
INFO - 2022-01-04 09:28:27 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:28:27 --> Model "UserModel" initialized
INFO - 2022-01-04 09:28:27 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:28:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:28:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:28:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:28:27 --> Final output sent to browser
DEBUG - 2022-01-04 09:28:27 --> Total execution time: 0.0643
INFO - 2022-01-04 02:28:29 --> Config Class Initialized
INFO - 2022-01-04 02:28:29 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:28:29 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:28:29 --> Utf8 Class Initialized
INFO - 2022-01-04 02:28:29 --> URI Class Initialized
INFO - 2022-01-04 02:28:29 --> Router Class Initialized
INFO - 2022-01-04 02:28:29 --> Output Class Initialized
INFO - 2022-01-04 02:28:29 --> Security Class Initialized
DEBUG - 2022-01-04 02:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:28:29 --> Input Class Initialized
INFO - 2022-01-04 02:28:29 --> Language Class Initialized
INFO - 2022-01-04 02:28:29 --> Loader Class Initialized
INFO - 2022-01-04 02:28:29 --> Helper loaded: url_helper
INFO - 2022-01-04 02:28:29 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:28:29 --> Controller Class Initialized
INFO - 2022-01-04 09:28:29 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:28:29 --> Model "UserModel" initialized
INFO - 2022-01-04 09:28:29 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:28:29 --> Final output sent to browser
DEBUG - 2022-01-04 09:28:29 --> Total execution time: 0.0463
INFO - 2022-01-04 02:28:50 --> Config Class Initialized
INFO - 2022-01-04 02:28:50 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:28:50 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:28:50 --> Utf8 Class Initialized
INFO - 2022-01-04 02:28:50 --> URI Class Initialized
INFO - 2022-01-04 02:28:50 --> Router Class Initialized
INFO - 2022-01-04 02:28:50 --> Output Class Initialized
INFO - 2022-01-04 02:28:50 --> Security Class Initialized
DEBUG - 2022-01-04 02:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:28:50 --> Input Class Initialized
INFO - 2022-01-04 02:28:50 --> Language Class Initialized
INFO - 2022-01-04 02:28:50 --> Loader Class Initialized
INFO - 2022-01-04 02:28:50 --> Helper loaded: url_helper
INFO - 2022-01-04 02:28:50 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:28:50 --> Controller Class Initialized
INFO - 2022-01-04 09:28:50 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:28:50 --> Model "UserModel" initialized
INFO - 2022-01-04 09:28:50 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:28:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:28:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:28:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:28:50 --> Final output sent to browser
DEBUG - 2022-01-04 09:28:50 --> Total execution time: 0.0706
INFO - 2022-01-04 02:28:52 --> Config Class Initialized
INFO - 2022-01-04 02:28:52 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:28:52 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:28:52 --> Utf8 Class Initialized
INFO - 2022-01-04 02:28:52 --> URI Class Initialized
INFO - 2022-01-04 02:28:52 --> Router Class Initialized
INFO - 2022-01-04 02:28:52 --> Output Class Initialized
INFO - 2022-01-04 02:28:52 --> Security Class Initialized
DEBUG - 2022-01-04 02:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:28:52 --> Input Class Initialized
INFO - 2022-01-04 02:28:52 --> Language Class Initialized
INFO - 2022-01-04 02:28:52 --> Loader Class Initialized
INFO - 2022-01-04 02:28:52 --> Helper loaded: url_helper
INFO - 2022-01-04 02:28:52 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:28:52 --> Controller Class Initialized
INFO - 2022-01-04 09:28:52 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:28:52 --> Model "UserModel" initialized
INFO - 2022-01-04 09:28:52 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:28:52 --> Final output sent to browser
DEBUG - 2022-01-04 09:28:52 --> Total execution time: 0.0466
INFO - 2022-01-04 02:29:05 --> Config Class Initialized
INFO - 2022-01-04 02:29:05 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:29:05 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:29:05 --> Utf8 Class Initialized
INFO - 2022-01-04 02:29:05 --> URI Class Initialized
INFO - 2022-01-04 02:29:05 --> Router Class Initialized
INFO - 2022-01-04 02:29:05 --> Output Class Initialized
INFO - 2022-01-04 02:29:05 --> Security Class Initialized
DEBUG - 2022-01-04 02:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:29:05 --> Input Class Initialized
INFO - 2022-01-04 02:29:05 --> Language Class Initialized
INFO - 2022-01-04 02:29:05 --> Loader Class Initialized
INFO - 2022-01-04 02:29:05 --> Helper loaded: url_helper
INFO - 2022-01-04 02:29:05 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:29:05 --> Controller Class Initialized
INFO - 2022-01-04 09:29:05 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:29:05 --> Model "UserModel" initialized
INFO - 2022-01-04 09:29:05 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:29:05 --> Final output sent to browser
DEBUG - 2022-01-04 09:29:05 --> Total execution time: 0.0507
INFO - 2022-01-04 02:29:31 --> Config Class Initialized
INFO - 2022-01-04 02:29:31 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:29:31 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:29:31 --> Utf8 Class Initialized
INFO - 2022-01-04 02:29:31 --> URI Class Initialized
INFO - 2022-01-04 02:29:31 --> Router Class Initialized
INFO - 2022-01-04 02:29:31 --> Output Class Initialized
INFO - 2022-01-04 02:29:31 --> Security Class Initialized
DEBUG - 2022-01-04 02:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:29:31 --> Input Class Initialized
INFO - 2022-01-04 02:29:31 --> Language Class Initialized
INFO - 2022-01-04 02:29:31 --> Loader Class Initialized
INFO - 2022-01-04 02:29:31 --> Helper loaded: url_helper
INFO - 2022-01-04 02:29:31 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:29:31 --> Controller Class Initialized
INFO - 2022-01-04 09:29:31 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:29:31 --> Model "UserModel" initialized
INFO - 2022-01-04 09:29:31 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:29:31 --> Final output sent to browser
DEBUG - 2022-01-04 09:29:31 --> Total execution time: 0.0637
INFO - 2022-01-04 02:30:57 --> Config Class Initialized
INFO - 2022-01-04 02:30:57 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:30:57 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:30:57 --> Utf8 Class Initialized
INFO - 2022-01-04 02:30:57 --> URI Class Initialized
INFO - 2022-01-04 02:30:57 --> Router Class Initialized
INFO - 2022-01-04 02:30:57 --> Output Class Initialized
INFO - 2022-01-04 02:30:57 --> Security Class Initialized
DEBUG - 2022-01-04 02:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:30:57 --> Input Class Initialized
INFO - 2022-01-04 02:30:57 --> Language Class Initialized
INFO - 2022-01-04 02:30:57 --> Loader Class Initialized
INFO - 2022-01-04 02:30:57 --> Helper loaded: url_helper
INFO - 2022-01-04 02:30:57 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:30:57 --> Controller Class Initialized
INFO - 2022-01-04 09:30:57 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:30:57 --> Model "UserModel" initialized
INFO - 2022-01-04 09:30:57 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:30:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:30:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:30:57 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:30:57 --> Final output sent to browser
DEBUG - 2022-01-04 09:30:57 --> Total execution time: 0.0764
INFO - 2022-01-04 02:30:59 --> Config Class Initialized
INFO - 2022-01-04 02:30:59 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:30:59 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:30:59 --> Utf8 Class Initialized
INFO - 2022-01-04 02:30:59 --> URI Class Initialized
INFO - 2022-01-04 02:30:59 --> Router Class Initialized
INFO - 2022-01-04 02:30:59 --> Output Class Initialized
INFO - 2022-01-04 02:30:59 --> Security Class Initialized
DEBUG - 2022-01-04 02:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:30:59 --> Input Class Initialized
INFO - 2022-01-04 02:30:59 --> Language Class Initialized
INFO - 2022-01-04 02:30:59 --> Loader Class Initialized
INFO - 2022-01-04 02:30:59 --> Helper loaded: url_helper
INFO - 2022-01-04 02:30:59 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:30:59 --> Controller Class Initialized
INFO - 2022-01-04 09:30:59 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:30:59 --> Model "UserModel" initialized
INFO - 2022-01-04 09:30:59 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:30:59 --> Final output sent to browser
DEBUG - 2022-01-04 09:30:59 --> Total execution time: 0.0541
INFO - 2022-01-04 02:31:04 --> Config Class Initialized
INFO - 2022-01-04 02:31:04 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:31:04 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:31:04 --> Utf8 Class Initialized
INFO - 2022-01-04 02:31:04 --> URI Class Initialized
INFO - 2022-01-04 02:31:04 --> Router Class Initialized
INFO - 2022-01-04 02:31:04 --> Output Class Initialized
INFO - 2022-01-04 02:31:04 --> Security Class Initialized
DEBUG - 2022-01-04 02:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:31:04 --> Input Class Initialized
INFO - 2022-01-04 02:31:04 --> Language Class Initialized
INFO - 2022-01-04 02:31:04 --> Loader Class Initialized
INFO - 2022-01-04 02:31:04 --> Helper loaded: url_helper
INFO - 2022-01-04 02:31:04 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:31:04 --> Controller Class Initialized
INFO - 2022-01-04 09:31:04 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:31:04 --> Model "UserModel" initialized
INFO - 2022-01-04 09:31:04 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:31:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:31:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:31:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:31:04 --> Final output sent to browser
DEBUG - 2022-01-04 09:31:04 --> Total execution time: 0.0691
INFO - 2022-01-04 02:31:05 --> Config Class Initialized
INFO - 2022-01-04 02:31:05 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:31:05 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:31:05 --> Utf8 Class Initialized
INFO - 2022-01-04 02:31:05 --> URI Class Initialized
INFO - 2022-01-04 02:31:05 --> Router Class Initialized
INFO - 2022-01-04 02:31:05 --> Output Class Initialized
INFO - 2022-01-04 02:31:05 --> Security Class Initialized
DEBUG - 2022-01-04 02:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:31:05 --> Input Class Initialized
INFO - 2022-01-04 02:31:05 --> Language Class Initialized
INFO - 2022-01-04 02:31:05 --> Loader Class Initialized
INFO - 2022-01-04 02:31:05 --> Helper loaded: url_helper
INFO - 2022-01-04 02:31:05 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:31:05 --> Controller Class Initialized
INFO - 2022-01-04 09:31:05 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:31:05 --> Model "UserModel" initialized
INFO - 2022-01-04 09:31:05 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:31:05 --> Final output sent to browser
DEBUG - 2022-01-04 09:31:05 --> Total execution time: 0.0623
INFO - 2022-01-04 02:36:24 --> Config Class Initialized
INFO - 2022-01-04 02:36:24 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:36:24 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:36:24 --> Utf8 Class Initialized
INFO - 2022-01-04 02:36:24 --> URI Class Initialized
INFO - 2022-01-04 02:36:24 --> Router Class Initialized
INFO - 2022-01-04 02:36:24 --> Output Class Initialized
INFO - 2022-01-04 02:36:24 --> Security Class Initialized
DEBUG - 2022-01-04 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:36:24 --> Input Class Initialized
INFO - 2022-01-04 02:36:24 --> Language Class Initialized
INFO - 2022-01-04 02:36:24 --> Loader Class Initialized
INFO - 2022-01-04 02:36:24 --> Helper loaded: url_helper
INFO - 2022-01-04 02:36:24 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:36:24 --> Controller Class Initialized
INFO - 2022-01-04 09:36:24 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:36:24 --> Model "UserModel" initialized
INFO - 2022-01-04 09:36:24 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:36:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:36:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:36:24 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:36:24 --> Final output sent to browser
DEBUG - 2022-01-04 09:36:24 --> Total execution time: 0.0745
INFO - 2022-01-04 02:36:25 --> Config Class Initialized
INFO - 2022-01-04 02:36:25 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:36:25 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:36:25 --> Utf8 Class Initialized
INFO - 2022-01-04 02:36:25 --> URI Class Initialized
INFO - 2022-01-04 02:36:25 --> Router Class Initialized
INFO - 2022-01-04 02:36:25 --> Output Class Initialized
INFO - 2022-01-04 02:36:25 --> Security Class Initialized
DEBUG - 2022-01-04 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:36:25 --> Input Class Initialized
INFO - 2022-01-04 02:36:25 --> Language Class Initialized
INFO - 2022-01-04 02:36:25 --> Loader Class Initialized
INFO - 2022-01-04 02:36:25 --> Helper loaded: url_helper
INFO - 2022-01-04 02:36:25 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:36:25 --> Controller Class Initialized
INFO - 2022-01-04 09:36:25 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:36:25 --> Model "UserModel" initialized
INFO - 2022-01-04 09:36:25 --> Model "AdminModel" initialized
ERROR - 2022-01-04 09:36:25 --> Severity: Warning --> Undefined variable $date_created C:\xampp\htdocs\OJT\application\controllers\Admin.php 88
INFO - 2022-01-04 09:36:25 --> Final output sent to browser
DEBUG - 2022-01-04 09:36:25 --> Total execution time: 0.0576
INFO - 2022-01-04 02:36:36 --> Config Class Initialized
INFO - 2022-01-04 02:36:36 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:36:36 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:36:36 --> Utf8 Class Initialized
INFO - 2022-01-04 02:36:36 --> URI Class Initialized
INFO - 2022-01-04 02:36:36 --> Router Class Initialized
INFO - 2022-01-04 02:36:36 --> Output Class Initialized
INFO - 2022-01-04 02:36:36 --> Security Class Initialized
DEBUG - 2022-01-04 02:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:36:36 --> Input Class Initialized
INFO - 2022-01-04 02:36:36 --> Language Class Initialized
INFO - 2022-01-04 02:36:36 --> Loader Class Initialized
INFO - 2022-01-04 02:36:36 --> Helper loaded: url_helper
INFO - 2022-01-04 02:36:36 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:36:36 --> Controller Class Initialized
INFO - 2022-01-04 09:36:36 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:36:36 --> Model "UserModel" initialized
INFO - 2022-01-04 09:36:36 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:36:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:36:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:36:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:36:36 --> Final output sent to browser
DEBUG - 2022-01-04 09:36:36 --> Total execution time: 0.0847
INFO - 2022-01-04 02:36:40 --> Config Class Initialized
INFO - 2022-01-04 02:36:40 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:36:40 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:36:40 --> Utf8 Class Initialized
INFO - 2022-01-04 02:36:40 --> URI Class Initialized
INFO - 2022-01-04 02:36:40 --> Router Class Initialized
INFO - 2022-01-04 02:36:40 --> Output Class Initialized
INFO - 2022-01-04 02:36:40 --> Security Class Initialized
DEBUG - 2022-01-04 02:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:36:40 --> Input Class Initialized
INFO - 2022-01-04 02:36:40 --> Language Class Initialized
INFO - 2022-01-04 02:36:40 --> Loader Class Initialized
INFO - 2022-01-04 02:36:40 --> Helper loaded: url_helper
INFO - 2022-01-04 02:36:40 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:36:40 --> Controller Class Initialized
INFO - 2022-01-04 09:36:40 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:36:40 --> Model "UserModel" initialized
INFO - 2022-01-04 09:36:40 --> Model "AdminModel" initialized
ERROR - 2022-01-04 09:36:40 --> Severity: Warning --> Undefined variable $date_created C:\xampp\htdocs\OJT\application\controllers\Admin.php 88
INFO - 2022-01-04 09:36:40 --> Final output sent to browser
DEBUG - 2022-01-04 09:36:40 --> Total execution time: 0.0706
INFO - 2022-01-04 02:37:09 --> Config Class Initialized
INFO - 2022-01-04 02:37:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:37:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:37:09 --> Utf8 Class Initialized
INFO - 2022-01-04 02:37:09 --> URI Class Initialized
INFO - 2022-01-04 02:37:09 --> Router Class Initialized
INFO - 2022-01-04 02:37:09 --> Output Class Initialized
INFO - 2022-01-04 02:37:09 --> Security Class Initialized
DEBUG - 2022-01-04 02:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:37:09 --> Input Class Initialized
INFO - 2022-01-04 02:37:09 --> Language Class Initialized
INFO - 2022-01-04 02:37:09 --> Loader Class Initialized
INFO - 2022-01-04 02:37:09 --> Helper loaded: url_helper
INFO - 2022-01-04 02:37:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:37:09 --> Controller Class Initialized
INFO - 2022-01-04 09:37:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:37:09 --> Model "UserModel" initialized
INFO - 2022-01-04 09:37:09 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:37:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:37:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:37:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:37:09 --> Final output sent to browser
DEBUG - 2022-01-04 09:37:09 --> Total execution time: 0.0754
INFO - 2022-01-04 02:37:11 --> Config Class Initialized
INFO - 2022-01-04 02:37:11 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:37:11 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:37:11 --> Utf8 Class Initialized
INFO - 2022-01-04 02:37:11 --> URI Class Initialized
INFO - 2022-01-04 02:37:11 --> Router Class Initialized
INFO - 2022-01-04 02:37:11 --> Output Class Initialized
INFO - 2022-01-04 02:37:11 --> Security Class Initialized
DEBUG - 2022-01-04 02:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:37:11 --> Input Class Initialized
INFO - 2022-01-04 02:37:11 --> Language Class Initialized
INFO - 2022-01-04 02:37:11 --> Loader Class Initialized
INFO - 2022-01-04 02:37:11 --> Helper loaded: url_helper
INFO - 2022-01-04 02:37:11 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:37:11 --> Controller Class Initialized
INFO - 2022-01-04 09:37:11 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:37:11 --> Model "UserModel" initialized
INFO - 2022-01-04 09:37:11 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:37:11 --> Final output sent to browser
DEBUG - 2022-01-04 09:37:11 --> Total execution time: 0.0658
INFO - 2022-01-04 02:37:13 --> Config Class Initialized
INFO - 2022-01-04 02:37:13 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:37:13 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:37:13 --> Utf8 Class Initialized
INFO - 2022-01-04 02:37:13 --> URI Class Initialized
INFO - 2022-01-04 02:37:13 --> Router Class Initialized
INFO - 2022-01-04 02:37:13 --> Output Class Initialized
INFO - 2022-01-04 02:37:13 --> Security Class Initialized
DEBUG - 2022-01-04 02:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:37:13 --> Input Class Initialized
INFO - 2022-01-04 02:37:13 --> Language Class Initialized
INFO - 2022-01-04 02:37:13 --> Loader Class Initialized
INFO - 2022-01-04 02:37:14 --> Helper loaded: url_helper
INFO - 2022-01-04 02:37:14 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:37:14 --> Controller Class Initialized
INFO - 2022-01-04 09:37:14 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:37:14 --> Model "UserModel" initialized
INFO - 2022-01-04 09:37:14 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:37:14 --> Final output sent to browser
DEBUG - 2022-01-04 09:37:14 --> Total execution time: 0.0703
INFO - 2022-01-04 02:37:14 --> Config Class Initialized
INFO - 2022-01-04 02:37:14 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:37:14 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:37:14 --> Utf8 Class Initialized
INFO - 2022-01-04 02:37:14 --> URI Class Initialized
INFO - 2022-01-04 02:37:14 --> Router Class Initialized
INFO - 2022-01-04 02:37:14 --> Output Class Initialized
INFO - 2022-01-04 02:37:14 --> Security Class Initialized
DEBUG - 2022-01-04 02:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:37:14 --> Input Class Initialized
INFO - 2022-01-04 02:37:14 --> Language Class Initialized
INFO - 2022-01-04 02:37:14 --> Loader Class Initialized
INFO - 2022-01-04 02:37:14 --> Helper loaded: url_helper
INFO - 2022-01-04 02:37:14 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:37:14 --> Controller Class Initialized
INFO - 2022-01-04 09:37:14 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:37:14 --> Model "UserModel" initialized
INFO - 2022-01-04 09:37:14 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:37:14 --> Final output sent to browser
DEBUG - 2022-01-04 09:37:14 --> Total execution time: 0.0634
INFO - 2022-01-04 02:37:17 --> Config Class Initialized
INFO - 2022-01-04 02:37:17 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:37:17 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:37:17 --> Utf8 Class Initialized
INFO - 2022-01-04 02:37:17 --> URI Class Initialized
INFO - 2022-01-04 02:37:17 --> Router Class Initialized
INFO - 2022-01-04 02:37:17 --> Output Class Initialized
INFO - 2022-01-04 02:37:17 --> Security Class Initialized
DEBUG - 2022-01-04 02:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:37:17 --> Input Class Initialized
INFO - 2022-01-04 02:37:17 --> Language Class Initialized
INFO - 2022-01-04 02:37:17 --> Loader Class Initialized
INFO - 2022-01-04 02:37:17 --> Helper loaded: url_helper
INFO - 2022-01-04 02:37:17 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:37:17 --> Controller Class Initialized
INFO - 2022-01-04 09:37:17 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:37:17 --> Model "UserModel" initialized
INFO - 2022-01-04 09:37:17 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:37:17 --> Final output sent to browser
DEBUG - 2022-01-04 09:37:17 --> Total execution time: 0.0463
INFO - 2022-01-04 02:37:19 --> Config Class Initialized
INFO - 2022-01-04 02:37:19 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:37:19 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:37:19 --> Utf8 Class Initialized
INFO - 2022-01-04 02:37:19 --> URI Class Initialized
INFO - 2022-01-04 02:37:19 --> Router Class Initialized
INFO - 2022-01-04 02:37:19 --> Output Class Initialized
INFO - 2022-01-04 02:37:19 --> Security Class Initialized
DEBUG - 2022-01-04 02:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:37:19 --> Input Class Initialized
INFO - 2022-01-04 02:37:19 --> Language Class Initialized
INFO - 2022-01-04 02:37:19 --> Loader Class Initialized
INFO - 2022-01-04 02:37:19 --> Helper loaded: url_helper
INFO - 2022-01-04 02:37:19 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:37:19 --> Controller Class Initialized
INFO - 2022-01-04 09:37:19 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:37:19 --> Model "UserModel" initialized
INFO - 2022-01-04 09:37:19 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:37:19 --> Final output sent to browser
DEBUG - 2022-01-04 09:37:19 --> Total execution time: 0.0497
INFO - 2022-01-04 02:37:20 --> Config Class Initialized
INFO - 2022-01-04 02:37:20 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:37:20 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:37:20 --> Utf8 Class Initialized
INFO - 2022-01-04 02:37:20 --> URI Class Initialized
INFO - 2022-01-04 02:37:20 --> Router Class Initialized
INFO - 2022-01-04 02:37:20 --> Output Class Initialized
INFO - 2022-01-04 02:37:20 --> Security Class Initialized
DEBUG - 2022-01-04 02:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:37:20 --> Input Class Initialized
INFO - 2022-01-04 02:37:20 --> Language Class Initialized
INFO - 2022-01-04 02:37:20 --> Loader Class Initialized
INFO - 2022-01-04 02:37:20 --> Helper loaded: url_helper
INFO - 2022-01-04 02:37:20 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:37:20 --> Controller Class Initialized
INFO - 2022-01-04 09:37:20 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:37:20 --> Model "UserModel" initialized
INFO - 2022-01-04 09:37:20 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:37:20 --> Final output sent to browser
DEBUG - 2022-01-04 09:37:20 --> Total execution time: 0.0498
INFO - 2022-01-04 02:37:25 --> Config Class Initialized
INFO - 2022-01-04 02:37:25 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:37:25 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:37:25 --> Utf8 Class Initialized
INFO - 2022-01-04 02:37:25 --> URI Class Initialized
INFO - 2022-01-04 02:37:25 --> Router Class Initialized
INFO - 2022-01-04 02:37:25 --> Output Class Initialized
INFO - 2022-01-04 02:37:25 --> Security Class Initialized
DEBUG - 2022-01-04 02:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:37:25 --> Input Class Initialized
INFO - 2022-01-04 02:37:25 --> Language Class Initialized
INFO - 2022-01-04 02:37:25 --> Loader Class Initialized
INFO - 2022-01-04 02:37:25 --> Helper loaded: url_helper
INFO - 2022-01-04 02:37:25 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:37:25 --> Controller Class Initialized
INFO - 2022-01-04 09:37:25 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:37:25 --> Model "UserModel" initialized
INFO - 2022-01-04 09:37:25 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:37:25 --> Final output sent to browser
DEBUG - 2022-01-04 09:37:25 --> Total execution time: 0.0526
INFO - 2022-01-04 02:43:27 --> Config Class Initialized
INFO - 2022-01-04 02:43:27 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:43:27 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:43:27 --> Utf8 Class Initialized
INFO - 2022-01-04 02:43:27 --> URI Class Initialized
INFO - 2022-01-04 02:43:27 --> Router Class Initialized
INFO - 2022-01-04 02:43:27 --> Output Class Initialized
INFO - 2022-01-04 02:43:27 --> Security Class Initialized
DEBUG - 2022-01-04 02:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:43:27 --> Input Class Initialized
INFO - 2022-01-04 02:43:27 --> Language Class Initialized
INFO - 2022-01-04 02:43:27 --> Loader Class Initialized
INFO - 2022-01-04 02:43:27 --> Helper loaded: url_helper
INFO - 2022-01-04 02:43:27 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:43:27 --> Controller Class Initialized
INFO - 2022-01-04 09:43:27 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:43:27 --> Model "UserModel" initialized
INFO - 2022-01-04 09:43:27 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:43:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:43:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:43:27 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:43:27 --> Final output sent to browser
DEBUG - 2022-01-04 09:43:27 --> Total execution time: 0.0716
INFO - 2022-01-04 02:43:28 --> Config Class Initialized
INFO - 2022-01-04 02:43:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:43:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:43:28 --> Utf8 Class Initialized
INFO - 2022-01-04 02:43:28 --> URI Class Initialized
INFO - 2022-01-04 02:43:28 --> Router Class Initialized
INFO - 2022-01-04 02:43:28 --> Output Class Initialized
INFO - 2022-01-04 02:43:28 --> Security Class Initialized
DEBUG - 2022-01-04 02:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:43:28 --> Input Class Initialized
INFO - 2022-01-04 02:43:28 --> Language Class Initialized
INFO - 2022-01-04 02:43:28 --> Loader Class Initialized
INFO - 2022-01-04 02:43:28 --> Helper loaded: url_helper
INFO - 2022-01-04 02:43:28 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:43:28 --> Controller Class Initialized
INFO - 2022-01-04 09:43:28 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:43:28 --> Model "UserModel" initialized
INFO - 2022-01-04 09:43:28 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:43:28 --> Final output sent to browser
DEBUG - 2022-01-04 09:43:28 --> Total execution time: 0.0597
INFO - 2022-01-04 02:43:29 --> Config Class Initialized
INFO - 2022-01-04 02:43:29 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:43:29 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:43:29 --> Utf8 Class Initialized
INFO - 2022-01-04 02:43:29 --> URI Class Initialized
INFO - 2022-01-04 02:43:29 --> Router Class Initialized
INFO - 2022-01-04 02:43:29 --> Output Class Initialized
INFO - 2022-01-04 02:43:29 --> Security Class Initialized
DEBUG - 2022-01-04 02:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:43:29 --> Input Class Initialized
INFO - 2022-01-04 02:43:29 --> Language Class Initialized
INFO - 2022-01-04 02:43:29 --> Loader Class Initialized
INFO - 2022-01-04 02:43:29 --> Helper loaded: url_helper
INFO - 2022-01-04 02:43:29 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:43:29 --> Controller Class Initialized
INFO - 2022-01-04 09:43:29 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:43:29 --> Model "UserModel" initialized
INFO - 2022-01-04 09:43:29 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:43:29 --> Final output sent to browser
DEBUG - 2022-01-04 09:43:29 --> Total execution time: 0.0527
INFO - 2022-01-04 02:44:09 --> Config Class Initialized
INFO - 2022-01-04 02:44:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:44:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:44:09 --> Utf8 Class Initialized
INFO - 2022-01-04 02:44:09 --> URI Class Initialized
INFO - 2022-01-04 02:44:09 --> Router Class Initialized
INFO - 2022-01-04 02:44:09 --> Output Class Initialized
INFO - 2022-01-04 02:44:09 --> Security Class Initialized
DEBUG - 2022-01-04 02:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:44:09 --> Input Class Initialized
INFO - 2022-01-04 02:44:09 --> Language Class Initialized
INFO - 2022-01-04 02:44:09 --> Loader Class Initialized
INFO - 2022-01-04 02:44:09 --> Helper loaded: url_helper
INFO - 2022-01-04 02:44:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:44:09 --> Controller Class Initialized
INFO - 2022-01-04 09:44:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:44:09 --> Model "UserModel" initialized
INFO - 2022-01-04 09:44:09 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:44:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:44:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:44:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:44:09 --> Final output sent to browser
DEBUG - 2022-01-04 09:44:09 --> Total execution time: 0.0693
INFO - 2022-01-04 02:44:11 --> Config Class Initialized
INFO - 2022-01-04 02:44:11 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:44:11 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:44:11 --> Utf8 Class Initialized
INFO - 2022-01-04 02:44:11 --> URI Class Initialized
INFO - 2022-01-04 02:44:11 --> Router Class Initialized
INFO - 2022-01-04 02:44:11 --> Output Class Initialized
INFO - 2022-01-04 02:44:11 --> Security Class Initialized
DEBUG - 2022-01-04 02:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:44:11 --> Input Class Initialized
INFO - 2022-01-04 02:44:11 --> Language Class Initialized
INFO - 2022-01-04 02:44:11 --> Loader Class Initialized
INFO - 2022-01-04 02:44:11 --> Helper loaded: url_helper
INFO - 2022-01-04 02:44:11 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:44:11 --> Controller Class Initialized
INFO - 2022-01-04 09:44:11 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:44:11 --> Model "UserModel" initialized
INFO - 2022-01-04 09:44:11 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:44:11 --> Final output sent to browser
DEBUG - 2022-01-04 09:44:11 --> Total execution time: 0.0533
INFO - 2022-01-04 02:44:18 --> Config Class Initialized
INFO - 2022-01-04 02:44:18 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:44:18 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:44:18 --> Utf8 Class Initialized
INFO - 2022-01-04 02:44:18 --> URI Class Initialized
INFO - 2022-01-04 02:44:18 --> Router Class Initialized
INFO - 2022-01-04 02:44:18 --> Output Class Initialized
INFO - 2022-01-04 02:44:18 --> Security Class Initialized
DEBUG - 2022-01-04 02:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:44:18 --> Input Class Initialized
INFO - 2022-01-04 02:44:18 --> Language Class Initialized
INFO - 2022-01-04 02:44:18 --> Loader Class Initialized
INFO - 2022-01-04 02:44:18 --> Helper loaded: url_helper
INFO - 2022-01-04 02:44:18 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:44:18 --> Controller Class Initialized
INFO - 2022-01-04 09:44:18 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:44:18 --> Model "UserModel" initialized
INFO - 2022-01-04 09:44:18 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:44:18 --> Final output sent to browser
DEBUG - 2022-01-04 09:44:18 --> Total execution time: 0.0742
INFO - 2022-01-04 02:45:20 --> Config Class Initialized
INFO - 2022-01-04 02:45:20 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:45:21 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:45:21 --> Utf8 Class Initialized
INFO - 2022-01-04 02:45:21 --> URI Class Initialized
INFO - 2022-01-04 02:45:21 --> Router Class Initialized
INFO - 2022-01-04 02:45:21 --> Output Class Initialized
INFO - 2022-01-04 02:45:21 --> Security Class Initialized
DEBUG - 2022-01-04 02:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:45:21 --> Input Class Initialized
INFO - 2022-01-04 02:45:21 --> Language Class Initialized
INFO - 2022-01-04 02:45:21 --> Loader Class Initialized
INFO - 2022-01-04 02:45:21 --> Helper loaded: url_helper
INFO - 2022-01-04 02:45:21 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:45:21 --> Controller Class Initialized
INFO - 2022-01-04 09:45:21 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:45:21 --> Model "UserModel" initialized
INFO - 2022-01-04 09:45:21 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:45:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:45:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:45:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:45:21 --> Final output sent to browser
DEBUG - 2022-01-04 09:45:21 --> Total execution time: 0.0760
INFO - 2022-01-04 02:45:21 --> Config Class Initialized
INFO - 2022-01-04 02:45:21 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:45:22 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:45:22 --> Utf8 Class Initialized
INFO - 2022-01-04 02:45:22 --> URI Class Initialized
INFO - 2022-01-04 02:45:22 --> Router Class Initialized
INFO - 2022-01-04 02:45:22 --> Output Class Initialized
INFO - 2022-01-04 02:45:22 --> Security Class Initialized
DEBUG - 2022-01-04 02:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:45:22 --> Input Class Initialized
INFO - 2022-01-04 02:45:22 --> Language Class Initialized
INFO - 2022-01-04 02:45:22 --> Loader Class Initialized
INFO - 2022-01-04 02:45:22 --> Helper loaded: url_helper
INFO - 2022-01-04 02:45:22 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:45:22 --> Controller Class Initialized
INFO - 2022-01-04 09:45:22 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:45:22 --> Model "UserModel" initialized
INFO - 2022-01-04 09:45:22 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:45:22 --> Final output sent to browser
DEBUG - 2022-01-04 09:45:22 --> Total execution time: 0.0492
INFO - 2022-01-04 02:46:47 --> Config Class Initialized
INFO - 2022-01-04 02:46:47 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:46:47 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:46:47 --> Utf8 Class Initialized
INFO - 2022-01-04 02:46:47 --> URI Class Initialized
INFO - 2022-01-04 02:46:47 --> Router Class Initialized
INFO - 2022-01-04 02:46:47 --> Output Class Initialized
INFO - 2022-01-04 02:46:47 --> Security Class Initialized
DEBUG - 2022-01-04 02:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:46:47 --> Input Class Initialized
INFO - 2022-01-04 02:46:47 --> Language Class Initialized
INFO - 2022-01-04 02:46:47 --> Loader Class Initialized
INFO - 2022-01-04 02:46:47 --> Helper loaded: url_helper
INFO - 2022-01-04 02:46:47 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:46:47 --> Controller Class Initialized
INFO - 2022-01-04 09:46:47 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:46:47 --> Model "UserModel" initialized
INFO - 2022-01-04 09:46:47 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:46:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:46:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:46:47 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:46:47 --> Final output sent to browser
DEBUG - 2022-01-04 09:46:47 --> Total execution time: 0.0707
INFO - 2022-01-04 02:47:51 --> Config Class Initialized
INFO - 2022-01-04 02:47:51 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:47:51 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:47:51 --> Utf8 Class Initialized
INFO - 2022-01-04 02:47:51 --> URI Class Initialized
INFO - 2022-01-04 02:47:51 --> Router Class Initialized
INFO - 2022-01-04 02:47:51 --> Output Class Initialized
INFO - 2022-01-04 02:47:51 --> Security Class Initialized
DEBUG - 2022-01-04 02:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:47:51 --> Input Class Initialized
INFO - 2022-01-04 02:47:51 --> Language Class Initialized
INFO - 2022-01-04 02:47:51 --> Loader Class Initialized
INFO - 2022-01-04 02:47:51 --> Helper loaded: url_helper
INFO - 2022-01-04 02:47:51 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:47:51 --> Controller Class Initialized
INFO - 2022-01-04 09:47:51 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:47:51 --> Model "UserModel" initialized
INFO - 2022-01-04 09:47:51 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:47:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:47:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:47:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:47:51 --> Final output sent to browser
DEBUG - 2022-01-04 09:47:51 --> Total execution time: 0.0697
INFO - 2022-01-04 02:48:02 --> Config Class Initialized
INFO - 2022-01-04 02:48:02 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:48:02 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:48:02 --> Utf8 Class Initialized
INFO - 2022-01-04 02:48:02 --> URI Class Initialized
INFO - 2022-01-04 02:48:02 --> Router Class Initialized
INFO - 2022-01-04 02:48:02 --> Output Class Initialized
INFO - 2022-01-04 02:48:02 --> Security Class Initialized
DEBUG - 2022-01-04 02:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:48:02 --> Input Class Initialized
INFO - 2022-01-04 02:48:02 --> Language Class Initialized
INFO - 2022-01-04 02:48:02 --> Loader Class Initialized
INFO - 2022-01-04 02:48:02 --> Helper loaded: url_helper
INFO - 2022-01-04 02:48:02 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:48:02 --> Controller Class Initialized
INFO - 2022-01-04 09:48:02 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:48:02 --> Model "UserModel" initialized
INFO - 2022-01-04 09:48:02 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:48:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:48:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:48:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:48:02 --> Final output sent to browser
DEBUG - 2022-01-04 09:48:02 --> Total execution time: 0.0697
INFO - 2022-01-04 02:48:10 --> Config Class Initialized
INFO - 2022-01-04 02:48:10 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:48:10 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:48:10 --> Utf8 Class Initialized
INFO - 2022-01-04 02:48:10 --> URI Class Initialized
INFO - 2022-01-04 02:48:10 --> Router Class Initialized
INFO - 2022-01-04 02:48:10 --> Output Class Initialized
INFO - 2022-01-04 02:48:10 --> Security Class Initialized
DEBUG - 2022-01-04 02:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:48:10 --> Input Class Initialized
INFO - 2022-01-04 02:48:10 --> Language Class Initialized
INFO - 2022-01-04 02:48:10 --> Loader Class Initialized
INFO - 2022-01-04 02:48:10 --> Helper loaded: url_helper
INFO - 2022-01-04 02:48:10 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:48:10 --> Controller Class Initialized
INFO - 2022-01-04 09:48:10 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:48:10 --> Model "UserModel" initialized
INFO - 2022-01-04 09:48:10 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:48:10 --> Final output sent to browser
DEBUG - 2022-01-04 09:48:10 --> Total execution time: 0.0727
INFO - 2022-01-04 02:48:38 --> Config Class Initialized
INFO - 2022-01-04 02:48:38 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:48:38 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:48:38 --> Utf8 Class Initialized
INFO - 2022-01-04 02:48:38 --> URI Class Initialized
INFO - 2022-01-04 02:48:38 --> Router Class Initialized
INFO - 2022-01-04 02:48:38 --> Output Class Initialized
INFO - 2022-01-04 02:48:38 --> Security Class Initialized
DEBUG - 2022-01-04 02:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:48:38 --> Input Class Initialized
INFO - 2022-01-04 02:48:38 --> Language Class Initialized
INFO - 2022-01-04 02:48:38 --> Loader Class Initialized
INFO - 2022-01-04 02:48:38 --> Helper loaded: url_helper
INFO - 2022-01-04 02:48:38 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:48:38 --> Controller Class Initialized
INFO - 2022-01-04 09:48:38 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:48:38 --> Model "UserModel" initialized
INFO - 2022-01-04 09:48:38 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:48:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:48:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:48:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:48:38 --> Final output sent to browser
DEBUG - 2022-01-04 09:48:38 --> Total execution time: 0.0589
INFO - 2022-01-04 02:48:40 --> Config Class Initialized
INFO - 2022-01-04 02:48:40 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:48:40 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:48:40 --> Utf8 Class Initialized
INFO - 2022-01-04 02:48:40 --> URI Class Initialized
INFO - 2022-01-04 02:48:40 --> Router Class Initialized
INFO - 2022-01-04 02:48:40 --> Output Class Initialized
INFO - 2022-01-04 02:48:40 --> Security Class Initialized
DEBUG - 2022-01-04 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:48:40 --> Input Class Initialized
INFO - 2022-01-04 02:48:40 --> Language Class Initialized
INFO - 2022-01-04 02:48:40 --> Loader Class Initialized
INFO - 2022-01-04 02:48:40 --> Helper loaded: url_helper
INFO - 2022-01-04 02:48:40 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:48:40 --> Controller Class Initialized
INFO - 2022-01-04 09:48:40 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:48:40 --> Model "UserModel" initialized
INFO - 2022-01-04 09:48:40 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:48:40 --> Final output sent to browser
DEBUG - 2022-01-04 09:48:40 --> Total execution time: 0.0485
INFO - 2022-01-04 02:48:40 --> Config Class Initialized
INFO - 2022-01-04 02:48:40 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:48:40 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:48:40 --> Utf8 Class Initialized
INFO - 2022-01-04 02:48:40 --> URI Class Initialized
INFO - 2022-01-04 02:48:40 --> Router Class Initialized
INFO - 2022-01-04 02:48:40 --> Output Class Initialized
INFO - 2022-01-04 02:48:40 --> Security Class Initialized
DEBUG - 2022-01-04 02:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:48:40 --> Input Class Initialized
INFO - 2022-01-04 02:48:40 --> Language Class Initialized
INFO - 2022-01-04 02:48:40 --> Loader Class Initialized
INFO - 2022-01-04 02:48:40 --> Helper loaded: url_helper
INFO - 2022-01-04 02:48:40 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:48:40 --> Controller Class Initialized
INFO - 2022-01-04 09:48:40 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:48:40 --> Model "UserModel" initialized
INFO - 2022-01-04 09:48:40 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:48:40 --> Final output sent to browser
DEBUG - 2022-01-04 09:48:40 --> Total execution time: 0.0548
INFO - 2022-01-04 02:49:02 --> Config Class Initialized
INFO - 2022-01-04 02:49:02 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:49:02 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:49:02 --> Utf8 Class Initialized
INFO - 2022-01-04 02:49:02 --> URI Class Initialized
INFO - 2022-01-04 02:49:02 --> Router Class Initialized
INFO - 2022-01-04 02:49:02 --> Output Class Initialized
INFO - 2022-01-04 02:49:02 --> Security Class Initialized
DEBUG - 2022-01-04 02:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:49:02 --> Input Class Initialized
INFO - 2022-01-04 02:49:02 --> Language Class Initialized
INFO - 2022-01-04 02:49:02 --> Loader Class Initialized
INFO - 2022-01-04 02:49:02 --> Helper loaded: url_helper
INFO - 2022-01-04 02:49:02 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:49:02 --> Controller Class Initialized
INFO - 2022-01-04 09:49:02 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:49:02 --> Model "UserModel" initialized
INFO - 2022-01-04 09:49:02 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:49:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:49:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:49:02 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:49:02 --> Final output sent to browser
DEBUG - 2022-01-04 09:49:02 --> Total execution time: 0.0989
INFO - 2022-01-04 02:49:03 --> Config Class Initialized
INFO - 2022-01-04 02:49:03 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:49:03 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:49:03 --> Utf8 Class Initialized
INFO - 2022-01-04 02:49:03 --> URI Class Initialized
INFO - 2022-01-04 02:49:03 --> Router Class Initialized
INFO - 2022-01-04 02:49:03 --> Output Class Initialized
INFO - 2022-01-04 02:49:03 --> Security Class Initialized
DEBUG - 2022-01-04 02:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:49:03 --> Input Class Initialized
INFO - 2022-01-04 02:49:03 --> Language Class Initialized
INFO - 2022-01-04 02:49:03 --> Loader Class Initialized
INFO - 2022-01-04 02:49:03 --> Helper loaded: url_helper
INFO - 2022-01-04 02:49:03 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:49:03 --> Controller Class Initialized
INFO - 2022-01-04 09:49:03 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:49:03 --> Model "UserModel" initialized
INFO - 2022-01-04 09:49:03 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:49:03 --> Final output sent to browser
DEBUG - 2022-01-04 09:49:03 --> Total execution time: 0.0451
INFO - 2022-01-04 02:49:38 --> Config Class Initialized
INFO - 2022-01-04 02:49:38 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:49:38 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:49:38 --> Utf8 Class Initialized
INFO - 2022-01-04 02:49:38 --> URI Class Initialized
INFO - 2022-01-04 02:49:38 --> Router Class Initialized
INFO - 2022-01-04 02:49:38 --> Output Class Initialized
INFO - 2022-01-04 02:49:38 --> Security Class Initialized
DEBUG - 2022-01-04 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:49:38 --> Input Class Initialized
INFO - 2022-01-04 02:49:38 --> Language Class Initialized
INFO - 2022-01-04 02:49:38 --> Loader Class Initialized
INFO - 2022-01-04 02:49:38 --> Helper loaded: url_helper
INFO - 2022-01-04 02:49:38 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:49:38 --> Controller Class Initialized
INFO - 2022-01-04 09:49:38 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:49:38 --> Model "UserModel" initialized
INFO - 2022-01-04 09:49:38 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:49:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:49:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:49:38 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:49:38 --> Final output sent to browser
DEBUG - 2022-01-04 09:49:38 --> Total execution time: 0.0682
INFO - 2022-01-04 02:49:44 --> Config Class Initialized
INFO - 2022-01-04 02:49:44 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:49:44 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:49:44 --> Utf8 Class Initialized
INFO - 2022-01-04 02:49:44 --> URI Class Initialized
INFO - 2022-01-04 02:49:44 --> Router Class Initialized
INFO - 2022-01-04 02:49:44 --> Output Class Initialized
INFO - 2022-01-04 02:49:44 --> Security Class Initialized
DEBUG - 2022-01-04 02:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:49:44 --> Input Class Initialized
INFO - 2022-01-04 02:49:44 --> Language Class Initialized
INFO - 2022-01-04 02:49:44 --> Loader Class Initialized
INFO - 2022-01-04 02:49:44 --> Helper loaded: url_helper
INFO - 2022-01-04 02:49:44 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:49:44 --> Controller Class Initialized
INFO - 2022-01-04 09:49:44 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:49:44 --> Model "UserModel" initialized
INFO - 2022-01-04 09:49:44 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:49:44 --> Final output sent to browser
DEBUG - 2022-01-04 09:49:44 --> Total execution time: 0.0689
INFO - 2022-01-04 02:50:01 --> Config Class Initialized
INFO - 2022-01-04 02:50:01 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:50:01 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:50:01 --> Utf8 Class Initialized
INFO - 2022-01-04 02:50:01 --> URI Class Initialized
INFO - 2022-01-04 02:50:01 --> Router Class Initialized
INFO - 2022-01-04 02:50:01 --> Output Class Initialized
INFO - 2022-01-04 02:50:01 --> Security Class Initialized
DEBUG - 2022-01-04 02:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:50:01 --> Input Class Initialized
INFO - 2022-01-04 02:50:01 --> Language Class Initialized
INFO - 2022-01-04 02:50:01 --> Loader Class Initialized
INFO - 2022-01-04 02:50:01 --> Helper loaded: url_helper
INFO - 2022-01-04 02:50:01 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:50:01 --> Controller Class Initialized
INFO - 2022-01-04 09:50:01 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:50:01 --> Model "UserModel" initialized
INFO - 2022-01-04 09:50:01 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:50:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:50:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:50:01 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:50:01 --> Final output sent to browser
DEBUG - 2022-01-04 09:50:01 --> Total execution time: 0.0771
INFO - 2022-01-04 02:50:02 --> Config Class Initialized
INFO - 2022-01-04 02:50:02 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:50:02 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:50:02 --> Utf8 Class Initialized
INFO - 2022-01-04 02:50:02 --> URI Class Initialized
INFO - 2022-01-04 02:50:02 --> Router Class Initialized
INFO - 2022-01-04 02:50:02 --> Output Class Initialized
INFO - 2022-01-04 02:50:02 --> Security Class Initialized
DEBUG - 2022-01-04 02:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:50:02 --> Input Class Initialized
INFO - 2022-01-04 02:50:02 --> Language Class Initialized
INFO - 2022-01-04 02:50:02 --> Loader Class Initialized
INFO - 2022-01-04 02:50:02 --> Helper loaded: url_helper
INFO - 2022-01-04 02:50:02 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:50:02 --> Controller Class Initialized
INFO - 2022-01-04 09:50:02 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:50:02 --> Model "UserModel" initialized
INFO - 2022-01-04 09:50:02 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:50:02 --> Final output sent to browser
DEBUG - 2022-01-04 09:50:02 --> Total execution time: 0.0768
INFO - 2022-01-04 02:50:36 --> Config Class Initialized
INFO - 2022-01-04 02:50:36 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:50:36 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:50:36 --> Utf8 Class Initialized
INFO - 2022-01-04 02:50:36 --> URI Class Initialized
INFO - 2022-01-04 02:50:36 --> Router Class Initialized
INFO - 2022-01-04 02:50:36 --> Output Class Initialized
INFO - 2022-01-04 02:50:36 --> Security Class Initialized
DEBUG - 2022-01-04 02:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:50:36 --> Input Class Initialized
INFO - 2022-01-04 02:50:36 --> Language Class Initialized
INFO - 2022-01-04 02:50:36 --> Loader Class Initialized
INFO - 2022-01-04 02:50:36 --> Helper loaded: url_helper
INFO - 2022-01-04 02:50:36 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:50:36 --> Controller Class Initialized
INFO - 2022-01-04 09:50:36 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:50:36 --> Model "UserModel" initialized
INFO - 2022-01-04 09:50:36 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:50:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:50:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:50:36 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:50:36 --> Final output sent to browser
DEBUG - 2022-01-04 09:50:36 --> Total execution time: 0.0961
INFO - 2022-01-04 02:50:37 --> Config Class Initialized
INFO - 2022-01-04 02:50:37 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:50:37 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:50:37 --> Utf8 Class Initialized
INFO - 2022-01-04 02:50:37 --> URI Class Initialized
INFO - 2022-01-04 02:50:37 --> Router Class Initialized
INFO - 2022-01-04 02:50:37 --> Output Class Initialized
INFO - 2022-01-04 02:50:37 --> Security Class Initialized
DEBUG - 2022-01-04 02:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:50:37 --> Input Class Initialized
INFO - 2022-01-04 02:50:37 --> Language Class Initialized
INFO - 2022-01-04 02:50:37 --> Loader Class Initialized
INFO - 2022-01-04 02:50:37 --> Helper loaded: url_helper
INFO - 2022-01-04 02:50:37 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:50:37 --> Controller Class Initialized
INFO - 2022-01-04 09:50:37 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:50:37 --> Model "UserModel" initialized
INFO - 2022-01-04 09:50:37 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:50:37 --> Final output sent to browser
DEBUG - 2022-01-04 09:50:37 --> Total execution time: 0.0727
INFO - 2022-01-04 02:50:40 --> Config Class Initialized
INFO - 2022-01-04 02:50:40 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:50:40 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:50:40 --> Utf8 Class Initialized
INFO - 2022-01-04 02:50:40 --> URI Class Initialized
INFO - 2022-01-04 02:50:40 --> Router Class Initialized
INFO - 2022-01-04 02:50:40 --> Output Class Initialized
INFO - 2022-01-04 02:50:40 --> Security Class Initialized
DEBUG - 2022-01-04 02:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:50:41 --> Input Class Initialized
INFO - 2022-01-04 02:50:41 --> Language Class Initialized
INFO - 2022-01-04 02:50:41 --> Loader Class Initialized
INFO - 2022-01-04 02:50:41 --> Helper loaded: url_helper
INFO - 2022-01-04 02:50:41 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:50:41 --> Controller Class Initialized
INFO - 2022-01-04 09:50:41 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:50:41 --> Model "UserModel" initialized
INFO - 2022-01-04 09:50:41 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:50:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:50:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:50:41 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:50:41 --> Final output sent to browser
DEBUG - 2022-01-04 09:50:41 --> Total execution time: 0.0588
INFO - 2022-01-04 02:50:44 --> Config Class Initialized
INFO - 2022-01-04 02:50:44 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:50:44 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:50:44 --> Utf8 Class Initialized
INFO - 2022-01-04 02:50:44 --> URI Class Initialized
INFO - 2022-01-04 02:50:44 --> Router Class Initialized
INFO - 2022-01-04 02:50:44 --> Output Class Initialized
INFO - 2022-01-04 02:50:44 --> Security Class Initialized
DEBUG - 2022-01-04 02:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:50:44 --> Input Class Initialized
INFO - 2022-01-04 02:50:44 --> Language Class Initialized
INFO - 2022-01-04 02:50:44 --> Loader Class Initialized
INFO - 2022-01-04 02:50:44 --> Helper loaded: url_helper
INFO - 2022-01-04 02:50:44 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:50:44 --> Controller Class Initialized
INFO - 2022-01-04 09:50:44 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:50:44 --> Model "UserModel" initialized
INFO - 2022-01-04 09:50:44 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:50:44 --> Final output sent to browser
DEBUG - 2022-01-04 09:50:44 --> Total execution time: 0.0665
INFO - 2022-01-04 02:51:04 --> Config Class Initialized
INFO - 2022-01-04 02:51:04 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:51:04 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:51:04 --> Utf8 Class Initialized
INFO - 2022-01-04 02:51:04 --> URI Class Initialized
INFO - 2022-01-04 02:51:04 --> Router Class Initialized
INFO - 2022-01-04 02:51:04 --> Output Class Initialized
INFO - 2022-01-04 02:51:04 --> Security Class Initialized
DEBUG - 2022-01-04 02:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:51:04 --> Input Class Initialized
INFO - 2022-01-04 02:51:04 --> Language Class Initialized
INFO - 2022-01-04 02:51:04 --> Loader Class Initialized
INFO - 2022-01-04 02:51:04 --> Helper loaded: url_helper
INFO - 2022-01-04 02:51:04 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:51:04 --> Controller Class Initialized
INFO - 2022-01-04 09:51:04 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:51:04 --> Model "UserModel" initialized
INFO - 2022-01-04 09:51:04 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:51:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 09:51:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 09:51:04 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 09:51:04 --> Final output sent to browser
DEBUG - 2022-01-04 09:51:04 --> Total execution time: 0.0579
INFO - 2022-01-04 02:52:28 --> Config Class Initialized
INFO - 2022-01-04 02:52:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:52:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:52:28 --> Utf8 Class Initialized
INFO - 2022-01-04 02:52:28 --> URI Class Initialized
INFO - 2022-01-04 02:52:28 --> Router Class Initialized
INFO - 2022-01-04 02:52:28 --> Output Class Initialized
INFO - 2022-01-04 02:52:28 --> Security Class Initialized
DEBUG - 2022-01-04 02:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:52:28 --> Input Class Initialized
INFO - 2022-01-04 02:52:28 --> Language Class Initialized
INFO - 2022-01-04 02:52:28 --> Loader Class Initialized
INFO - 2022-01-04 02:52:28 --> Helper loaded: url_helper
INFO - 2022-01-04 02:52:28 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:52:28 --> Controller Class Initialized
INFO - 2022-01-04 09:52:28 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:52:28 --> Model "UserModel" initialized
INFO - 2022-01-04 09:52:28 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:52:28 --> Final output sent to browser
DEBUG - 2022-01-04 09:52:28 --> Total execution time: 0.0565
INFO - 2022-01-04 02:52:30 --> Config Class Initialized
INFO - 2022-01-04 02:52:30 --> Hooks Class Initialized
DEBUG - 2022-01-04 02:52:30 --> UTF-8 Support Enabled
INFO - 2022-01-04 02:52:30 --> Utf8 Class Initialized
INFO - 2022-01-04 02:52:30 --> URI Class Initialized
INFO - 2022-01-04 02:52:30 --> Router Class Initialized
INFO - 2022-01-04 02:52:30 --> Output Class Initialized
INFO - 2022-01-04 02:52:30 --> Security Class Initialized
DEBUG - 2022-01-04 02:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 02:52:30 --> Input Class Initialized
INFO - 2022-01-04 02:52:30 --> Language Class Initialized
INFO - 2022-01-04 02:52:30 --> Loader Class Initialized
INFO - 2022-01-04 02:52:30 --> Helper loaded: url_helper
INFO - 2022-01-04 02:52:30 --> Database Driver Class Initialized
DEBUG - 2022-01-04 02:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 02:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 02:52:30 --> Controller Class Initialized
INFO - 2022-01-04 09:52:30 --> Model "LoginModel" initialized
INFO - 2022-01-04 09:52:30 --> Model "UserModel" initialized
INFO - 2022-01-04 09:52:30 --> Model "AdminModel" initialized
INFO - 2022-01-04 09:52:30 --> Final output sent to browser
DEBUG - 2022-01-04 09:52:30 --> Total execution time: 0.0529
INFO - 2022-01-04 03:10:00 --> Config Class Initialized
INFO - 2022-01-04 03:10:00 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:10:00 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:10:00 --> Utf8 Class Initialized
INFO - 2022-01-04 03:10:00 --> URI Class Initialized
INFO - 2022-01-04 03:10:00 --> Router Class Initialized
INFO - 2022-01-04 03:10:00 --> Output Class Initialized
INFO - 2022-01-04 03:10:00 --> Security Class Initialized
DEBUG - 2022-01-04 03:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:10:00 --> Input Class Initialized
INFO - 2022-01-04 03:10:00 --> Language Class Initialized
INFO - 2022-01-04 03:10:00 --> Loader Class Initialized
INFO - 2022-01-04 03:10:00 --> Helper loaded: url_helper
INFO - 2022-01-04 03:10:00 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:10:00 --> Controller Class Initialized
INFO - 2022-01-04 10:10:00 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:10:00 --> Model "UserModel" initialized
INFO - 2022-01-04 10:10:00 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:10:00 --> Final output sent to browser
DEBUG - 2022-01-04 10:10:00 --> Total execution time: 0.0717
INFO - 2022-01-04 03:10:25 --> Config Class Initialized
INFO - 2022-01-04 03:10:25 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:10:25 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:10:25 --> Utf8 Class Initialized
INFO - 2022-01-04 03:10:25 --> URI Class Initialized
INFO - 2022-01-04 03:10:25 --> Router Class Initialized
INFO - 2022-01-04 03:10:25 --> Output Class Initialized
INFO - 2022-01-04 03:10:25 --> Security Class Initialized
DEBUG - 2022-01-04 03:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:10:25 --> Input Class Initialized
INFO - 2022-01-04 03:10:25 --> Language Class Initialized
INFO - 2022-01-04 03:10:25 --> Loader Class Initialized
INFO - 2022-01-04 03:10:25 --> Helper loaded: url_helper
INFO - 2022-01-04 03:10:25 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:10:25 --> Controller Class Initialized
INFO - 2022-01-04 10:10:25 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:10:25 --> Model "UserModel" initialized
INFO - 2022-01-04 10:10:25 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:10:25 --> Final output sent to browser
DEBUG - 2022-01-04 10:10:25 --> Total execution time: 0.0756
INFO - 2022-01-04 03:14:59 --> Config Class Initialized
INFO - 2022-01-04 03:14:59 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:14:59 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:14:59 --> Utf8 Class Initialized
INFO - 2022-01-04 03:14:59 --> URI Class Initialized
INFO - 2022-01-04 03:14:59 --> Router Class Initialized
INFO - 2022-01-04 03:14:59 --> Output Class Initialized
INFO - 2022-01-04 03:14:59 --> Security Class Initialized
DEBUG - 2022-01-04 03:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:14:59 --> Input Class Initialized
INFO - 2022-01-04 03:14:59 --> Language Class Initialized
INFO - 2022-01-04 03:14:59 --> Loader Class Initialized
INFO - 2022-01-04 03:14:59 --> Helper loaded: url_helper
INFO - 2022-01-04 03:14:59 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:14:59 --> Controller Class Initialized
INFO - 2022-01-04 10:14:59 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:14:59 --> Model "UserModel" initialized
INFO - 2022-01-04 10:14:59 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:14:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:14:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 10:14:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:14:59 --> Final output sent to browser
DEBUG - 2022-01-04 10:14:59 --> Total execution time: 0.0813
INFO - 2022-01-04 03:15:00 --> Config Class Initialized
INFO - 2022-01-04 03:15:00 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:00 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:00 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:00 --> URI Class Initialized
INFO - 2022-01-04 03:15:00 --> Router Class Initialized
INFO - 2022-01-04 03:15:00 --> Output Class Initialized
INFO - 2022-01-04 03:15:01 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:01 --> Input Class Initialized
INFO - 2022-01-04 03:15:01 --> Language Class Initialized
INFO - 2022-01-04 03:15:01 --> Loader Class Initialized
INFO - 2022-01-04 03:15:01 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:01 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:01 --> Controller Class Initialized
INFO - 2022-01-04 10:15:01 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:01 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:01 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:01 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:01 --> Total execution time: 0.0500
INFO - 2022-01-04 03:15:03 --> Config Class Initialized
INFO - 2022-01-04 03:15:03 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:03 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:03 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:03 --> URI Class Initialized
INFO - 2022-01-04 03:15:03 --> Router Class Initialized
INFO - 2022-01-04 03:15:03 --> Output Class Initialized
INFO - 2022-01-04 03:15:03 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:03 --> Input Class Initialized
INFO - 2022-01-04 03:15:03 --> Language Class Initialized
INFO - 2022-01-04 03:15:03 --> Loader Class Initialized
INFO - 2022-01-04 03:15:03 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:03 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:03 --> Controller Class Initialized
INFO - 2022-01-04 10:15:03 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:03 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:03 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:15:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 10:15:03 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:15:03 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:03 --> Total execution time: 0.0484
INFO - 2022-01-04 03:15:06 --> Config Class Initialized
INFO - 2022-01-04 03:15:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:06 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:06 --> URI Class Initialized
INFO - 2022-01-04 03:15:06 --> Router Class Initialized
INFO - 2022-01-04 03:15:06 --> Output Class Initialized
INFO - 2022-01-04 03:15:06 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:06 --> Input Class Initialized
INFO - 2022-01-04 03:15:06 --> Language Class Initialized
INFO - 2022-01-04 03:15:06 --> Loader Class Initialized
INFO - 2022-01-04 03:15:06 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:06 --> Controller Class Initialized
INFO - 2022-01-04 10:15:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:06 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:06 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:06 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:06 --> Total execution time: 0.0439
INFO - 2022-01-04 03:15:07 --> Config Class Initialized
INFO - 2022-01-04 03:15:07 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:07 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:07 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:07 --> URI Class Initialized
INFO - 2022-01-04 03:15:07 --> Router Class Initialized
INFO - 2022-01-04 03:15:07 --> Output Class Initialized
INFO - 2022-01-04 03:15:07 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:07 --> Input Class Initialized
INFO - 2022-01-04 03:15:07 --> Language Class Initialized
INFO - 2022-01-04 03:15:07 --> Loader Class Initialized
INFO - 2022-01-04 03:15:07 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:07 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:07 --> Controller Class Initialized
INFO - 2022-01-04 10:15:07 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:07 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:07 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:07 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:07 --> Total execution time: 0.0689
INFO - 2022-01-04 03:15:25 --> Config Class Initialized
INFO - 2022-01-04 03:15:25 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:25 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:25 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:25 --> URI Class Initialized
INFO - 2022-01-04 03:15:25 --> Router Class Initialized
INFO - 2022-01-04 03:15:25 --> Output Class Initialized
INFO - 2022-01-04 03:15:25 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:25 --> Input Class Initialized
INFO - 2022-01-04 03:15:25 --> Language Class Initialized
INFO - 2022-01-04 03:15:25 --> Loader Class Initialized
INFO - 2022-01-04 03:15:25 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:25 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:25 --> Controller Class Initialized
INFO - 2022-01-04 10:15:25 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:25 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:25 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:15:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 10:15:25 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:15:25 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:25 --> Total execution time: 0.0741
INFO - 2022-01-04 03:15:27 --> Config Class Initialized
INFO - 2022-01-04 03:15:27 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:27 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:27 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:27 --> URI Class Initialized
INFO - 2022-01-04 03:15:27 --> Router Class Initialized
INFO - 2022-01-04 03:15:27 --> Output Class Initialized
INFO - 2022-01-04 03:15:27 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:27 --> Input Class Initialized
INFO - 2022-01-04 03:15:27 --> Language Class Initialized
INFO - 2022-01-04 03:15:27 --> Loader Class Initialized
INFO - 2022-01-04 03:15:27 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:27 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:27 --> Controller Class Initialized
INFO - 2022-01-04 10:15:27 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:27 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:27 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:27 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:27 --> Total execution time: 0.0512
INFO - 2022-01-04 03:15:32 --> Config Class Initialized
INFO - 2022-01-04 03:15:32 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:32 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:32 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:32 --> URI Class Initialized
INFO - 2022-01-04 03:15:32 --> Router Class Initialized
INFO - 2022-01-04 03:15:32 --> Output Class Initialized
INFO - 2022-01-04 03:15:32 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:32 --> Input Class Initialized
INFO - 2022-01-04 03:15:32 --> Language Class Initialized
INFO - 2022-01-04 03:15:32 --> Loader Class Initialized
INFO - 2022-01-04 03:15:32 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:33 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:33 --> Controller Class Initialized
INFO - 2022-01-04 10:15:33 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:33 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:33 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:33 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:33 --> Total execution time: 0.0720
INFO - 2022-01-04 03:15:33 --> Config Class Initialized
INFO - 2022-01-04 03:15:33 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:33 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:33 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:33 --> URI Class Initialized
INFO - 2022-01-04 03:15:33 --> Router Class Initialized
INFO - 2022-01-04 03:15:33 --> Output Class Initialized
INFO - 2022-01-04 03:15:33 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:33 --> Input Class Initialized
INFO - 2022-01-04 03:15:33 --> Language Class Initialized
INFO - 2022-01-04 03:15:33 --> Loader Class Initialized
INFO - 2022-01-04 03:15:33 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:33 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:33 --> Controller Class Initialized
INFO - 2022-01-04 10:15:33 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:33 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:33 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:33 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:33 --> Total execution time: 0.0546
INFO - 2022-01-04 03:15:35 --> Config Class Initialized
INFO - 2022-01-04 03:15:35 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:35 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:35 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:35 --> URI Class Initialized
INFO - 2022-01-04 03:15:35 --> Router Class Initialized
INFO - 2022-01-04 03:15:35 --> Output Class Initialized
INFO - 2022-01-04 03:15:35 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:35 --> Input Class Initialized
INFO - 2022-01-04 03:15:35 --> Language Class Initialized
INFO - 2022-01-04 03:15:35 --> Loader Class Initialized
INFO - 2022-01-04 03:15:35 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:35 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:35 --> Controller Class Initialized
INFO - 2022-01-04 10:15:35 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:35 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:35 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:35 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:35 --> Total execution time: 0.0734
INFO - 2022-01-04 03:15:38 --> Config Class Initialized
INFO - 2022-01-04 03:15:38 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:38 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:38 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:38 --> URI Class Initialized
INFO - 2022-01-04 03:15:38 --> Router Class Initialized
INFO - 2022-01-04 03:15:38 --> Output Class Initialized
INFO - 2022-01-04 03:15:38 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:38 --> Input Class Initialized
INFO - 2022-01-04 03:15:38 --> Language Class Initialized
INFO - 2022-01-04 03:15:38 --> Loader Class Initialized
INFO - 2022-01-04 03:15:38 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:38 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:38 --> Controller Class Initialized
INFO - 2022-01-04 10:15:38 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:38 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:38 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:38 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:38 --> Total execution time: 0.0502
INFO - 2022-01-04 03:15:41 --> Config Class Initialized
INFO - 2022-01-04 03:15:41 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:15:41 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:15:41 --> Utf8 Class Initialized
INFO - 2022-01-04 03:15:41 --> URI Class Initialized
INFO - 2022-01-04 03:15:41 --> Router Class Initialized
INFO - 2022-01-04 03:15:41 --> Output Class Initialized
INFO - 2022-01-04 03:15:41 --> Security Class Initialized
DEBUG - 2022-01-04 03:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:15:41 --> Input Class Initialized
INFO - 2022-01-04 03:15:41 --> Language Class Initialized
INFO - 2022-01-04 03:15:41 --> Loader Class Initialized
INFO - 2022-01-04 03:15:41 --> Helper loaded: url_helper
INFO - 2022-01-04 03:15:41 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:15:41 --> Controller Class Initialized
INFO - 2022-01-04 10:15:41 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:15:41 --> Model "UserModel" initialized
INFO - 2022-01-04 10:15:41 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:15:41 --> Final output sent to browser
DEBUG - 2022-01-04 10:15:41 --> Total execution time: 0.0724
INFO - 2022-01-04 03:22:38 --> Config Class Initialized
INFO - 2022-01-04 03:22:38 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:22:38 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:22:38 --> Utf8 Class Initialized
INFO - 2022-01-04 03:22:38 --> URI Class Initialized
INFO - 2022-01-04 03:22:38 --> Router Class Initialized
INFO - 2022-01-04 03:22:38 --> Output Class Initialized
INFO - 2022-01-04 03:22:38 --> Security Class Initialized
DEBUG - 2022-01-04 03:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:22:38 --> Input Class Initialized
INFO - 2022-01-04 03:22:38 --> Language Class Initialized
INFO - 2022-01-04 03:22:38 --> Loader Class Initialized
INFO - 2022-01-04 03:22:38 --> Helper loaded: url_helper
INFO - 2022-01-04 03:22:38 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:22:38 --> Controller Class Initialized
INFO - 2022-01-04 10:22:38 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:22:38 --> Model "UserModel" initialized
INFO - 2022-01-04 10:22:38 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:22:38 --> Final output sent to browser
DEBUG - 2022-01-04 10:22:38 --> Total execution time: 0.0493
INFO - 2022-01-04 03:22:40 --> Config Class Initialized
INFO - 2022-01-04 03:22:40 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:22:40 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:22:40 --> Utf8 Class Initialized
INFO - 2022-01-04 03:22:40 --> URI Class Initialized
INFO - 2022-01-04 03:22:40 --> Router Class Initialized
INFO - 2022-01-04 03:22:40 --> Output Class Initialized
INFO - 2022-01-04 03:22:40 --> Security Class Initialized
DEBUG - 2022-01-04 03:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:22:40 --> Input Class Initialized
INFO - 2022-01-04 03:22:40 --> Language Class Initialized
INFO - 2022-01-04 03:22:40 --> Loader Class Initialized
INFO - 2022-01-04 03:22:40 --> Helper loaded: url_helper
INFO - 2022-01-04 03:22:40 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:22:40 --> Controller Class Initialized
INFO - 2022-01-04 10:22:40 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:22:40 --> Model "UserModel" initialized
INFO - 2022-01-04 10:22:40 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:22:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:22:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 10:22:40 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:22:40 --> Final output sent to browser
DEBUG - 2022-01-04 10:22:40 --> Total execution time: 0.0588
INFO - 2022-01-04 03:22:43 --> Config Class Initialized
INFO - 2022-01-04 03:22:43 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:22:43 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:22:43 --> Utf8 Class Initialized
INFO - 2022-01-04 03:22:43 --> URI Class Initialized
INFO - 2022-01-04 03:22:43 --> Router Class Initialized
INFO - 2022-01-04 03:22:43 --> Output Class Initialized
INFO - 2022-01-04 03:22:43 --> Security Class Initialized
DEBUG - 2022-01-04 03:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:22:43 --> Input Class Initialized
INFO - 2022-01-04 03:22:43 --> Language Class Initialized
INFO - 2022-01-04 03:22:43 --> Loader Class Initialized
INFO - 2022-01-04 03:22:43 --> Helper loaded: url_helper
INFO - 2022-01-04 03:22:43 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:22:43 --> Controller Class Initialized
INFO - 2022-01-04 10:22:43 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:22:43 --> Model "UserModel" initialized
INFO - 2022-01-04 10:22:43 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:22:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:22:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 10:22:43 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:22:43 --> Final output sent to browser
DEBUG - 2022-01-04 10:22:43 --> Total execution time: 0.0582
INFO - 2022-01-04 03:22:45 --> Config Class Initialized
INFO - 2022-01-04 03:22:45 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:22:45 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:22:45 --> Utf8 Class Initialized
INFO - 2022-01-04 03:22:45 --> URI Class Initialized
INFO - 2022-01-04 03:22:45 --> Router Class Initialized
INFO - 2022-01-04 03:22:45 --> Output Class Initialized
INFO - 2022-01-04 03:22:45 --> Security Class Initialized
DEBUG - 2022-01-04 03:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:22:45 --> Input Class Initialized
INFO - 2022-01-04 03:22:45 --> Language Class Initialized
ERROR - 2022-01-04 03:22:45 --> 404 Page Not Found: Admin/user_list.php
INFO - 2022-01-04 03:22:46 --> Config Class Initialized
INFO - 2022-01-04 03:22:46 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:22:46 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:22:46 --> Utf8 Class Initialized
INFO - 2022-01-04 03:22:46 --> URI Class Initialized
INFO - 2022-01-04 03:22:46 --> Router Class Initialized
INFO - 2022-01-04 03:22:46 --> Output Class Initialized
INFO - 2022-01-04 03:22:46 --> Security Class Initialized
DEBUG - 2022-01-04 03:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:22:46 --> Input Class Initialized
INFO - 2022-01-04 03:22:46 --> Language Class Initialized
ERROR - 2022-01-04 03:22:46 --> 404 Page Not Found: Admin/user_list.php
INFO - 2022-01-04 03:22:47 --> Config Class Initialized
INFO - 2022-01-04 03:22:47 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:22:47 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:22:47 --> Utf8 Class Initialized
INFO - 2022-01-04 03:22:47 --> URI Class Initialized
INFO - 2022-01-04 03:22:47 --> Router Class Initialized
INFO - 2022-01-04 03:22:47 --> Output Class Initialized
INFO - 2022-01-04 03:22:47 --> Security Class Initialized
DEBUG - 2022-01-04 03:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:22:47 --> Input Class Initialized
INFO - 2022-01-04 03:22:47 --> Language Class Initialized
ERROR - 2022-01-04 03:22:47 --> 404 Page Not Found: Admin/user_list.php
INFO - 2022-01-04 03:22:48 --> Config Class Initialized
INFO - 2022-01-04 03:22:48 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:22:48 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:22:48 --> Utf8 Class Initialized
INFO - 2022-01-04 03:22:48 --> URI Class Initialized
INFO - 2022-01-04 03:22:48 --> Router Class Initialized
INFO - 2022-01-04 03:22:48 --> Output Class Initialized
INFO - 2022-01-04 03:22:48 --> Security Class Initialized
DEBUG - 2022-01-04 03:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:22:48 --> Input Class Initialized
INFO - 2022-01-04 03:22:48 --> Language Class Initialized
ERROR - 2022-01-04 03:22:48 --> 404 Page Not Found: Admin/user_list.php
INFO - 2022-01-04 03:24:48 --> Config Class Initialized
INFO - 2022-01-04 03:24:48 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:24:48 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:24:48 --> Utf8 Class Initialized
INFO - 2022-01-04 03:24:48 --> URI Class Initialized
INFO - 2022-01-04 03:24:48 --> Router Class Initialized
INFO - 2022-01-04 03:24:48 --> Output Class Initialized
INFO - 2022-01-04 03:24:48 --> Security Class Initialized
DEBUG - 2022-01-04 03:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:24:48 --> Input Class Initialized
INFO - 2022-01-04 03:24:48 --> Language Class Initialized
ERROR - 2022-01-04 03:24:48 --> 404 Page Not Found: Admin/user_list.php
INFO - 2022-01-04 03:25:57 --> Config Class Initialized
INFO - 2022-01-04 03:25:57 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:25:57 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:25:57 --> Utf8 Class Initialized
INFO - 2022-01-04 03:25:57 --> URI Class Initialized
INFO - 2022-01-04 03:25:57 --> Router Class Initialized
INFO - 2022-01-04 03:25:57 --> Output Class Initialized
INFO - 2022-01-04 03:25:57 --> Security Class Initialized
DEBUG - 2022-01-04 03:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:25:57 --> Input Class Initialized
INFO - 2022-01-04 03:25:57 --> Language Class Initialized
ERROR - 2022-01-04 03:25:57 --> 404 Page Not Found: Admin/user_list.php
INFO - 2022-01-04 03:26:01 --> Config Class Initialized
INFO - 2022-01-04 03:26:01 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:26:01 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:26:01 --> Utf8 Class Initialized
INFO - 2022-01-04 03:26:01 --> URI Class Initialized
INFO - 2022-01-04 03:26:01 --> Router Class Initialized
INFO - 2022-01-04 03:26:01 --> Output Class Initialized
INFO - 2022-01-04 03:26:01 --> Security Class Initialized
DEBUG - 2022-01-04 03:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:26:01 --> Input Class Initialized
INFO - 2022-01-04 03:26:01 --> Language Class Initialized
INFO - 2022-01-04 03:26:01 --> Loader Class Initialized
INFO - 2022-01-04 03:26:01 --> Helper loaded: url_helper
INFO - 2022-01-04 03:26:01 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:26:01 --> Controller Class Initialized
INFO - 2022-01-04 10:26:01 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:26:01 --> Model "UserModel" initialized
INFO - 2022-01-04 10:26:01 --> Model "AdminModel" initialized
INFO - 2022-01-04 03:26:06 --> Config Class Initialized
INFO - 2022-01-04 03:26:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:26:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:26:06 --> Utf8 Class Initialized
INFO - 2022-01-04 03:26:06 --> URI Class Initialized
INFO - 2022-01-04 03:26:06 --> Router Class Initialized
INFO - 2022-01-04 03:26:06 --> Output Class Initialized
INFO - 2022-01-04 03:26:06 --> Security Class Initialized
DEBUG - 2022-01-04 03:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:26:06 --> Input Class Initialized
INFO - 2022-01-04 03:26:06 --> Language Class Initialized
INFO - 2022-01-04 03:26:06 --> Loader Class Initialized
INFO - 2022-01-04 03:26:06 --> Helper loaded: url_helper
INFO - 2022-01-04 03:26:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:26:06 --> Controller Class Initialized
INFO - 2022-01-04 10:26:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:26:06 --> Model "UserModel" initialized
INFO - 2022-01-04 10:26:06 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:26:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:26:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 10:26:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:26:06 --> Final output sent to browser
DEBUG - 2022-01-04 10:26:06 --> Total execution time: 0.0739
INFO - 2022-01-04 03:26:07 --> Config Class Initialized
INFO - 2022-01-04 03:26:07 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:26:07 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:26:07 --> Utf8 Class Initialized
INFO - 2022-01-04 03:26:07 --> URI Class Initialized
INFO - 2022-01-04 03:26:07 --> Router Class Initialized
INFO - 2022-01-04 03:26:07 --> Output Class Initialized
INFO - 2022-01-04 03:26:07 --> Security Class Initialized
DEBUG - 2022-01-04 03:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:26:07 --> Input Class Initialized
INFO - 2022-01-04 03:26:07 --> Language Class Initialized
INFO - 2022-01-04 03:26:07 --> Loader Class Initialized
INFO - 2022-01-04 03:26:07 --> Helper loaded: url_helper
INFO - 2022-01-04 03:26:07 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:26:07 --> Controller Class Initialized
INFO - 2022-01-04 10:26:07 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:26:07 --> Model "UserModel" initialized
INFO - 2022-01-04 10:26:07 --> Model "AdminModel" initialized
INFO - 2022-01-04 03:26:09 --> Config Class Initialized
INFO - 2022-01-04 03:26:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:26:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:26:09 --> Utf8 Class Initialized
INFO - 2022-01-04 03:26:09 --> URI Class Initialized
INFO - 2022-01-04 03:26:09 --> Router Class Initialized
INFO - 2022-01-04 03:26:09 --> Output Class Initialized
INFO - 2022-01-04 03:26:09 --> Security Class Initialized
DEBUG - 2022-01-04 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:26:09 --> Input Class Initialized
INFO - 2022-01-04 03:26:09 --> Language Class Initialized
INFO - 2022-01-04 03:26:09 --> Loader Class Initialized
INFO - 2022-01-04 03:26:09 --> Helper loaded: url_helper
INFO - 2022-01-04 03:26:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:26:09 --> Controller Class Initialized
INFO - 2022-01-04 10:26:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:26:09 --> Model "UserModel" initialized
INFO - 2022-01-04 10:26:09 --> Model "AdminModel" initialized
INFO - 2022-01-04 03:26:09 --> Config Class Initialized
INFO - 2022-01-04 03:26:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:26:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:26:09 --> Utf8 Class Initialized
INFO - 2022-01-04 03:26:09 --> URI Class Initialized
INFO - 2022-01-04 03:26:09 --> Router Class Initialized
INFO - 2022-01-04 03:26:09 --> Output Class Initialized
INFO - 2022-01-04 03:26:09 --> Security Class Initialized
DEBUG - 2022-01-04 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:26:09 --> Input Class Initialized
INFO - 2022-01-04 03:26:09 --> Language Class Initialized
INFO - 2022-01-04 03:26:09 --> Loader Class Initialized
INFO - 2022-01-04 03:26:09 --> Helper loaded: url_helper
INFO - 2022-01-04 03:26:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:26:09 --> Controller Class Initialized
INFO - 2022-01-04 10:26:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:26:09 --> Model "UserModel" initialized
INFO - 2022-01-04 10:26:09 --> Model "AdminModel" initialized
INFO - 2022-01-04 03:26:09 --> Config Class Initialized
INFO - 2022-01-04 03:26:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:26:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:26:09 --> Utf8 Class Initialized
INFO - 2022-01-04 03:26:09 --> URI Class Initialized
INFO - 2022-01-04 03:26:09 --> Router Class Initialized
INFO - 2022-01-04 03:26:09 --> Output Class Initialized
INFO - 2022-01-04 03:26:09 --> Security Class Initialized
DEBUG - 2022-01-04 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:26:09 --> Input Class Initialized
INFO - 2022-01-04 03:26:09 --> Language Class Initialized
INFO - 2022-01-04 03:26:09 --> Loader Class Initialized
INFO - 2022-01-04 03:26:09 --> Helper loaded: url_helper
INFO - 2022-01-04 03:26:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:26:09 --> Controller Class Initialized
INFO - 2022-01-04 10:26:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:26:09 --> Model "UserModel" initialized
INFO - 2022-01-04 10:26:09 --> Model "AdminModel" initialized
INFO - 2022-01-04 03:52:06 --> Config Class Initialized
INFO - 2022-01-04 03:52:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:52:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:52:06 --> Utf8 Class Initialized
INFO - 2022-01-04 03:52:06 --> URI Class Initialized
INFO - 2022-01-04 03:52:06 --> Router Class Initialized
INFO - 2022-01-04 03:52:06 --> Output Class Initialized
INFO - 2022-01-04 03:52:06 --> Security Class Initialized
DEBUG - 2022-01-04 03:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:52:06 --> Input Class Initialized
INFO - 2022-01-04 03:52:06 --> Language Class Initialized
INFO - 2022-01-04 03:52:06 --> Loader Class Initialized
INFO - 2022-01-04 03:52:06 --> Helper loaded: url_helper
INFO - 2022-01-04 03:52:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:52:06 --> Controller Class Initialized
INFO - 2022-01-04 10:52:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:52:06 --> Model "UserModel" initialized
INFO - 2022-01-04 10:52:06 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:52:06 --> Final output sent to browser
DEBUG - 2022-01-04 10:52:06 --> Total execution time: 0.0774
INFO - 2022-01-04 03:52:08 --> Config Class Initialized
INFO - 2022-01-04 03:52:08 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:52:08 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:52:08 --> Utf8 Class Initialized
INFO - 2022-01-04 03:52:08 --> URI Class Initialized
INFO - 2022-01-04 03:52:08 --> Router Class Initialized
INFO - 2022-01-04 03:52:08 --> Output Class Initialized
INFO - 2022-01-04 03:52:08 --> Security Class Initialized
DEBUG - 2022-01-04 03:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:52:08 --> Input Class Initialized
INFO - 2022-01-04 03:52:08 --> Language Class Initialized
INFO - 2022-01-04 03:52:08 --> Loader Class Initialized
INFO - 2022-01-04 03:52:08 --> Helper loaded: url_helper
INFO - 2022-01-04 03:52:08 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:52:08 --> Controller Class Initialized
INFO - 2022-01-04 10:52:08 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:52:08 --> Model "UserModel" initialized
INFO - 2022-01-04 10:52:08 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:52:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:52:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/about.php
INFO - 2022-01-04 10:52:08 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:52:08 --> Final output sent to browser
DEBUG - 2022-01-04 10:52:08 --> Total execution time: 0.0583
INFO - 2022-01-04 03:52:09 --> Config Class Initialized
INFO - 2022-01-04 03:52:09 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:52:09 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:52:09 --> Utf8 Class Initialized
INFO - 2022-01-04 03:52:09 --> URI Class Initialized
DEBUG - 2022-01-04 03:52:09 --> No URI present. Default controller set.
INFO - 2022-01-04 03:52:09 --> Router Class Initialized
INFO - 2022-01-04 03:52:09 --> Output Class Initialized
INFO - 2022-01-04 03:52:09 --> Security Class Initialized
DEBUG - 2022-01-04 03:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:52:09 --> Input Class Initialized
INFO - 2022-01-04 03:52:09 --> Language Class Initialized
INFO - 2022-01-04 03:52:09 --> Loader Class Initialized
INFO - 2022-01-04 03:52:09 --> Helper loaded: url_helper
INFO - 2022-01-04 03:52:09 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:52:09 --> Controller Class Initialized
INFO - 2022-01-04 10:52:09 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:52:09 --> Model "UserModel" initialized
INFO - 2022-01-04 10:52:09 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:52:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:52:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 10:52:09 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:52:09 --> Final output sent to browser
DEBUG - 2022-01-04 10:52:09 --> Total execution time: 0.0524
INFO - 2022-01-04 03:52:11 --> Config Class Initialized
INFO - 2022-01-04 03:52:11 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:52:11 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:52:11 --> Utf8 Class Initialized
INFO - 2022-01-04 03:52:11 --> URI Class Initialized
INFO - 2022-01-04 03:52:11 --> Router Class Initialized
INFO - 2022-01-04 03:52:11 --> Output Class Initialized
INFO - 2022-01-04 03:52:11 --> Security Class Initialized
DEBUG - 2022-01-04 03:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:52:11 --> Input Class Initialized
INFO - 2022-01-04 03:52:11 --> Language Class Initialized
INFO - 2022-01-04 03:52:11 --> Loader Class Initialized
INFO - 2022-01-04 03:52:11 --> Helper loaded: url_helper
INFO - 2022-01-04 03:52:11 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:52:11 --> Controller Class Initialized
INFO - 2022-01-04 10:52:11 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:52:11 --> Model "UserModel" initialized
INFO - 2022-01-04 10:52:11 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:52:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:52:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 10:52:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:52:11 --> Final output sent to browser
DEBUG - 2022-01-04 10:52:11 --> Total execution time: 0.0570
INFO - 2022-01-04 03:53:11 --> Config Class Initialized
INFO - 2022-01-04 03:53:11 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:53:11 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:53:11 --> Utf8 Class Initialized
INFO - 2022-01-04 03:53:11 --> URI Class Initialized
DEBUG - 2022-01-04 03:53:11 --> No URI present. Default controller set.
INFO - 2022-01-04 03:53:11 --> Router Class Initialized
INFO - 2022-01-04 03:53:11 --> Output Class Initialized
INFO - 2022-01-04 03:53:11 --> Security Class Initialized
DEBUG - 2022-01-04 03:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:53:11 --> Input Class Initialized
INFO - 2022-01-04 03:53:11 --> Language Class Initialized
INFO - 2022-01-04 03:53:11 --> Loader Class Initialized
INFO - 2022-01-04 03:53:11 --> Helper loaded: url_helper
INFO - 2022-01-04 03:53:11 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:53:11 --> Controller Class Initialized
INFO - 2022-01-04 10:53:11 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:53:11 --> Model "UserModel" initialized
INFO - 2022-01-04 10:53:11 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:53:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:53:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 10:53:11 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:53:11 --> Final output sent to browser
DEBUG - 2022-01-04 10:53:11 --> Total execution time: 0.0505
INFO - 2022-01-04 03:53:13 --> Config Class Initialized
INFO - 2022-01-04 03:53:13 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:53:13 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:53:13 --> Utf8 Class Initialized
INFO - 2022-01-04 03:53:13 --> URI Class Initialized
INFO - 2022-01-04 03:53:13 --> Router Class Initialized
INFO - 2022-01-04 03:53:13 --> Output Class Initialized
INFO - 2022-01-04 03:53:13 --> Security Class Initialized
DEBUG - 2022-01-04 03:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:53:13 --> Input Class Initialized
INFO - 2022-01-04 03:53:13 --> Language Class Initialized
INFO - 2022-01-04 03:53:13 --> Loader Class Initialized
INFO - 2022-01-04 03:53:13 --> Helper loaded: url_helper
INFO - 2022-01-04 03:53:13 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:53:13 --> Controller Class Initialized
INFO - 2022-01-04 10:53:13 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:53:13 --> Model "UserModel" initialized
INFO - 2022-01-04 10:53:13 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:53:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 10:53:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 10:53:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 10:53:13 --> Final output sent to browser
DEBUG - 2022-01-04 10:53:13 --> Total execution time: 0.0556
INFO - 2022-01-04 03:53:28 --> Config Class Initialized
INFO - 2022-01-04 03:53:28 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:53:28 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:53:28 --> Utf8 Class Initialized
INFO - 2022-01-04 03:53:28 --> URI Class Initialized
INFO - 2022-01-04 03:53:28 --> Router Class Initialized
INFO - 2022-01-04 03:53:28 --> Output Class Initialized
INFO - 2022-01-04 03:53:28 --> Security Class Initialized
DEBUG - 2022-01-04 03:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:53:28 --> Input Class Initialized
INFO - 2022-01-04 03:53:28 --> Language Class Initialized
INFO - 2022-01-04 03:53:28 --> Loader Class Initialized
INFO - 2022-01-04 03:53:28 --> Helper loaded: url_helper
INFO - 2022-01-04 03:53:28 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:53:28 --> Controller Class Initialized
INFO - 2022-01-04 10:53:28 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:53:28 --> Model "UserModel" initialized
INFO - 2022-01-04 10:53:28 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:53:28 --> Final output sent to browser
DEBUG - 2022-01-04 10:53:28 --> Total execution time: 0.0621
INFO - 2022-01-04 03:59:15 --> Config Class Initialized
INFO - 2022-01-04 03:59:15 --> Hooks Class Initialized
DEBUG - 2022-01-04 03:59:15 --> UTF-8 Support Enabled
INFO - 2022-01-04 03:59:15 --> Utf8 Class Initialized
INFO - 2022-01-04 03:59:15 --> URI Class Initialized
INFO - 2022-01-04 03:59:15 --> Router Class Initialized
INFO - 2022-01-04 03:59:15 --> Output Class Initialized
INFO - 2022-01-04 03:59:15 --> Security Class Initialized
DEBUG - 2022-01-04 03:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 03:59:15 --> Input Class Initialized
INFO - 2022-01-04 03:59:15 --> Language Class Initialized
INFO - 2022-01-04 03:59:15 --> Loader Class Initialized
INFO - 2022-01-04 03:59:15 --> Helper loaded: url_helper
INFO - 2022-01-04 03:59:15 --> Database Driver Class Initialized
DEBUG - 2022-01-04 03:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 03:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 03:59:15 --> Controller Class Initialized
INFO - 2022-01-04 10:59:15 --> Model "LoginModel" initialized
INFO - 2022-01-04 10:59:15 --> Model "UserModel" initialized
INFO - 2022-01-04 10:59:15 --> Model "AdminModel" initialized
INFO - 2022-01-04 10:59:15 --> Final output sent to browser
DEBUG - 2022-01-04 10:59:15 --> Total execution time: 0.0569
INFO - 2022-01-04 04:04:06 --> Config Class Initialized
INFO - 2022-01-04 04:04:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:04:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:04:06 --> Utf8 Class Initialized
INFO - 2022-01-04 04:04:06 --> URI Class Initialized
INFO - 2022-01-04 04:04:06 --> Router Class Initialized
INFO - 2022-01-04 04:04:06 --> Output Class Initialized
INFO - 2022-01-04 04:04:06 --> Security Class Initialized
DEBUG - 2022-01-04 04:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:04:06 --> Input Class Initialized
INFO - 2022-01-04 04:04:06 --> Language Class Initialized
INFO - 2022-01-04 04:04:06 --> Loader Class Initialized
INFO - 2022-01-04 04:04:06 --> Helper loaded: url_helper
INFO - 2022-01-04 04:04:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:04:06 --> Controller Class Initialized
INFO - 2022-01-04 11:04:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:04:06 --> Model "UserModel" initialized
INFO - 2022-01-04 11:04:06 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:04:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:04:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:04:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:04:06 --> Final output sent to browser
DEBUG - 2022-01-04 11:04:06 --> Total execution time: 0.0741
INFO - 2022-01-04 04:04:21 --> Config Class Initialized
INFO - 2022-01-04 04:04:21 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:04:21 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:04:21 --> Utf8 Class Initialized
INFO - 2022-01-04 04:04:21 --> URI Class Initialized
INFO - 2022-01-04 04:04:21 --> Router Class Initialized
INFO - 2022-01-04 04:04:21 --> Output Class Initialized
INFO - 2022-01-04 04:04:21 --> Security Class Initialized
DEBUG - 2022-01-04 04:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:04:21 --> Input Class Initialized
INFO - 2022-01-04 04:04:21 --> Language Class Initialized
INFO - 2022-01-04 04:04:21 --> Loader Class Initialized
INFO - 2022-01-04 04:04:21 --> Helper loaded: url_helper
INFO - 2022-01-04 04:04:21 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:04:21 --> Controller Class Initialized
INFO - 2022-01-04 11:04:21 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:04:21 --> Model "UserModel" initialized
INFO - 2022-01-04 11:04:21 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:04:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:04:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:04:21 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:04:21 --> Final output sent to browser
DEBUG - 2022-01-04 11:04:21 --> Total execution time: 0.0536
INFO - 2022-01-04 04:04:46 --> Config Class Initialized
INFO - 2022-01-04 04:04:46 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:04:46 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:04:46 --> Utf8 Class Initialized
INFO - 2022-01-04 04:04:46 --> URI Class Initialized
INFO - 2022-01-04 04:04:46 --> Router Class Initialized
INFO - 2022-01-04 04:04:46 --> Output Class Initialized
INFO - 2022-01-04 04:04:46 --> Security Class Initialized
DEBUG - 2022-01-04 04:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:04:46 --> Input Class Initialized
INFO - 2022-01-04 04:04:46 --> Language Class Initialized
INFO - 2022-01-04 04:04:46 --> Loader Class Initialized
INFO - 2022-01-04 04:04:46 --> Helper loaded: url_helper
INFO - 2022-01-04 04:04:46 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:04:46 --> Controller Class Initialized
INFO - 2022-01-04 11:04:46 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:04:46 --> Model "UserModel" initialized
INFO - 2022-01-04 11:04:46 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:04:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:04:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:04:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:04:46 --> Final output sent to browser
DEBUG - 2022-01-04 11:04:46 --> Total execution time: 0.0592
INFO - 2022-01-04 04:05:32 --> Config Class Initialized
INFO - 2022-01-04 04:05:32 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:05:32 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:05:32 --> Utf8 Class Initialized
INFO - 2022-01-04 04:05:32 --> URI Class Initialized
INFO - 2022-01-04 04:05:32 --> Router Class Initialized
INFO - 2022-01-04 04:05:32 --> Output Class Initialized
INFO - 2022-01-04 04:05:32 --> Security Class Initialized
DEBUG - 2022-01-04 04:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:05:32 --> Input Class Initialized
INFO - 2022-01-04 04:05:32 --> Language Class Initialized
INFO - 2022-01-04 04:05:32 --> Loader Class Initialized
INFO - 2022-01-04 04:05:32 --> Helper loaded: url_helper
INFO - 2022-01-04 04:05:32 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:05:32 --> Controller Class Initialized
INFO - 2022-01-04 11:05:32 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:05:32 --> Model "UserModel" initialized
INFO - 2022-01-04 11:05:32 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:05:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:05:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:05:33 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:05:33 --> Final output sent to browser
DEBUG - 2022-01-04 11:05:33 --> Total execution time: 0.0785
INFO - 2022-01-04 04:05:42 --> Config Class Initialized
INFO - 2022-01-04 04:05:42 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:05:42 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:05:42 --> Utf8 Class Initialized
INFO - 2022-01-04 04:05:42 --> URI Class Initialized
INFO - 2022-01-04 04:05:42 --> Router Class Initialized
INFO - 2022-01-04 04:05:42 --> Output Class Initialized
INFO - 2022-01-04 04:05:42 --> Security Class Initialized
DEBUG - 2022-01-04 04:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:05:42 --> Input Class Initialized
INFO - 2022-01-04 04:05:42 --> Language Class Initialized
INFO - 2022-01-04 04:05:42 --> Loader Class Initialized
INFO - 2022-01-04 04:05:42 --> Helper loaded: url_helper
INFO - 2022-01-04 04:05:42 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:05:42 --> Controller Class Initialized
INFO - 2022-01-04 11:05:42 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:05:42 --> Model "UserModel" initialized
INFO - 2022-01-04 11:05:42 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:05:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:05:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:05:42 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:05:42 --> Final output sent to browser
DEBUG - 2022-01-04 11:05:42 --> Total execution time: 0.0529
INFO - 2022-01-04 04:06:59 --> Config Class Initialized
INFO - 2022-01-04 04:06:59 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:06:59 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:06:59 --> Utf8 Class Initialized
INFO - 2022-01-04 04:06:59 --> URI Class Initialized
INFO - 2022-01-04 04:06:59 --> Router Class Initialized
INFO - 2022-01-04 04:06:59 --> Output Class Initialized
INFO - 2022-01-04 04:06:59 --> Security Class Initialized
DEBUG - 2022-01-04 04:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:06:59 --> Input Class Initialized
INFO - 2022-01-04 04:06:59 --> Language Class Initialized
INFO - 2022-01-04 04:06:59 --> Loader Class Initialized
INFO - 2022-01-04 04:06:59 --> Helper loaded: url_helper
INFO - 2022-01-04 04:06:59 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:06:59 --> Controller Class Initialized
INFO - 2022-01-04 11:06:59 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:06:59 --> Model "UserModel" initialized
INFO - 2022-01-04 11:06:59 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:06:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:06:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:06:59 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:06:59 --> Final output sent to browser
DEBUG - 2022-01-04 11:06:59 --> Total execution time: 0.0778
INFO - 2022-01-04 04:07:06 --> Config Class Initialized
INFO - 2022-01-04 04:07:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:07:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:07:06 --> Utf8 Class Initialized
INFO - 2022-01-04 04:07:06 --> URI Class Initialized
INFO - 2022-01-04 04:07:06 --> Router Class Initialized
INFO - 2022-01-04 04:07:06 --> Output Class Initialized
INFO - 2022-01-04 04:07:06 --> Security Class Initialized
DEBUG - 2022-01-04 04:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:07:06 --> Input Class Initialized
INFO - 2022-01-04 04:07:06 --> Language Class Initialized
INFO - 2022-01-04 04:07:06 --> Loader Class Initialized
INFO - 2022-01-04 04:07:06 --> Helper loaded: url_helper
INFO - 2022-01-04 04:07:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:07:06 --> Controller Class Initialized
INFO - 2022-01-04 11:07:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:07:06 --> Model "UserModel" initialized
INFO - 2022-01-04 11:07:06 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:07:06 --> Final output sent to browser
DEBUG - 2022-01-04 11:07:06 --> Total execution time: 0.0655
INFO - 2022-01-04 04:07:07 --> Config Class Initialized
INFO - 2022-01-04 04:07:07 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:07:07 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:07:07 --> Utf8 Class Initialized
INFO - 2022-01-04 04:07:07 --> URI Class Initialized
INFO - 2022-01-04 04:07:07 --> Router Class Initialized
INFO - 2022-01-04 04:07:07 --> Output Class Initialized
INFO - 2022-01-04 04:07:07 --> Security Class Initialized
DEBUG - 2022-01-04 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:07:07 --> Input Class Initialized
INFO - 2022-01-04 04:07:07 --> Language Class Initialized
INFO - 2022-01-04 04:07:07 --> Loader Class Initialized
INFO - 2022-01-04 04:07:07 --> Helper loaded: url_helper
INFO - 2022-01-04 04:07:07 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:07:07 --> Controller Class Initialized
INFO - 2022-01-04 11:07:07 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:07:07 --> Model "UserModel" initialized
INFO - 2022-01-04 11:07:07 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:07:07 --> Final output sent to browser
DEBUG - 2022-01-04 11:07:07 --> Total execution time: 0.0464
INFO - 2022-01-04 04:07:12 --> Config Class Initialized
INFO - 2022-01-04 04:07:12 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:07:12 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:07:12 --> Utf8 Class Initialized
INFO - 2022-01-04 04:07:12 --> URI Class Initialized
INFO - 2022-01-04 04:07:12 --> Router Class Initialized
INFO - 2022-01-04 04:07:12 --> Output Class Initialized
INFO - 2022-01-04 04:07:12 --> Security Class Initialized
DEBUG - 2022-01-04 04:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:07:12 --> Input Class Initialized
INFO - 2022-01-04 04:07:12 --> Language Class Initialized
INFO - 2022-01-04 04:07:12 --> Loader Class Initialized
INFO - 2022-01-04 04:07:12 --> Helper loaded: url_helper
INFO - 2022-01-04 04:07:12 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:07:12 --> Controller Class Initialized
INFO - 2022-01-04 11:07:12 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:07:12 --> Model "UserModel" initialized
INFO - 2022-01-04 11:07:12 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:07:12 --> Final output sent to browser
DEBUG - 2022-01-04 11:07:12 --> Total execution time: 0.0478
INFO - 2022-01-04 04:07:32 --> Config Class Initialized
INFO - 2022-01-04 04:07:32 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:07:32 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:07:32 --> Utf8 Class Initialized
INFO - 2022-01-04 04:07:32 --> URI Class Initialized
INFO - 2022-01-04 04:07:32 --> Router Class Initialized
INFO - 2022-01-04 04:07:32 --> Output Class Initialized
INFO - 2022-01-04 04:07:32 --> Security Class Initialized
DEBUG - 2022-01-04 04:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:07:32 --> Input Class Initialized
INFO - 2022-01-04 04:07:32 --> Language Class Initialized
INFO - 2022-01-04 04:07:32 --> Loader Class Initialized
INFO - 2022-01-04 04:07:32 --> Helper loaded: url_helper
INFO - 2022-01-04 04:07:32 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:07:32 --> Controller Class Initialized
INFO - 2022-01-04 11:07:32 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:07:32 --> Model "UserModel" initialized
INFO - 2022-01-04 11:07:32 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:07:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:07:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:07:32 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:07:32 --> Final output sent to browser
DEBUG - 2022-01-04 11:07:32 --> Total execution time: 0.0771
INFO - 2022-01-04 04:07:35 --> Config Class Initialized
INFO - 2022-01-04 04:07:35 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:07:35 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:07:35 --> Utf8 Class Initialized
INFO - 2022-01-04 04:07:35 --> URI Class Initialized
INFO - 2022-01-04 04:07:35 --> Router Class Initialized
INFO - 2022-01-04 04:07:35 --> Output Class Initialized
INFO - 2022-01-04 04:07:35 --> Security Class Initialized
DEBUG - 2022-01-04 04:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:07:35 --> Input Class Initialized
INFO - 2022-01-04 04:07:35 --> Language Class Initialized
INFO - 2022-01-04 04:07:35 --> Loader Class Initialized
INFO - 2022-01-04 04:07:35 --> Helper loaded: url_helper
INFO - 2022-01-04 04:07:35 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:07:35 --> Controller Class Initialized
INFO - 2022-01-04 11:07:35 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:07:35 --> Model "UserModel" initialized
INFO - 2022-01-04 11:07:35 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:07:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:07:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:07:35 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:07:35 --> Final output sent to browser
DEBUG - 2022-01-04 11:07:35 --> Total execution time: 0.0781
INFO - 2022-01-04 04:08:13 --> Config Class Initialized
INFO - 2022-01-04 04:08:13 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:08:13 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:08:13 --> Utf8 Class Initialized
INFO - 2022-01-04 04:08:13 --> URI Class Initialized
INFO - 2022-01-04 04:08:13 --> Router Class Initialized
INFO - 2022-01-04 04:08:13 --> Output Class Initialized
INFO - 2022-01-04 04:08:13 --> Security Class Initialized
DEBUG - 2022-01-04 04:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:08:13 --> Input Class Initialized
INFO - 2022-01-04 04:08:13 --> Language Class Initialized
INFO - 2022-01-04 04:08:13 --> Loader Class Initialized
INFO - 2022-01-04 04:08:13 --> Helper loaded: url_helper
INFO - 2022-01-04 04:08:13 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:08:13 --> Controller Class Initialized
INFO - 2022-01-04 11:08:13 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:08:13 --> Model "UserModel" initialized
INFO - 2022-01-04 11:08:13 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:08:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:08:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:08:13 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:08:13 --> Final output sent to browser
DEBUG - 2022-01-04 11:08:13 --> Total execution time: 0.0740
INFO - 2022-01-04 04:41:52 --> Config Class Initialized
INFO - 2022-01-04 04:41:52 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:41:52 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:41:52 --> Utf8 Class Initialized
INFO - 2022-01-04 04:41:52 --> URI Class Initialized
INFO - 2022-01-04 04:41:52 --> Router Class Initialized
INFO - 2022-01-04 04:41:52 --> Output Class Initialized
INFO - 2022-01-04 04:41:52 --> Security Class Initialized
DEBUG - 2022-01-04 04:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:41:52 --> Input Class Initialized
INFO - 2022-01-04 04:41:52 --> Language Class Initialized
INFO - 2022-01-04 04:41:52 --> Loader Class Initialized
INFO - 2022-01-04 04:41:52 --> Helper loaded: url_helper
INFO - 2022-01-04 04:41:52 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:41:52 --> Controller Class Initialized
INFO - 2022-01-04 11:41:52 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:41:52 --> Model "UserModel" initialized
INFO - 2022-01-04 11:41:52 --> Model "AdminModel" initialized
INFO - 2022-01-04 11:41:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 11:41:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 11:41:52 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:41:52 --> Final output sent to browser
DEBUG - 2022-01-04 11:41:52 --> Total execution time: 0.0582
INFO - 2022-01-04 04:44:39 --> Config Class Initialized
INFO - 2022-01-04 04:44:39 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:44:39 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:44:39 --> Utf8 Class Initialized
INFO - 2022-01-04 04:44:39 --> URI Class Initialized
INFO - 2022-01-04 04:44:39 --> Router Class Initialized
INFO - 2022-01-04 04:44:39 --> Output Class Initialized
INFO - 2022-01-04 04:44:39 --> Security Class Initialized
DEBUG - 2022-01-04 04:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:44:39 --> Input Class Initialized
INFO - 2022-01-04 04:44:39 --> Language Class Initialized
INFO - 2022-01-04 04:44:39 --> Loader Class Initialized
INFO - 2022-01-04 04:44:39 --> Helper loaded: url_helper
INFO - 2022-01-04 04:44:39 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:44:39 --> Controller Class Initialized
INFO - 2022-01-04 11:44:39 --> Model "LoginModel" initialized
INFO - 2022-01-04 04:44:39 --> Config Class Initialized
INFO - 2022-01-04 04:44:39 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:44:39 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:44:39 --> Utf8 Class Initialized
INFO - 2022-01-04 04:44:39 --> URI Class Initialized
INFO - 2022-01-04 04:44:39 --> Router Class Initialized
INFO - 2022-01-04 04:44:39 --> Output Class Initialized
INFO - 2022-01-04 04:44:39 --> Security Class Initialized
DEBUG - 2022-01-04 04:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:44:39 --> Input Class Initialized
INFO - 2022-01-04 04:44:39 --> Language Class Initialized
INFO - 2022-01-04 04:44:39 --> Loader Class Initialized
INFO - 2022-01-04 04:44:39 --> Helper loaded: url_helper
INFO - 2022-01-04 04:44:39 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:44:39 --> Controller Class Initialized
INFO - 2022-01-04 11:44:39 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:44:39 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 11:44:39 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 11:44:39 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:44:39 --> Final output sent to browser
DEBUG - 2022-01-04 11:44:39 --> Total execution time: 0.0590
INFO - 2022-01-04 04:44:50 --> Config Class Initialized
INFO - 2022-01-04 04:44:50 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:44:50 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:44:50 --> Utf8 Class Initialized
INFO - 2022-01-04 04:44:50 --> URI Class Initialized
INFO - 2022-01-04 04:44:50 --> Router Class Initialized
INFO - 2022-01-04 04:44:50 --> Output Class Initialized
INFO - 2022-01-04 04:44:50 --> Security Class Initialized
DEBUG - 2022-01-04 04:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:44:50 --> Input Class Initialized
INFO - 2022-01-04 04:44:50 --> Language Class Initialized
INFO - 2022-01-04 04:44:50 --> Loader Class Initialized
INFO - 2022-01-04 04:44:50 --> Helper loaded: url_helper
INFO - 2022-01-04 04:44:50 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:44:50 --> Controller Class Initialized
INFO - 2022-01-04 11:44:50 --> Model "LoginModel" initialized
INFO - 2022-01-04 04:44:50 --> Config Class Initialized
INFO - 2022-01-04 04:44:50 --> Hooks Class Initialized
DEBUG - 2022-01-04 04:44:50 --> UTF-8 Support Enabled
INFO - 2022-01-04 04:44:50 --> Utf8 Class Initialized
INFO - 2022-01-04 04:44:50 --> URI Class Initialized
INFO - 2022-01-04 04:44:50 --> Router Class Initialized
INFO - 2022-01-04 04:44:50 --> Output Class Initialized
INFO - 2022-01-04 04:44:50 --> Security Class Initialized
DEBUG - 2022-01-04 04:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 04:44:50 --> Input Class Initialized
INFO - 2022-01-04 04:44:50 --> Language Class Initialized
INFO - 2022-01-04 04:44:50 --> Loader Class Initialized
INFO - 2022-01-04 04:44:50 --> Helper loaded: url_helper
INFO - 2022-01-04 04:44:50 --> Database Driver Class Initialized
DEBUG - 2022-01-04 04:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 04:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 04:44:50 --> Controller Class Initialized
INFO - 2022-01-04 11:44:50 --> Model "LoginModel" initialized
INFO - 2022-01-04 11:44:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 11:44:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 11:44:50 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 11:44:50 --> Final output sent to browser
DEBUG - 2022-01-04 11:44:50 --> Total execution time: 0.0476
INFO - 2022-01-04 06:04:12 --> Config Class Initialized
INFO - 2022-01-04 06:04:12 --> Hooks Class Initialized
DEBUG - 2022-01-04 06:04:12 --> UTF-8 Support Enabled
INFO - 2022-01-04 06:04:12 --> Utf8 Class Initialized
INFO - 2022-01-04 06:04:12 --> URI Class Initialized
INFO - 2022-01-04 06:04:12 --> Router Class Initialized
INFO - 2022-01-04 06:04:12 --> Output Class Initialized
INFO - 2022-01-04 06:04:12 --> Security Class Initialized
DEBUG - 2022-01-04 06:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 06:04:12 --> Input Class Initialized
INFO - 2022-01-04 06:04:12 --> Language Class Initialized
INFO - 2022-01-04 06:04:12 --> Loader Class Initialized
INFO - 2022-01-04 06:04:12 --> Helper loaded: url_helper
INFO - 2022-01-04 06:04:12 --> Database Driver Class Initialized
DEBUG - 2022-01-04 06:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 06:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 06:04:12 --> Controller Class Initialized
INFO - 2022-01-04 13:04:12 --> Model "LoginModel" initialized
INFO - 2022-01-04 06:04:12 --> Config Class Initialized
INFO - 2022-01-04 06:04:12 --> Hooks Class Initialized
DEBUG - 2022-01-04 06:04:12 --> UTF-8 Support Enabled
INFO - 2022-01-04 06:04:12 --> Utf8 Class Initialized
INFO - 2022-01-04 06:04:12 --> URI Class Initialized
INFO - 2022-01-04 06:04:12 --> Router Class Initialized
INFO - 2022-01-04 06:04:12 --> Output Class Initialized
INFO - 2022-01-04 06:04:12 --> Security Class Initialized
DEBUG - 2022-01-04 06:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 06:04:12 --> Input Class Initialized
INFO - 2022-01-04 06:04:12 --> Language Class Initialized
INFO - 2022-01-04 06:04:12 --> Loader Class Initialized
INFO - 2022-01-04 06:04:12 --> Helper loaded: url_helper
INFO - 2022-01-04 06:04:12 --> Database Driver Class Initialized
DEBUG - 2022-01-04 06:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 06:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 06:04:12 --> Controller Class Initialized
INFO - 2022-01-04 13:04:12 --> Model "LoginModel" initialized
INFO - 2022-01-04 13:04:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/login-header.php
INFO - 2022-01-04 13:04:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\login/index.php
INFO - 2022-01-04 13:04:12 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 13:04:12 --> Final output sent to browser
DEBUG - 2022-01-04 13:04:12 --> Total execution time: 0.0435
INFO - 2022-01-04 06:04:20 --> Config Class Initialized
INFO - 2022-01-04 06:04:20 --> Hooks Class Initialized
DEBUG - 2022-01-04 06:04:20 --> UTF-8 Support Enabled
INFO - 2022-01-04 06:04:20 --> Utf8 Class Initialized
INFO - 2022-01-04 06:04:20 --> URI Class Initialized
INFO - 2022-01-04 06:04:20 --> Router Class Initialized
INFO - 2022-01-04 06:04:20 --> Output Class Initialized
INFO - 2022-01-04 06:04:20 --> Security Class Initialized
DEBUG - 2022-01-04 06:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 06:04:20 --> Input Class Initialized
INFO - 2022-01-04 06:04:20 --> Language Class Initialized
INFO - 2022-01-04 06:04:20 --> Loader Class Initialized
INFO - 2022-01-04 06:04:20 --> Helper loaded: url_helper
INFO - 2022-01-04 06:04:20 --> Database Driver Class Initialized
DEBUG - 2022-01-04 06:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 06:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 06:04:20 --> Controller Class Initialized
INFO - 2022-01-04 13:04:20 --> Model "LoginModel" initialized
ERROR - 2022-01-04 13:04:20 --> Severity: Warning --> Undefined variable $user_id C:\xampp\htdocs\OJT\application\controllers\Login.php 49
INFO - 2022-01-04 06:04:20 --> Config Class Initialized
INFO - 2022-01-04 06:04:20 --> Hooks Class Initialized
DEBUG - 2022-01-04 06:04:20 --> UTF-8 Support Enabled
INFO - 2022-01-04 06:04:20 --> Utf8 Class Initialized
INFO - 2022-01-04 06:04:20 --> URI Class Initialized
DEBUG - 2022-01-04 06:04:20 --> No URI present. Default controller set.
INFO - 2022-01-04 06:04:20 --> Router Class Initialized
INFO - 2022-01-04 06:04:20 --> Output Class Initialized
INFO - 2022-01-04 06:04:20 --> Security Class Initialized
DEBUG - 2022-01-04 06:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 06:04:20 --> Input Class Initialized
INFO - 2022-01-04 06:04:20 --> Language Class Initialized
INFO - 2022-01-04 06:04:20 --> Loader Class Initialized
INFO - 2022-01-04 06:04:20 --> Helper loaded: url_helper
INFO - 2022-01-04 06:04:20 --> Database Driver Class Initialized
DEBUG - 2022-01-04 06:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 06:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 06:04:20 --> Controller Class Initialized
INFO - 2022-01-04 13:04:20 --> Model "LoginModel" initialized
INFO - 2022-01-04 13:04:20 --> Model "UserModel" initialized
INFO - 2022-01-04 13:04:20 --> Model "AdminModel" initialized
INFO - 2022-01-04 13:04:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 13:04:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 13:04:20 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 13:04:20 --> Final output sent to browser
DEBUG - 2022-01-04 13:04:20 --> Total execution time: 0.0477
INFO - 2022-01-04 06:04:46 --> Config Class Initialized
INFO - 2022-01-04 06:04:46 --> Hooks Class Initialized
DEBUG - 2022-01-04 06:04:46 --> UTF-8 Support Enabled
INFO - 2022-01-04 06:04:46 --> Utf8 Class Initialized
INFO - 2022-01-04 06:04:46 --> URI Class Initialized
INFO - 2022-01-04 06:04:46 --> Router Class Initialized
INFO - 2022-01-04 06:04:46 --> Output Class Initialized
INFO - 2022-01-04 06:04:46 --> Security Class Initialized
DEBUG - 2022-01-04 06:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 06:04:46 --> Input Class Initialized
INFO - 2022-01-04 06:04:46 --> Language Class Initialized
INFO - 2022-01-04 06:04:46 --> Loader Class Initialized
INFO - 2022-01-04 06:04:46 --> Helper loaded: url_helper
INFO - 2022-01-04 06:04:46 --> Database Driver Class Initialized
DEBUG - 2022-01-04 06:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 06:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 06:04:46 --> Controller Class Initialized
INFO - 2022-01-04 13:04:46 --> Model "LoginModel" initialized
INFO - 2022-01-04 13:04:46 --> Model "UserModel" initialized
INFO - 2022-01-04 13:04:46 --> Model "AdminModel" initialized
INFO - 2022-01-04 13:04:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 13:04:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 13:04:46 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 13:04:46 --> Final output sent to browser
DEBUG - 2022-01-04 13:04:46 --> Total execution time: 0.0572
INFO - 2022-01-04 06:04:49 --> Config Class Initialized
INFO - 2022-01-04 06:04:49 --> Hooks Class Initialized
DEBUG - 2022-01-04 06:04:49 --> UTF-8 Support Enabled
INFO - 2022-01-04 06:04:49 --> Utf8 Class Initialized
INFO - 2022-01-04 06:04:49 --> URI Class Initialized
INFO - 2022-01-04 06:04:49 --> Router Class Initialized
INFO - 2022-01-04 06:04:49 --> Output Class Initialized
INFO - 2022-01-04 06:04:49 --> Security Class Initialized
DEBUG - 2022-01-04 06:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 06:04:49 --> Input Class Initialized
INFO - 2022-01-04 06:04:49 --> Language Class Initialized
INFO - 2022-01-04 06:04:49 --> Loader Class Initialized
INFO - 2022-01-04 06:04:49 --> Helper loaded: url_helper
INFO - 2022-01-04 06:04:49 --> Database Driver Class Initialized
DEBUG - 2022-01-04 06:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 06:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 06:04:49 --> Controller Class Initialized
INFO - 2022-01-04 13:04:49 --> Model "LoginModel" initialized
INFO - 2022-01-04 13:04:49 --> Model "UserModel" initialized
INFO - 2022-01-04 13:04:49 --> Model "AdminModel" initialized
INFO - 2022-01-04 13:04:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 13:04:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/profile.php
INFO - 2022-01-04 13:04:49 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 13:04:49 --> Final output sent to browser
DEBUG - 2022-01-04 13:04:49 --> Total execution time: 0.0531
INFO - 2022-01-04 06:04:51 --> Config Class Initialized
INFO - 2022-01-04 06:04:51 --> Hooks Class Initialized
DEBUG - 2022-01-04 06:04:51 --> UTF-8 Support Enabled
INFO - 2022-01-04 06:04:51 --> Utf8 Class Initialized
INFO - 2022-01-04 06:04:51 --> URI Class Initialized
INFO - 2022-01-04 06:04:51 --> Router Class Initialized
INFO - 2022-01-04 06:04:51 --> Output Class Initialized
INFO - 2022-01-04 06:04:51 --> Security Class Initialized
DEBUG - 2022-01-04 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 06:04:51 --> Input Class Initialized
INFO - 2022-01-04 06:04:51 --> Language Class Initialized
INFO - 2022-01-04 06:04:51 --> Loader Class Initialized
INFO - 2022-01-04 06:04:51 --> Helper loaded: url_helper
INFO - 2022-01-04 06:04:51 --> Database Driver Class Initialized
DEBUG - 2022-01-04 06:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 06:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 06:04:51 --> Controller Class Initialized
INFO - 2022-01-04 13:04:51 --> Model "LoginModel" initialized
INFO - 2022-01-04 13:04:51 --> Model "UserModel" initialized
INFO - 2022-01-04 13:04:51 --> Model "AdminModel" initialized
INFO - 2022-01-04 13:04:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 13:04:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\admin/index.php
INFO - 2022-01-04 13:04:51 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 13:04:51 --> Final output sent to browser
DEBUG - 2022-01-04 13:04:51 --> Total execution time: 0.0577
INFO - 2022-01-04 06:05:06 --> Config Class Initialized
INFO - 2022-01-04 06:05:06 --> Hooks Class Initialized
DEBUG - 2022-01-04 06:05:06 --> UTF-8 Support Enabled
INFO - 2022-01-04 06:05:06 --> Utf8 Class Initialized
INFO - 2022-01-04 06:05:06 --> URI Class Initialized
DEBUG - 2022-01-04 06:05:06 --> No URI present. Default controller set.
INFO - 2022-01-04 06:05:06 --> Router Class Initialized
INFO - 2022-01-04 06:05:06 --> Output Class Initialized
INFO - 2022-01-04 06:05:06 --> Security Class Initialized
DEBUG - 2022-01-04 06:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-04 06:05:06 --> Input Class Initialized
INFO - 2022-01-04 06:05:06 --> Language Class Initialized
INFO - 2022-01-04 06:05:06 --> Loader Class Initialized
INFO - 2022-01-04 06:05:06 --> Helper loaded: url_helper
INFO - 2022-01-04 06:05:06 --> Database Driver Class Initialized
DEBUG - 2022-01-04 06:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-04 06:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-04 06:05:06 --> Controller Class Initialized
INFO - 2022-01-04 13:05:06 --> Model "LoginModel" initialized
INFO - 2022-01-04 13:05:06 --> Model "UserModel" initialized
INFO - 2022-01-04 13:05:06 --> Model "AdminModel" initialized
INFO - 2022-01-04 13:05:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/header.php
INFO - 2022-01-04 13:05:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\dashboard/index.php
INFO - 2022-01-04 13:05:06 --> File loaded: C:\xampp\htdocs\OJT\application\views\templates/footer.php
INFO - 2022-01-04 13:05:06 --> Final output sent to browser
DEBUG - 2022-01-04 13:05:06 --> Total execution time: 0.0517
