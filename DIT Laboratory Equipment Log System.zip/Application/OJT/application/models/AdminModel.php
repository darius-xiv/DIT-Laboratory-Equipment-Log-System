<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class AdminModel extends CI_Model {

        public function __construct(){
                date_default_timezone_set('Asia/Manila');
        }

        public function checkUser()
        {
                $this->db->select('*'); 
                $this->db->from('users');
                $this->db->where('user_id');
                $query = $this->db->get();

                return $query->result();
        }
        
        public function validateUser($username, $pwd)
        {
                $username = $this->db->escape_str($username);
                $pwd = $this->db->escape_str($pwd);

                $where_cond = "(username = '" . $username . "' AND password = '" . $pwd . "')";

                $this->db->select('*'); 
                $this->db->from('users');
                $this->db->where($where_cond);
                $query = $this->db->get();

                return $query->result();
        }

        public function getAllUsers()
        {
                $this->db->select('*'); 
                $this->db->from('users');
                $this->db->limit(500);
                $query = $this->db->get();

                return $query->result();
        }

        public function getAllItems()
        {
                $this->db->select('*'); 
                $this->db->from('items');
                $this->db->limit(500);
                $query = $this->db->get();

                return $query->result();
        }

        public function getAllTransaction()
        {
                $this->db->select('transaction.*, items.item_name, items.item_desc, items.item_qty, users.student_id, users.first_name, users.last_name'); 
                $this->db->from('transaction');
                $this->db->join('items', "transaction.item_id = items.item_id");
                $this->db->join('users', "transaction.user_id = users.user_id");
                $this->db->order_by('transaction.date_created', 'DESC'); 
                $this->db->limit(500);
                $query = $this->db->get();

                return $query->result();
        }


        public function getAllLogs()
        {
                $this->db->select('logs.log_id, logs.user_id, logs.description, logs.date_created, users.student_id, users.student_id, users.email_add, users.contact_no'); 
                $this->db->from('logs');
                $this->db->join('users', "logs.user_id = users.user_id", "LEFT OUTER");
                $this->db->order_by('logs.date_created', 'DESC');
                $this->db->limit(500);
                $query = $this->db->get();

                return $query->result();
        }

        public function getAllPendingUsers()
        {
                $this->db->select('*'); 
                $this->db->from('users');
                $this->db->where('is_active', 0);
                $this->db->order_by('date_updated', 'DESC');
                $this->db->limit(500);
                $query = $this->db->get();

                return $query->result();
        }

        public function getSpecifiedUserProfile($user_id)
        {
                $this->db->select('*'); 
                $this->db->from('users');
                $this->db->where('is_active', 0);
                $this->db->order_by('date_updated', 'DESC');
                $this->db->limit(500);
                $query = $this->db->get();

                return $query->result();
        }

        public function getIsActiveSpecifiedUser($user_id)
        {
                $user_id = $this->db->escape_str($user_id);

                $this->db->select('user_id, is_active'); 
                $this->db->from('users');
                $this->db->where('user_id', $user_id);
                // $this->db->limit(1);
                $query = $this->db->get();

                return $query->result();
        }

        public function updateIsStatusUser($user_id, $is_active)
        {
                $user_id=$this->db->escape_str($user_id);
		$is_active=$this->db->escape_str($is_active);
                $date_updated = date("Y-m-d H:i:s");

                $data = array("is_active" => $is_active, 'date_updated' => $date_updated);
                $this->db->where("user_id=", $user_id);
                $this->db->update("users", $data);
        }

        public function insertLogs($description)
        {
                $user_id=$this->session->userdata('user_id');
                $description=$this->db->escape_str($description);
                $date_created = date("Y-m-d H:i:s");

                $data = array("user_id" => $user_id, 'description' => $description, 'date_created' => $date_created);
                $this->db->insert("logs", $data);
        }

        public function getProfileUser($user_id)
        {
                $user_id = $this->db->escape_str($user_id);

                $this->db->select('*'); 
                $this->db->from('users');
                $this->db->where('user_id', $user_id);
                // $this->db->limit(1);
                $query = $this->db->get();

                return $query->result();
        }

        public function getProfileItem($item_id)
        {
                $item_id = $this->db->escape_str($item_id);

                $this->db->select('*'); 
                $this->db->from('items');
                $this->db->where('item_id', $item_id);
                // $this->db->limit(1);
                $query = $this->db->get();

                return $query->result();
        }

        public function updateUserProfile($user_id, $student_id, $first_name, $last_name, $email_add, $contact_no)
        {
                $user_id=$this->db->escape_str($user_id);
                $student_id=$this->db->escape_str($student_id);
                $first_name=$this->db->escape_str($first_name);
                $last_name=$this->db->escape_str($last_name);
                $email_add=$this->db->escape_str($email_add);
		$contact_no=$this->db->escape_str($contact_no);
                $date_updated = date("Y-m-d H:i:s");

                $data = array(
                        "student_id" => $student_id, 
                        "first_name" => $first_name, 
                        "last_name" => $last_name, 
                        "email_add" => $email_add, 
                        "contact_no" => $contact_no, 
                        'date_updated' => $date_updated
                );
                $this->db->where("user_id=", $user_id);
                $this->db->update("users", $data);
        }

        public function addUserProfile($student_id, $password, $first_name, $last_name, $email_add, $contact_no)
        {
                $student_id=$this->db->escape_str($student_id);
                $password=$this->db->escape_str($password);
                $password_hash=md5($password);
                $first_name=$this->db->escape_str($first_name);
                $last_name=$this->db->escape_str($last_name);
                $email_add=$this->db->escape_str($email_add);
		$contact_no=$this->db->escape_str($contact_no);
                $date_created = date("Y-m-d H:i:s");
                $date_updated = date("Y-m-d H:i:s");

                $data = array(
                        "student_id" => $student_id, 
                        "password" => $password_hash, 
                        "first_name" => $first_name, 
                        "last_name" => $last_name, 
                        "email_add" => $email_add, 
                        "contact_no" => $contact_no, 
                        'date_created' => $date_created,
                        'date_updated' => $date_updated
                );
                $this->db->insert("users", $data);
        }

        public function addItemProfile($item_name, $item_desc, $item_qty)
        {
                $item_name=$this->db->escape_str($item_name);
                $is_available="Yes";
                $item_desc=$this->db->escape_str($item_desc);
                $item_qty=$this->db->escape_str($item_qty);
                $date_created = date("Y-m-d H:i:s");

                $data = array(
                        "item_name" => $item_name, 
                        "is_available" => $is_available, 
                        "item_desc" => $item_desc, 
                        "item_qty" => $item_qty, 
                        'date_created' => $date_created
                );
                $this->db->insert("items", $data);
        }

        public function updateItemProfile($item_id, $item_name, $item_desc, $item_qty)
        {
                $item_id=$this->db->escape_str($item_id);
                $item_name=$this->db->escape_str($item_name);
                $item_desc=$this->db->escape_str($item_desc);
                $item_qty=$this->db->escape_str($item_qty);
                $date_updated = date("Y-m-d H:i:s");

                $data = array(
                        "item_name" => $item_name, 
                        "item_desc" => $item_desc, 
                        "item_qty" => $item_qty, 
                        'date_created' => $date_updated
                );
                $this->db->where("item_id=", $item_id);
                $this->db->update("items", $data);
        }

        public function getBorrowedItem($transaction_id)
        {
                $transaction_id = $this->db->escape_str($transaction_id);

                $this->db->select('*'); 
                $this->db->from('transaction');
                $this->db->where('transaction_id', $transaction_id);
                // $this->db->limit(1);
                $query = $this->db->get();

                return $query->result();
        }

        public function updateIsStatusUserBorrowed($transaction_id, $is_status)
        {
                $transaction_id=$this->db->escape_str($transaction_id);
		$is_status=$this->db->escape_str($is_status);
                $date_created = date("Y-m-d H:i:s");

                $data = array("is_status" => $is_status, 'date_created' => $date_created);
                $this->db->where("transaction_id=", $transaction_id);
                $this->db->update("transaction", $data);
        }

        public function updateItemStatus($item_id, $is_available)
        {
                $item_id = $this->db->escape_str($item_id);
                $is_available = $this->db->escape_str($item_id);;

                $data = array(
                "is_available" => $is_available, 
                );
                $this->db->where("item_id=", $item_id);
                $this->db->update("items", $data);
        }

}
?>