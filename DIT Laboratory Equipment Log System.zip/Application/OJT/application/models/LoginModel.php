<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class LoginModel extends CI_Model {

        public function __construct(){
                date_default_timezone_set('Asia/Manila');
        }

        public function checkUser()
        {
                $this->db->select('*'); 
                $this->db->from('users');
                $this->db->where('user_id');
                $query = $this->db->get();

                return $query->result();
        }
        
        public function validateUser($student_id, $pwd)
        {
                $student_id = $this->db->escape_str($student_id);
                $pwd = $this->db->escape_str($pwd);

                $where_cond = "(student_id = '" . $student_id . "' AND password = '" . $pwd . "' AND is_active = 1)";

                $this->db->select('*'); 
                $this->db->from('users');
                $this->db->where($where_cond);
                $query = $this->db->get();

                return $query->result();
        }

        public function checkStudentNumberExist($student_id)
        {
                $student_id = $this->db->escape_str($student_id);

                $where_cond = "(student_id = '" . $student_id . "')";

                $this->db->select('student_id'); 
                $this->db->from('users');
                $this->db->limit(1);
                $this->db->where($where_cond);
                $query = $this->db->get();
                
                return  $query->result();
        }

        public function registerAccount($register_student_num, $register_email, $register_password)
        {
                $register_student_num = $this->db->escape_str($register_student_num);
                $register_email = $this->db->escape_str($register_email);
                $register_password = md5($this->db->escape_str($register_password));
                $is_active = 0;
                $date_created = date("Y-m-d H:i:s");
                $date_updated = date("Y-m-d H:i:s");

		$data =  array(
                        "is_active" => $is_active,
			"student_id" => $register_student_num,
			"email_add" => $register_email,
                        "password" => $register_password,
			"date_created" => $date_created,
                        "date_updated" => $date_updated
		);
		$this->db->insert("users",$data);
        }

        public function insertLogs($description)
        {
                $user_id=$this->session->userdata('user_id');
                $description=$this->db->escape_str($description);
                $date_created = date("Y-m-d H:i:s");

                $data = array("user_id" => $user_id, 'description' => $description, 'date_created' => $date_created);
                $this->db->insert("logs", $data);
        }

}
?>