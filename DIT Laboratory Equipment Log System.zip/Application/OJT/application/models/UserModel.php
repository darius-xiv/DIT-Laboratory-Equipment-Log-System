<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class UserModel extends CI_Model {

    public function fetchUserProfile($user_id)
    {
        $user_id = $this->db->escape_str($user_id);

        $this->db->select('*'); 
        $this->db->from('users');
        $this->db->where('user_id', $user_id);
        $this->db->limit(1);
        $query = $this->db->get();

        return $query->result();
    }

    public function fetchMinimumLogs()
    {
        $this->db->select('logs.user_id, users.student_id, users.first_name, users.last_name, logs.description, logs.date_created'); 
        $this->db->from('logs');
        $this->db->join('users', "logs.user_id = users.user_id", "LEFT OUTER JOIN");
        $this->db->order_by('logs.date_created', "DESC");
        $this->db->limit(5);
        $query = $this->db->get();
        
        return $query->result();
    }

    public function fetchTopItems()
    {
        //SELECT *, count(user_id) AS top_user FROM transaction GROUP BY user_id ORDER BY min(user_id) desc;
        $where_clause = "MIN(transaction.item_id) DESC";
        $this->db->select('transaction.*, items.item_name, count(transaction.item_id) AS top_items'); 
        $this->db->from('transaction');
        $this->db->join('items', 'transaction.item_id = items.item_id', 'LEFT OUTER');
        $this->db->group_by('transaction.item_id');
        $this->db->where('transaction.is_status', 'Received');
        $this->db->order_by($where_clause);
        $this->db->limit(5);
        $query = $this->db->get();

        return $query->result();
    }

    public function fetchTopUsers()
    {
        $where_clause = "MIN(transaction.user_id) DESC";
        $this->db->select('transaction.*, users.first_name, count(transaction.user_id) AS top_users'); 
        $this->db->from('transaction');
        $this->db->join('users', 'transaction.user_id = users.user_id', 'LEFT OUTER');
        $this->db->group_by('transaction.user_id');
        $this->db->where('transaction.is_status', 'Received');
        $this->db->order_by($where_clause);
        $this->db->limit(5);
        $query = $this->db->get();

        return $query->result();
    }

    public function pendingUserList()
	{
		$this->load->view('dashboard/home_borrowing_table.php');
	}

    public function getAllAvailableItem()
    {
        $this->db->select('*'); 
        $this->db->from('items');
        $this->db->where('is_available', 'Yes');
        $this->db->order_by('date_created', 'DESC'); 
        $query = $this->db->get();

        return $query->result();
    }

    public function getSpecificItem($item_id)
    {
        $item_id = $this->db->escape_str($item_id);

        $this->db->select('*'); 
        $this->db->from('items');
        $this->db->where('item_id', $item_id);
        // $this->db->limit(1);
        $query = $this->db->get();

        return $query->result();
    }

    public function borrowItem($item_id){

		$item_id = $this->db->escape_str($item_id);
        $user_id = $this->session->userdata('user_id');
        $is_status = "Pending";
        $date_created = date("Y-m-d H:i:s");

        $data = array(
            "user_id" => $user_id, 
            "item_id" => $item_id, 
            "is_status" => $is_status, 
            "date_created" => $date_created
        );
        $this->db->insert("transaction", $data);
    }

    public function updateItemStatusPending($item_id)
    {
        $item_id = $this->db->escape_str($item_id);
        $is_available = "No";

        $data = array(
            "is_available" => $is_available, 
        );
        $this->db->where("item_id=", $item_id);
        $this->db->update("items", $data);
    }
    
    public function insertLogs($description)
    {
            $user_id=$this->session->userdata('user_id');
            $description=$this->db->escape_str($description);
            $date_created = date("Y-m-d H:i:s");

            $data = array("user_id" => $user_id, 'description' => $description, 'date_created' => $date_created);
            $this->db->insert("logs", $data);
    }

    public function updateUserProfile($user_id, $student_id, $first_name, $last_name, $email_add, $contact_no)
    {
        $user_id=$this->db->escape_str($user_id);
        $student_id=$this->db->escape_str($student_id);
        $first_name=$this->db->escape_str($first_name);
        $last_name=$this->db->escape_str($last_name);
        $email_add=$this->db->escape_str($email_add);
        $contact_no=$this->db->escape_str($contact_no);
        $date_updated = date("Y-m-d H:i:s");

        $data = array(
            "student_id" => $student_id, 
            "first_name" => $first_name, 
            "last_name" => $last_name, 
            "email_add" => $email_add, 
            "contact_no" => $contact_no, 
            'date_updated' => $date_updated
        );

        $this->db->where("user_id=", $user_id);
        $this->db->update("users", $data);
    }

    public function getUserInventoryTransactions()
    {
        $user_id=$this->session->userdata('user_id');
        $this->db->select('transaction.*, items.item_name, items.item_desc, items.item_qty'); 
        $this->db->from('transaction');
        $this->db->join('items', 'transaction.item_id = items.item_id', 'LEFT OUTER');
        $this->db->where('transaction.user_id', $user_id);
        $query = $this->db->get();

        return $query->result();
    }

    public function getSpecificTransaction($transaction_id)
    {
        $transaction_id = $this->db->escape_str($transaction_id);

        $this->db->select('*'); 
        $this->db->from('transaction');
        $this->db->where('transaction_id', $transaction_id);
        // $this->db->limit(1);
        $query = $this->db->get();

        return $query->result();
    }

    public function returnItem($transaction_id){

		$transaction_id = $this->db->escape_str($transaction_id);
        $is_status = "Returned";
        $date_created = date("Y-m-d H:i:s");

        $data = array(
            "is_status" => $is_status, 
            "date_created" => $date_created
        );
        $this->db->where("transaction_id=", $transaction_id);
        $this->db->update("transaction", $data);
    }
}
?>