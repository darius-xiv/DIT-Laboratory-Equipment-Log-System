<table class="table table-hover" id="admin_borrow_list" style="width: 100%;"></table>

<script>
    $(document).ready(function(){
        

    
    var getBorrowList;

    $(document).on('click', '#change_is_status', function(){

        var transaction_id = $(this).attr("data-id");
        var datastring = "transaction_id="+transaction_id;
        // alert(datastring);
        $.ajax({
            type: "POST",
            url: "<?= base_url('admin/editBorrowItem'); ?>",
            data: datastring,
            cache: false,
            success: function (data) {

                $("#modal_title").html('Change status');

                $("#getModal").modal("show");
                $("#modal_body").html(data);
                
            }
        });
    });

    function get_borrow_list(){
        $('#admin_borrow_list').empty();
        $.ajax({ 
            url: "<?= base_url('admin/getBorrowList'); ?>",
            type:'get',
            dataType:'json',
            cache: false,

            success: function(response){
                    
                if (response.status == "success"){
                    getBorrowList = $("#admin_borrow_list").DataTable({
                        "order": [],
                        "data": response.finalData,
                        "columns": 
                            [
                                { title: "Student ID", data: "student_id" },
                                { title: "Name", data: "full_name" },
                                { title: "Item", data: "item_name" },
                                { title: "Desc", data: "item_desc" },
                                { title: "Status", data: "is_status" },
                                { title: "Date", data: "date_created" },
                                { title: "Action", data: "", "render": function(data, type, full, meta)
                                    {
                                        var html = "";

                                        html += "<button type='button' class='btn btn-primary' data-toggle='modal' title='Change' id='change_is_status' data-id='"+full.transaction_id+"'><i class='fa fa-cogs'></i></button>&nbsp;";
                                      
                                        return html;
                                    }  
                                }
                            ]
                    });
                }
                else{
                    
                }
            }
        });
    }

    get_borrow_list();
    
    });
</script>