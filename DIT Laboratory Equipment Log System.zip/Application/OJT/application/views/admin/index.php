<div class="container py-5">
    <div class="row">
        <div class="col-md-2 nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <a class="nav-link active" id="v-pills-intro-tab" data-toggle="pill" href="#v-pills-intro" role="tab" aria-controls="v-pills-intro" aria-selected="true"><i class="fa fa-book"></i> &nbsp; Introduction</a>
            <a class="nav-link" id="v-pills-users-tab" data-toggle="pill" href="#v-pills-users" role="tab" aria-controls="v-pills-users" aria-selected="true"><i class="fa fa-group"></i> &nbsp; Users</a>
            <a class="nav-link" id="v-pills-items-tab" data-toggle="pill" href="#v-pills-items" role="tab" aria-controls="v-pills-items" aria-selected="false"><i class="fa fa-cart-plus"></i> &nbsp; Items</a>
            <a class="nav-link" id="v-pills-log-tab" data-toggle="pill" href="#v-pills-log" role="tab" aria-controls="v-pills-log" aria-selected="false"><i class="fa fa-history"></i> &nbsp; Logs</a>
            <a class="nav-link" id="v-pills-pending-users-tab" data-toggle="pill" href="#v-pills-pending-users" role="tab" aria-controls="v-pills-pending-users" aria-selected="false"><i class="fa fa-user-plus"></i> &nbsp; Pending users</a>
            <a class="nav-link" id="v-pills-borrow-tab" data-toggle="pill" href="#v-pills-borrow" role="tab" aria-controls="v-pills-borrow" aria-selected="false"><i class="fa fa-exchange"></i> &nbsp; Borrow item</a>
        </div>
        <div class="col-md-10 tab-content" id="v-pills-tabContent">
            <!-- <div class='d-flex justify-content-center'><div class='spinner-grow text-primary m-5' style='width: 5rem; height: 5rem;'></div></div> -->
            <div class="tab-pane fade show active" id="v-pills-intro" role="tabpanel" aria-labelledby="v-pills-intro-tab">
                <div class="jumbotron">
                    <div class="row">
                        <div class="col-md-8">
                            <h1>Hello!</h1>
                            <p class="text-justify">This is the introduction part of the administration page, where it contains almost the functionality of the system and manual how to operate it and what does it do whenever you do something.But first, before that I would like to share the things that I have used upon the development of this web application. The things that I used upon the development of this system was composed of a MVC framework named CodeIgniter and different libraries of JavaScript such as ChartJS, Glyphcons, Ajax, DataTable, Bootstrap and etc. (It is just all jQuery but I prefer to break it down to let give some hints on what I only know hehe). Also the concept applied here was a combination of OOP and Procedural Programming (I prefer this two because I still struggle using PDO).</p>
                            <p class="text-justify">Going back to the topic, the succeeding information was based only on the opinion of the developers mind on how will the application work and this is just simply a beta version of the web app. Further a do, a changes may apply based on the necessity of its end-users. </p>
                        </div>
                        <div class="col-md-4">
                            <span class="d-flex justify-content-center p-3"><img src="assets/img/anime-hi.gif" alt="Hi, don't click me pls." class="custom-hover rounded" style="width: 100%; height: auto;"></span>
                            <small><i>It only takes a minute to say hello, but it can make a big difference in someones day.</i> &#128512;</small>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 p-5">
                        <span class="align-middle">
                            <h2>The activity stream</h2>
                            <p class="text-justify">The activity stream is also known as the short activity log where it shows the latest event happened and occured in the system, this part logs every interaction that the user make from loggin in, borrowing item, editting profile, managing adminstration features, and even in the log-out.</p>
                        </span>
                    </div>
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/activity-stream.png" alt="Developer Profile" class="custom-hover rounded" style="width: 70%; height: auto;"></span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/start.png" alt="Developer Profile" class="custom-hover rounded" style="width: 70%; height: auto;"></span>
                    </div>
                    <div class="col-md-6 p-5">
                        <span class="align-middle">
                            <h2>Start up</h2>
                            <p class="text-justify">This segment shows the interactivity where it greets the user upon landing on the index page, the 'highlighted' let's start! was a clickable text where it interchange into a data table that corresponds where the end user can borrow the equipment they needed.</p>
                        </span>
                    </div>
                </div>
                <hr>    
                <div class="row">
                    <div class="row p-5">
                        <h2>Charts</h2>
                        <p class="text-justify">The charts was function was simulate a graphical illustration showing the current top users and top items that were identified as the actively participated in the system, the limitation for each entry in charts was only 5, and modifiable. The chart is also dynamic where it changes upon changing the status of an item or a user.</p>
                    </div>
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/chart1.png" alt="Developer Profile" class="custom-hover rounded" style="width: 70%; height: auto;"></span>
                    </div>
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/chart2.png" alt="Developer Profile" class="custom-hover rounded" style="width: 70%; height: auto;"></span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/nav-icons.png" alt="Developer Profile" class="custom-hover rounded" style="width: 90%; height: auto;"></span>
                    </div>
                    <div class="col-md-6 p-5">
                        <span class="align-middle">
                            <h2>Nav button</h2>
                            <p class="text-justify">The nav button in the toppest part of the web app does corresponds on the level of authenticity available in the system where the administration part were only be accessible for those who are set as an admin, and blocks the parameter whenever the user is not an admin.</p>
                        </span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6 p-5">
                        <span class="align-middle">
                            <h2>Side panel</h2>
                            <p class="text-justify">The side-panel or the administration side navigation were optimized to be a dynamic button that work synchronously towards the buttons indicated. Each side panels contains different pages containing tables and sort of other buttons.</p>
                        </span>
                    </div>
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/side-panel.png" alt="Developer Profile" class="custom-hover rounded" style="width: 70%; height: auto;"></span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/modal-1.png" alt="Developer Profile" class="custom-hover rounded" style="width: 90%; height: auto;"></span>
                    </div>
                    <div class="col-md-6 p-5">
                        <span class="align-middle">
                            <h2>Modal</h2>
                            <p class="text-justify">Each modal corresponds to the contained attribute of a button in the datatable, each modal has different manner of how they interact based on the function of a specific button. Each modal signifies a new form that evaluates the input and changing status by the admin user.</p>
                        </span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="row p-5">
                        <h2>User tab</h2>
                        <p class="text-justify">User tab is the a segment where the adminstration can track the record of a user, and manipulate it based on the available actions provided by the web system. Containing a three button of add user, where the admin can simply a user directly, the edit button, where the admin can change the profile information of the user, and the change status button, where the admin can deactive the account of the user.</p>
                    </div>
                    <div class="row">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/user-tab.png" alt="Developer Profile" class="custom-hover rounded" style="width: 70%; height: auto;"></span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/item-tab.png" alt="Developer Profile" class="custom-hover rounded" style="width: 90%; height: auto;"></span>
                    </div>
                    <div class="col-md-6 p-5">
                        <span class="align-middle">
                            <h2>Item tab</h2>
                            <p class="text-justify">The item tab is data table that contains a series of information regarding to an item register in the system, the each item has an action button where the admin can edit the information of the item registered. Additionally, in the upper-right corner of the page, there is an item button where the admin can register an item.</p>
                        </span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6 p-5">
                        <span class="align-middle">
                            <h2>Log tab</h2>
                            <p class="text-justify">The history or log tab does contain the history of all events happen in the system, unlike in the activity stream, the log tab does contains information that were necessary to track the occurences of a user, thus the implementation of search, it is easier for to track from inputing a certain keyword involve on the event.</p>
                        </span>
                    </div>
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/log-tab.png" alt="Developer Profile" class="custom-hover rounded" style="width: 90%; height: auto;"></span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/pending-tab.png" alt="Developer Profile" class="custom-hover rounded" style="width: 90%; height: auto;"></span>
                    </div>
                    <div class="col-md-6 p-5">
                        <span class="align-middle">
                            <h2>Pending user tab</h2>
                            <p class="text-justify">The pending user tab includes a table of users who are currently deactivate due to new users account and an actual deactivated account set by the admin. The pending users segregates the active user to the inactive users. A button was included to be operated by the admin whether it will be activated or not.</p>
                        </span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="row">
                        <span class="align-middle">
                            <h2>Borrow tab</h2>
                            <p class="text-justify">The borrow tab is a datatable of the transaction made in the system, each transaction corresponds on the action of the user and the admin from a lending process or borrowing process that takes place as the main feature of the program. Each status contains a "Pending"( which the initial value for the end user when they borrow ), the "Approved" ( means that the user can now take the item and dismisses the activity of the item in the home page borrowing tab ), the "Returned" ( where it was return by the end user and suppose to be check and received by the admin ), and lastly the "Received" ( where the process endeds and recorded as a used item by the user, for every instances of a success, a record will be applied on the charts in the home page as a graphical illustration that simulates the manipulation of data inside the system ).
                            </p>
                        </span>
                    </div>
                    <div class="row">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/borrow-tab.png" alt="Developer Profile" class="custom-hover rounded" style="width: 90%; height: auto;"></span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="row">
                        <span class="align-middle">
                            <h2>Borrow tab</h2>
                            <p class="text-justify">The profile page contains the whole operation a regular end user where he/she could manipulate the data that were available in his/her end. The profile can interchange a editting field upon click the edit icon. And also the data table indicated below has a significant factor on operating the entries of borrowed items from the user.
                            </p>
                        </span>
                    </div>
                    <div class="row">
                        <span class="d-flex justify-content-center p-3"><img src="assets/img/profile-page.png" alt="Developer Profile" class="custom-hover rounded" style="width: 90%; height: auto;"></span>
                    </div>
                </div>
                
                
            </div>
            <div class="tab-pane fade" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab">
                <h2 class="py-2">List of users</h2>
                <span class="d-flex justify-content-end"><button class="btn btn-success mb-3" id="add_user">Add user</button></span>
                <div id="my-users-tab"></div>
            </div>
            <div class="tab-pane fade" id="v-pills-items" role="tabpanel" aria-labelledby="v-pills-items-tab">
                <h2 class="py-2">List of items</h2>
                <span class="d-flex justify-content-end"><button class="btn btn-success mb-3" id="add_item">Add item</button></span>
                <div id="my-items-tab"></div>
            </div>
            <div class="tab-pane fade" id="v-pills-log" role="tabpanel" aria-labelledby="v-pills-log-tab">
                <h2 class="py-2">History / Logs</h2>
                <div id="my-logs-tab"></div>
            </div>
            <div class="tab-pane fade" id="v-pills-pending-users" role="tabpanel" aria-labelledby="v-pills-pending-users-tab">
                <h2 class="py-2">List of pending users</h2>
                <div id="my-pending-tab"></div>
            </div>
            <div class="tab-pane fade" id="v-pills-borrow" role="tabpanel" aria-labelledby="v-pills-borrow-tab">
                <h2 class="py-2">Borrowing transactions</h2>
                <div id="my-borrow-tab"></div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){

        $('#add_user').click(function(event){
            event.preventDefault();
                $.ajax({
                type: "POST",
                url: "<?= base_url('admin/addUser'); ?>",
                data: {},
                cache: false,
                success: function (data) {

                    $("#modal_title").html('Add user');
                    $("#getModal").modal("show");
                    $("#modal_body").html(data);
                }
            });
        });

        $('#add_item').click(function(event){
            event.preventDefault();
                $.ajax({
                type: "POST",
                url: "<?= base_url('admin/addItem'); ?>",
                data: {},
                cache: false,
                success: function (data) {

                    $("#modal_title").html('Add item');
                    $("#getModal").modal("show");
                    $("#modal_body").html(data);
                }
            });
        });

        $('#v-pills-users-tab').click(function(e){
            e.preventDefault();
            $.ajax({
                type: "GET",
                url: "<?= base_url("admin/userList");?>",
                data: { },
                beforeSend: function() { 
                    $('#my-users-tab').html("<?= "<div class='d-flex justify-content-center'><div class='spinner-grow text-primary m-5' style='width: 5rem; height: 5rem;'></div></div>"; ?>");      
                },
                success: function(data){
                    $('#my-users-tab').html(data);
                }
            });
        });

        $('#v-pills-items-tab').click(function(e){
            e.preventDefault();
            $.ajax({
                type: "GET",
                url: "<?= base_url("admin/itemList");?>",
                data: { },
                beforeSend: function() { 
                    $('#my-items-tab').html("<?= "<div class='d-flex justify-content-center'><div class='spinner-grow text-primary m-5' style='width: 5rem; height: 5rem;'></div></div>"; ?>");      
                },
                success: function(data){
                    $('#my-items-tab').html(data);
                }
            });
        });

        $('#v-pills-log-tab').click(function(e){
            e.preventDefault();
            $.ajax({
                type: "GET",
                url: "<?= base_url("admin/logList");?>",
                data: { },
                beforeSend: function() { 
                    $('#my-logs-tab').html("<?= "<div class='d-flex justify-content-center'><div class='spinner-grow text-primary m-5' style='width: 5rem; height: 5rem;'></div></div>"; ?>");      
                },
                success: function(data){
                    $('#my-logs-tab').html(data);
                }
            });
        });

        $('#v-pills-pending-users-tab').click(function(e){
            e.preventDefault();
            $.ajax({
                type: "GET",
                url: "<?= base_url("admin/PendingUserList");?>",
                data: { },
                beforeSend: function() { 
                    $('#my-pending-tab').html("<?= "<div class='d-flex justify-content-center'><div class='spinner-grow text-primary m-5' style='width: 5rem; height: 5rem;'></div></div>"; ?>");      
                },
                success: function(data){
                    $('#my-pending-tab').html(data);
                }
            });
        });

        $('#v-pills-borrow-tab').click(function(e){
            e.preventDefault();
            $.ajax({
                type: "GET",
                url: "<?= base_url("admin/borrowList");?>",
                data: { },
                beforeSend: function() { 
                    $('#my-borrow-tab').html("<?= "<div class='d-flex justify-content-center'><div class='spinner-grow text-primary m-5' style='width: 5rem; height: 5rem;'></div></div>"; ?>");      
                },
                success: function(data){
                    $('#my-borrow-tab').html(data);
                }
            });
        });

       
        
    });
</script>