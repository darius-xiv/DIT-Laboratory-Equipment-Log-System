<table class="table table-hover" id="admin_item_list" style="width: 100%;"></table>

<script>
    $(document).ready(function(){
        

    
    var getItemList;

    $(document).on('click', '#item_edit', function(){

        var item_id = $(this).attr("data-id");
        var datastring = "item_id="+item_id;
        // alert(datastring);
        $.ajax({
            type: "POST",
            url: "<?= base_url('admin/editItem'); ?>",
            data: datastring,
            cache: false,
            success: function (data) {

                $("#modal_title").html('Edit profile');

                $("#getModal").modal("show");
                $("#modal_body").html(data);
                
            }
        });
    });

    function get_item_list(){
        $('#admin_item_list').empty();
        $.ajax({ 
            url: "<?= base_url('admin/getItemList'); ?>",
            type:'get',
            dataType:'json',
            cache: false,

            success: function(response){
                    
                if (response.status == "success"){
                    getItemList = $("#admin_item_list").DataTable({
                        "order": [],
                        "data": response.finalData,
                        "columns": 
                            [
                                { title: "Item name", data: "item_name" },
                                { title: "Description", data: "item_desc" },
                                { title: "Quantity", data: "item_qty" },
                                { title: "Available", data: "is_available" },
                                { title: "Date", data: "date_created" },
                                { title: "Action", data: "", "render": function(data, type, full, meta)
                                    {
                                        var html = "";

                                        html += "<button type='button' class='btn btn-primary' data-toggle='modal' title='Edit' id='item_edit' data-id='"+full.item_id+"'><i class='fa fa-edit'></i></button>&nbsp;";
                                      
                                        return html;
                                    }  
                                }
                            ]
                    });
                }
                else{
                    
                }
            }
        });
    }

    get_item_list();
    
    });
</script>