<table class="table table-hover" id="admin_log_list" style="width: 100%;"></table>

<script>
    $(document).ready(function(){
        

    
    var getLogList;

    function get_log_list(){
        $('#admin_log_list').empty();
        $.ajax({ 
            url: "<?= base_url('admin/getLogList'); ?>",
            type:'get',
            dataType:'json',
            cache: false,

            success: function(response){
                    
                if (response.status == "success"){
                    getLogList = $("#admin_log_list").DataTable({
                        "order": [],
                        "data": response.finalData,
                        "columns": 
                            [
                                { title: "History ID", data: "log_id" },
                                { title: "Student ID", data: "student_id" },
                                { title: "Log entry", data: "description" },
                                { title: "Date", data: "log_date" }
                            ]
                    });
                }
                else{
                    
                }
            }
        });
    }

    get_log_list();
    
    });
</script>