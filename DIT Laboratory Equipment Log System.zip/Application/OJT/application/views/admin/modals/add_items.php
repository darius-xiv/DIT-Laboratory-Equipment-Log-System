<form id="form_to_add" method="POST" enctype="multipart/form-data">
        <div class="modal-body" id="modal_body"> 
                <div class="row mb-1">
                        <label  class="col-md-4" for="item_name">Nametag</label>
                        <input class="col-md-8" type="text" name="item_name" value="" required>
                </div>
                <div class="row mb-1">
                        <label  class="col-md-4" for="item_desc">Description</label>
                        <input class="col-md-8" type="text" name="item_desc" value="" required>
                </div>
                <div class="row mb-1">
                        <label  class="col-md-4" for="item_qty">Quantity</label>
                        <input class="col-md-8" type="number" name="item_qty" value="" required>
                </div>
        </div>
        <div class="modal-footer" id="modal_footer">
                <input type="submit" class="btn btn-success mx-1" value="Add" id="add_confirm">
                <button class="btn btn-danger mx-1" data-dismiss="modal" id="change_status_dismiss">Cancel</button>
        </div>
</form>
<div class="alert alert-info" id="message_handler"><div class="spinner-border spinner-border-sm"></div> Loading </div>

<script>
$(document).ready(function(){

        var $message_handler = $('#message_handler').hide();

        $('#form_to_add').on('submit', function(event){
                event.preventDefault();
                var form_data = new FormData($('#form_to_add')[0]);
                $.ajax({
                        type: 'POST',
                        url: "<?= base_url('admin/addItemScript');?>",
                        data: form_data,
                        dataType:'json',
                        processData: false,
                        contentType: false,
                        cache: false,
                        
                        beforeSend: function() { 
                                $('#message_handler').show();     
                        },
                        success: function (response) {
                                $('#message_handler').attr("class", "alert alert-success").html("<b>Success!</b> You have added an item.").delay(2000).hide('slow');
                                $('#add_confirm').attr("disabled","disabled");
                                $('#v-pills-items-tab').click();
                        }
                });
        });
});
</script>