<form id="form_to_add" method="POST" enctype="multipart/form-data">
        <div class="modal-body" id="modal_body"> 
                <div class="row mb-1">
                        <label  class="col-md-4" for="student_id">Student no.</label>
                        <input class="col-md-8" type="text" name="student_id" value="" required>
                </div>
                <div class="row mb-1">
                        <label  class="col-md-4" for="password">Password</label>
                        <input class="col-md-8" type="password" name="password" value="" required>
                </div>
                <div class="row mb-1">
                        <label  class="col-md-4" for="first_name">First name</label>
                        <input class="col-md-8" type="text" name="first_name" value="" required>
                </div>
                <div class="row mb-1">
                        <label  class="col-md-4" for="last_name">Last name</label>
                        <input class="col-md-8" type="text" name="last_name" value="" required>
                </div>
                <div class="row mb-1">
                        <label  class="col-md-4" for="email_add">Email address</label>
                        <input class="col-md-8" type="email" name="email_add" value="" required>
                </div>
                <div class="row mb-1">
                        <label  class="col-md-4" for="contact_no">Contact no.</label>
                        <input class="col-md-8" type="text" name="contact_no" value="" required>
                </div>
        </div>
        <div class="modal-footer" id="modal_footer">
                <input type="submit" class="btn btn-success mx-1" value="Add" id="add_confirm">
                <button class="btn btn-danger mx-1" data-dismiss="modal" id="change_status_dismiss">Cancel</button>
        </div>
</form>
<div class="alert alert-info" id="message_handler"><div class="spinner-border spinner-border-sm"></div> Loading </div>

<script>
$(document).ready(function(){

        var $message_handler = $('#message_handler').hide();

        $('#form_to_add').on('submit', function(event){
                event.preventDefault();
                var form_data = new FormData($('#form_to_add')[0]);
                // alert(form_data);
                $.ajax({
                        type: 'POST',
                        url: "<?= base_url('admin/addUserScript');?>",
                        data: form_data,
                        dataType:'json',
                        processData: false,
                        contentType: false,
                        cache: false,
                        
                        beforeSend: function() { 
                                $('#message_handler').show();     
                        },
                        success: function (response) {
                                $('#message_handler').attr("class", "alert alert-success").html("<b>Success!</b> You have change the status.").delay(2000).hide('slow');
                                $('#add_confirm').attr("disabled","disabled");
                                // alert(response.success+" "+response.is_active+" "+response.user_id); 
                                // location.reload();
                                $('#v-pills-users-tab').click();
                                // setTimeout(function(){
                                //         $('#change_status_dismiss').click();
                                // }, 3000);
                        }
                });
        });
});
</script>