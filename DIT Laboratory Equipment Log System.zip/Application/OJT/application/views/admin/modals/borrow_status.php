<?php
    if($is_status == "Pending")
    {
?>
<div class="modal-body d-block" id="modal_body"> 
    <div class="d-flex justify-content-center"><p>Are you sure you want to approve this transaction?</p></div>
        <div class="d-flex justify-content-center">
                <button class="btn btn-success mx-1" id="confirm">Yes</button>
                <button class="btn btn-danger mx-1" data-dismiss="modal" id="change_status_dismiss">No</button>
        </div>
</div>
<?php
    $is_status = "Approved";
    } 
    else if($is_status == "Returned")
    {
?>  
<div class="modal-body d-block" id="modal_body"> 
    <div class="d-flex justify-content-center"><p>Are you sure you already receive the item?</p></div>
        <div class="d-flex justify-content-center">
                <button class="btn btn-success mx-1" id="confirm">Yes</button>
                <button class="btn btn-danger mx-1" data-dismiss="modal" id="change_status_dismiss">No</button>
        </div>
</div>
<?php
    $is_status = "Received";
    }
    else {
?>
    <div class="d-flex justify-content-center"><p>You can't change this user due to its status.</p></div>
<?php
    }
?>
<div class="alert alert-info" id="message_handler"><div class="spinner-border spinner-border-sm"></div> Loading </div>


<script>
$(document).ready(function(){

        var $message_handler = $('#message_handler').hide();

        $('#confirm').click(function(event){
                event.preventDefault();
                var get_transaction_id = '<?= $transaction_id; ?>';
                var get_current_status = '<?= $is_status; ?>';
                var get_current_item_id = '<?= $item_id; ?>';

                datastring = "transaction_id="+get_transaction_id+"&is_status="+get_current_status+"&item_id="+get_current_item_id;
                // alert(datastring);

                $.ajax({
                        type: 'POST',
                        url: "<?= base_url('admin/changeBorrowedStatusScript');?>",
                        data: datastring,
                        dataType:'json',
                        cache: false,
                        beforeSend: function() { 
                                $('#message_handler').show();     
                        },
                        success: function (response) {
                                $('#message_handler').attr("class", "alert alert-success").html("<b>Success!</b> You have change the status.").delay(2000).hide('slow');
                                $('#confirm').attr("disabled","disabled");
                                
                                $('#v-pills-borrow-tab').click();
                        }
                        });

        });

});
</script>