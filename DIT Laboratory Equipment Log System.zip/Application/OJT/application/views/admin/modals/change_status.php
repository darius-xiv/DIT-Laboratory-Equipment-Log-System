<div class="modal-body d-block" id="modal_body"> 
        <div class="d-flex justify-content-center"><p>Are you sure you want to change the status of this user?</p></div>
                <div class="d-flex justify-content-center">
                        <button class="btn btn-success mx-1" id="confirm">Yes</button>
                        <button class="btn btn-danger mx-1" data-dismiss="modal" id="change_status_dismiss">No</button>
                </div>
        </div>
<div class="alert alert-info" id="message_handler"><div class="spinner-border spinner-border-sm"></div> Loading </div>


<script>
$(document).ready(function(){

        var $message_handler = $('#message_handler').hide();

        $('#confirm').click(function(event){
                event.preventDefault();
                var get_current_id = '<?= $user_id; ?>';
                var get_current_status = '<?= $is_active; ?>';

                datastring = "user_id="+get_current_id+"&is_active="+get_current_status;
                // alert(datastring);

                $.ajax({
                        type: 'POST',
                        url: "<?= base_url('admin/changeStatusScript');?>",
                        data: datastring,
                        dataType:'json',
                        cache: false,
                        beforeSend: function() { 
                                $('#message_handler').show();     
                        },
                        success: function (response) {
                                $('#message_handler').attr("class", "alert alert-success").html("<b>Success!</b> You have change the status.").delay(2000).hide('slow');
                                $('#confirm').attr("disabled","disabled");
                                // alert(response.success+" "+response.is_active+" "+response.user_id); 
                                // location.reload();
                                $('#v-pills-users-tab').click();
                                // setTimeout(function(){
                                //         $('#change_status_dismiss').click();
                                // }, 3000);
                        }
                        });

        });

});
</script>