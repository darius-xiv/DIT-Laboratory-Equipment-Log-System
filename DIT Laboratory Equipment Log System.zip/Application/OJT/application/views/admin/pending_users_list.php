<table class="table table-hover" id="admin_pending_list"  style="width: 100%;"></table>

<script>
    $(document).ready(function(){

    
    var getPendingUserList;

    $(document).on('click', '#approve_status', function(){

        var user_id = $(this).attr("data-id");
        var datastring = "user_id="+user_id;
        // alert(datastring);
        $.ajax({
            type: "POST",
            url: "<?= base_url('admin/approvalUser'); ?>",
            data: datastring,
            cache: false,
            success: function (data) {
                
                $("#modal_title").html('User approval');

                $("#getModal").modal("show");
                $("#modal_body").html(data);
                
            }
        });
    });

    function get_pending_user_list(){
        $('#admin_pending_list').empty();
        $.ajax({ 
            url: "<?= base_url('admin/getPendingUserList'); ?>",
            type:'get',
            dataType:'json',
            cache: false,

            success: function(response){
                    
                if (response.status == "success"){
                    getPendingUserList = $("#admin_pending_list").DataTable({
                        "order": [],
                        "data": response.finalData,
                        "columns": 
                            [
                                { title: "Student no.", data: "student_id"},
                                { title: "E-mail address", data: "email_add"},
                                { title: "Date", data: "date_updated"},
                                { title: "Action", data: "", "render": function(data, type, full, meta)
                                    {
                                        var html = "";
                                        html += "<button type='button' class='btn btn-success' data-toggle='modal' title='Approve user' id='approve_status' data-id='"+full.user_id+"'><i class='fa fa-plus-circle'></i></button>&nbsp;";
                                      
                                        return html;
                                    }  
                                }
                            ]
                    });
                }
                else{
                    
                }
            }
        });
    }

    get_pending_user_list();
    
    });
</script>