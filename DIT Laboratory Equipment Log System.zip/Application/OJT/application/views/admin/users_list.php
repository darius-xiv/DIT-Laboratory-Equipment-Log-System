<table class="table table-hover" id="admin_user_list"  style="width: 100%;"></table>

<script>
$(document).ready(function(){
        
    var getUserList;

    $(document).on('click', '#edit', function(){

        var user_id = $(this).attr("data-id");
        var datastring = "user_id="+user_id;
        // alert(datastring);
        $.ajax({
            type: "POST",
            url: "<?= base_url('admin/editUser'); ?>",
            data: datastring,
            cache: false,
            success: function (data) {

                $("#modal_title").html('Edit profile');

                $("#getModal").modal("show");
                $("#modal_body").html(data);
                
            }
        });
    });

    $(document).on('click', '#change_status', function(){

        var user_id = $(this).attr("data-id");
        var datastring = "user_id="+user_id;
        // alert(datastring);
        $.ajax({
            type: "POST",
            url: "<?= base_url('admin/changeStatus'); ?>",
            data: datastring,
            cache: false,
            success: function (data) {
                
                $("#modal_title").html('Change status');

                $("#getModal").modal("show");
                $("#modal_body").html(data);
                
            }
        });
    });




    function get_user_list(){
        $('#admin_user_list').empty();
        $.ajax({ 
            url: "<?= base_url('admin/getUserList'); ?>",
            type:'get',
            dataType:'json',
            cache: false,

            success: function(response){
                    
                if (response.status == "success"){
                    getUserList = $("#admin_user_list").DataTable({
                        "order": [],
                        "data": response.finalData,
                        "columns": 
                            [
                                { title: "Student no.", data: "student_id"},
                                { title: "Name", data: "full_name"},
                                { title: "E-mail address", data: "email_add"},
                                { title: "Contact no.", data: "contact_no"},
                                { title: "Active", data: "is_active_status"},
                                { title: "Action", data: "", "render": function(data, type, full, meta)
                                    {
                                        var html = "";

                                        html += "<button type='button' class='btn btn-primary' data-toggle='modal' title='Edit' id='edit' data-id='"+full.user_id+"'><i class='fa fa-edit'></i></button>&nbsp;";
                                        html += "<button type='button' class='btn btn-info' data-toggle='modal' title='Change Status' id='change_status' data-id='"+full.user_id+"'><i class='fa fa-refresh'></i></button>&nbsp;";
                                      
                                        return html;
                                    }  
                                }
                            ]
                    });
                }
                else{
                    
                }
            }
        });
    }

    get_user_list();    
});
</script>