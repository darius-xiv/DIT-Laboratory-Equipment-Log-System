<div class="container py-5">
    <div class="row">
        <div class="col-md-5">
            <h1 class="text-center">About the <span class="text-primary custom-hover"> dev</span>eloper</h1>
            <span class="d-flex justify-content-center p-3"><img src="assets/img/dev-pp.jpg" alt="Developer Profile" class="custom-hover rounded rounded-circle" style="width: 100%; height: auto;"></span>
            <span class="d-flex justify-content-center mb-4">
                <a href="https://facebook.com/darkeuz"><i class="fa fa-facebook-square mx-1" style="font-size:32px"></i></a> &nbsp; 
                <a href="https://www.instagram.com/i.xiv.xcviii/"><i class="fa fa-instagram mx-1" style="font-size:32px"></i></a> &nbsp; 
                <a href="https://twitter.com/darkeuz_"><i class="fa fa-twitter-square mx-1" style="font-size:32px"></i></a>
            </span>
            <span class="d-flex justify-content-center p-5"><p class="blockquote-footer">For I consider that the sufferings of this present time are not worth comparing with the glory that is going to be revealed to us.  <cite title="Romans 8:18 CSB">Romans 8:18</cite></p></span>
            
        </div>
        <div class="col-md-7">
            <div class="jumbotron custom-enlarge-description">
                <h1>Letter</h1>
                <p class="text-justify">Hello! First of all, thank you for using my application, I am very glad that you had reach this point reading my sentiment on how I deal and finish (mostly) the features of this web app. It’s been a long journey where I start and to be honest there are lot of struggles and uncanny events happened along the way on the completion of this task. Well, it had been a roller coaster of emotion from the moment I get stuck and learn on most of things upon the development of this system. So I hope that if you are the next developer of this system, just be creative and always think of the box, every function made here was just came from an impulsive decision and look how it went through (was it cool right?). But yeah, be considerate on practicing the proper architecture you have learned in programming, such as the concepts applied to make it more user friendly not only to the end users but also to the developers. I applied so much principles here, and so to prevent you from being overwhelm on those if ever, I suggest to practice OOP and native PHP. Again, thank you very much and I hope you had a good day!</p>
            </div>
            <div class="jumbotron custom-enlarge-description">
                <h2>Appreciation</h2>
                <p class="text-justify">Upon the completion of this a light capstone project, I would like also to thank my teachers and instructors who had been huge a part of my whole college in Cavite State University – Silang Campus, honing my skillsets and knowledge about programming especially in web development. Mentioning Mr. Cereneo S. Santiago Jr., who had been my technical critic in my thesis and instructor on most of my subjects. Mr. Jared E. Alabanza, who had been my adviser in thesis and whom I look up as a developer. To my friends and family, who continuously support me whenever I needed. Thank you so much.</p>
            </div>
        </div>
    </div>
</div>