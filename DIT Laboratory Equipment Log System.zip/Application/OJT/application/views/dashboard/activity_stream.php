    <h1>Activity Stream</h1>
    
<?php
    foreach ($fetch_logs as $row) {

        if ($row['first_name'] != '' && $row['last_name'] != '') {
            $shown_name = $row['first_name'] . " " . $row['last_name'];
        }
        else if ($row['student_id'] != 0) {
            $shown_name = $row['student_id'];
        }
        else {
            $shown_name = "No name";
        }

        $convert_date = date("F j Y @ g:i A", strtotime($row['date_created']));
?>
    <hr class="bg-light">
    <p class="my-0"><?= $shown_name; ?> &#8212; <?= $row['description']; ?>. </p>
    <small><p class="text-warning"><?= $convert_date; ?></p></small>
<?php
    }
?>
    <hr class="bg-light">
    <small class="d-flex justify-content-center"></small>
    <hr class="bg-light">