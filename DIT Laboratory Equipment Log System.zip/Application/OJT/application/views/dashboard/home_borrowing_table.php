<table class="table table-hover" id="borrow_table" style="width: 100%;"></table>

<script>

$(document).ready(function(){

    var borrowList;

    $(document).on('click', '#borrow_item', function(){

    var item_id = $(this).attr("data-id");
    var datastring = "item_id="+item_id;
    // alert(datastring);
        $.ajax({
            type: "POST",
            url: "<?= base_url('dashboard/borrowItem'); ?>",
            data: datastring,
            cache: false,
            success: function (data) {
                
                $("#modal_title").html('Borrow this item?');

                $("#getModal").modal("show");
                $("#modal_body").html(data);
                
            }
        });
    });

    
    function get_borrow_table(){
        
        $('#borrow_table').empty();
        $.ajax({ 
            url: "<?= base_url('dashboard/getBorrowingTable'); ?>",
            type:'get',
            dataType:'json',
            cache: false,

            success: function(response){
                    
                if (response.status == "success"){
                    borrowList = $("#borrow_table").dataTable({
                        "order": [],
                        "data": response.finalData,
                        "columns": 
                            [
                                { title: "Item ID", data: "item_id" },
                                { title: "Name", data: "item_name" },
                                { title: "Description", data: "item_desc" },
                                { title: "Quantity", data: "item_qty" },
                                { title: "Action", data: "", "render": function(data, type, full, meta)
                                    {
                                        var html = "";
                                        html += "<button type='button' class='btn btn-success' data-toggle='modal' title='Borrow item?' id='borrow_item' data-id='"+full.item_id+"'><i class='fa fa-plus-circle'></i></button>&nbsp;";
                                      
                                        return html;
                                    }  
                                }
                            ]
                    });
                }
                else{
                    console.log('Something went wrong');
                }
            }
        });
    }

    get_borrow_table();
    
});
</script>