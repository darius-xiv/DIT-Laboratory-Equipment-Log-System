
<script src="assets/js/charts.js"></script>
<!-- <div class="jumbotron">
    <div class="container">
        <h1 class="display-4 mx-2">Welcome, Darius!</h1>
        <p class="lead mx-2">It is nice to know that you are here.</p>
    </div>
</div> -->
<?php
    $shown_user_name = "new user";
    if ($this->session->userdata('first_name') != "") {
        $shown_user_name = $this->session->userdata('first_name');
    }

?>

<div class="container">
    <div class="row my-2">
        <div class="col-md-4 bg-secondary mt-4 py-2 text-justify text-light rounded" id="activity_stream_tab"></div>
        <div class="col-md-8 mt-4 py-2 text-justify align-middle" >
            <div id="home_borrow" class="p-3">
                <div class="jumbotron" style="background:transparent !important" >
                    <h1 class='d-flex justify-content-center'>Hello &nbsp;<span class="text-info"> <?= $shown_user_name;?></span>!</h1>
                    <h3 class='d-flex justify-content-center'>It is nice to see you here!</h3>
                    <span class='d-flex justify-content-center'><img id="borrow_now" src="<?= base_url(); ?>assets/img/started.gif" alt="Click to get started" title="Click to start" style="width: 250px;">
                </div></span>
            </div>
        </div>
    </div>
    <div class="row my-4">
        <div class="col-lg-6 my-2">
            <h2>Most borrowed items</h2>
            <div id="donut" style="height: 300px;"></div>
        </div>
        <div class="col-lg-6 my-2">
            <h2>Top borrowers</h2>
            <div id="bar_chart" style="height: 300px;"></div>
        </div>
    </div>
    <div class="row my-4">
        
    </div>
</div>
<script>
    $(document).ready(function(){
        
        $('#borrow_now').click(function(e){
            e.preventDefault();
                $.ajax({
                    type: "GET",
                    url: "<?= base_url("dashboard/getBorrowingList");?>",
                    data: { },
                    beforeSend: function() { 
                        $('#home_borrow').html("<?= "<div class='d-flex justify-content-center'><div class='spinner-grow text-primary m-5' style='width: 5rem; height: 5rem;'></div></div>"; ?>");      
                    },
                    success: function(data){
                        $('#home_borrow').html(data);
                    }
                });
        });

        get_activity_stream();
        var getActivityStream;

        function get_activity_stream(){

            $('#activity_stream_tab').empty();
            
            $.ajax({
                url: "<?= base_url("dashboard/fetchLogs");?>",
                type: "GET",
                beforeSend: function() { 
                    $('#activity_stream_tab').html("<?= "<div class='d-flex justify-content-center'><div class='spinner-grow text-light m-5' style='width: 5rem; height: 5rem;'></div></div>"; ?>");      
                },
                success: function(response){
                    // var result = $('#</div>').append(response).find('#activity_stream_tab').html();
                    $('#activity_stream_tab').html(response);
                    // $('#activity_stream_tab').html(response);
                }
            });
        
        }

    });

    var donut_options = {
        animationEnabled: true,
        // title: {
        //   text: "ACME Corporation Apparel Sales"
        // },
        data: [{
        type: "doughnut",
        innerRadius: "40%",
        showInLegend: true,
        legendText: "{label}",
        indexLabel: "{label}: #percent%",
        dataPoints: [
<?php
        foreach ($fetch_top_items as $row) {
?>
            { label: "<?= $row['item_name'];?>", y: <?= $row['top_items'];?> },
<?php
        }
?>
            // { label: "Keys", y: 115 },
            // { label: "Printer", y: 70 },
            // { label: "Projector", y: 55 },
            // { label: "Crimping tool", y: 12 },
            // { label: "Others", y: 0 }
        ]
        }]
    };

    $("#donut").CanvasJSChart(donut_options);

    var bar_chart_options = {
        animationEnabled: true,
        // title: {
        //   text: "Column Chart in jQuery CanvasJS"              
        // },
        data: [              
        {

        type: "column",
        dataPoints: [
<?php
        foreach ($fetch_top_users as $row) {
?>
            { label: "<?= $row['first_name'];?>",  y: <?= $row['top_users'];?>  },
<?php
        }
?>
            // { label: "Darius Chua",  y: 40  },
            // { label: "Rajesh Cholia", y: 15  },
            // { label: "Ciara Dela Masa", y: 25  },
            // { label: "Rama Yu",  y: 30  },
            // { label: "Cereneo Santiago",  y: 28  }
            ]
        }
        ]
    };
    $("#bar_chart").CanvasJSChart(bar_chart_options);

    // var sortable_function = {
    //     $(function() {
    //     $( "#sortable_items" ).sortable();
    //   });
  // };
</script>