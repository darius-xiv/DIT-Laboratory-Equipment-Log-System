<div class="modal-body d-block" id="modal_body"> 
        <div class="d-flex justify-content-center"><p>Are you sure you want to borrow this item?</p></div>
                <div class="d-flex justify-content-center">
                        <button class="btn btn-success mx-1" id="confirm_make_borrow">Yes</button>
                        <button class="btn btn-danger mx-1" data-dismiss="modal" id="change_status_dismiss">No</button>
                </div>
        </div>
<div class="alert alert-info" id="message_handler"><div class="spinner-border spinner-border-sm"></div> Loading </div>


<script>
$(document).ready(function(){

    var $message_handler = $('#message_handler').hide();

        $('#confirm_make_borrow').click(function(event){
            event.preventDefault();
            var get_current_id = '<?= $item_id; ?>';

            datastring = "item_id="+get_current_id;
                // alert(datastring);

                $.ajax({
                    type: 'POST',
                    url: "<?= base_url('dashboard/makeBorrowScript');?>",
                    data: datastring,
                    dataType:'json',
                    cache: false,
                    beforeSend: function() { 
                        $('#message_handler').show();     
                    },
                    success: function (response) {
                        $('#message_handler').attr("class", "alert alert-success").html("<b>Success!</b> Please check your inventory in your profile").delay(2000).hide('slow');
                        $('#confirm_make_borrow').attr("disabled","disabled");
                                
                        $('#borrow_now').click();
                    }
                });

        });

});
</script>