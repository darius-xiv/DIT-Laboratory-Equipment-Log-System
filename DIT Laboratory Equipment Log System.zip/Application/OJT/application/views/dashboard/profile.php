<div class="container mt-4">
    <div >
        <div class="d-flex justify-content-center">
            <div class="row">
                <div class="col-md-4  d-flex justify-content-center">
                    <img src="assets/img/default-profile.jpg" alt="Profile picture" onclick="alert('Change profile picture')" class="custom-hover">
                </div>
                <div class="col-md-6 offset-md-2 align-self-center">
                    <form id="profile_to_upload" method="POST" enctype="multipart/form-data">
                        <fieldset class="border p-4">
                            <legend class="w-auto">Profile</legend>
                            <div class="d-flex flex-row-reverse">
                                <i class="fa fa-edit mb-2" id="edit-allow"></i>
                            </div>
                            <div class="d-flex flex-row-reverse mb-2">
                                <span class="btn btn-danger btn-sm" id="profile-submit-cancel" hidden>Cancel</span>
                                <input type="submit" class="btn btn-success btn-sm mx-1" value="Save" id="profile-submit-edit" hidden>
                            </div>
                            
                            <div class="mb-3 row">
                                <label for="first_name" class="col-sm-4 col-form-label">First name</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="first_name" value="<?= $first_name; ?>"required readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="last_name" class="col-sm-4 col-form-label">Last name</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="last_name" value="<?= $last_name; ?>" required readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="email_add" class="col-sm-4 col-form-label">E-mail</label>
                                <div class="col-sm-8">
                                    <input type="email" class="form-control" name="email_add" placeholder="sample@gmail.com" value="<?= $email_add; ?>" required readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="contact" class="col-sm-4 col-form-label">Contact no.</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="contact" value="<?= $contact_no; ?>" required readonly>
                                </div>
                            </div>
                            <div class="d-flex flex-row-reverse">
                                
                            </div>
                        </fieldset>
                    </form>
                    
                </div>
            </div>
        </div>
        <hr>
        <div class="my-3" id="my_inventory">
            <div class="row d-flex justify-content-center">
                <img id="open_my_bag" src="<?= base_url(); ?>assets/img/bag.gif" alt="Click to get started" title="Click to view your inventory" style="width: 250px;">
            </div>
            <div class="row d-flex justify-content-center">
                <small>Click to view inventory</small>
            </div>
        </div>
    </div>
</div>
<script src="assets/js/profile.js"></script>

<script>
    $(document).ready(function(){

        $('#profile_to_upload').on('submit', function(event){
                event.preventDefault();
                var form_data = new FormData($('#profile_to_upload')[0]);
                // alert(form_data);
                $.ajax({
                        type: 'POST',
                        url: "<?= base_url('dashboard/updateProfileInfo');?>",
                        data: form_data,
                        dataType:'json',
                        processData: false,
                        contentType: false,
                        cache: false,
                        success: function () {
                            location.reload();
                        }
                });
        });

        var showInventory
        function show_my_inventory(){
            $('#my_inventory').empty();
            $.ajax({
                    type: "GET",
                    url: "<?= base_url("dashboard/getInventoryBag");?>",
                    data: { },
                    beforeSend: function() { 
                        $('#my_inventory').html("<?= "<div class='d-flex justify-content-center'><div class='spinner-grow text-primary m-5' style='width: 5rem; height: 5rem;'></div></div>"; ?>");      
                    },
                    success: function(data){
                        $('#my_inventory').html(data);
                    }
                });

        }

        show_my_inventory();
        // $('#open_my_bag').click(function(e){
        //     e.preventDefault();
                
        // });





    });
</script>