
<h1>My inventory</h1>
<table class="table table-hover" id="inventory_bag_table" style="width: 100%;"></table>

<script>

$(document).ready(function(){

    var inventLis;

    $(document).on('click', '#return_item', function(){

    var transaction_id = $(this).attr("data-id");
    var datastring = "transaction_id="+transaction_id;
    // alert(datastring);
        $.ajax({
            type: "POST",
            url: "<?= base_url('dashboard/returnItem'); ?>",
            data: datastring,
            cache: false,
            success: function (data) {
                
                $("#modal_title").html('Return this item?');

                $("#getModal").modal("show");
                $("#modal_body").html(data);
                
            }
        });
    });

    
    function get_inventory_table(){
        
        $('#inventory_bag_table').empty();
        $.ajax({ 
            url: "<?= base_url('dashboard/getInventoryTable'); ?>",
            type:'get',
            dataType:'json',
            cache: false,

            success: function(response){
                    
                if (response.status == "success"){
                    inventList = $("#inventory_bag_table").dataTable({
                        "order": [],
                        "data": response.finalData,
                        "columns": 
                            [
                                { title: "Name", data: "item_name" },
                                { title: "Description", data: "item_desc" },
                                { title: "Quantity", data: "item_qty" },
                                { title: "Status", data: "is_status" },
                                { title: "Action", data: "", "render": function(data, type, full, meta)
                                    {
                                        var html = "";
                                        if (full.is_status == 'Approved'){
                                            html += "<button type='button' class='btn btn-success' data-toggle='modal' title='Borrow item?' id='return_item' data-id='"+full.transaction_id+"'><i class='fa fa-plus-circle'></i></button>&nbsp;";
                                        }

                                        return html;
                                    }  
                                }
                            ]
                    });
                }
                else{
                    console.log('Something went wrong');
                }
            }
        });
    }

    get_inventory_table();
    
});
</script>