
<div class="">
    <div class="shadow container custom-login-box rounded my-5">
           <div class="p-2 bg-color-custom">
               <span class="d-flex justify-content-center"><h1 class="text-primary mb-0 pb-0 mt-4">DIT</h1></span>
               <span class="d-flex justify-content-center"><h3 class="mt-0 pt-0">Equipment Log System</h3></span>
           </div>
           <div class="row p-3">
                    <button class="col-md-6 d-flex justify-content-center btn btn-info" id="login-btn">Login</button>
                    <button class="col-md-6 d-flex justify-content-center btn btn-outline-info" id="register-btn">Register</button>
           </div>
           <form action="login/loginPageScript" method="POST" class="px-4 mt-3" id="login-form">
                <input type="hidden" name="authenticate_page"  value="login_attempt">
                <label for="login_student_num">Student no.</label>
                <input type="text" name="login_student_num" class="form-control" value="<?php echo isset($_POST['login_student_num']); ?>" required>
<?php
                // if ($this->session->flashdata('incorrect_user_pwd') == "false") { 
?>
                <!-- <small class='d-block text-danger' id="student_num_warning">Please check your student no.!</small>  -->
<?php
                // }
?>
                <label for="login_password">Password</label>
                <input type="password" name="login_password" class="form-control" required id='password-input'>
<?php
                // if ($this->session->flashdata('incorrect_user_pwd') == "false") { 
?>
                <!-- <small class='d-block text-danger' id="password_warning">Please check your password!</small>  -->
<?php
                // }
?>
                <div class="checkbox">
                    <label><input type="checkbox" id="check"> Show password</label>
                </div>
                <input type="submit" value="Login" class="btn btn-success btn-block mt-3" id="make_log">
                <a href="#" class="" id="forgot_pass">Forgot password?</a>
           </form>
           <form action="login/loginPageScript" method="POST" class="px-4 mt-1" id="register-form" style="display: none;">
                <input type="hidden" name="authenticate_page" value="register_attempt">
                <label for="register_student_num">Student no.</label>
                <input type="text" name="register_student_num" class="form-control" required>
                <label for="register_email">Email address</label>
                <input type="email" name="register_email" class="form-control" required>
                <label for="register_password">Password</label>
                <input type="password" name="register_password" class="form-control" required>
                <label for="register_re_password">Confirm password</label>
                <input type="password" name="register_re_password" class="form-control" required>
                <input type="submit" value="Register" class="btn btn-success btn-block mt-3" id="make_reg">
           </form>
     </div>
</div>

<script>
    $(document).ready(function (){

        toastr.options = {
            "closeButton": true,
            "newestOnTop": true,
            "progressBar": true,
            "positionClass": "toast-top-center",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
            
        }
<?php
        if (!empty($this->session->flashdata('login_error')) && $this->session->flashdata('login_error') != "success")
        {
?>
            toastr.error("<?= $this->session->flashdata('login_error'); ?>");
<?php
        } 
        else if (!empty($this->session->flashdata('login_error')) && $this->session->flashdata('login_error') == "success") 
        {
?>
            toastr.success("Please wait for your account to be activated.", "Registration success!");
<?php
        }
?>
        

        $("#login-btn").click(function() {
            $("#login-form").show("slow");
            $("#register-form").hide("slow");
            toastr.remove();
            toastr.info('Make sure that you already had an activated account to log-in.');
        });
        $( "#register-btn" ).click(function() {
            $("#login-form").hide("slow");
            $("#register-form").show("slow");
            toastr.remove();
<?php
        if (!empty($this->session->flashdata('login_error')) && $this->session->flashdata('login_error') == "success") 
        {
?>
            toastr.info('Do you wish to register another account?','You are already registered');
<?php
        } else {
?>
            toastr.info('Please fill up the fields.');
<?php
        }
?>
            
        });

        $('#check').click(function(){
            $(this).is(':checked') ? $('#password-input').attr('type', 'text') : $('#password-input').attr('type', 'password');
            toastr.remove();
            toastr.warning('Be careful! Someone might see your password.'  );
        });

        $('#forgot_pass').click(function(){
            toastr.remove();
            toastr.success('We are still working on it :)', 'Sorry for incovenience');
        });

    });
</script>