<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel ="icon" href="<?= base_url('assets/img/icon2.png'); ?>" type="image/x-icon">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    
    
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    
    <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
    <script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>

    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/custom-style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css"/>
    <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
     
    <title>
<?php
        if (!empty($title)) {
            echo $title;
        } else {
            echo "DIT Equipment Log System";
        }
?>
    </title>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="index.php"><b class="text-primary">DIT</b> Laboratory Equipment Log System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
            </ul>

            <span class="navbar-text">
                <a class="btn btn-light" href="about">About</a>
            </span>
            <!-- <span class="navbar-text">
                <a class="btn btn-light mr-4" href="contact">Contact</a>
            </span> -->
            
            <form class="form-inline my-2 my-lg-0">
            <div class="btn-group">
                <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-user-circle"></i> | 
<?php 
                if (!empty($this->session->userdata('first_name')) || $this->session->userdata('first_name') != NULL)
                {
                    echo $this->session->userdata('first_name');
                }
                else if (!empty($this->session->userdata('student_id')) || $this->session->userdata('student_id') != NULL) 
                {
                    echo $this->session->userdata('student_id');
                }
                else {
                    echo "N/A";
                }

?>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
<?php
                if ($this->session->userdata('is_admin') == 1)
                {
?>
                    <a class="dropdown-item btn btn-secondary" href="admin">Administration</a>
<?php
                }
?>
                    <a class="dropdown-item btn btn-secondary" href="profile">Profile</a>
                    <a class="dropdown-item btn btn-secondary" href="login/logoutPageScript">Log out</a>
                </div>
            </div>
            </form>
        </div>
    </div>
</nav>
    
