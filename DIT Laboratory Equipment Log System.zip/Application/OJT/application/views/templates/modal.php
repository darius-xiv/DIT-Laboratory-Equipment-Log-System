<div id="getModal" class="modal fade" role="dialog">
    <div class="modal-dialog" id="modal_size">

        <div class="modal-content">
            <div class="modal-header" id="modal_header">
                <h4 class="modal-title" id="modal_title"></h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body" id="modal_body"> </div>
            <div class="modal-footer" id="modal_footer"> </div>
        </div>

    </div>
</div>