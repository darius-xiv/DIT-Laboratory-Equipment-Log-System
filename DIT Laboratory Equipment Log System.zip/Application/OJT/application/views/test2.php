<?php

   echo $registration_data;
?>