$(document).ready(function() {

    $('#edit-allow').click(function(){
        $("#edit-allow").hide();
        $("#profile-submit-edit").prop("hidden", false);
        $("#profile-submit-cancel").prop("hidden", false);

        $("input[name='first_name']").prop("readonly", false);
        $("input[name='last_name']").prop("readonly", false);
        $("input[name='email_add']").prop("readonly", false);
        $("input[name='contact']").prop("readonly", false);
    });

    $('#profile-submit-cancel').click(function(){
        $("#edit-allow").show();
        $("#profile-submit-edit").prop("hidden", true);
        $("#profile-submit-cancel").prop("hidden", true);

        $("input[name='first_name']").prop("readonly", true);
        $("input[name='last_name']").prop("readonly", true);
        $("input[name='email_add']").prop("readonly", true);
        $("input[name='contact']").prop("readonly", true);
    });
    
});