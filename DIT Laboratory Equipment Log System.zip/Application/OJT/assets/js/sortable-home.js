window.onload = function () {

    console.log("dog");
    
}