Folder OJT ->> Source code of application, if you are using local. Just put it into the htdocs of your local server. (I use XAMPP)
dit_sql.sql ->> This is the db of the system.