-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2022 at 02:34 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dit_ojt`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_desc` varchar(255) NOT NULL,
  `item_qty` int(11) NOT NULL,
  `is_available` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `item_desc`, `item_qty`, `is_available`, `date_created`) VALUES
(1, '201 Key', 'Room key for 201 Building 3', 3, 'Yes', '2022-01-09 02:19:56'),
(2, '202 Key', 'Use for Room 202', 4, 'Yes', '2022-01-07 16:34:14'),
(3, '203 Key', 'Use for Room 203', 2, 'Yes', '2022-01-07 16:34:22'),
(4, '203 Key', 'Use for Room 205', 6, 'Yes', '2022-01-07 16:35:06'),
(5, '411 Key', 'Use for Room 411', 3, 'Yes', '2022-01-07 16:38:31'),
(6, 'Laptop', 'I5 Intel processor', 1, 'Yes', '2022-01-09 03:23:14'),
(7, 'Projector', 'EPSON brand', 1, 'Yes', '2022-01-09 03:23:42'),
(8, 'Printer', 'Brother brand', 1, 'No', '2022-01-09 03:24:03'),
(9, 'Broom', 'A typical broom', 1, 'No', '2022-01-09 03:24:19'),
(10, '101 Key', 'Key for Room 101', 1, 'Yes', '2022-01-09 03:24:33'),
(11, 'Laptop', 'Asus', 1, 'Yes', '2022-01-09 03:24:41');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `user_id`, `description`, `date_created`) VALUES
(1, 1, 'This is the first log', '2022-01-04 04:51:42'),
(2, 1, 'has approved a user', '2022-01-07 10:58:44'),
(3, 1, 'has change a status of a user', '2022-01-07 10:59:40'),
(4, 1, '201703045 has logged in', '2022-01-07 11:08:57'),
(5, 1, '201703045 has logged in', '2022-01-07 11:10:26'),
(6, 2, 'has logged in', '2022-01-07 11:12:55'),
(7, 1, 'has logged in', '2022-01-07 11:13:50'),
(8, 1, 'has logged out', '2022-01-07 11:14:16'),
(9, 2, 'has logged in', '2022-01-07 11:18:44'),
(10, 2, 'has logged out', '2022-01-07 11:18:46'),
(11, 1, 'has logged in', '2022-01-07 11:18:58'),
(12, 1, 'has change a status of a user', '2022-01-07 11:22:16'),
(13, 1, 'has logged out', '2022-01-07 11:52:23'),
(14, 2, 'has logged in', '2022-01-07 11:52:32'),
(15, 2, 'has logged out', '2022-01-07 11:52:38'),
(16, 1, 'has logged in', '2022-01-07 11:52:44'),
(17, 1, 'has edit a user profile', '2022-01-07 13:44:51'),
(18, 1, 'has edit a user profile', '2022-01-07 13:44:54'),
(19, 1, 'has edit a user profile', '2022-01-07 13:49:20'),
(20, 1, 'has edit a user profile', '2022-01-07 13:49:44'),
(21, 1, 'has edit a user profile', '2022-01-07 13:49:52'),
(22, 1, 'has edit a user profile', '2022-01-07 13:49:55'),
(23, 1, 'has edit a user profile', '2022-01-07 13:50:04'),
(24, 1, 'has edit a user profile', '2022-01-07 13:50:14'),
(25, 1, 'has edit a user profile', '2022-01-07 13:50:17'),
(26, 1, 'has edit a user profile', '2022-01-07 13:50:21'),
(27, 1, 'has edit a user profile', '2022-01-07 13:50:24'),
(28, 1, 'has edit a user profile', '2022-01-07 13:50:27'),
(29, 1, 'has edit a user profile', '2022-01-07 13:50:30'),
(30, 1, 'has edit a user profile', '2022-01-07 13:50:33'),
(31, 1, 'has edit a user profile', '2022-01-07 13:50:36'),
(32, 1, 'has edit a user profile', '2022-01-07 13:50:39'),
(33, 1, 'has edit a user profile', '2022-01-07 13:50:43'),
(34, 1, 'has edit a user profile', '2022-01-07 13:50:46'),
(35, 1, 'has edit a user profile', '2022-01-07 13:50:49'),
(36, 1, 'has edit a user profile', '2022-01-07 13:50:52'),
(37, 1, 'has edit a user profile', '2022-01-07 13:50:55'),
(38, 1, 'has edit a user profile', '2022-01-07 13:50:58'),
(39, 1, 'has edit a user profile', '2022-01-07 13:51:01'),
(40, 1, 'has edit a user profile', '2022-01-07 13:51:04'),
(41, 1, 'has edit a user profile', '2022-01-07 13:51:07'),
(42, 1, 'has edit a user profile', '2022-01-07 13:51:10'),
(43, 1, 'has edit a user profile', '2022-01-07 13:51:14'),
(44, 1, 'has edit a user profile', '2022-01-07 13:51:17'),
(45, 1, 'has edit a user profile', '2022-01-07 13:51:21'),
(46, 1, 'has edit a user profile', '2022-01-07 13:51:25'),
(47, 1, 'has edit a user profile', '2022-01-07 13:51:35'),
(48, 1, 'has approved a user', '2022-01-07 13:52:14'),
(49, 1, 'has edit a user profile', '2022-01-07 13:52:36'),
(50, 1, 'has edit a user profile', '2022-01-07 13:52:37'),
(51, 1, 'has edit a user profile', '2022-01-07 13:53:24'),
(52, 1, 'has edit a user profile', '2022-01-07 13:53:25'),
(53, 1, 'has edit a user profile', '2022-01-07 13:53:31'),
(54, 1, 'has edit a user profile', '2022-01-07 13:54:09'),
(55, 1, 'has edit a user profile', '2022-01-07 13:54:45'),
(56, 1, 'has edit a user profile', '2022-01-07 13:55:01'),
(57, 1, 'has change a status of a user', '2022-01-07 14:00:55'),
(58, 1, 'has approved a user', '2022-01-07 14:01:05'),
(59, 1, 'has edit a user profile', '2022-01-07 14:01:32'),
(60, 1, 'has add a user profile', '2022-01-07 14:27:38'),
(61, 1, 'has add a user profile', '2022-01-07 14:32:21'),
(62, 1, 'has edit a user profile', '2022-01-07 14:32:33'),
(63, 1, 'has add a user profile', '2022-01-07 14:34:00'),
(64, 1, 'has add a user profile', '2022-01-07 14:36:32'),
(65, 1, 'has edit a user profile', '2022-01-07 14:39:22'),
(66, 1, 'has change a status of a user', '2022-01-07 14:39:29'),
(67, 1, 'has add an item', '2022-01-07 15:21:20'),
(68, 1, 'has add an item', '2022-01-07 15:22:41'),
(69, 1, 'has add an item', '2022-01-07 15:23:13'),
(70, 1, 'has edit a user profile', '2022-01-07 15:28:41'),
(71, 1, 'has edit a user profile', '2022-01-07 15:28:52'),
(72, 1, 'has edit a user profile', '2022-01-07 15:31:05'),
(73, 1, 'has edit a user profile', '2022-01-07 15:31:12'),
(74, 1, 'has edit a user profile', '2022-01-07 15:31:43'),
(75, 1, 'has edit a user profile', '2022-01-07 15:31:57'),
(76, 1, 'has edit a user profile', '2022-01-07 15:32:05'),
(77, 1, 'has edit a user profile', '2022-01-07 15:32:26'),
(78, 1, 'has edit a user profile', '2022-01-07 15:32:39'),
(79, 1, 'has edit a user profile', '2022-01-07 15:32:55'),
(80, 1, 'has add an item', '2022-01-07 15:52:36'),
(81, 1, 'has edit an item', '2022-01-07 16:34:14'),
(82, 1, 'has edit an item', '2022-01-07 16:34:22'),
(83, 1, 'has edit an item', '2022-01-07 16:35:06'),
(84, 1, 'has approved a user', '2022-01-07 16:38:06'),
(85, 1, 'has edit an item', '2022-01-07 16:38:17'),
(86, 1, 'has edit an item', '2022-01-07 16:38:31'),
(87, 1, 'has logged in', '2022-01-08 11:53:48'),
(88, 1, 'has logged in', '2022-01-09 00:08:03'),
(89, 1, 'has edit an item', '2022-01-09 02:19:56'),
(90, 1, 'has add an item', '2022-01-09 03:23:14'),
(91, 1, 'has add an item', '2022-01-09 03:23:42'),
(92, 1, 'has add an item', '2022-01-09 03:24:03'),
(93, 1, 'has add an item', '2022-01-09 03:24:19'),
(94, 1, 'has add an item', '2022-01-09 03:24:33'),
(95, 1, 'has add an item', '2022-01-09 03:24:41'),
(96, 1, 'has logged out', '2022-01-09 03:40:37'),
(97, 1, 'has logged in', '2022-01-09 03:40:47'),
(98, 1, 'has borrow an item', '2022-01-09 04:19:37'),
(99, 1, 'has updated profile', '2022-01-09 04:52:29'),
(100, 1, 'has updated profile', '2022-01-09 04:53:51'),
(101, 1, 'has updated profile', '2022-01-09 05:00:04'),
(102, 1, 'has updated profile', '2022-01-09 05:00:08'),
(103, 1, 'has logged out', '2022-01-09 05:27:36'),
(104, 2, 'has logged in', '2022-01-09 05:27:44'),
(105, 2, 'has logged out', '2022-01-09 05:28:04'),
(106, 1, 'has logged in', '2022-01-09 05:28:11'),
(107, 1, 'has logged out', '2022-01-09 05:28:15'),
(108, 2, 'has logged in', '2022-01-09 05:28:25'),
(109, 2, 'has updated profile', '2022-01-09 05:28:42'),
(110, 2, 'has logged out', '2022-01-09 05:28:51'),
(111, 1, 'has logged in', '2022-01-09 05:29:03'),
(112, 1, '3', '2022-01-09 05:46:07'),
(113, 1, '3', '2022-01-09 05:47:00'),
(114, 1, '2', '2022-01-09 05:47:32'),
(115, 1, '1', '2022-01-09 05:47:52'),
(116, 1, '3', '2022-01-09 05:49:00'),
(117, 1, '1', '2022-01-09 05:49:31'),
(118, 1, 'has borrowed an item', '2022-01-09 05:50:20'),
(119, 1, 'has borrowed an item', '2022-01-09 05:50:31'),
(120, 1, 'has returned an item', '2022-01-09 05:53:03'),
(121, 1, 'has change a borrowed status of a user', '2022-01-09 06:32:36'),
(122, 1, 'has borrowed an item', '2022-01-09 06:33:56'),
(123, 1, 'has change a borrowed status of a user', '2022-01-09 06:58:24'),
(124, 1, 'has change a borrowed status of a user', '2022-01-09 06:58:47'),
(125, 1, 'has logged out', '2022-01-09 07:04:04'),
(126, 2, 'has logged in', '2022-01-09 07:04:13'),
(127, 2, 'has borrowed an item', '2022-01-09 07:04:19'),
(128, 2, 'has returned an item', '2022-01-09 07:04:26'),
(129, 2, 'has logged out', '2022-01-09 07:04:32'),
(130, 1, 'has logged in', '2022-01-09 07:04:39'),
(131, 1, 'has change a borrowed status of a user', '2022-01-09 07:04:54'),
(132, 1, 'has logged out', '2022-01-09 07:05:27'),
(133, 2, 'has logged in', '2022-01-09 07:05:34'),
(134, 2, 'has borrowed an item', '2022-01-09 07:05:50'),
(135, 2, 'has logged out', '2022-01-09 07:08:15'),
(136, 1, 'has logged in', '2022-01-09 07:08:38'),
(137, 1, 'has change a borrowed status of a user', '2022-01-09 07:08:48'),
(138, 1, 'has logged out', '2022-01-09 07:08:51'),
(139, 2, 'has logged in', '2022-01-09 07:08:57'),
(140, 2, 'has returned an item', '2022-01-09 07:09:08'),
(141, 2, 'has logged out', '2022-01-09 07:09:12'),
(142, 1, 'has logged in', '2022-01-09 07:09:18'),
(143, 1, 'has change a borrowed status of a user', '2022-01-09 07:09:24'),
(144, 1, 'has logged out', '2022-01-09 07:10:55'),
(145, 2, 'has logged in', '2022-01-09 07:11:03'),
(146, 2, 'has logged out', '2022-01-09 07:25:46'),
(147, 1, 'has logged in', '2022-01-09 07:26:32');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `is_status` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `user_id`, `item_id`, `is_status`, `date_created`) VALUES
(1, 1, 8, 'Received', '2022-01-09 06:58:24'),
(2, 1, 6, 'Received', '2022-01-09 06:58:47'),
(3, 1, 9, 'Returned', '2022-01-09 05:49:00'),
(5, 1, 2, 'Pending', '2022-01-09 05:50:20'),
(6, 1, 11, 'Received', '2022-01-09 06:32:36'),
(7, 1, 10, 'Pending', '2022-01-09 06:33:56'),
(8, 2, 7, 'Received', '2022-01-09 07:04:54'),
(9, 2, 1, 'Received', '2022-01-09 07:09:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `is_admin` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `student_id` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email_add` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `is_admin`, `is_active`, `username`, `student_id`, `password`, `first_name`, `last_name`, `email_add`, `contact_no`, `date_created`, `date_updated`) VALUES
(1, 1, 1, 'my_admin', 201703045, 'f5bb0c8de146c67b44babbf4e6584cc0', 'Admin', 'Account', 'sample@gmail.com', '09123121231', '2021-12-28 07:32:00', '2022-01-09 05:00:08'),
(2, 0, 1, 'darius', 201702045, 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Demo', 'Profile', 'sample1@gmail.com', '09123456789', '2021-12-29 09:21:25', '2022-01-09 05:28:42'),
(3, 0, 1, '', 201702003, 'f5bb0c8de146c67b44babbf4e6584cc0', 'Sample', 'Account', 'sample@cvsu.edu.ph', '09321321321', '2022-01-04 08:27:23', '2022-01-07 15:32:39'),
(4, 0, 1, '', 201702022, 'f5bb0c8de146c67b44babbf4e6584cc0', 'Sample edit', 'Edit', 'x@hotmail.com', '09123123123', '2022-01-05 10:33:10', '2022-01-07 15:32:55'),
(5, 0, 0, '', 201502444, 'f5bb0c8de146c67b44babbf4e6584cc0', 'Dar', 'Wix', 'sample@gmail.com', '09635412456', '2022-01-07 14:27:38', '2022-01-07 15:31:05'),
(6, 0, 1, '', 201101001, 'f5bb0c8de146c67b44babbf4e6584cc0', 'Kim', 'Sample', 'sample@gmail.com', '09456873456', '2022-01-07 14:32:21', '2022-01-07 16:38:06'),
(7, 0, 1, '', 201103100, '934b535800b1cba8f96a5d72f72f1611', 'Sample', 'Account', 'sample@gmail.com', '09123123123', '2022-01-07 14:34:00', '2022-01-07 15:31:43'),
(8, 0, 0, '', 201302344, '6734d831b05187c6a73756786ed62a20', 'Pipoy', 'Lam', 'asdasda@gmail.com', '09121213333', '2022-01-07 14:36:32', '2022-01-07 15:32:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
